# Arithmetic-Operator Research Roadmap for the RiemannGaussian Project

## Purpose

This roadmap turns the current operator-interaction map into an iterative research program for the Lean agent.

The guiding hypothesis is that a successful RH architecture may need to keep several structures of the integers coupled **simultaneously**, rather than repeatedly converting everything into a one-variable weighted prime sum.

The central structures are:

- additive translation / finite differences;
- multiplicative dilation;
- cutoff / initial-segment order;
- divisor incidence and Dirichlet convolution;
- valuations \(v_p\);
- quotient-remainder / floor structure;
- modular-additive Fourier / Ramanujan operators;
- GCD / LCM kernels;
- factorial-binomial / Gamma-Kummer operators.

The scores below are **heuristic research-priority scores**, not claims about the literature:

- **4** — especially underexplored / high-priority
- **3** — underexplored
- **2** — moderately explored
- **1** — well-developed
- **0** — diagonal / not an interaction

The project should prioritize interactions that satisfy all three of the following:

1. **Arithmetic specificity** — the mechanism genuinely uses the ordinary integers/primes and fails for smooth-density or generalized-prime controls.
2. **Source sensitivity** — a hypothetical zeta zero produces a provably nonzero response.
3. **Non-collapse** — after all exact identities are joined, the mechanism still imposes more than an arbitrary scalar test
   \[
   \sum_n \Lambda(n) w(n).
   \]

A branch which fails one of those tests should be closed with the strongest exact no-go theorem available and then abandoned.

---

# Global iteration protocol

Every research branch should follow the same six-stage protocol.

## Stage 1 — Exact finite operator identity

Define the operator interaction on finite integer data and prove its exact identity in Lean.

Requirements:

- retain all prime powers;
- retain endpoint/floor conventions exactly;
- do not replace integer cutoffs by continuous approximations;
- keep additive, multiplicative and order structure visible.

Output:

- one or more exact Lean identities;
- a short markdown note explaining the operator meaning.

## Stage 2 — Source-response preflight

Feed in the diagnostic zero component
\[
\psi(x)-x=-\frac{m}{\rho}x^\rho
\]
or the corresponding logarithmic derivative / Mellin mode.

Determine exactly whether the proposed operator sees the mode.

**Pass condition:** the matched zero produces a nonzero response at the expected source scale.

**Fail condition:** the operator annihilates the zero, typically through a factor of \(\zeta(\rho)\), a symmetry, or an exact source-conservation identity.

If it fails, stop and record the no-go.

## Stage 3 — Pole / density separation

Determine the response to the continuous density/pole mode and, if needed, construct an exact finite combination that cancels it without cancelling the zero mode.

Pass only if the pole can be removed **without** introducing an equally large compensating source.

## Stage 4 — Collapse audit

Join the entire finite arithmetic expression before estimating.

Ask:

> Does the final object still contain a genuinely collective arithmetic constraint, or has it become an arbitrary scalar twisted Chebyshev / von Mangoldt test?

Tests:

- replace \(\Lambda\) by arbitrary weights \(w(n)\);
- test delta weights;
- test generalized-prime / smooth-density controls;
- test whether all matrix/reindexing identities remain valid for arbitrary weights.

If all structure survives arbitrary weights, the arithmetic content has collapsed and the branch should be frozen.

## Stage 5 — Independent arithmetic estimate

Only after Stages 1–4 pass should the agent search for inequalities.

The estimate must be obtained **after joining all correlated rows/terms**.

Reject:

- componentwise norm payment;
- rowwise SBP allowances;
- generic GCD bounds that lose the source scale;
- PNT-scale envelopes that are weaker than the hypothetical zero source;
- finite numerical evidence used as an asymptotic theorem.

## Stage 6 — Endpoint transfer

Connect the new inequality to one of the already-proved conditional endpoints:

- strip-wide prime-moment non-coherence;
- Suzuki subexponential signed lower bound;
- complete Gaussian/Weil reflected correlation vanishing;
- another already-checked RH-equivalent criterion.

A branch counts as true RH progress only when it discharges a previously open arithmetic premise rather than creating another equivalent reformulation.

---

# Priority Tier 1 — Highest-value interactions

## 1. Cutoff \(P_N\) × Divisor incidence / Dirichlet convolution

**Priority score: 4**

### Why this is promising

The cutoff operator
\[
P_Nf=\sum_{n\le N}f(n)
\]
is additive/order-theoretic, while divisor convolution is multiplicative.

Their interaction creates exact floor terms:
\[
\sum_{n\le N}\sum_{d\mid n}f(d)
=
\sum_{d\le N}\left\lfloor\frac Nd\right\rfloor f(d).
\]

This is the basic source of the successful integer-carry identities.

### First experiments

1. Study commutators between cutoff and divisor convolution:
   \[
   P_N(f*g)-(\text{appropriate truncated convolution of }P_Nf,P_Ng).
   \]
2. Form mixed second differences in \(N\) before collapsing divisor sums.
3. Search for matrix-valued rather than scalar cutoff identities.
4. Test whether exact Möbius inversion across several cutoffs creates a collective constraint not valid for arbitrary weights.

### Success criterion

An exact matrix or multilinear identity that:

- depends essentially on divisor incidence and cutoff geometry;
- remains source-sensitive;
- does not reduce to one scalar kernel against \(\Lambda\).

### Early rejection test

If arbitrary weights satisfy the same joined identity with no additional arithmetic restriction, freeze this branch.

---

## 2. Cutoff \(P_N\) × Valuations \(v_p\)

**Priority score: 4**

### Why this is promising

Valuations linearize multiplication:
\[
v_p(ab)=v_p(a)+v_p(b),
\]
while cutoffs encode the ordinary order of integers.

Legendre's formula
\[
v_p(N!)=\sum_{r\ge1}\left\lfloor\frac{N}{p^r}\right\rfloor
\]
already couples them exactly.

### First experiments

1. Formalize valuation vectors of cutoff products:
   \[
   N!\mapsto (v_p(N!))_p.
   \]
2. Study mixed covariance matrices of \(v_p(N!)\) across nearby/multiple scales.
3. Compare Archimedean \(\log(N!)\) with the complete valuation vector using
   \[
   \log(N!)=\sum_p v_p(N!)\log p.
   \]
4. Introduce Kummer carry counts for binomial/multinomial coefficients.

### Success criterion

A PSD or signed matrix inequality involving several scales whose proof uses both:

- exact valuation/carry compatibility; and
- Archimedean factorial/Gamma structure.

### Best candidate

The Kummer–Gamma mixed-Hessian branch already suggested:
\[
\log\binom{(a+b)N}{aN}
\]
and its mixed discrete Hessian.

---

## 3. Cutoff \(P_N\) × Modular-additive Fourier / Ramanujan

**Priority score: 4**

### Why this is promising

This interaction keeps exact finite intervals and additive characters together:
\[
\sum_{n\le N} a_n e^{2\pi i hn/q}.
\]

Ramanujan sums also encode divisibility:
\[
c_q(n)=\sum_{d\mid(q,n)} d\,\mu(q/d).
\]

So this branch can potentially couple:

- additive Fourier structure;
- exact integer cutoffs;
- gcd/divisibility;
- Möbius inversion.

### First experiments

1. Define cutoff Ramanujan transforms of \(\Lambda\), \(\mu\), and divisor-incidence profiles.
2. Build finite Gram matrices across moduli and cutoff scales.
3. Search for exact orthogonality/correlation identities surviving prime-power weights.
4. Compare the resulting matrices with Gaussian/Weil kernels.

### Source preflight

Evaluate the response of a component \(x^\rho\) after the appropriate height matching.

### Rejection test

If all structure becomes a standard finite Fourier transform of an arbitrary sequence, identify what extra literal-prime constraint is still present; if none, stop.

---

## 4. Cutoff \(P_N\) × GCD / LCM kernels

**Priority score: 4**

### Why this is promising

GCD is the natural correlation operation of the divisibility lattice.

Kernels such as
\[
K(m,n)=F(\gcd(m,n))
\]
often admit exact factorisations through divisor incidence matrices.

Combining them with cutoffs could produce finite PSD constraints that ordinary Dirichlet-series methods do not expose.

### First experiments

1. Build finite cutoff GCD matrices with entries
   \[
   \sum_{d\mid\gcd(m,n)} w(d).
   \]
2. Specialize \(w=\Lambda,\mu,\phi\), and prime-power weights.
3. Study mixed cutoff differences of these matrices.
4. Test Schur products with additive Gaussian Toeplitz matrices.

### Success criterion

A matrix inequality whose admissible kernels are genuinely restricted by integer gcd geometry, rather than arbitrary scalar weights.

---

## 5. Divisor incidence / Dirichlet convolution × Floor / quotient-remainder

**Priority score: 4**

### Why this is promising

This is the algebraic heart of the factorial/carry identity:
\[
\sum_d\left\lfloor\frac Nd\right\rfloor\Lambda(d)=\log(N!).
\]

But the branch should now be developed as an **operator algebra**, not as isolated summation tricks.

### First experiments

1. Define quotient-profile operators
   \[
   Q_N(d)=\left\lfloor\frac Nd\right\rfloor.
   \]
2. Study their convolution, finite differences, and Gram matrices.
3. Classify exact finite-dimensional identities generated by \(Q_N\).
4. Search for identities involving several \(N\)'s which are not linear in the arithmetic weight.

### Rejection test

The recent carry collapse showed that linear/quadratic reindexing can collapse to a scalar \(\Lambda\)-test. Explicitly check for this immediately.

---

## 6. Floor / quotient-remainder × Modular-additive Fourier / Ramanujan

**Priority score: 4**

### Why this is promising

Euclidean division gives
\[
n=qd+r,\qquad 0\le r<d,
\]
while finite Fourier analysis sees the residue \(r\).

This is a genuinely natural interaction between order and congruence.

### First experiments

1. Fourier-expand quotient/remainder profiles in the residue variable.
2. Study correlations of floor jumps with Ramanujan sums.
3. Build phase-coded floor matrices indexed by both scale and modulus.
4. Look for exact cancellation identities that fail for smooth models.

### Source preflight

Check whether the zero-mode response survives modular averaging.

---

## 7. Floor / quotient-remainder × GCD / LCM kernels

**Priority score: 4**

### Why this is promising

This interaction combines Euclidean division with divisibility correlation.

The recent carry work already produced exact gcd formulas from floor increments; this branch should ask whether a **larger matrix geometry** survives where the scalar carry route collapsed.

### First experiments

1. Use several independent quotient profiles, not one Fejér packet.
2. Form matrix-valued gcd identities before choosing coefficients.
3. Search for rank constraints, total positivity, or PSD structure.
4. Test whether the final matrix identity holds for arbitrary denominator weights.

If it does, stop.

---

## 8. Modular-additive Fourier / Ramanujan × Factorial-binomial / Gamma-Kummer

**Priority score: 4**

### Why this is promising

This is probably the least conventional top-tier interaction.

Kummer carries encode prime-power valuations of binomial coefficients:
\[
v_p\binom{a+b}{a}.
\]

Modular Fourier analysis can resolve carry/congruence classes before summing over \(p\).

The Archimedean side is controlled by Gamma.

### First experiments

1. Fourier-analyze Kummer carry counts in \(a,b\) modulo small moduli.
2. Form exact matrices of binomial/Gamma second differences with modular phases.
3. Search for PSD kernels after summing over prime powers.
4. Test scale Mellin transforms for zero sensitivity.

### Strong success condition

A kernel simultaneously carrying:

- Kummer prime-power data;
- modular additive characters;
- Gamma convexity / positivity;
- nonzero zeta-zero response.

---

# Priority Tier 2 — Strong secondary directions

## 9. Shift / finite difference × Divisor convolution

**Score: 3**

Study commutators
\[
\Delta(f*g)-(\Delta f)*g-f*(\Delta g)
\]
and exact divisor-boundary corrections.

Main question: does successor arithmetic expose something not available from smooth convolution?

---

## 10. Shift / finite difference × Valuations

**Score: 3**

Study
\[
v_p(n+1)-v_p(n)
\]
and higher correlations.

This directly measures incompatibility between additive successor and multiplicative structure.

Potentially useful through matrix correlations rather than pointwise estimates.

---

## 11. Shift / finite difference × GCD / LCM

**Score: 3**

Examples:
\[
\gcd(n+h,m+h)-\gcd(n,m).
\]

Look for finite PSD/correlation identities over \(h\), not isolated average-order theorems.

---

## 12. Dilation × Cutoff

**Score: 3**

Study operator commutators between
\[
(D_qf)(n)=f(qn)
\]
and cutoff.

This reproduces floor effects but may be richer in matrix form across many \(q\)'s.

---

## 13. Dilation × Floor / quotient-remainder

**Score: 3**

Classify exact identities for
\[
\left\lfloor\frac{qN}{d}\right\rfloor
-
q\left\lfloor\frac Nd\right\rfloor.
\]

Look for multi-dilation Gram matrices and source-sensitive scale Mellin transforms.

---

## 14. Dilation × Modular Fourier / Ramanujan

**Score: 3**

This is the finite-adelic interaction between multiplication and additive characters.

Possible connection to Hecke-style operators should be checked before claiming novelty.

---

## 15. Dilation × GCD / LCM

**Score: 3**

Study how gcd kernels transform under common/noncommon dilation.

Potentially useful for exact spectral scaling.

---

## 16. Dilation × Gamma-Kummer

**Score: 3**

Study binomial/multinomial coefficients under scale multiplication.

Potentially useful in the scale-Mellin architecture.

---

## 17. Divisor convolution × Gamma-Kummer

**Score: 3**

Search for convolution identities inside factorial/binomial valuation expansions.

Could connect Selberg-type convolution to Gamma convexity without losing integer cutoffs.

---

## 18. GCD / LCM × Gamma-Kummer

**Score: 3**

Form factorial/binomial matrices indexed by divisibility lattices and test PSD/spectral structure.

---

# Priority Tier 3 — Mostly classical but useful as infrastructure

These interactions are important but should not consume research time unless needed by a Tier 1/2 branch.

## Divisor convolution × valuations

**Score: 1**

Highly classical; use as infrastructure.

## Valuations × GCD/LCM

**Score: 1**

Essentially min/max calculus in valuation coordinates.

## Valuations × Gamma-Kummer

**Score: 1**

Classical Legendre/Kummer territory; useful foundation rather than likely source of novelty by itself.

## Shift × dilation

**Score: 2**

Classical affine-semigroup interaction.

## Shift × cutoff

**Score: 2**

Standard finite-difference boundary calculus.

## Modular Fourier × GCD

**Score: 2**

Ramanujan sums already connect these strongly; novelty would need another operator layered on top.

---

# Recommended branch order

The agent should iterate in this order unless a branch produces a clearly stronger lead.

## Phase A — Kummer / Gamma / cutoff geometry

1. Cutoff × valuations.
2. Gamma-Kummer mixed Hessian.
3. Gaussian Schur-product coupling.
4. Scale-Mellin zero-response audit.
5. Collapse audit.

This is the currently preferred new architecture.

## Phase B — Modular quotient geometry

1. Floor × modular Fourier.
2. Cutoff × Ramanujan.
3. Add divisor incidence.
4. Search for matrix constraints that survive arbitrary-weight tests.

## Phase C — GCD matrix geometry

1. Cutoff × GCD/LCM.
2. Floor × GCD/LCM.
3. Add Gaussian Toeplitz kernels.
4. Test collective PSD / spectral inequalities.

## Phase D — Operator commutators

1. cutoff–dilation;
2. cutoff–convolution;
3. shift–valuation;
4. shift–convolution.

The target is an exact noncommutativity invariant with a nonzero zero-mode response.

---

# Research scorecard

For every branch, maintain a small table:

| Criterion | Status |
|---|---|
| Exact Lean identity | open / passed / failed |
| Uses literal integer structure | open / passed / failed |
| Zero-mode response nonzero | open / passed / failed |
| Pole/density controllable | open / passed / failed |
| Survives arbitrary-weight collapse test | open / passed / failed |
| Independent signed arithmetic estimate | open / passed / failed |
| Transfers to existing RH endpoint | open / passed / failed |

A branch with two structural failures should be frozen immediately.

---

# Shared countermodels and rejection controls

Every new mechanism should be tested against:

1. **Smooth positive coherent density** models already used in the Riesz audits.
2. **Generalized-prime / Beurling systems** with prescribed zeros.
3. **Arbitrary denominator weights** in any matrix/reindexing identity.
4. **Synthetic off-axis modes** in the Gaussian/Suzuki framework.
5. **Constant/coherent moment sequences** where relevant.
6. **Finite phase recurrence** counterexamples.

A mechanism is interesting only if it excludes at least one of these for an arithmetic reason that the actual primes satisfy.

---

# Lean engineering policy

## Build small leaf modules

Each branch should start with a new isolated module and scoped check script.

## Prove exact identities before inequalities

No asymptotic or numerical work should precede exact source and collapse audits.

## Preserve signs and correlations

Do not split a joined quadratic/matrix into positive capacities unless that split is itself justified at source scale.

## Record no-go theorems

A failed branch should leave behind a theorem explaining the obstruction, not only a markdown note.

## Numerical probes are diagnostics only

Use them to choose conjectures, exceptional cases and rational constants, never as proof dependencies.

---

# Milestone definition

The next truly meaningful project milestone is **not another RH-equivalent reformulation**.

It is one of:

1. an unconditional arithmetic inequality that discharges an existing RH endpoint;
2. a new matrix/Gram positivity theorem for the actual primes that excludes an off-line zero mode;
3. a source-sensitive operator interaction that provably cannot be reproduced by the current smooth/generalized-prime controls and yields a quantitatively stronger constraint than current zero-free-region machinery.

---

# Long-horizon completion objective

The long-horizon objective for the agent is:

> **Systematically search the arithmetic-operator interaction space until either (a) one operator architecture yields an unconditional source-sensitive arithmetic estimate strong enough to discharge an existing Lean-checked RH criterion, or (b) every high-priority interaction is reduced to a formally proved structural obstruction/collapse theorem.**
>
> For each branch, require exact finite identities, zero-mode sensitivity, pole separation, arbitrary-weight/generalized-prime collapse audits, and only then quantitative estimates. Never count a new carrier, transform, determinant, or equivalent criterion as progress by itself. The preferred success endpoint is a theorem that combines ordinary integer addition, prime-power multiplication/divisibility, cutoff/order geometry, and Archimedean/Gaussian structure in one final signed or PSD inequality and from it proves either the Suzuki subexponential lower bound, the Gaussian/Weil vanishing condition, or strip-wide prime-moment non-coherence. If a branch collapses to an arbitrary twisted \(\Lambda\)-sum or requires a theorem equivalent in strength to the desired zero-free region, record the exact no-go and move to the next ranked operator interaction without reopening it.

