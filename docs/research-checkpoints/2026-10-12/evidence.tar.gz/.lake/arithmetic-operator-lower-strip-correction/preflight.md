# Genuine angular correction at the lower strip

This is a read-only source/API gate. No new Lean theorem, lower-strip
nonvanishing, native cutoff estimate or family no-go is asserted.

## Exact existing extraction and its direction

`QuasiRHPrincipalEulerAudit.actual_R_eq_angular_character` identifies
the actual principal local ratio as

    R_P(s) = a_eta(P) Norm(P)^(-(6s-3)),
    a_eta(I) = conjugate(angularFactor(primaryGenerator I))^6
               * elementCoeff eta (primaryGenerator I)^6.

Both actual phases remain. At w=1,z=1/6 the other coordinates are
q=Norm(P)^(-1), D=elementCoeff eta(primaryP) Norm(P)^(-s).
The residual is exactly

    g_P(s) = (1-q^2) * (1-q*(R_P(s)-D_P(s))/(1-D_P(s))).

The existing `correction_factorization`, proved for Re(s)>2/3, says

    residualCorrection(s)
      = product_P(1-a_eta(P) Norm(P)^(-(6s-3)))
        * principalCorrection(s).

Consequently, if the genuine angular Euler series is denoted by
L_ang(v) in its convergent half-plane, the direction is

    principalCorrection(s) = residualCorrection(s) * L_ang(6s-3).

It is multiplication by angular L, not division. A zero of angular L
can therefore cancel the reciprocal finite-ray L source. Holomorphic
continuation alone would not pass the nonzero source gate.

## Radial and coordinate normalization

`FiniteGaussPhase.angularFactor z` is the actual embedding divided by
its complex norm. For a nonzero native primary ideal generator z,
`CompletedGauss.primaryGenerator_norm_sq` identifies |embedding z|^2
with Norm(I). Thus on admissible ideals the exact algebraic angular
factor has the form

    a_eta(I) = conjugate(embedding z)^6 * elementCoeff eta(z)^6
               / Norm(I)^3.

After multiplication by Norm(I)^(-(6s-3)), its radial form is

    conjugate(embedding z)^6 * elementCoeff eta(z)^6 / Norm(I)^(6s).

The normalized spectral variable is v=6s-3. This is not the finite
character eta^6 evaluated at 6s: the nonconstant angular numerator
is essential. The sixth power removes unit ambiguity but not the
infinite-type angular dependence. Modulus/ramified exclusions and
zero primary generators remain the same as in the actual product.

## What is already available and what is not

`exists_residual_cutoff` already gives analytic residualCorrection
and norm(residualCorrection-1)<=1/2 on every fixed Re(s)>sigma>1/2,
after the explicit finite small-prime cutoff. Its summable defect
exponent is min(2,6sigma-2,sigma+1)>1. The residual can therefore be
made nonzero at any selected point in this half-plane without
granting anything about the angular factor.

`exists_extended_principal_cutoff` gives the original principal
correction analytic and close to one only for sigma>2/3. The angular
Euler exponent 6sigma-3 must exceed one for its current summability
argument. In the unresolved interval 1/2<Re(s)<=2/3 the transformed
angular real part lies in (0,1], exactly outside this Euler argument.

`HeckeFamily.Character` in `Hecke/Family.lean` consists of an ideal
modulus, a residue MulChar, unit triviality, and a positive finite
period with period_mem. There is no infinity-type field. Its
`elementCoeff_add_period_mul` proves actual coordinate periodicity.
`Hecke/Theta.lean` constructs a degree-zero periodic Gaussian theta
pair with k=1; `Hecke/IdealBridge.lean` continues precisely that
finite coefficient. No inspected API identifies the extracted
angular coefficient with such a character or provides the required
degree-six harmonic-theta analytic continuation.

The imported public >7/8 theorem is for Dirichlet L-functions and
zeta; internal Hecke APIs also use this finite-ray Character type.
None may be silently applied to the angular correction. Even a
hypothetical applicable >7/8 theorem at v would only directly give
Re(s)>31/48, not the full interval down to 1/2. No such application
is made here. The parent's separate leaf tests actual nonperiodicity;
this note does not duplicate it or promote absence of an API to a
mathematical impossibility theorem.

## Exact missing cancellation/source condition

The actual principal source includes principalCorrection(s)/L_eta(s),
times its Gaussian/profile/slot factors. Suppose a genuine continued
angular L has been constructed and the selected finite-ray L has
analytic zero order m at rho. Let n be the order of the angular L
at 6rho-3. The affine substitution has nonzero derivative six, so it
preserves n. At a point with the residual and other displayed factors
nonzero, the remaining quotient has order n-m:

* n<m: a reciprocal pole survives;
* n=m: the supposed source pole is removable;
* n>m: the numerator suppresses it further.

This is a local analytic-order preflight, not a newly checked source
theorem. In particular the useful condition is n<m, or the stronger
nonvanishing n=0. It cannot be replaced by mere analyticity. A pole
of a hypothetical meromorphic angular continuation would strengthen
rather than cancel the reciprocal source, but no such pole is assumed
or imported. Local finite excluded Euler factors are nonzero whenever
their normalized real exponents are positive; they do not license
an infinite product estimate at Re(v)<=1.

No inspected actual theorem relates zeros of the finite-ray L_eta at
rho to zeros of its angular-six twist at 6rho-3. No equality of
finite/infinite types, rightmost hypothesis, generic zero separation,
or independent source estimate is added. The missing input is an
actual angular continuation bridge followed by a source-sensitive
joint zero/cancellation statement on that specific pair of functions.

## Useful native APIs for the separate nonperiodicity gate

* `FiniteGaussPhase.angularFactor`: PrimeRows/ActiveGaussFactorization:488.
* `ConcreteTraceCRT.eisEmbedding_injective`: Arithmetic/EisensteinEmbedding:155.
* `ActualEisensteinCubic.eisEmbedding_eval`: GaussSum/QuadraticTrace:217.
* `ActualEisensteinCubic.eisEmbedding_norm_sq_eq_absNorm_span`:
  GaussSum/SexticRadialPoisson:597.
* `CompletedGauss.primaryGenerator_span`: Arithmetic/IdealMobius:303.
* `CompletedGauss.primaryGenerator_norm_sq`: Arithmetic/IdealMobius:321.
* `ActualEisensteinCubic.lambda_sq_dvd_three`, used in Hecke/RowClosure:119.
* `HeckeFamily.elementCoeff_add_period_mul`: Hecke/Family:72.

These allow a primary test element 1+3*period_eta*period_proxy*omega,
whose finite residue coefficients equal those at one, while retaining
its actual angular sixth power. No finite matching-period or common
scalar-centering result has been repeated.
