# Independent mathematical review of the angular-period gate

Read-only review of `scripts/QuasiRHAngularPeriodAudit.lean`; no root
leaf edit, new carrier, compensator theorem or arithmetic bound.

## Separating element: pass, with the stated scope

The proof uses the literal native element

    z = 1 + 3*period_eta*period_psi*omega.

Both finite residue coefficients equal one by their actual period
identities. The element is primary because lambda^2 divides three.
Its embedding has the form 1+b*omega3 with b>=3. The imaginary part
of its sixth power has nonzero coefficient

    3*b*(1-b)*(1+b)*(2-b)*(1-2*b) * Im(omega3).

Every displayed factor is nonzero for b>=3. This also proves z!=0.
If the conjugated normalized angular sixth power were one, applying
conjugation and clearing the nonzero real norm would make the sixth
embedding power real, contradicting this exact imaginary part. Thus
actualAPhase eta(z) differs from the proxy's finite residue value one.

The primary-generator theorem then transfers this very element to
the actual nonzero principal ideal (z), while idealCoeff_span gives
the proxy's value. The witness has residue one for both moduli, so
it is not exploiting a bad-prime/support zero. The concluded absence
of coefficient equality with ANY finite-ray character is correct.

It blocks direct use of the finite-ray nonvanishing theorem by
identifying the angular ideal coefficient with idealCoeff psi. It
does not prove absence of an independent infinity-type continuation,
functional equation, zero-order theorem, a different L-function
comparison, or an accidental norm-fiber series identity. Those require
their own bridges. The leaf states this narrower scope correctly.

## Finite multiplicative compensators do not remove angular zeros

Let G(s)=L_ang(6s-3), assuming its genuine continuation has first
been constructed, and let R be the existing nonzero residual.
The exact principal source factor is R(s)G(s)/L_eta(s).

A finite prime deletion/restoration changes G only by a finite product
of factors 1-a(P)Norm(P)^(-(6s-3)) or their reciprocals. On the strict
core Re(s)>1/2, Re(6s-3)>0 and the actual |a(P)|<=1, so every such
factor is nonzero. This finite compensator is an analytic unit there.
It preserves each angular zero order exactly. It cannot rescue a
source canceled by an angular zero of at least the finite-ray order.

More generally any holomorphic multiplier E can only preserve or
increase G's zero order. To lower it multiplicatively would require
a pole in E at that same zero. Such a pole is additional spectral
data and cannot be supplied by the preceding finite Euler factors.
Using 1/G is the infinite angular inverse, not a finite correction;
its singularity at the angular zero must be accounted for arithmetically.

## Other finite operations: exact source accounting, not a free bound

Adding a finite correction E replaces the quotient by

    (R*G+E)/L_eta = (R*G)/L_eta + E/L_eta.

If E(rho)!=0 it can restore the reciprocal source, but the complete
new source is in the added term E/L_eta. An independent estimate for
that literal added arithmetic term is needed; no bound on the old
source-free quotient transfers to it.

Selective numerator differentiation can also restore a canceled
source in principle. For the simplest case, put H=R*G. The exact
meromorphic identity away from the divisor is

    H'/L_eta = (H/L_eta)' + H*L_eta'/L_eta^2.

When the old H/L_eta is regular, differentiating the WHOLE quotient
keeps it regular. Any pole restored by H'/L_eta sits in the explicit
cross term H*L_eta'/L_eta^2. Higher finite jets have the analogous
Leibniz cross terms. They are not paid by regularity of the old
quotient or by the existing native estimate. A genuinely independent
row parameter could differentiate the numerator alone, but its exact
native operator/source and joint signed estimate would have to be
proved; this review does not forbid that different mechanism.

Thus the present separating-element theorem and finite-unit correction
gate are sound. The remaining source gap is actual joint information
about the finite-ray divisor and its angular-six divisor, or a genuinely
new source-preserving arithmetic operator with an independent estimate.
No theorem declaring all compensators or all angular methods impossible
is justified by this review.
