# Calibrated complete-row cuspidal-input gate

Read-only preflight, 2026-10-08. No new Lean theorem, proof execution, or arithmetic estimate is claimed.

## Exact positive statement already checked

`Detector/CalibrationCRT.lean:98`, `calibration_mixed_fourier_zero`, proves vanishing of the complete joined numerator Fourier coefficient at every frequency H not coprime to the calibration generator, under the stated native CRT coprimality hypothesis. In particular it kills H=0 for a nontrivial calibration modulus. `Detector/CalibrationRemoval.lean:45`, `actualPhysicalFourier_calibration_factor`, retains the exact calibration factor `star(C.residueMonoid H)` and the bare physical Fourier coefficient, with native ideal/Gauss factors and all phase information.

This is a finite quotient Fourier statement in the numerator variable. It is not a constant-term theorem for an automorphic function at all cusps. No inference from one to the other is licensed by these identities.

## Actual inverse-row bridge that must be retained

`Detector/LowCompensation.lean:15`, `lowMarkedInverseRow`, is a finite ray-character combination of `InverseMoment.markedCompletedT` with actual base

```
rowTwist (physicalRayPeriodicBase eta S hS sigma chi)
  (calibrationForSet S hS).generator 1 m
```

and the native divisor mark `D | A`. `Detector/LowSelectedSum.lean:46` and its correction theorem retain the prescribed slot coefficients and sum every selected divisor mark, with the same numerator-dependent twist. A fixed-base approximation is not supplied.

`GaussSum/FiniteTranslations.lean:522`, `fixedThetaTwist_infinity_coefficient`, is the exact normalized residual Fourier-coefficient bridge for native I*J^3 labels. `Eisenstein/FixedThetaTwists.lean` supplies finite quotient inversion for the actual fixed twist. `GaussSum/ResidualEquivalence.lean:333`, `fixedActiveCusp_fourier_multiplier`, packages those coefficients into prescribed translated active-cusp data. These establish the actual coefficient/translation expansion; they do not assert all cusp constant terms vanish for its joined automorphic realization.

## Existing all-cusp positive APIs are for a different operator

There is a genuinely stronger checked all-cusp identity already available:

`Eisenstein/CubeEigenrelation.lean:217`, `cubeSourceDifference_cusp_average_zero`, holds for every `M : SL(2,O)` and gives zero average of the actual cube-average residual difference over its enlarged period. `Eisenstein/ResidualOrthogonality.lean` proves the associated uniform all-cusp decay.

The operator is exactly

```
cubeSourceDifference p = cubeAverage p cubicSourceResidualFunction
  - Norm(p)^(-1) * cubicSourceResidualFunction.
```

It is not the calibration character twist or the marked inverse row. Identifying the latter with this difference (or a prescribed family of such differences), retaining marks and numerator dependence and then checking the actual hypothetical-zero source, is a separate unresolved gate. No source is assumed retained by this replacement.

`Eisenstein/SourceCuspKernels.lean:116`, `sourceCuspZFamily_series`, and `sourceCuspZTerm_zero` retain the cusp-local horizontal derivatives, with frequency zero absent for each of the three original representatives. `ReflectedCuspMellin.lean` supplies corresponding derivative decay. These locally differentiated cusp profiles are not already identified with one fixed cuspidal automorphic form of the required weight/level and the native inverse coefficients; derivatives also alter the coefficient multiplier.

## Exact remaining applicability condition

One must construct a full joined automorphic function (or a rigorously controlled fixed finite family) whose native I*J^3 coefficients reproduce the actual calibrated `lowSelectedInverseRow`, including all slot/divisibility masks and every complex phase. At its actual level, prove

```
for every cusp c and every height v>0,
  integral over the actual cusp period lattice of F(c.(z,v)) dz = 0.
```

The original three cusp representatives need not exhaust the cusps at the enlarged finite-twist level. Every transformed constant term must be evaluated with its own cusp reduction, character/Kubota multiplier and height scale. Vanishing of the complete numerator H=0 coefficient does not evaluate those terms. Even all-cusp zero averages would still need the other cuspidal-form hypotheses and coefficient normalization of a cited estimate.

Finally prove that this exact joined cusp removal preserves a nonzero target-zero principal term; if a remainder is necessary, compute its source rather than assuming it negligible. A projection that kills the whole residual signal would not pass the source gate.

## Verdict and scope

The inspected APIs prove complete numerator-frequency cancellation, exact native coefficient/finite-translation bridges, and an all-cusp identity for the distinct cube-difference operator. They do not presently prove calibration-specific all-cusp cuspidality or a source-preserving full-row reduction to the latter operator. Thus direct use of a cuspidal bound for the calibrated row remains an open applicability gate.

This is not a theorem that the actual calibrated twist is noncuspidal, and it is not a no-go for all finite translates, twists, codes, or compensated combinations. The earlier raw/projected/conjugated residual nonzero-average audit is preserved at its narrower scope and was not extended here.


## Follow-up: the all-cusp cube difference is exactly zero

The final imported theorem is stronger than the intermediate cusp removal:

- `Eisenstein/PrimeRecurrence.lean:258`, `cubeDifferenceL2_eq_zero`;
- `Eisenstein/PrimeRecurrence.lean:291`, `cubeSourceDifference_eq_zero`;
- `Eisenstein/PrimeRecurrence.lean:305`, `cubicSource_cubeAverage`;
- `Eisenstein/PrimeRecurrence.lean:311`, `sourceArithmeticResidue_prime_cube`.

For every actual primary prime element p and every w, these prove

```
(U_(p^3) - Norm(P)^(-1) Id) cubicSourceResidualFunction(w) = 0.
```

Thus the apparent all-cusp remainder is identically zero. Every linear coefficient extraction or Mellin/source functional of this difference is zero. It supplies no source-preserving cuspidal remainder for the unmodified native base. This is an exact scoped operator no-go, not a claim that character twists or arbitrary masked commutators vanish.

The exact Fourier effect is also pinned by `Eisenstein/CorrespondenceEnergy.lean:463`, `cubeAverage_fourier`, and `cubeSource_fourier`: a Fourier index h is replaced by h*p^3 with the corresponding height scaled by the embedding cube. The actual residue satisfies `sourceArithmeticResidue(h*p^3)=sourceArithmeticResidue(h)`; the normalized residual Fourier coefficient picks up the exact sqrt(Norm(P)) factor before its Bessel/height normalization. These are the native cube recurrence, not cancellation of the source.

For a multiplicative fixed twist the finite arithmetic identity is only

```
Psi(h*p^3) = Psi(h) * Psi(p)^3.
```

Its interpretation in a globally twisted automorphic cube operator, at every cusp and through the actual marked inverse row, is not supplied here. In particular, applying the already-zero raw cube difference and then a linear twist/mask remains zero; applying twist/mask first leaves the exact commutator with U_(p^3), which has neither an attached inverse-L principal source nor an independent estimate in the inspected APIs. A changed cube eigenvalue or finite Euler multiplier alone is not a source-preserving native full-row bridge.

Next meaningful gate: construct that specific commutator for the prescribed calibrated/numerator-dependent, slot-marked inverse row and compute its complete inverse-L principal multiplier. If it still annihilates the target source, stop; if it preserves the source, prove its all-cusp cuspidal realization and every remaining mask/cutoff contribution. The existing all-cusp cube-difference identity cannot be substituted for those steps.
