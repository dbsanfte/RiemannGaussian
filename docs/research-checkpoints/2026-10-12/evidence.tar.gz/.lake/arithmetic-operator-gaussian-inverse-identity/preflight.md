# Read-only Gaussian/additive × actual inverse-row preflight

This checkpoint adds no Lean theorem or arithmetic estimate. It checks
existing native integer/ideal identities against the pinned imported
OpenAI low-row setup. Source paths and current hashes are recorded in
`source-pins.json`; the twelve critical historical vendor pins still match.
No proof, public registration, shared document or build configuration was
changed and no broad build was run.

## The actual prescribed join before Cauchy

`Detector/LowSelectedSum.lowSelectedInverseRow` is a finite polynomial in
the actual marked completed inverse row. After its fixed ray correction,
every monomial is

    markedCompletedT(rowTwist(Psi,m), W, T, A -> 1[D divides A]),
    A = I * J^3.

The divisor D is the product of genuinely distinct selected prime ideals.
`LowPrimeFamily.lowCanonicalInverseRow_eq` and
`LowActualReflectedEnergy.lowSelectedInverseRow_actual_ideal` already prove
the exact product of individual prime-ideal marks, preserving coprimality,
the actual primary generators, excluded primes, height phase and all slots.
No arbitrary or smooth row is substituted.

`LowSeparated.lowSeparatedIntegrand` couples this B to the actual additive
Gauss amplitude before estimating:

    Mellin(W0,iv) * sum_m annularMask(m) * calibrationCharacter(m)
      * radialPhase(m,v) * sum_sigma additiveAmplitude(sigma,m,v) * B(sigma,m).

`LowGramApplied.lowSeparatedIntegrand_actual_gram` then accepts arbitrary B
and uses its row-square norm. `LowTupleGram.compensation_tuple_actual_gram`
also norm-sums the unselected tuple. A new bounded scalar inserted into
that class does not improve its exponent or identify an actual source.

## Tempting exact identities that are already available

1. **Ideal coprimality support.** If a supported prime P divides I*J^3
   and the numerator m lies in P, the local sextic row vanishes. This is
   already present in `idealRowHom`, `columnWeight_zero_of_mask`, and
   `cubeWeight_zero_of_mask`. Deleting zero atoms changes neither the
   joined value nor its source. This alone is not a quantitative saving.

2. **Complete common-factor Jacobi cancellation.** For units n1,n2
   modulo P and nonzero k modulo P, with chi=sextic^c nonprincipal,

       localCorrelation(chi,n1,n2,k) = -chi(n1/n2).

   At k=0 the value is (Norm(P)-1)*chi(n1/n2); when 6 divides c,
   a nonzero k instead gives (Norm(P)-2)*chi(n1/n2). All one-zero
   n1/n2 cases are explicitly retained. These are already proved in
   `Moments/Correlation.localCorrelation_units` and
   `Moments/Canonical.canonical_primePower_units`, including the exact
   prime-power fiber factor Norm(P)^(c-1). The actual GCD/common-factor
   bridge and CRT product are in `GramGcdSource.actual_gcd_lift` and
   `GramGlobalExtension.actualCommon_eq_globalExtension`. Thus the
   obvious local Jacobi strengthening does not require a new module.

3. **Actual sextic/cubic Gauss compatibility.** The exact Jacobi and
   normalized Gauss identities are already proved in
   `GaussSum/CubicNormalization.gauss_sextic_relation` and its normalized
   version. These are literal finite-field arithmetic identities,
   not an assumed independence of Gauss phases.

4. **Prime priority and cube inversion.** `Descent/Completion` proves
   `markedCompletedT_prime_priority`, retaining the residual slot list
   after removing primes already supplied by H, and
   `marked_cube_inner_inverse` / `marked_cube_inverse`, retaining the
   moving norm cutoff X/Norm(H)^3 and the mark at H^3*A. Re-proving this
   finite-support convolution would add a representation, not a saving.
   Using the fully inverted squarefree column in place of completedT
   changes the compared analytic data; its original principal source
   may not be inherited without a new source gate.

## Matching source and density preflight

The complete matching channel is not mean-zero. The already checked
`QuasiRHCoupledResidueAudit.actual_completed_matching` retains all
I=P, J=P^(2t) incidences: their completed valuation is 6t+1, and their
additive/inverse local product is the same nonzero Gauss scalar on every
unit numerator. `actual_masked_matching` leaves the full finite signed
masked numerator sum. Separate mean-zero rows, blanket matching deletion
or CRT completion do not pay this term.

For unchanged arithmetic slot factors, the actual double-principal
Mellin source factors as profileMass times a common reciprocal-L kernel.
`QuasiRHProfileCenteringAudit.centered_source_zero` already proves that
scalar profile centering annihilates the entire such source, including
the hypothetical zero response. This is not a general prohibition on
analytic density-germ subtraction.

A genuinely noncommon arithmetic operation has the exact source
difference left by `two_profile_arithmetic_difference`:

    profileMass(V)*profileMass(W) * commonSource(B0-B1).

Its own density/pole cancellation must be checked separately, and
the resulting actual principal multiplier at the selected zero must be
nonzero. No literal operation giving that noncommon difference together
with an improved joint estimate has been isolated in this pass.

## Collapse audit and the precise still-open estimate

The existing finite product/priority/CRT joins accept arbitrary outer
slot coefficients and preserve all masks. They are not additional
inequalities on the prescribed signed inverse coefficients. Free rows
can saturate arbitrary-B Cauchy; this does not refute a new bound for
the particular actual row. Smooth or generalized-prime controls are
not granted genuine ideal, sextic, Mobius, Gamma or binomial identities.

The missing estimate must couple the signed local factors above with
the actual `lowSelectedInverseRow` across m, selected ideals and the
Gaussian cutoff *before* row or subset norms. It must pay all common
and noncommon prime-power branches, residual slot lists and incomplete
boundaries without replacing the joined character phases by their
absolute values. A signed improvement only to the additive Gram side
does not automatically improve the full inverse/additive join.

At the imported geometry the existing low budget is
Z^(3/16+epsilon), versus principal signal Z^(beta-11/16).
The checked calibration already shows that removing the whole sixth-
frequency allowance saves only 1/96; it is insufficient for the
critical-line target, which needs a gain strictly larger than 3/8.
The current exact local Jacobi identities therefore should not be
advertised as an unharvested route to RH by themselves.

## Outcome

No genuinely new finite integer identity with a provable signed saving
was found in this scoped preflight. The natural finite local candidates
are already implemented, and their source/cutoff caveats are explicit.
No new leaf is justified merely to repackage them. The prescribed joint
estimate and a source-preserving noncommon slot operation remain OPEN;
absence of such an estimate in this inspection is not a family no-go.

The existing Gaussian/Weil all-width positivity/vanishing endpoints and
`SuzukiLaplaceCompensator.riemannHypothesis_of_suzuki_signal_scaled_subexponential_lower_bound`
remain available, but none grants this imported Eisenstein join an
independent estimate. A bridge to those endpoints must retain its own
arithmetic source and one-sided estimate; changing the architecture is
not evidence that the remaining inequality has been proved.
