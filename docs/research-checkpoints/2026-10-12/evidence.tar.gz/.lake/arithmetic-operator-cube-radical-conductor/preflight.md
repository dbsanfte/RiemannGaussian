# Native cube parity and radical cofactor-conductor gate

Read-only applicability/source preflight. No proof edits, builds,
new assumptions, signed estimate, sector source inference or zero-free claim.

## Exact decomposition already imported

CubicSieve/CubeLabels.lean, QuadraticSquarefreeKernel:

- squarePart_sq_mul_squarefreePart: V^2*U=J;
- squarefree_squarefreePart: U is squarefree;
- decompositionEquiv and squarefree_decomposition_tsum: exact reindex of
  every nonzero ideal J, with its ORIGINAL coefficient/test function;
- norm_decomposition: Norm(V)^2*Norm(U)=Norm(J).

U and V may share primes. No coprimality between them is asserted.
This is the appropriate parity decomposition for J; Detector/SixthDecomposition
instead decomposes the FREQUENCY H as u*a^6. Do not confuse these variables.

For a native matching local prime P, I squarefree and
A=I*J^3=(P)^(6t+1)*B, retained P not dividing J forces t=0 and I=P*I0.
Then, exactly,

    B=I0*U^3*V^6,
    chi_B(m)=C.residueMonoid(m)
             *idealRowHom(m,I0)*idealRowHom(m,U)^3
             *coprimalityMask(primaryGenerator(V),m).

This formula is direct idealRowHom multiplicativity plus the imported
ReflectionPool.idealRowHom_sixth_denominator_mask for Supported V;
ChineseRemainder/PrimaryCompletions.idealRowHom_sixth_mask is the equivalent
full supported-ideal statement. All V powers, endpoints and nonunit zeros
are retained. The U^3 factor is the imported quadratic row on admissible
squarefree U (Reflection/IdealBridge.idealRowHom_cube_eq_quadratic).
Supported U/V are inherited from the original supported J decomposition.
For t>0 first remove the matching P powers exactly; no unrelated-J estimate
is inferred for those rows by this note.

## Exact FULL period, not just primitive conductor

Detector/RowRadicalConductor.idealRowHom_congr_radical already proves

    x-y in B.radical => idealRowHom(x,B)=idealRowHom(y,B)

including ALL nonunit zeros and every actual local sextic power.
Combined with the literal calibration periodicity, chi_B has the safe
period ideal span(C.generator)*B.radical. Its actual puncture has the
additional P factor. Neither period is claimed minimal for arbitrary B.

Since radical(B)=radical(I0*U*V), a safe norm bound is

    Norm(B.radical) <= Norm(I0)*Norm(U)*Norm(V.radical)
                    <= Norm(I0)*Norm(U)*Norm(V).

The first reduction is genuine. It cannot delete the radical(V) mask:
even if the primitive character attached to V^6 is principal, its literal
row is ZERO on a prime dividing V and ONE away from it. Such a mask still
needs that prime in the full additive period. U^3 has a genuine quadratic
phase; it is not erased by a sixth-power mask. Overlaps of I0,U,V may
reduce their union radical further; they must be retained exactly.

The imported primitive character statements also retain an explicit mask:
RowRadicalConductor.primitive_of_equal_elements and sourceRow_primitive_radical
write the SAME coefficient as primitive coefficient times original
coprimality support. They do NOT assert full-row periodicity modulo only
the primitive conductor. The frequency-side radical/conductor savings are
already used by RowReflectedAllocation.row_same_primitive_allocation;
this does not directly pay the different physical cofactor B population.

## Native quantitative geometry

Use the pinned P-unrelated matching t=0 Gaussian-centred exponents

    Norm(B)~Z^(11/16), Q~Z^(5/6-2d),
    Q/Norm(P)~Z^(17/48-d), 0<=d<=1/6.

Let Norm(I0)~Z^i, Norm(U)~Z^u, Norm(V)~Z^v and Norm(rad V)~Z^r.
Then i+3u+6v=11/16, r<=v. The safe radical-period exponent is <=i+u+r.
The short annulus volume/radical-period exponent is bounded below by

    -1/3-d+2u+6v-r,

and, using only r<=v, by -1/3-d+2u+5v.
This identifies useful smaller-period classes without replacing a signed
sum by a norm estimate.

Two exact diagnostic extremes:

1. Squarefree unrelated J (V=1), bounded I0:
   u=11/48. The short ratio exponent is 1/8-d; at d=1/6 it is -1/24.
   Thus cube radical reduction still does NOT furnish a long-period gap
   across this entire native admitted geometry. This is a nominal scale
   audit, not a cofinal population or nonzero-source theorem for that sector.
2. Square J=V^2 with U=1, bounded I0, even allowing V squarefree:
   v=11/96. At d=1/6 the short ratio exponent is 7/96>0.
   More powerful V can improve it further. This is genuinely promising
   geometric leverage for that class, but no uniform native Gaussian
   Poisson constants or signed source-preserving bound has been proved.

All exact Fraction checks are persisted in quantitative-preflight.json.
The J=1 endpoint has NO cube radical reduction. Its bounded/large I0 and
matching p puncture survive every parity reindex; the earlier source gates
already prohibit discarding this endpoint.

## Source and collapse gate

The native J reindex is an exact equivariance: it retains the actual
cubeWeight(rowTwist(...),J), squarefree Gauss coefficient on I, outer
Mobius H, original total-index mark, moving Gaussian argument,
calibration, numerator-dependent phase and every support/cutoff.
Its Mellin/Euler source is the SAME native reciprocal target-L source,
with the same actual correction and all J powers, whenever the existing
convergent-series/contour hypotheses apply. This note does not extend
those hypotheses or attach an isolated source to U or V.

Algebraically, at each local Euler factor, parity reindex merely replaces
sum_j a^j by sum_(v>=0,u in{0,1}) a^(2v+u): the same factor, including j=0.
It does not supply a new independent source estimate. Native
QuasiRHInverseMatchingAudit already joins the matching positive J powers
with the correctly shifted outer Mobius inverse and retains J=1; equal
unshifted cutoffs keep an unpaid last boundary. One must not count those
same matching powers as a second source saving here.

The radical period is also valid for arbitrary ideal-row coefficients;
common source/profile conservation remains. Any useful new result would
need to apply the smaller-period geometry to the ACTUAL joined signed
U/V/I0/H prescription and prove its source gate, not assume every positive
J sector has the same source or estimate each row by a primitive conductor
while dropping its imprimitive mask.

## Verdict

Finite identity/radical gate passes using already imported native results.
There is real sector-dependent conductor leverage, especially large square
parts. Uniform all-J period payment fails to follow: J=1 and large
squarefree U geometries still remain, and the global source-sensitive signed
estimate is unproved. No blanket primitive-period removal, new low-budget
saving or claim that all cube/radical interactions are exhausted.
Remaining domain is 1/2<beta<=7/8. Keep principalSlot3/5, angular>2/3 and
global>7/8 gates distinct.

## Refined principal-source square-cube gate

Detector/LocalSeries.markedTerm_odd and LocalSummation.principalInner_odd
prove exact odd local J-valuation cancellation AFTER the native principal
frequency sum (e<=1). Thus the principal source Euler channel only uses
J=V^2, including V=1. This does NOT say nonsquare physical J summands vanish
before the principal frequency join, or that an isolated V sector has the
whole source. The finite literal population and its masks remain unchanged.

The even channel retains evenRatio^r. At w=1,z=1/6 its exact factor is
actualAPhase(P)*Norm(P)^(3-6s); PrincipalEulerAudit.actual_R_eq_angular_character
identifies the angular-six/finite-target character. Physical V^6 becomes a
nonunit mask, but this EXTERIOR angular phase on V remains.

In this principal square-cube regime, B=I0*V^6, i+6v=11/16, and

    full radical period <= Norm(C)*Norm(I0)*Norm(rad V),
    short volume / full radical period exponent >= -1/3-d+5v.

At the worst depth d=1/6, the guaranteed long-period range is v>1/10.
The admitted maximum v=11/96 exceeds 1/10 by exactly 7/480. At that
maximum the gap is 7/96; at v=1/10 it is zero; at v=21/200 it is 1/40.
More powerful V and overlaps may improve these safe bounds. V=1 and
smaller square V still have no uniform gap from this argument.

This is a concrete possible joint-estimate target: use the actual angular
V coefficient together with the radical-period/mask Gaussian row for
large V. No independent signed source estimate or whole-source coverage
is supplied. The smaller V contribution must remain in the exact ledger.
