# Safe cube-order coordinate: native source/budget preflight

This is a read-only audit, not a new theorem or arithmetic inequality. The exact native Euler family already allows arbitrary cube coordinate `z`; this pass adds no sliced carrier. `preflight.json` pins 17 source files and records nine exact rational checks.

## What a safe coordinate actually improves

The actual local ratio is

`R=actualAPhase * Q^(4-6s-6z)`.

Consequently its angular Euler channel has argument `6s+6z-4` (the channel notation `L_ang` is shorthand for the existing actual angular-character ideal Euler factors, not a newly proved general-coordinate L-function identification).

| Real cube coordinate | R norm exponent | Angular argument | Angular absolute Euler gate | Compensated RB exponent |
|---|---:|---:|---:|---:|
| 1/6 | 3-6sigma | 6s-3 | sigma>2/3 | 3-5sigma |
| 1/3 | 2-6sigma | 6s-2 | sigma>1/2 | 2-5sigma |
| 1/2 | 1-6sigma | 6s-1 | sigma>1/3 | 1-5sigma |

Thus the proposed safe slice genuinely bypasses the **pointwise angular Euler-domain** obstruction: at `z=1/3`, every `sigma>1/2` has angular argument real part above one; `z=1/2` has still more margin. The compensating `conj(eta)*Q^s` likewise has a decaying angular error there.

These are exact consequences of `EulerCoordinates.coordR` and the native compensated replacement. The native literal marked-source identity is currently checked only on `Re(s)>3/2`, `Re(w)>2`, `Re(z)>1/6`. Generalizing the normal-product argument to fixed safe z on each compact `sigma>=sigma0>1/2` is plausible analytic engineering; it requires separate proofs, finite exclusions, and local nonvanishing checks. Do not claim one fixed exclusion set gives a uniformly nonzero residual on the entire open `sigma>1/2` domain from these exponent calculations.

## The physical scale changes too

The actual source multiplier contains

`X^(1/2-z) * Z^(s+z-1) * Y^(w-1) / L_eta(s)`

and each actual marked slot contains the exact prefactor `Q^(z-1)`.

For the native `X=Z^(17/48)` and `Y=Z^(23/48)`, writing `xi=Re(z)`, `omega=Re(w)`, the Mellin prefactor exponent is

`E=sigma+(31/48)xi+(23/48)omega-125/96`.

At `w=1` this gives:

* `z=1/6`: `E=sigma-103/144`;
* `z=1/3`: `E=sigma-175/288`;
* `z=1/2`: `E=sigma-1/2`.

Relative to the native cube axis, the bare Mellin prefactor therefore **increases** by `31/288` or `31/144`. Each marked-prime slot additionally changes its literal `Q^(z-1)` weight. These are coordinate/source-scale changes, not cancellation savings. No pointwise prefactor exponent can be assigned to the entire z/w integral without estimating its signed oscillation.

At the actual double residue `w=1,z=1/6`, the checked raw source is

`X^(1/3)*Z^(s-5/6)`.

After the existing native source normalization, the checked source is

`Z^(s-11/16)*exp((s-5/6)^2)/L_eta(s) * H(1,1/6)*slotRatio(s)`.

Changing an initial right contour does not change that source residue.

## The native contour explicitly restores the old source

`PrincipalTransport.continued_z_shift` (`:194`) proves equality between every line `1/6<xi<=2` and the line `xi=2`, at native `w=3`. Its current hypotheses include `Re(s)>=7/8` and the reciprocal zero-supremum gap. This is equality of the same Gaussian integral, not a new bound on it.

`PrincipalTransport.source_initial_ordered_at_a` (`:353`) and `source_initial_joint_ordered_at_a` (`:635`) then identify the physical initial integral with:

1. a w-leftover on `Re(w)=19/20` and the chosen right cube line;
2. a z-leftover at `Re(z)=33/200` after the w residue;
3. the exact double residue `(Rprincipal^2/6)*K(s,1,1/6)`.

Choosing `xi=1/3` or `1/2` changes only the initial right line. Returning to the source-bearing cube pole evaluates the angular channel at `6s-3`, restoring the previous lower-strip angular/order gate. Continuing the actual contour through the lower strip requires proof of those boundaries/corrections, not just the nonzero safe-line Euler product.

Even if the fixed-z residual is analytic and nonzero, the **integrated** multiplier of `1/L_eta(s)` can cancel. There is no theorem here proving that the z/w Gaussian integral has a nonzero residue at every hypothetical lower-strip zero. Slice nonvanishing does not imply integrated source nonvanishing.

## Decision

The safe coordinate is useful analytic source-domain engineering. It supplies no new actual-prime constraint: after normalization it is the same reciprocal `L_eta` under a regular Euler/Mellin multiplier. It neither cancels that zero source nor proves an independent signed arithmetic estimate.

Freeze this proposal at the preflight. A valid reopening needs an exact nonzero source theorem for the whole safe-coordinate Gaussian integral together with a stronger independent arithmetic budget, or an explicit source-preserving contour boundary payment. No new sliced carrier, below-7/8 source claim, or RH inference is justified.

## Source pins

Primary native interfaces are `EulerCoordinates`, `PrincipalEulerIdentity`, `MarkedRational`, `FiniteProductBounds.localMultiplier`, `FiniteProductX.continuedSourceMultiplier`, `MellinScaling`, `InitialScales`, `PrincipalInput`, `PrincipalTransport`, `PrincipalContours`, `PrincipalMellinResidues.source_double_residue`, and `PrincipalSignalComparison.normalized_source_double_residue`. Existing local audits `QuasiRHPrincipalEulerAudit`, `QuasiRHLowerStripSlotAudit`, and `QuasiRHCubeSourceGateAudit` retain every actual phase. All hashes are in `preflight.json`; no source file was modified.
