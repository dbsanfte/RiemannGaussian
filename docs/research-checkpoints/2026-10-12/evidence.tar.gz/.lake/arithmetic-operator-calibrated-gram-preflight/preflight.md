# Actual calibrated two-row Gram: source/conductor preflight

This is a read-only audit of the pinned native rows, not a newly compiled Lean theorem or an RH estimate. No random coefficient array, free surrogate row, or floating source model was used. `preflight.json` pins 16 source files and records five exact rational scale checks.

## Exact join before Cauchy

For two actual matching rows `A=P^(6t+1)*B`, `A'=P'^(6t'+1)*B'`, use `QuasiRHCalibratedMatchingAudit.calibrated_matching_atom` separately on each row. It retains the actual Gauss constants `G_P`, `G_P'`, and both nonunit punctures. After those constants are factored outside, the native row is

`f_B,P(m)=C.residueMonoid(m) * idealRowHom(m)(B) * 1_(m notin P)`.

Its two-row Gram product is exactly

`|C.residueMonoid(m)|^2 * idealRowHom(m)(B) * conj(idealRowHom(m)(B')) * 1_(m notin P) * 1_(m notin P')`.

The common calibration is therefore a unit mask. Its nonprincipal phase no longer creates mean-zero cancellation. This is materially different from the checked *linear* calibrated complete-period mean-zero theorem.

For supported cofactors away from calibration primes, write `e_Q=v_Q(B)`, `f_Q=v_Q(B')`. At every good odd prime `Q` in their support, the exact local unit character is `actualSextic(Q)^(e_Q-f_Q)`. The order-six theorem and CRT give:

* a zero complete mean if any exponent difference is nonzero modulo six;
* otherwise the local unit-density factor `1-1/Norm(Q)`.

Every calibration/puncture prime contributes its unit density as well. Thus, over the honest radical-union period, the normalized mean is

`1_(all e_Q=f_Q mod 6) * product_(Q in E)(1-1/Norm(Q))`,

times `G_P*conj(G_P')`. Here `E` includes calibration, both cofactor supports, and both punctures. The exponent test includes a puncture prime if it occurs in the opposite cofactor; merely puncturing that prime does not neutralize its relative character. For a common matching `P`, the test at `P` is automatically principal only under an explicit restriction `P not dividing B,B'` (for example, canonical removed-owner squarefree `J=1` cofactors). The arbitrary `matching_cofactor_atom` factorization does not impose that coprimality, so no automatic conclusion is asserted there.

Do not confuse exponent-zero **pointwise** ideal-row powers with the principal `MulChar` on nonunits: an absent prime contributes no unit mask, while a positive sixth-power incidence does.

The exact ingredients already exist:

* `Detector/PhysicalAnalytic.lean:11,25`: calibration norm and unit norm;
* `Moments/Canonical.lean:14,84`: actual sextic order six and exact ideal-row reduction;
* `ChineseRemainder/PrimaryCompletions.lean:419,427`: sixth-power unit mask;
* `Detector/GramMean.lean:12,20,33`: nonprincipal exponent, prime-power mean zero, and CRT mean zero;
* `scripts/QuasiRHCalibratedMatchingAudit.lean:120,155,187`: actual matching, linear calibrated mean, and honest period.

The full supported two-row wrapper was not newly Lean-compiled in this read-only pass. The displayed formulas are exact consequences of those checked native APIs.

## Which classes survive?

On genuine squarefree `J=1` cofactors, exponents lie in `{0,1}`; relative agreement modulo six forces `B=B'`. The diagonal survives with positive unit density.

For native `I*J^3` with squarefree `I`, relative agreement means the same `I` and even differences of the prime valuations of `J`: two distinct cube orders differing by a square lie in the same sextic class. Their phases cannot be deleted. The full inverse-row coefficients may cancel them through the already-audited total-index inverse, but this Gram identity supplies no additional relation among those coefficients.

Complete-period joining therefore gives ordinary character-class orthogonality plus actual unit masks. It holds for arbitrary complex coefficients on these rows; no new sign or linear identity among the actual Gaussian/Gauss/ray/height coefficients follows.

## Honest period versus the Gaussian scale

Keep the physical numerator norm scale

`Q=Nc*Z^(5/6-2d)`, `Norm(P)~Z^(23/48-d)`, `0<=d<=1/6`.

At the native squarefree `J=1` inverse saddle, `Norm(B)~Z^(11/16)`. These are nominal pinned slot/window scales, not assertions about a signed annular sum.

* Fixed cofactors: `Q/[Nc*Norm(P)*fixed_period]~Z^(17/48-d)`, which tends to infinity. A fixed nonprincipal relative row can enter the ordinary Poisson small-period regime.
* Growing diagonal: `Q/[Nc*Norm(P)*Norm(B)]~Z^(-1/3-d)`, which tends to zero, and the diagonal mean is nonzero anyway.
* Distinct disjoint growing cofactors at a common matching prime: honest period norm is `Nc*Norm(P)*Norm(BB')~Z^(89/48-d)`; its ratio to `Q` is `Q/period~Z^(-49/48-d)`.

Overlap can reduce the relative-character conductor. The minimal character conductor, the honest radical unit-mask period, and the full principal-index period must not be conflated. Neither the nominal ratio nor complete-period orthogonality proves an actual short-window lower bound or a family-wide impossibility theorem.

`Detector/GramPeriodicPoisson.lean:900,961` already supplies a generic arbitrary periodic-profile estimate with factor `min(1,(Norm(period)/N)^A)`. For the growing honest period that factor is one, not a saving. This is also a joint four-dimensional bound; it is not automatically an estimate for the original linear inverse row.

## Source gate and decision

`PhysicalReopen.physical_spectral_reopen` and `SpectralPoisson.physical_spectral_poisson` already retain the exact actual spectral coefficients and Gaussian numerator jointly before Cauchy. They remain the appropriate native bridge; no new carrier is needed.

Calibration kills the linear `H=0` Fourier coefficient, but actual source frequencies `H=u*a^6` survive by `SourceCoefficient.sourceHighCoefficient_eq_bare` (`Detector/SourceCoefficient.lean:25`). A Gram diagonal is not the same thing as the principal linear source. There is currently no exact actual hypothetical-zero response theorem proving that discarding/centering the diagonal or the sixth-equivalent blocks preserves that source. A linear zeta/Hecke residue cannot simply be squared and assigned to the Gram statistic.

The continued principal source correction remains proved only on `Re(s)>7/8` (`PrincipalSignalComparison.lean:344,349`). No below-7/8 source gate follows from this finite period computation.

**Decision:** do not develop another complete-period Gram or norm-pay the calibrated diagonal. The new exact mean classification supplies no independent signed coefficient constraint beyond already-existing character orthogonality. A useful continuation needs (i) genuinely new signed control of the long-conductor offdiagonal blocks and (ii) an exact actual source-preserving projection/bridge. Neither is supplied by complete-period CRT algebra. This is a no-go for the proposed *period-only* proof, not a no-go for every coupled long-conductor estimate.
