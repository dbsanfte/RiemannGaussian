# Unconditional cubic-Gauss input: native applicability gate

Read-only audit, 2026-10-08. No proof file edited, new Lean declaration,
new hypothesis, native arithmetic estimate or broader build. `preflight.json`
records 19 source hashes, seven exact rational checks and six nominal parameter
rows. This is an applicability/source preflight, not validation of a new theorem
in our chain.

## Primary revision and genuinely new input

Current OpenAI math revision is `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.
The cubic-Gauss paper at this revision and at our vendor revision
`adc7f1241b42e322a6451854ab7e4b4c146bf78a` is byte-identical: 649981 bytes,
SHA256 `0af3e675f8a6a5b3e47da9ea5ca7434a825f48f7186f79594b1ee5d54d443a37`.
The new input is not a revision to our imported 7/8 proof. It is a distinct
September 25 preprint already present at that upstream commit.

Primary PDF:
https://raw.githubusercontent.com/openai/math/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-unconditional-first-moment-for-cubic-Gauss-sums-September-25-2026/paper.pdf

Primary README:
https://raw.githubusercontent.com/openai/math/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-unconditional-first-moment-for-cubic-Gauss-sums-September-25-2026/README.md

All sums use primary Eisenstein prime elements congruent to 1 mod 3 and
include both prime ideals above a split rational prime. The normalized cubic
Gauss sum is G, and c*=(2*pi)^(2/3)/(3*Gamma(2/3)). Theorem 1.1 gives its
unconditional all-primary-prime first moment with main exponent 5/6.
This is genuinely stronger than a GRH-postulated first moment or an estimate
requiring a cuspidal form. The noncuspidal cubic model is retained explicitly.

The best direct new scalar estimate for a native gate is Proposition 3.1
(pp.10-11):

  sum_r a_r sum_u [G(ru)-c*mu^2(ru)*Norm(ru)^(-1/6)] W_r(Norm(u)/U)
       << X^(5/6-1/100),   RU~X, R<=X^.51.

Outer coefficients may be divisor-bounded; the inner sum is unrestricted,
with uniformly smooth radial norm weights. This is an explicit power saving.
It is NOT a theorem with arbitrary growing sextic twists of the inner
variable. Its proof uses the exact cube-completion inverse and evaluates
that specific level series/model.

Proposition 4.1 (pp.13-18) supplies a positive fixed power saving for the
exceptional cubic-character second moments at (P,Q) near (Y,1) or
(Y^(1/3),Y^(1/3)). The beta column must be a squarefree-restricted
convolution of at most k0 prime sequences, each on its OWN independent
smooth norm dyad, each prime norm >=Y^c for fixed c>0. A coupled cutoff on
the prime factors is specifically excluded. The character family is
chi_b(v*p*q^2), p,q coprime and squarefree, with small auxiliary v,e.
The power saving is existential; no numerical value is supplied.

## Bilinear and angular scope

Proposition 5.1 uses AB~X, X^.32<=B<=sqrt(X), H=B^2/A. For B>X^.40, beta
must have the preceding bounded independently smooth prime-convolution
structure. For B<=X^.40, a general divisor-bounded squarefree beta is
permitted. The fixed/low-height corrected estimate additionally requires:

* all beta factors above a sufficiently large power of log X;
* a uniform Siegel-Walfisz property against nonprincipal cubic Hecke
  characters of logarithmic conductor/height, including exclusions;
* a smooth radial outer weight independent of the inner coefficients.

Proposition 7.1 (pp.35-36) consequently proves the corrected bilinear
G(ab)-c*mu^2(ab)*Norm(ab)^(-1/6) is O(X^(5/6)log(X)^(-D)) at low height,
with independent alpha_a,beta_b and the hypotheses above. The product
profile is restored by Mellin separation; it is not a license for an
arbitrary nonsplit arithmetic matrix coefficient.

Proposition 7.2 (pp.36-39) bounds G(ab) on growing integrated height blocks,
T>=log(X)^Ct. It does not require roughness/SW, but still requires the
structured beta when B>X^.40. It also needs B>=cX^(1/3), or
B>=X^(1/3-3*kappa) at the upper heights. This is not a fixed-height source
estimate. Paying high height blocks leaves the native low-height join.

Appendix A.7 (pp.48-50) carries these estimates through a FIXED integer
angular twist theta_ell(ab). It DOES include ell=6. Its constants depend
on ell and it gives no growing-angular uniformity. The introductory
exclusion for powers G(prime)^k with 3 dividing k is a DIFFERENT result;
it does not exclude fixed angular mode 6 in A.7. Conversely, the angular
phase on native V^6 alone is not automatically theta_6(ab).

Theorem 1.1/A.1 themselves have prime support. Our I0 population includes
all squarefree composite cofactors. The paper's exact prime detector in
Proposition 6.1 produces bounded independent prime-convolution pieces
from a PRIME SUM; it cannot simply be applied to an arbitrary prescribed
I0/H matrix as if that matrix had the same prime identity.

## Actual native coefficient and the first missing algebraic gate

Arithmetic/IdealMobius.lean defines, on squarefree supported I0,

  alpha_native(I0)=star(angular(primaryGenerator I0))*gaussTwo(I0).

Its row column is alpha_native(I0)*Psi(primaryGenerator I0)/sqrt(Norm I0).
For the actual low row Psi is numerator-dependent rowTwist, including
eta, calibration, finite ray corrections and idealRowHom(m,I0). The
latter is a SEXTIC character, with all nonunit zeros. gaussTwo uses the
square of the canonical sextic character, so its coefficient is cubic;
that does not make the additional sextic row character cubic.

The finite calibrated matching identity retains I=P*I0, principal J=V^2,
P not dividing V, and gives the same row weighted by

  kappa(p)*C.residueMonoid(m)*1_(m notin P)*mask(V,m)
      *E_t(I0)*idealRowHom(m,I0).

E_t is the actual native spectralSummand, with completedMask,
completedCorrection, eta/calibration/ray phase, Gauss column, full powers,
Gaussian height and both norm weights. I0 and V need NOT be coprime.
Unit neutrality restricts support but its surviving projector is one.

Therefore the required bridge is an EXACT reindexing of this literal
joined expression into the paper's G(ru) or G(ab) kernel, with correctly
oriented cubic character, primary/trace normalization, independent
coefficients and an admissible uniformly controlled profile. It is not
proved by matching the words 'cubic Gauss sum'. In particular:

* a growing native m-dependent sextic twist cannot be absorbed into a
  fixed angular mode or a logarithmic-conductor ray character;
* decomposing sextic into cubic and quadratic parts leaves a genuine
  quadratic factor depending on BOTH numerator and cofactor;
* thinning m to squares/sixth powers to remove that factor is not paid;
* after the actual dual gamma1 join, alpha_native*gamma1 becomes
  mu(I0)*canonicalProductG(I0), with the fixed-ray phase retained. At that
  stage the naked Gauss kernel has already been consumed, and the new
  theorem does not directly estimate mu(I0) times an arbitrary moving
  dual window;
* the inverse Mobius index and the Poisson dual frequency index must
  remain DISTINCT. Relabeling both as H does not cancel them.

Mellin separation MAY legitimately separate a ratio/product norm profile
with a common integrable majorant. Its I0-dependence alone is not a
universal no-go. What still needs proof is that this transformation also
separates the actual shared-prime CRT/nonunit/divisibility masks and
prescribed coefficients without a source-sized remainder or unbounded
sum of inadmissible pieces. Prop.4.1 averages a specified cubic character
family; it is not an arbitrary sextic/growing-conductor estimate.

## Exact nominal length preflight, retaining V=1

These checks use only the native nominal V=1 cofactor scale and are NOT a
new decomposition or source claim for an isolated V sector. It cannot be
silently removed; small V is the surviving unpaid range.

Write Norm(I0)~Z^(11/16), d in [0,1/6]. The native long annulus has norm
volume Z^(5/6-2d); the punctured short annulus has volume
Z^(17/48-d). If one provisionally identifies these two variables with a
paper bilinear pair, the shorter-variable fraction B/(log_X Z) is:

| pair | d=0 | d=1/6 |
|---|---:|---:|
| long annulus/I0 | 33/73 | 8/19 |
| short annulus/I0 | 17/50 | 3/14 |
| dual of short annulus/I0 | 16/49 | 8/19 |

The long annulus is always in the B>X^.40 structured-coefficient regime.
The native all-squarefree I0/numerator column is not currently a bounded
independently smooth prime convolution. The fixed excluded-prime set
also does not imply the paper's growing log-roughness.

On the short annulus, even the H=B^2/A lower bound fails once d>1/96.
Its minimum-length requirement B>=X^.32 fails once d>25/816. At d=1/6
its shorter fraction is 3/14, far below the theorem's range. After
Poisson the short dual range grows to Z^(1/2), and its paired fraction
8/19 again lands in the structured large-B regime. This preserves the
same problem rather than supplying a free short-side saving.

There is a possible Type-I RANGE gate with the marked prime as outer
level: Norm(P)~Z^(23/48-d) compared with Norm(I0)~Z^(11/16) stays below
the paper R<=X^.51 threshold. Range alone is not applicability: the
unrestricted inner must still have the paper's exact cubic kernel and
uniform radial profile, whereas the native inner retains the growing
sextic rowTwist and all physical/inverse masks.

The native low budget exponent is 3/16; its target signal exponent is
beta-11/16. Reaching beta=1/2 requires gain strictly greater than 3/8.
The final X^(5/6)log^-D result is a logarithmic saving, not an automatic
fixed-power improvement of that native exponent. Prop.3.1's 1/100 is a
real scalar saving in ITS variables, but no global native 1/100 credit is
claimed without the actual summation weights and normalization.

## Source/density gate: corrected model is not raw cube subtraction

If the exact coefficient bridge is established, linearity gives a native
ledger with corrected kernel plus the SAME-weight cubic model. Compute
its complete principal Mellin factor before estimating the correction.
The model cannot be discarded as a density term by analogy.

The existing native source factorization is

  L_fixed(6z)*L_fixed(w)/L_eta(x)*globalClosedCorrection.

Its density poles occur in w and 6z; the reciprocal target L_eta(x)
supplies the desired zero source. A model subtraction must be traced
through the full calibrated I0/J/inverse/dual join to determine which of
these factors it changes. No existing identity equates the cubic model
c*mu^2(n)*Norm(n)^(-1/6) to a source-free native contribution.

The checked raw cube difference U_(p^3)F-Norm(P)^(-1)F is identically ZERO
(PrimeRecurrence.cubeSourceDifference_eq_zero). That is a DIFFERENT
operator from G(ab)-c*mu^2(ab)*Norm(ab)^(-1/6). It warns against generic
source-free projections but does not prove that the paper's corrected
kernel kills the reciprocal source. Neither source preservation nor
source annihilation for that replacement is claimed here.

## Verdict and strongest next distinct gate

The literature does supply new, unconditional, source-explicit estimates;
freeze neither them nor all collective native cofactor cancellation.
There is presently NO exact native admissible-coefficient/source bridge,
so there is no new native power credit and no extension of the 7/8 chain.

The strongest next useful test is the explicit Prop.3.1 Type-I comparison:
construct the exact same-weight cubic coefficient/profile factorization
for the prescribed native neutral small-V join, retaining the growing
numerator twist, puncture, calibration and all inverse marks. If it
cannot be made radial/cubic without leaving a growing quadratic character
or coupled matrix coefficient, state that residual exactly. If it can,
evaluate the corresponding cubic-model principal Mellin multiplier and
ONLY then transfer the 1/100 saving. The alternative is a genuine
independent prime-convolution factorization of the post-Poisson large-B
column, with its total complexity and source-bearing remainder paid.

This is a scoped open applicability gate, not a blanket impossibility of
using the new theorem. Global source/contour >7/8, angular >2/3 and the
principal-slot >3/5 gates remain separate. No source is attached to an
isolated small-V row, and no claimed RH saving rests on an announcement,
an arbitrary row weight, an unvalidated cusp projection or a floating
calculation.
