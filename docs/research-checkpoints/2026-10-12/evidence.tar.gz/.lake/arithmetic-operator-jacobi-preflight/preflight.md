# Jacobi/Gauss matching preflight

Read-only source gate, 2026-10-08. No new Lean theorem, arithmetic bound, source asymptotic or shared-file edit.

## 1. Exact native finite product is already imported

The squarefree inverse column is normalized CUBIC Gauss (`gamma2`) times the conjugate angular factor, not a sextic Gauss square. The matching additive numerator supplies raw SEXTIC Gauss (`sqrt(Norm P)*gamma1`) with its exact character(-1) factor. Thus the native matched prime product is gamma1*gamma2.

The checked identity `breveGamma1_gamma2_eq_neg_alpha_G` is

```
gamma1(P)*gamma2(P) = -angular(p)*G(P).
```

For a genuine primary squarefree coprime product, `canonicalProductCoefficient_mul_gauss_one` strengthens this to

```
canonicalProductCoefficient(I)*canonicalProductGauss_1(I)
 = mu(I)*canonicalProductG(I).
```

This retains the actual cubic reciprocity cross factors. `canonicalProductG_eq_fixed_quotient` then identifies G exactly with a fixed quotient-four ray phase of the primary product. It has norm one; this is neither a new infinity-type channel nor a cross-prime cancellation estimate.

An artificial sextic square can also be rewritten by the classical finite-field Gauss/Jacobi product identity, but it is not the native squarefree cubic coefficient. Replacing gamma2 by gamma1 would change the arithmetic carrier and require a new literal coefficient and source bridge. No such replacement is made here.

## 2. Coprime/cofactor relation is already used by the actual source

`gaussTwo_coprime_product_sextic` retains the exact sextic reciprocity pair. `correctedFiniteCoefficient_product` cancels it jointly against the actual completed reciprocity normalization, and `bareSourceCoefficient_product` makes the corrected source multiplicative. `bareIdealHighSeries_row_hasProd` supplies the resulting genuine Euler product.

At a primary prime, `localGamma_one_two_full_signal` and `corrected_prime_cubic_signal` give the native corrected gamma2 expression `-gamma1^(-1)`. These are existing ingredients of the local principal source, not new estimates.

The actual calibrated physical matching formula retains a nonempty calibration and every cofactor character:

```
matching coefficient *
  [ U_B(Q) - chi_B(p)*U_B(Q/Norm(P)) ].
```

Jacobi normalization only changes the known nonzero coefficient in front; it does not constrain or estimate this signed difference. `calibrated_matching_period_zero` preserves the exact zero complete-period mean. It does not pay the actual growing-conductor incomplete annulus.

## 3. Actual source and density gates

Since these replacements are exact equalities at the native coefficients, they preserve the already attached complete source where its existing continuation hypotheses are proved. `sourceHighCoefficient_eq_bare` cancels calibration at the prescribed sixth-power source frequencies, with genuine coprimality retained. `sourceCorrection_eq_principal` identifies the source correction, and `sourceCorrection_bound` makes it an analytic nonzero factor only on the already proved Re(s)>7/8 domain. The inverse-L/target source and its exact pole/density normalization are already present in that theorem chain.

This preflight supplies no new lower-strip continuation/nonvanishing or density separation. In particular, a finite Gauss/Jacobi equality cannot remove the known angular correction zero-order issue at 6s-3 or prove the lower-strip principal contour/source gate. No finite-ray theorem is substituted for an infinity-type channel.

## 4. Collapse audit

After the exact imported cancellation, the expression is the old native Möbius/finite-ray coefficient with its original exterior cutoff, cofactor, phase and calibration weights. It is not a new integer restriction on those weights. The finite product identity remains valid after multiplying by ANY complex exterior weight. Consequently it cannot by itself force a signed estimate for arbitrary weights: on a finite supported squarefree population one may choose weights conjugating mu(I)*G(I), leaving positive unit mass.

This diagnostic does not grant smooth-density/generalized-prime countermodels genuine Jacobi/binomial/Gamma compatibility. Rather, AFTER the actual finite-field identities have been used, the proposed operator contributes only the same already normalized coefficient; the identity contains no further joint arithmetic constraint to test on those controls. Every actual exterior arithmetic restriction still needs its own signed bound.

## Verdict and precise open alternative

Stop the proposed Gauss/Jacobi replacement as new research input: its strongest native finite identity, reciprocity/cofactor multiplicativity, and source normalization are already imported. Do not build a duplicate leaf. This is a scoped normalization-collapse audit, not a no-go for all Jacobi correlations.

A genuinely different interaction would retain a NONMATCHING prescribed cofactor/prime Jacobi correlation across several primes that does not reduce to the existing corrected coefficient product, and prove its actual zero response after density removal. No such exact relation or source theorem was found in this short preflight. The surviving calibrated annulus and collective cross-prime/cofactor estimate remain the current arithmetic gate.
