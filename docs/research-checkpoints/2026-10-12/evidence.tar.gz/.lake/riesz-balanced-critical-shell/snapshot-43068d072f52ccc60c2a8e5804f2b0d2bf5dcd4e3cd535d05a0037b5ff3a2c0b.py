from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

root = Path.cwd()
folder = root / '.lake/riesz-balanced-critical-shell'
leaf = Path('RiemannGaussian/ZetaRieszCriticalPrimeFloor.lean')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot(path):
    path = Path(path)
    sha = digest(path)
    suffix = path.suffix
    target = folder / f'snapshot-{sha}{suffix}'
    if not target.exists():
        shutil.copy2(path, target)
    return dict(path=str(path), sha256=sha,
                snapshot=str(target.relative_to(root)))


previous = json.loads(Path('docs/riesz-prime-head-transport-audit.json').read_text())
for source in previous['sources']:
    path = Path(source['path'])
    if path.name == 'AGENTS.md':
        continue
    assert digest(path) == source['sha256'], path
compiled_root = Path('.lake/build/lib/lean/RiemannGaussian.olean')
old_root = next(item for item in previous['compiledArtifacts']
                if item['path'] == str(compiled_root))
assert digest(compiled_root) == old_root['sha256']
axioms = json.loads((folder / 'axioms.json').read_text())
probe = json.loads((folder / 'probe.json').read_text())
assert axioms['onlyStandardAxioms']
assert probe['frozenSignatureRegressions'] == 18
for source in probe['sources']:
    assert digest(source['path']) == source['sha256'], source['path']

source_paths = [leaf,
    Path('RiemannGaussian/ZetaRieszBalancedRadialPayment.lean'),
    Path('RiemannGaussian/ZetaRieszBalancedAllocationPayment.lean'),
    Path('RiemannGaussian/ZetaRieszBalancedOwnerFloor.lean'),
    Path('RiemannGaussian/ZetaRieszPostHingeEnergy.lean'),
    Path('RiemannGaussian/ZetaSquarefreeRieszWindows.lean'),
    Path('scripts/probe_riesz_balanced_critical_shell.py'),
    Path('scripts/probe_riesz_balanced_signature.py'),
    Path('scripts/probe_riesz_balanced_joint.py'),
    Path('docs/zeta-riesz-critical-prime-floor.md'),
    Path('AGENTS.md'), Path('lean-toolchain'), Path('lake-manifest.json')]
proof = leaf.read_text()
report = dict(
    schemaVersion=1, date='2026-10-03',
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    objective='Close out the floor.', goalRemainsActive=True,
    slice='Exact least-prime critical-shell classification and a literal signed favorable-phase payment in the balanced-minus-head floor; no cofinal allowance is inferred.',
    sources=[snapshot(p) for p in source_paths],
    compiledArtifacts=[snapshot(compiled_root), snapshot(
        '.lake/build/lib/lean/RiemannGaussian/ZetaRieszCriticalPrimeFloor.olean')],
    validation=dict(
        scope='Focused local strict leaf, targeted build, frozen compiled ordinary root plus explicit leaf; no wider gates.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(leaf), exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszCriticalPrimeFloor --wfail', exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true .lake/riesz-balanced-critical-shell/Audit.lean',
                   exitCode=0, compiledOrdinaryRootImported=True, explicitLeafImported=True,
                   frozenCompiledRootMatchesPrevious=True, rootSourceNotRebuilt=True,
                   allNamespaceLintersPass=True, lintersPerNamespace=14),
        publicTheorems=len(re.findall(r'^theorem ', proof, re.M)),
        publicDefinitions=len(re.findall(r'^def ', proof, re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheoremsIncludingPrivateAndGenerated=axioms['theoremsIncludingPrivateHelpers'],
        everyCompiledDeclarationAxiomChecked=True, onlyStandardAxioms=True,
        previousFrozenLeafProofProbeAndDocumentationSourcesPreserved=True),
    exactResults=dict(
        originalSquarefreeCofactorAndBothLeastPrimePairingsRetained=True,
        gapEndpointsAndEmptyDivisorRetained=True,
        allSubsetRanksJoinedBeforeSignedEvaluation=True,
        responseOnGap='log(r) * sum_{L-log(r)-log(q)<log(d)<=L-log(r), d|b} mu(d)',
        primeCriticalBudget='2*log(n)<3*L',
        primeCriticalShellExactlySingleton=True,
        allOtherPrimeAndCompositeCriticalDivisorsExcluded=True,
        exactPrimeCriticalResponse='-log(r)',
        exactOriginalCoefficient='log(n)*log(r)/L',
        noTotalCountParitySignAssumption=True,
        nativeBudgetDischargedForOrderAtLeast65536=True,
        nativePrimeCriticalCountAtMostFour=True,
        nativeHighCountPrimeCriticalPaymentNotClaimed=True,
        favorableOriginalPhaseSubfamilyIndependentlyNonnegative=True,
        favorablePaymentSpentInWholeCentralMinusSameHeadInequality=True,
        originalCentralPhaseCountPhysicalOwnerRadialMasksRetained=True,
        sameFullSignedPrimeHeadRetained=True,
        noCompletionDensityZeroHypothesisClippingMonotonicityOrStackedCredits=True),
    optionalProbe=dict(
        snapshot=snapshot(folder / 'probe.json'),
        command='../.venv/bin/python scripts/probe_riesz_balanced_critical_shell.py --orders 6 7 8',
        cases=len(probe['cases']), orders=[6,7,8], heights=[54,65,100],
        independentFrozenSignatureRegressions=18,
        exactIntegerDivisorCutoffs=True, fullComplexPhaseAndSameFullHeadRetained=True,
        allCountsRetainedAndJoined=True, noFittedCountWeightsOrPhaseFreezing=True,
        toyLength='-2N log(10001/20000)', movingIntegerLength=False,
        nativeDyadicSchedule=False, fullNativeDeletionMasks=False,
        previousEventualBudgetsApplied=False, floatingExplorationNotIntervalCertificate=True,
        optionalOutsideBuildsAndCI=True, nativeFloorSavingsPercentageClaimed=False,
        nativeSourceScaleCofinalFloorCertificate=False),
    openPremises=dict(
        remainingTarget='cofinal Re(centralRest) - SAME full signed nativeHead >= -399/5000-o(1)',
        adversePrimeCriticalPhaseBoundProved=False,
        globalActiveCrossingOrCompositeCriticalEstimateProved=False,
        wholeCofinalFloorProved=False, multiplicityCeilingProved=False,
        restrictedContradictionProved=False, zeroExclusionProved=False, rhProved=False),
    publication=dict(localOnly=True, noCommitsOrPushes=True, noSubagents=True,
        noRootRegistration=True, noReadmeExplorerOrPublicEndpointUpdates=True,
        concurrentSemiprimeWorkPreserved=True),
    provenance=[snapshot(folder/p) for p in ['strict-lean.log','build.log','audit.log',
        'Audit.lean','axioms.json','probe.log','write_report.py']])
Path('docs/riesz-critical-prime-floor-audit.json').write_text(
    json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    publicDefinitions=report['validation']['publicDefinitions'],
    compiledDeclarations=axioms['declarations'],
    checkedTheorems=axioms['theoremsIncludingPrivateHelpers'],
    frozenSignatureRegressions=18, onlyStandardAxioms=True,
    cofinalFloorProved=False)))
