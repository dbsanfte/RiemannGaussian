# Native p-free unit probe: exact finite gate, no source inference

The probe uses the **unit after removing all p powers** from the ordinary
integer binomial coefficient, not the raw residue. Valuations are retained as
separate exact arrays. It includes both unit endpoints and two separate
crossing families before joining them; no norm is used in the resonant join.

For distinct primes p,q and P=p^r,Q=q^s,D=PQ, the tested depth identity is

    unit_p choose(D-1,k)
      = (-1)^(k mod P) unit_p choose(Q-1,floor(k/P)) mod p,

and the p valuation is exactly the valuation of that upper binomial entry.
The q identity is the swapped formula. Consequently the character product
recurs with sigma=chi_p(-1)chi_q(-1) except at P or Q depth crossings. This
suppresses shallow p/q crossings but does not remove the genuine upper unit
columns.

At a Gaussian-integer code lambda the exact joined defect is

    (1-sigma*lambda) sum_k lambda^k a_k
      = 1-sigma*lambda^D + J_p(lambda)+J_q(lambda).

At lambda=sigma, this has no information about the trace: it is only
derivative conservation. Odd D has zero endpoint and J_p+J_q=0; even D has
endpoint 1-sigma and J_p+J_q=sigma-1. In particular the p=2 endpoint cannot
be discarded. Both jump sums are stored separately.

The actual resonant mean is the native staircase overlap

    sum_ij length([iP,(i+1)P) intersection [jQ,(j+1)Q)) A_i B_j,

with A_i=chi_p(-1)^i chi_p(unit choose(Q-1,i)) and its swapped B_j. There are
exactly P+Q-1 positive incidences. Free A=B=1 gives the full mass D, so this
overlap geometry alone cannot bound resonance. This is an audit of the
geometry-only inference, **not a compatibility claim** that arbitrary arrays
are genuine prime/binomial unit columns.

Finite native examples demonstrate the missing upper-unit information:
p=3,q=11 has raw-residue resonant trace0 but unit trace-9, entirely from
positive-valuation layers. p=103,q=107 has raw trace64 and unit trace-2139.
Neither example establishes asymptotic growth or a hypothetical-zero source.

Fixed p=3, q=5,29,53 all have residue5 mod24, with unit resonant sums7,-17,7.
Their affine-in-q determinant1152 excludes ONLY the old level24 periodic
bulk plus endpoint/q formula. Levels8/12/24/72 have exact differing-sign
witnesses recorded separately. No all-level nonperiodicity is inferred.

The cheap fixed P=2 branch collapses completely. Its literal unit column is
chi_q(-1)^(k mod Q). The uncoded normalized trace is1 when q=1 mod4 and1/Q
when q=3 mod4; the lambda=-1 trace is always0. Thus a putative source-sized
uncoded packet is a principal-plus-chi4 selector with an absolutely safer
1/Q correction. At paper level, its continued prime series would retain a
principal zeta-zero residue (and any coincident chi4-L zero has the same
negative-residue sign), but this numerical script does not prove that
analytic theorem. Even if proved separately, the native carry coupling is
gone: an independent centered bound is still a signed prime/character
estimate. This is a fixed-cofactor-two collapse, not a no-go for all unit
codes.

The growing unaligned p=3 and joint growing-prime staircase still has an
OPEN actual-zeta source gate. External p^(-iy),q^(-iy) phases can multiply
these identities exactly, but no Euler/Mellin residue or cofinal source
limit follows from finite unit sums or a smooth power diagnostic. Fixed-p
equidistribution also cannot be substituted for a growing-prime rate.

Validation: the final probe exited0, Python bytecode compilation passed,
and the output checks370 native rows including226 proper-power rows and96
even rows;1,488,360 depth identities;1,488,360 valuation identities;
1,487,620 adjacent unit recurrences;1,480 joined Fourier identities;
1,110 exact nonresonant squared-gap bounds;370 staircase joins;26 fixed-P=2
collapse checks. The JSON separately labels floating internal-code samples.
All of these are diagnostic checks, not Lean proof inputs.
