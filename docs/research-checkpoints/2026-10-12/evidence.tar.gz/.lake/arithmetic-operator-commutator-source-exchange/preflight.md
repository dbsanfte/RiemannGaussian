# Native reciprocal/phase divisor exchange gate

Isolated finite Lean leaf: scripts/ArithmeticOperatorDivisorExchangeAudit.lean.
Final warning-as-error build exited 0: 78 all-local declarations, 66 theorems
including generated helpers, all 15 linters, standard axioms only. Twenty
source pins and 108 exact integer/Gaussian-rational regressions are retained.
No commit/push, shared metadata edit, new RH inequality or zero exclusion.

## Distinct native operators; actual finite cutoff

Z(n,d)=1_(d|n), M(n,d)=mu(n/d)1_(d|n), and T_y(n,n)=n^(-iy).
The finite intermediate sum is over 1<=d<=X. The quadratic explicitly keeps
its head and X; all new prime-fiber witnesses use head=0. They do NOT claim
an obstruction after every head. Both phases and every Mobius/prime-power
fiber are kept before signs are inspected.

    E = M(T_y+T_-y)Z - 2I,
    C = M(T_y+T_-y)Z - (T_y+T_-y).

E is centered conjugation; C is the source-retaining phase commutator.
They must not be interchanged. On genuine rows {1,p}, inherited from the
FULL native cutoff X>=p, put f_p=2(cos(y log p)-1). Then

    E|_{1,p} = [[0,0],[f_p,f_p]],
    C|_{1,p} = [[0,0],[f_p,0]].

The leaf proves these full-prefix identities, not a substitute 2x2 model.
At y=19*pi/log(2)>54, f_2=-4. Literal zero-extended row vectors give both
negative and positive quadratics: E(0,1)=-4, E(-2,1)=4; C(1,1)=-4,
C(-1,1)=4. Universal positive OR negative semidefiniteness therefore fails
on actual integer-prime incidence. This alone says NOTHING against a
specially prescribed actual-Mangoldt vector.

## Actual Lambda vector has stronger exact structure

The checked native action equals literal Mobius inversion of the phased
integer logarithm. With theta=y log p and nu>=1 it gives EXACTLY

    (E Lambda)(p^nu)
      = 2 log p [nu(cos(nu theta)-1)
          -(nu-1)(cos((nu-1)theta)-1)],

    (C Lambda)(p^nu)
      = 2(nu-1)log p [cos(nu theta)-cos((nu-1)theta)].

Every endpoint and proper power is retained. The complete E prime-power
tower telescopes before any norm:

    sum_{nu=1}^J Lambda(p^nu)(E Lambda)(p^nu)
      = 2(log p)^2 J(cos(J theta)-1) <= 0.

This is a genuine signed identity for the prescribed Lambda vector.
In contrast, C Lambda(p)=0 on EVERY ordinary prime. The leaf formally
proves that a nonzero Lambda(n)(C Lambda)(n) forces n to be a proper prime
power. Squaring/testing on the Lambda support discards precisely the
composite-output channel carrying C's linear source.

## Source preflight (paper-level, clearly separated from finite Lean)

On Re(s)>1, imported mixed-height inverse identities give the exact
ordinary integer Euler responses. If ZetaLog(s)=-zeta'(s)/zeta(s), then

    L(E Lambda,s)
      = -zeta'(s+iy)/zeta(s)-zeta'(s-iy)/zeta(s)-2 ZetaLog(s),

    L(C Lambda,s)
      = -zeta'(s+iy)/zeta(s)-zeta'(s-iy)/zeta(s)
          -ZetaLog(s+iy)-ZetaLog(s-iy).

These equations are asserted first only on the genuine Euler half-plane;
local meromorphic continuations are not divergent-series identities.
For rho=beta+iy, 0<beta<1, the repo proves zeta(beta)!=0. Thus E's linear
response is regular at s=beta: its matched source is annihilated. C's
linear response has residue +2m at beta, with the actual conjugate-zero
multiplicity retained. The shifted Gamma numerators are regular there.

The prescribed C quadratic is different. It has no ordinary-prime terms.
The checked proper-power formula yields the elementary bound

    |Lambda(n)(C Lambda)(n)|
      <= 4*zetaProperPrimePowerCoefficient(n)*log n.

For n=p^nu, nu>=2, this follows from |cos a-cos b|<=2 and nu-1<=nu;
ordinary primes and non-prime-powers contribute zero. This ALL-n bound and
its analytic-series conclusion are read-only deductions, not new compiled
Lean declarations. The pinned summable_zetaProperPrimePowerMoment(1)
provides exactly the convergent majorant on Re(s)>1/2 (and higher log
moments give locally uniform analytic domination). Hence this quadratic
cannot carry a matched beta>1/2 zero singularity. There is no source to
oppose even if an excellent bound were obtained.

E's prescribed quadratic retains ordinary-prime terms. Let

    P1(s)=sum_p (log p)^2 p^(-s).

On Re(s)>1 its full joined response is

    P1(s+iy)+P1(s-iy)-2P1(s) + properPowerCorrection(s).

The proper-power correction is analytic on Re(s)>1/2 using the same
polynomial-log majorants. The ordinary-prime identity is
P1=-ZetaLog' plus an analytic proper-power term. Consequently its selected
matched DOUBLE-pole coefficient is -2m at real beta. Its density/pole
channels have principal coefficients -2 at s=1 and +1 at s=1+-iy.
All density channels remain; neither phase is deleted.

The exact tower sign <=0 is compatible with this NEGATIVE zero source.
It is also compatible with the larger negative density contribution.
Separating that density requires a signed dilation/subtraction and forfeits
the original one-sided tower sign. No o(X^beta log X) remainder estimate
follows. This is source conservation, not a newly paid source.

## Free, smooth-density and generalized-prime controls

All finite M/Z/phase exchange algebra is valid for arbitrary integer arrays;
retaining actual mu is essential, and a free array is NOT asserted to
satisfy the full actual Lambda Gamma observations. The imported finite
Gamma uniqueness theorem already excludes that shortcut.

Universal matrix positivity is refuted by the actual prime-fiber witness,
not just by a free or smooth countermodel. The prescribed E tower sign
uses only the positive single-prime tower weight after its exact telescope;
its right side is nonpositive regardless of the matched Chebyshev source.
Thus smooth/power sources and generalized Euler controls with such positive
towers do not acquire a conflicting restriction from this sign alone.
The imported positive-density Gram gate also says a PSD statistic that
cancels a strictly positive density exactly must kill every column source.
One cannot add pole cancellation and preserve a source merely by appealing
to generic Gram positivity.

## Action-changing verdict

1. Universal symmetric exchange PSD is false on literal prime incidence.
2. The actual C quadratic is source-blind because only proper powers remain.
3. The actual E quadratic has an exact signed tower theorem, but its source
   has the permitted sign; density centering recreates an unpaid signed
   ordinary-prime sum, not a new arithmetic restriction.

Freeze these proposed universal/prescribed-diagonal rescues. A useful next
interaction must retain C's composite-output source and constrain it by an
independent actual cross-column arithmetic relation, or prove a genuinely
source-sensitive density-centered E remainder. No blanket no-go for such
new correlations, and no full operator-family exhaustion, is claimed.
