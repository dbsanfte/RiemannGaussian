import RiemannGaussian.ArithmeticOperatorGammaTwistAudit
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
open Complex RiemannGaussian RiemannGaussian.SuzukiCarryCorrelation
open scoped BigOperators ComplexConjugate
#check Matrix.mul_apply
#check Fin.sum_univ_two
#check Matrix.PosSemidef
#check Real.pi_gt_three
#check ArithmeticFunction.convolution_moebius_log
#check ArithmeticFunction.sum_log_mul_moebius_eq
#check ArithmeticFunction.vonMangoldt_eq_sum_log_mul_moebius
#check Nat.sum_divisorsAntidiagonal
example (y : ℝ) (n : ℕ) :
    primePhase y n + primePhase (-y) n =
      (2 * Real.cos (y*Real.log n) : ℝ) := by
  apply Complex.ext <;> simp [primePhase, Complex.exp_re, Complex.exp_im, Real.cos_neg, Real.sin_neg] <;> ring
