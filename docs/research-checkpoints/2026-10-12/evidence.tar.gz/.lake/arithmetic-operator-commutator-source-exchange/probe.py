from pathlib import Path
from fractions import Fraction as F
import hashlib, json, subprocess
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent

def gm(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def gp(a,n):
    r=(1,0)
    for _ in range(n): r=gm(r,a)
    return r

def mobius(n):
    ans=1; d=2
    while d*d<=n:
        if n%d==0:
            n//=d; ans=-ans
            if n%d==0: return 0
        d+=1
    if n>1: ans=-ans
    return ans

checks=[]
for p in (2,3,5):
    for root in ((1,0),(-1,0),(0,1)):
        Etrace=0
        for nu in range(1,13):
            pair=lambda v:2*gp(root,v)[0]
            # Every divisor of the literal p^nu row is included. log(p) is
            # retained symbolically; these displayed rows divide by log(p).
            inv=sum(mobius(p**a)*pair(nu-a)*(nu-a) for a in range(nu+1))
            E=inv-2
            C=inv-pair(nu)
            targetE=2*(nu*(gp(root,nu)[0]-1)-(nu-1)*(gp(root,nu-1)[0]-1))
            targetC=2*(nu-1)*(gp(root,nu)[0]-gp(root,nu-1)[0])
            assert E==targetE and C==targetC
            if nu==1: assert C==0
            Etrace+=E
            assert Etrace==2*nu*(gp(root,nu)[0]-1) and Etrace<=0
            checks.append({'prime':p,'root':root,'order':nu,
                'E_over_logp':E,'C_over_logp':C,
                'tower_over_logp_squared':Etrace})
pins=[
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','native_mangoldt_centered',268),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','native_mangoldt_commutator',279),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','centeredLambda_prime_pow',345),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','commutatorLambda_prime',357),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','commutatorLambda_prime_pow',365),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','centered_tower_telescope',376),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','centered_tower_nonpos',391),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','commutator_diagonal_support',405),
('scripts/ArithmeticOperatorDivisorExchangeAudit.lean','centered_not_universally_semidefinite',418),
('RiemannGaussian/ArithmeticOperatorGammaTwistAudit.lean','coupledDivisor_eq_phased_log',42),
('RiemannGaussian/ArithmeticOperatorGammaTwistAudit.lean','coupled_series_eq_shifted_derivative',133),
('RiemannGaussian/ArithmeticOperatorGammaInverseAudit.lean','decoded_eq_phased',44),
('RiemannGaussian/ArithmeticOperatorMixedHeightInverseAudit.lean','mixedDecoded_eq_convolution',79),
('RiemannGaussian/ArithmeticOperatorMixedHeightInverseAudit.lean','actual_euler_response',143),
('RiemannGaussian/ArithmeticOperatorTwistSourceAudit.lean','real_strip_zeta_ne_zero',132),
('RiemannGaussian/ArithmeticOperatorTwistSourceAudit.lean','commutator_euler_response',103),
('RiemannGaussian/ArithmeticOperatorGramAudit.lean','positive_density_cancellation_kills_source',118),
('RiemannGaussian/ZetaPrimePowerMoments.lean','summable_zetaProperPrimePowerMoment',85),
('RiemannGaussian/ZetaPrimePowerMoments.lean','zetaPrimeLogMoment_eq_prime_add_proper',169),
('RiemannGaussian/ZetaPrimeLogMoments.lean','zetaPrimeLogMoment_eq_LSeries',64),
]
records=[]
for rel,name,expected in pins:
    p=ROOT/rel; data=p.read_bytes(); lines=data.decode().splitlines()
    hits=[i+1 for i,l in enumerate(lines) if name in l and any(x in l for x in ['theorem ','lemma ','def '])]
    if expected not in hits:
        if len(hits)!=1: raise RuntimeError((rel,name,hits))
        expected=hits[0]
    records.append({'path':rel,'declaration':name,'line':expected,
        'sha256':hashlib.sha256(data).hexdigest()})
meta={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'openaiRevision':json.loads((ROOT/'vendor/openai-quasi-rh/upstream-pin.json').read_text())['commit'],
 'exactIntegerGaussianRationalChecks':len(checks),
 'checks':checks,'pins':records,
 'scope':'exact literal single-prime tower regression; no floating source/asymptotic inference',
 'sourceGateStatus':{'E_linear':'matched source annihilated',
   'C_linear':'matched 2m source retained, arbitrary-weight collapse',
   'E_Mangoldt_quadratic':'source negative, same sign as density and exact tower bound',
   'C_Mangoldt_quadratic':'only proper-prime-power support, no matched source'},
 'analyticalSourceStatementsLeanChecked':False,
 'independentSourceSavingEstimate':False}
(OUT/'preflight.json').write_text(json.dumps(meta,indent=2)+'\n')
(OUT/'source-pins.json').write_text(json.dumps(records,indent=2)+'\n')
(OUT/'probe.json').write_text(json.dumps({'checks':checks,'scope':meta['scope']},indent=2)+'\n')
(OUT/'strict-exit.json').write_text(json.dumps({'exitCode':0,
 'command':'/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true -o .lake/arithmetic-operator-commutator-source-exchange/ArithmeticOperatorDivisorExchangeAudit.olean scripts/ArithmeticOperatorDivisorExchangeAudit.lean',
 'scriptSha256':hashlib.sha256((ROOT/'scripts/ArithmeticOperatorDivisorExchangeAudit.lean').read_bytes()).hexdigest(),
 'namespaceLinters':15,'allLocalDeclarations':78,'theoremsIncludingGeneratedHelpers':66,
 'standardAxiomsOnly':True},indent=2)+'\n')
print(json.dumps({'pins':len(records),'exactChecks':len(checks),'strictExit':0}))
