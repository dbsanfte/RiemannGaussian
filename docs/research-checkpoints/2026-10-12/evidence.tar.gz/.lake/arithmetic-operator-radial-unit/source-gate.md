# Actual calibrated radial unit gate

## Exact native result

Let chi_B(m)=C.residueMonoid(m)*idealRowHom(m,B), with the ACTUAL calibration
and cofactor ideal. Keep the complete window W(elementNorm(m)/Q), including
its fixed height phase, all cofactor elements and all prime powers.
For every Eisenstein unit epsilon, the checked leaf proves

    U_B(Q) = chi_B(epsilon)*U_B(Q).

Multiplication by epsilon preserves elementNorm, the complete lattice, and
the ideal puncture. Consequently the SAME equivariance holds for

    U_B(Q)-chi_B(p)*U_B(Q/elementNorm(p)).

If any unit has chi_B(epsilon)!=1, both the annulus and the actual puncture
are exactly ZERO. The six-unit average Pi_B is exactly the indicator of
UnitNeutral(C,B); Pi_B times the original annulus/puncture is that SAME row.
The native matching wrapper retains its exact actualSextic(-1)*gaussSum
constant and powers (span p)^(6*t+1)*B, not a newly modeled row.

## Surviving supported class

For Supported B, the imported CanonicalUnitEuler normalization gives

    chi_B(epsilon)
      = C.residueMonoid(epsilon)
        * eisEmbedding(epsilon^((absNorm B-1)/6)).

The leaf reuses this and the norm-mod-36 theorem. UnitNeutral(C,B) depends
on absNorm(B) modulo36, with C fixed. Supported B only excludes ramified
and characteristic-two factors; it does NOT automatically imply this
neutrality. Imported Hecke.UnitRows.unitSupplement_seven gives a genuine
supported norm7 example where the cofactor unit phase is eisEmbedding(epsilon).
The variable epsilon here is the numerator/cofactor ELEMENT. The imported
unitSupplement character, viewed instead as a function of the IDEAL B,
is already unit-trivial as a Hecke character; these are different actions.

## Actual source check and scope

The imported sourceHighCoefficient_eq_bare explicitly cancels calibration
with its star(C.residueMonoid(u)) mask, tau, generator normalization and
reciprocity factors, retaining the bare source. The imported
rawArithmeticSeries_eq_sixth_high retains that calibration mask through
its FreeRow sum. Neither theorem states that each bare high coefficient
has UnitNeutral(C,B) in the above physical cofactor role.
HeckeFamily.Character.unit_trivial and IdealBridge.elementTerm_unit_mul
already ensure the target Hecke series descends to ideals. LowElementRows
reindexes all six units and bounds their energy; it does not give the new
pointwise radial deletion as a signed growing-cofactor estimate.

Thus the projector preserves each ORIGINAL radial matching row exactly.
There is no claim that a discarded nonneutral physical row has a nonzero
hypothetical-zero residue. There is also no claim that the selected/global
continued source lives in an individual B row: that would require its
actual spectral/Mellin bridge. Source survival of the complete carrier is
not changed by inserting an exact identity, but no new source theorem or
contour range follows.

## Collapse verdict

This is a finite six-character selection. On UnitNeutral(C,B), Pi_B=1 and
the prescribed signed radial sum is unchanged, including its cofactor-one
endpoint when neutral. The unit symmetry itself supplies NO rate on this
surviving growing-cofactor sum, no numerator/cross-cofactor correlation,
and no replacement for the native low 3/16 budget.
No uniform six-sector population fraction or density is inferred.
The all-height surviving domain remains 1/2<beta<=7/8; principalSlot's
3/5 and angular absolute convergence >2/3 gates remain separate.
This scoped unit-sector gate is now closed; do not refine it as an RH bound.

## Validation

Only the isolated leaf is compiled, warningAsError=true, all15 namespace
linters, and all local declarations checked by module provenance for
standard axioms propext/Classical.choice/Quot.sound, including generated
helpers. No broader checks, root registration, shared edits, commit/push,
new arithmetic growth estimate or zero-free claim.
