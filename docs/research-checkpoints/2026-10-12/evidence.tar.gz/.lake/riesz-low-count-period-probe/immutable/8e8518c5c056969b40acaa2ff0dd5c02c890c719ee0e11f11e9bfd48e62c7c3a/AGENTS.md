# RiemannGaussian agent guide

## Project mission

RiemannGaussian is a research project seeking a complete, kernel-checked Lean
proof of the Riemann hypothesis. The target is Mathlib's
`RiemannHypothesis`; finite models, numerical certificates, asymptotic
experiments, and reformulations are useful only when they strengthen a
rigorous chain to that target.

The proof is not complete. The generated dashboard in
`docs/proof-status.svg` is the canonical compact status summary. At present,
the Gaussian/Weil and Suzuki/contour branches prove that the complete
safe-axis logarithmic defect is asymptotic, with `o(1)` error, to its positive
Poisson linearization, which is exactly height-scaled Blaschke derivative
variation. A checked dyadic Tauberian theorem now identifies decay of those
quantities with `H(T) / T → 0`, where `H` is cumulative upper spectral height.
The literal correctly normalized arithmetic Suzuki `Psi` is now identified
with the transport hinge model, and Lean proves it strictly positive on an
unconditional nonzero punctured neighborhood of the origin. Lean also derives
the transport smooth curvature as the second derivative of the literal
Archimedean term on positive time and proves its exact tail normalization with
computed frozen base value and slope. At the canonical first-event base
`t = log 2`, Lean now proves the exact event cut and strict negativity of the
frozen slope, so the literal tail-positivity criterion has no remaining
base-data assumptions. The literal frozen base value is also proved greater
than `7 / 125`, and the first frozen slope is greater than `-3 / 10`. Exact
curvature bounds then prove the synthetic cutoff-one transport gap strictly
positive, so cutoff zero and cutoff one are both discharged. The remaining
criterion begins at cutoff two, where every prefix contains a future
von Mangoldt event. Lean now identifies the mass and log-moment of every such
complete prefix with exact finite Abel transforms of `Chebyshev.psi`, proves
that its canonical transport point solves the literal Archimedean
slope-matching equation, and rewrites the open gap as the Archimedean value
plus a centered Chebyshev log-moment. Lean now evaluates the continuous
`psi(x) = x` part of that moment in closed form and isolates the remainder as
one explicit boundary term and signed integral against `psi(x) - x`. Exact
Chebyshev mass and Archimedean slope bounds now locate every canonical center
at `r >= log N - 2`; consequently the elementary derivative kernel is
nonnegative and strictly decreasing on every unresolved prefix. Its negative
derivative is a second strictly positive kernel. A checked
absolute-continuity argument rewrites the open moment through the cumulative
error `integral_1^x (psi(u) - u) du`, and a finite Abel identity identifies
that primitive with an exact triangular von-Mangoldt sum minus
`(x^2 - 1) / 2`. Further exact curvature and Chebyshev-mass estimates trap
the canonical center at every endpoint `N` in
`log N - 2 <= r_N < log N + 5`; hence the endpoint coefficient left outside
the cumulative moment is at most `5 * N^(-1/2)` in absolute value. The open
arithmetic statement is therefore a uniform two-level cumulative PNT-error
bound against positive kernels, with its endpoint coefficient now controlled.
Lean further proves that the complete cumulative moment is at most
`45 * sqrt N` in absolute value, the direct boundary term is at most
`25 * sqrt N`, and the full centered PNT remainder is at most `70 * sqrt N`.
Consequently that remainder divided by `N` tends to zero along the canonical
centers. The smooth baseline is now split exactly into a nonnegative
exponential convexity reserve and a lower-order term. The latter is bounded
by an explicit logarithmic envelope and is `o(sqrt N)`. Hence Lean proves the
dimensionless asymptotic frontier
`gap_N / sqrt N = 4 * (exp(delta_N/2) - 1 - delta_N/2) +
PNTError(r_N,N) / sqrt N + o(1)`, where `delta_N = r_N - log N`.
The center equation is now coupled to the same arithmetic measure: if
`E_mass` and `E_log` are its weighted mass and log-moment errors, Lean proves
exactly `PNTError(r_N,N) = E_log(N) - r_N * E_mass(N)` and proves
`E_mass(N) / sqrt N = 2 * (exp(delta_N/2) - 1) + o(1)`. Lean now performs the
corresponding Legendre elimination exactly. For the corrected mass ratio
`q_N = exp(delta_N/2)` and relative entropy
`H(q) = q * log q - q + 1 >= 0`, the literal finite gap is
`gap_N = E_endpoint(N) - 4 * sqrt N * H(q_N) + smooth_correction_N`, where
`E_endpoint` is a direct finite weighted von-Mangoldt sum and the source-exact
correction is `o(sqrt N)`. The missing arithmetic theorem must show that this
fixed-endpoint error dominates the entropy cost uniformly and ultimately
derive a genuine global zero-location constraint. Lean further proves the
quantitative upper bound
`4 * sqrt N * H(q_N) <= (E_mass(N) - smooth_slope(r_N))^2 / sqrt N`, so a
specific fixed-endpoint quadratic mass--moment inequality is sufficient for
every gap and for the uniform tail. Its premise is open and may be strictly
stronger than the exact entropy condition. The fixed-endpoint error now also
has a checked discrete work law
`E_endpoint(N+1)-E_endpoint(N) = D_N-log((N+1)/N)E_mass(N)`, with every smooth
drift `D_N >= 0` and strictly positive evaluated initial margin at `N=2`.
Lean telescopes this into initial margin plus cumulative smooth drift minus
cumulative signed mass-error work, and proves a corresponding block-work
inequality sufficient for the literal tail. For the literal weighted
Chebyshev logarithmic-average error `A_N`, Lean now proves exactly
`E_endpoint(N) = -A_N-log(N)-4` and identifies the cumulative signed work as
`A_N+log(N)-log(2)+4*sqrt(2)+sum D_j`. The exact entropy condition and the
sufficient quadratic majorant are therefore explicit quantitative upper
bounds for this single logarithmic average. Lean further proves
`0 <= D(b,b+1) <= b^(-3/2)` for `b >= 1`, so the smooth drift series is
summable and cumulative signed work minus `A_N+log(N)` converges to an
explicit finite constant. The smooth term therefore cannot provide an
unbounded margin. Lean now extends the literal formula for the logarithmic
average to every real endpoint `b >= 1`, proves each real logarithmic Mellin
atom integrable, and evaluates its weighted integral as the corresponding
von-Mangoldt Dirichlet term divided by `(sigma - 1/2)^2`; the square-root main
term is exactly `4/(sigma-1)`. Lean now also proves absolute summability of
the supported atom norm integrals, performs the infinite sum-integral
exchange, and identifies the complete transform on every real `sigma > 1`
with `(zeta'/zeta)(sigma)/(sigma-1/2)^2 + 4/(sigma-1)`. After exposing every
completed-zeta pole and Archimedean term, Lean proves that this same literal
arithmetic integral recovers the genuine spectral-xi negative logarithmic
derivative at `-i(sigma-1/2)`. Lean also proves genuine integrability and the
global substitution `x=exp(t)`, then complexifies the literal one-sided
Laplace transform on `Re z > 1/2`. It proves integrability of the parameter
derivative, differentiation under the infinite integral, and holomorphy. The
real-ray zeta response extends by the identity theorem throughout that same
half-plane, where the transform recovers the genuine spectral-xi negative
logarithmic derivative at every corresponding complex spectral point. Lean
now cancels the apparent pole at `z=1/2` and constructs a zero-adaptive
completed continuation whose open holomorphy domain contains the closed safe
half-plane and genuinely crosses to `Re z<1/2`. It agrees with the literal
integral on `Re z>1/2`, recovers spectral xi throughout its holomorphic
domain, and has residue `m_rho/(rho-1/2)^2` at every nonzero shifted zeta-zero
coordinate. The original integral is not asserted to converge in the
continued region. Lean now removes the inherited `z^(-2)` normalization and
proves that the pole-cleared response has residue `m_rho` at every shifted
nontrivial zero, without an exceptional-coordinate hypothesis. Applying the
fixed-positive-time heat weights to these arithmetic residues gives exactly
the genuine spectral-xi heat residues, and their absolutely convergent series
sums to the complete existing fixed-time heat. In the same shifted coordinate,
Lean now derives the smooth boundary heat kernel and its full real derivative,
proves its Cauchy--Green source is nonzero on the critical boundary, and proves
an exact arithmetic area--boundary identity for the heat-weighted pole-cleared
response on every zero-free rectangle. Lean also isolates each xi-zero
puncture and proves its shrinking circle integral recovers the exact
moving-kernel residue. It now proves the rectangular base case for excision:
four zero-free rectangles glue around one shrinking square, the square
boundary has the same exact residue limit, and the resulting improper
four-piece area integral converges to the outer boundary minus that residue.
It now proves the same fixed-radius and improper identities for the smooth
heat kernel times an arbitrary principal part `L / (z-c)`, providing the
termwise interface needed for finite principal-part regularization. Lean now
constructs that finite regularization unconditionally on every positive
shifted-coordinate slab of bounded imaginary height: the finite window is
proved complete for the xi divisor, every local multiplicity-weighted
principal part is subtracted, and one analytic representative patches the raw
remainder across all selected zeros. The heat-weighted response is therefore
a proved finite sum of the exact weighted principal parts plus one weighted
analytic remainder away from the divisor. Lean proves the integrability
prerequisite: every weighted principal-part source is locally Lebesgue
integrable through its pole, the project's iterated rectangular area equals a
genuine complex-plane set integral, and the actual finite-window arithmetic
source is integrable through its complete finite xi divisor. Lean also
constructs a single rectangle minus the finite union of common-radius complex
balls and proves its actual-source integral converges to the full planar area.
A checked half-open-square decomposition now identifies the termwise
shrinking-square approximation with that same ordinary through-divisor limit.
The resulting parameter-free finite Cauchy--Green identity states that the
actual arithmetic area equals the outer boundary minus the complete finite
multiplicity-weighted heat-residue sum; the literal common-ball integral
converges to this value. Lean now also retains exactly the selected off-axis
half-divisor on every eligible negative-real rectangle. The real part of the
selected finite heat sum is nonnegative and is strictly positive when its
window contains an off-axis zero; the sum converges to the existing
RH-equivalent boundary-heat total and equals an explicit arithmetic
boundary-minus-bulk functional. Lean now constructs canonical cofinal
rectangles using explicit finite real-coordinate extrema and the existing
quantitative zero-free heights. The corresponding actual boundary-minus-bulk
sequence converges to `2*pi*i` times the complete detector, and its convergence
to zero is equivalent to RH. Its real part is identically zero, while its
imaginary part is exactly `2*pi` times the selected finite heat sum. Lean proves
this scalar is nonnegative, monotone along the quantitative heights, strictly
positive when a window contains an off-axis zero, and zero exactly when that
window is empty. Lean now also constructs a genuine near-edge half-strip
exhaustion: the horizontal sides converge to `-1/2` and `0` while staying an
explicit positive distance from the bounded-height divisor, the vertical
height tends to infinity, and every fixed selected zero enters eventually.
Each stage satisfies the exact filtered positive Cauchy--Green identity.
Lean now passes those non-nested filtered sums to the complete detector by
dominated convergence and obtains a global near-edge arithmetic
boundary-minus-bulk limit. Lean also splits that functional exactly into four
named oriented boundary sides and one bulk term; its imaginary part is
stagewise nonnegative, strictly positive when a selected zero is present, and
converges without height normalization to the complete detector scalar. Lean
now proves a uniform exponential bound for the pole-cleared response across
both selected horizontal sides, including the Archimedean digamma correction.
The fixed-positive-time Gaussian dominates this bound, so both horizontal
integrals tend to zero unconditionally. The live contour frontier is therefore
exactly the two vertical sides minus the bulk. Lean now also splits both the
weighted response and its source pointwise into the genuine xi logarithmic
derivative and the explicit Archimedean regular correction. The regular
correction is analytic on every selected rectangle, so its boundary equals
its bulk exactly; its horizontal sides vanish by the same Gaussian mechanism,
and its vertical-minus-bulk term tends to zero. Subtracting the entire regular
piece leaves the unnormalized detector limit unchanged. The live three-term
remainder is therefore concentrated in the `xi'/xi` component. Lean now
proves this at the integral level rather than only pointwise: both selected
vertical lines lie in the zero-free pole-cleared domain, their interval
integrals split exactly, the bulk split is justified through genuine planar
integrability, and the regular-subtracted functional equals the two explicit
xi-logarithmic-derivative vertical terms minus the explicit xi source bulk at
every stage. This literal three-term functional retains the unnormalized
detector limit. Lean now takes its imaginary part through every integral using
proved interval and planar integrability. The result is a fully real scalar:
two vertical integrals of the real heat kernel times `Re (xi'/xi)`, minus an
explicit planar integral involving both real and imaginary logarithmic-
derivative components. Lean proves that the bulk coefficients are exactly the
two partial derivatives of the real heat kernel, so the remaining source is a
first-order heat-gradient pairing. Turning that pairing into a Green/Dirichlet
or explicit-formula identity with an unconditional vanishing estimate remains
open arithmetic rigidity. Lean now also defines the shifted xi log-norm
potential `U(a,y) = log |xi(1/2+a+I*y)|` and proves away from the divisor that
`U_a = Re (xi'/xi)` and `U_y = -Im (xi'/xi)`. The finite bounded-height divisor
inside every selected rectangle is proved planar-null, so the off-divisor
identity promotes to an almost-everywhere equality, the gradient pairing is
genuinely integrable, and its ordinary planar integral equals the explicit xi
bulk. Both vertical boundaries are zero-free, making the entire live scalar
exactly a boundary-minus-`grad K · grad U` functional with the same
unnormalized detector limit. The xi functional equation and conjugation
symmetry now prove `U` even in its shifted real coordinate; its horizontal
derivative and the real heat kernel are odd, so their boundary product is
even. Lean uses this to reflect the near-`s = 0` left boundary to positive
shifted coordinates in `(1/4, 1/2)`, equivalently actual xi coordinates in
`(3/4, 1)` tending to `1` from below, without changing any finite scalar or
its detector limit. This does not enter the absolute Dirichlet-series region.
Lean further differentiates the reflection symmetries and proves the complete
pairing `grad K · grad U` odd in the shifted real coordinate. Both boundaries
and the entire bulk are now reflected, with genuine through-divisor planar
integrability proved on the positive rectangles. Thus every finite live
scalar is an exact boundary-plus-gradient functional wholly in actual xi
coordinates `1/2 < Re s < 1`; its inner edge tends to `1/2` from above and its
outer edge to `1` from below. No decay in that open strip has been proved.
Lean now also removes the upper-quadrant restriction from the existing paired
Dirichlet-eta construction. On every point of `1/2 < Re s < 1`, its absolutely
convergent paired series equals `(1-2*2^(-s))*zeta(s)`, the elementary factor
is nonzero, and the paired series therefore retains exactly the zeta divisor.
Lean now differentiates that series by locally uniform holomorphic
convergence and obtains an exact quotient of convergent paired eta series for
`zeta'/zeta` at every nonzero zeta point of the same strip.
Lean also exposes the squared quotient energy without assuming an unproved
through-divisor `L²` estimate and develops a divisor-preserving `L¹` radial
flux. Paired eta has exactly the zeta analytic order at every
nontrivial zero, and its normalized-bilinear flux on shrinking circles tends
to `2*pi` times the positive analytic multiplicity. The remaining frontier is
a global arithmetic cancellation or coercivity estimate for that flux inside
the complete live detector. The actual Gaussian boundary-heat weight is now
inserted into the literal eta quotient: finite selected flux windows recover
their exact heat-residue totals as the puncture radius shrinks, and these
limiting values converge to `2*pi` times the complete detector. Lean now
selects one positive common radius at each natural window height, proves every
selected integrand is simultaneously `L¹`, bounds the radius and flux error by
`1/(n+1)`, and proves the resulting single diagonal eta-flux sequence converges
to the complete detector. The chosen circles are now also proved to stay in
the positive eta half-plane and avoid its complete divisor. On those circles,
Lean proves exactly that the normalized radial quotient is one half the
radius times the radial derivative of `log |E|^2`. Genuine `L¹` integrability
transfers through this identity, and one sequence of finite heat-weighted
paired-eta log-norm variations converges to the detector. No arithmetic bound
forcing that variation to vanish has been proved. Lean now also constructs
the explicit finite paired-eta polynomials `E_N` and derivative polynomials
`D_N`, proves both converge locally uniformly on `Re s > 0`, and proves
`D_N / E_N` converges locally uniformly to the literal eta logarithmic
derivative on its exact zero-free domain. Lean now transfers this convergence
uniformly to every selected compact detector circle, proves the finite
denominators eventually stay nonzero and the finite radial integrands are
genuinely `L¹`, and selects growing truncations `N_n ≥ n`. The resulting
single sequence of finite paired-eta Dirichlet-polynomial flux windows
converges to the complete detector. On every selected finite denominator,
Lean now also proves the exact radial identity
`d/dr log |E_N|^2 = 2 Re(exp(i theta) D_N / E_N)`, transfers genuine `L¹`
integrability, and rewrites the complete diagonal limit as entirely finite
log-norm variations. No quantitative convergence rate or arithmetic bound
forcing that finite sequence to vanish is currently claimed.
Lean now also proves a domain-local Rouché comparison. Every nontrivial zeta
zero has an arbitrarily small positive-half-plane isolating circle on which
all sufficiently long finite eta sums are boundary-nonzero and their exact
logarithmic-derivative winding equals the genuine analytic zeta-zero
multiplicity. This preserves local divisor mass but supplies no global bound.
The nonzero winding is now converted into actual finite arithmetic roots:
for every nontrivial zeta zero, Lean selects growing indices `N_n ≥ n` and
zeros of `E_(N_n)` converging to that zeta zero with distance below
`1 / (n + 1)`. This is divisor persistence, not a zero-location estimate.
Lean now also identifies `E_N(s) / s` exactly with a finite positive-measure
Laplace partition function. Every positive-real-part finite eta zero obeys
exact exponentially tilted cosine and sine moment cancellations, and every
nonempty such zero has, after centering its support, total phase spread
strictly greater than `pi`. These constraints hold eventually along the
verified finite-root sequence converging to each nontrivial zeta zero. The
open problem is a global rigidity estimate strong enough to turn those
positive-measure cancellations into a zero-location restriction; the phase
bound alone decays like `1 / log N` and does not do so.
Lean now removes the truncation completely. It constructs the fixed measure
obtained by restricting Lebesgue measure to the disjoint union of all
`(log(2n+1), log(2n+2)]`, proves the complex Laplace kernel genuinely
integrable against it throughout `Re s > 0`, and proves its transform is
exactly paired eta divided by `s`. Thus every nontrivial zeta zero is an exact
zero of this one infinite positive-measure transform, and both of its complete
tilted Fourier moments vanish there. The live zero-location problem is now
literal rigidity of this explicit arithmetic measure, not passage from finite
roots to a limiting transform.
Lean now extracts the first direct zero-location inequality from that fixed
measure. The first interval gives an explicit tilted-mass lower bound, measure
domination gives the exact complete first-moment upper bound, and the
Lipschitz estimate for cosine turns exact cancellation into
`rho.re * (1 - exp (-rho.re * log 2)) <= |rho.im|` for every nontrivial zeta
zero. This unconditionally excludes real nontrivial zeros, but is far too weak
to force the critical line. The live task is to exploit more of the interval
arithmetic than this first-moment bound retains.
Lean now retains the quadratic cosine remainder and the complete second
exponential moment. It proves the strictly stronger threshold
`rho.re * sqrt (1 - exp (-rho.re * log 2)) <= |rho.im|`, together with its
equivalent squared form, at every nontrivial zeta zero. This is verified direct
progress beyond the first-moment estimate, but it remains vertical rather than
horizontal and therefore gives no approach to `rho.re = 1/2` by itself.
Lean now uses the functional-equation partner to reach the horizontal
direction. The same ordinate annihilates the fixed eta measure at tilts
`rho.re` and `1 - rho.re`. Their difference factors as an exponentially
damped hyperbolic sine. If `rho.re != 1/2`, sign normalization produces an
explicit density strictly positive on the complete eta support whose cosine
and sine moments both vanish at the zero's ordinate. This is a conditional
off-critical certificate, not an exclusion theorem. The live arithmetic task
is no longer left as a generic positive-measure question. Lean now partitions
the full positive half-line exactly into the eta support and its omitted
logarithmic gaps, identifies the complex horizontal kernel with that positive
density times its Fourier phase, and computes its full transform as
`2*a^2 / (((1/2+a)+I*y)*((1/2-a)+I*y))`. At every zeta zero the support
transform vanishes, so the gap transform must equal this rational value; it is
nonzero for an off-critical zero. The live task is a quantitative estimate
from the alternating logarithmic-gap geometry that contradicts this exact
target. No such estimate is currently proved.
The abstract gaps are now eliminated as well. Lean identifies them exactly as
the pairwise-disjoint intervals `(log(2n+2), log(2n+3)]`, proves the associated
interval Laplace series absolutely summable on `Re s > 0`, and proves that its
literal even-odd Dirichlet series is `1 - pairedEtaCore(s)`. Every nontrivial
zero and its functional-equation partner therefore make this gap series equal
exactly `1`; the horizontal gap transform is the complementary difference of
the two interval series and remains nonzero off the line. The live task is now
a termwise arithmetic estimate on these explicit intervals, not an abstract
support-complement argument.
Lean now has the first such finite estimate. For the first `N` support and gap
sums it proves exactly `E_N(s)+G_N(s)=1-(2N+1)^(-s)`. It realizes the remaining
eta tail as a restricted positive measure and obtains the closed bound
`||G_N(rho)-1|| <= (||rho||/rho.re+1)*(2N+1)^(-rho.re)` at every nontrivial
zero. Applying the same theorem to the functional-equation partner replaces
the exponent by `1-rho.re`; these decay exponents are distinct under the
off-critical hypothesis. This remains an upper-bound certificate, not an
exclusion. The live task is to prove a lower bound or sharp asymptotic that
couples the two complementary rates and cannot hold when they differ.
Lean now also extracts the Euler cancellation hidden by that absolute tail
bound. The support-minus-gap summand is the consecutive second difference
`(2n+1)^(-s)-2(2n+2)^(-s)+(2n+3)^(-s)`, its complete series is exactly
`2*E(s)-1`, and it equals `-1` at every nontrivial zeta zero. Solving this
identity together with the finite telescope gives exactly
`G_N(rho)-1=-(2N+1)^(-rho)/2+(-1-D_N(rho))/2`. The partner obeys the same
formula at exponent `1-rho.re`. The immediate analytic task is to prove that
the second-difference tail is smaller by one endpoint power. That expected
individual asymptotic is not itself a zero-location contradiction; the live
arithmetic task remains a rigorously proved coupling that cannot accommodate
both complementary off-line evaluations.
Lean now proves the required extra-power estimate rather than assuming it.
For every `Re s>0`, the Euler second-difference tail from cutoff `N` has norm
at most `2*||s||*||s+1||*(2N+1)^(-Re(s)-1)`. Hence every nontrivial zero obeys
the sharp bound
`||G_N(rho)-1+(2N+1)^(-rho)/2|| <=
||rho||*||rho+1||*(2N+1)^(-rho.re-1)`, and the partner obeys the corresponding
bound at real exponent `1-rho.re`. This rigorously confirms the research
warning: unequal raw-tail rates are the expected compatible endpoint
asymptotics, not a contradiction. Lean now packages the exact complex limit
`(2N+1)^s*(G_N(s)-G(s)) -> -1/2` and the corresponding positive scaled-norm
limit. A generic checked theorem proves that independent eventual two-sided
multiplicative comparability of two such raw errors forces their decay
exponents to agree. Applied to a zero and its functional-equation partner,
the explicitly defined complementary eta-gap comparison principle forces
`rho.re=1/2`. Conversely, RH makes every zero equal to its reflected partner,
so Lean proves that the global comparison principle is exactly equivalent to
Mathlib's literal `RiemannHypothesis`. No theorem proves either open direction;
comparability is conjecture-strength, not a routine estimate. The raw
cutoff-tail analysis is therefore exhausted as a source of contradiction.
Lean now begins the symmetry-aware pivot by proving an exact finite Gaussian
Gram identity for the actual first `2N` alternating eta atoms. Their genuine
Gaussian `L²` norm equals a completely explicit arithmetic double sum, and
the same checked theorem proves that sum real and nonnegative. This is generic
finite Gram structure and does not relate `sigma` to `1-sigma`. Lean now also
constructs the finite positive logarithmic eta measure and proves its Laplace
transform exactly equals `E_N(s)/s` away from the origin. A checked Fubini
exchange and Gaussian Fourier evaluation identify the Gaussian norm of this
normalized finite eta polynomial with the strictly positive double kernel
`sqrt(pi/tau)*exp(-sigma*(t+u))*exp(-(t-u)^2/(4*tau))` over two copies of the
eta measure. Lean proves all integrability hypotheses, nonnegativity, and the
fully expanded finite sum over pairs of support intervals. This remains
generic positive-Laplace structure and does not relate `sigma` to `1-sigma`.
Lean now differentiates that genuine double integral twice in `sigma`. Its
first derivative is exactly the negative first logarithmic-time moment and its
second derivative is exactly the positive second moment. For every nonempty
truncation at positive Gaussian time, both moments are strictly positive; the
raw Gram profile is therefore strictly decreasing and strictly convex. Lean
also proves the exact Cauchy--Schwarz moment determinant
`M_1(sigma)^2 <= G(sigma)*M_2(sigma)`, identifies the second derivative of
`log G` with its normalized nonnegative determinant, and proves global
log-convexity of the raw profile. These remain generic positive-Laplace facts.
Lean also proves that its values at `sigma` and `1-sigma` are equal exactly when
`sigma=1/2`. This is a closure interface, not the missing coupling: no theorem
derives the complementary equality from zeta, xi, or the finite eta zero
condition.
Lean now derives the correct completion rather than postulating it. For
`C(s)=s*(1-s)*GammaR(s)/(1-2*2^(-s))`, the actual function `C(s)*E(s)` is
proved locally equal to the entire xi normalization throughout
`0 < Re(s) < 1`, and the previously exposed regular correction is exactly
`C'/C`. Every iterated derivative inherits xi's functional-equation parity
and conjugation. At each nontrivial zero of arbitrary multiplicity `m`, Lean
uses the exact analytic order to eliminate every lower Leibniz term and proves
the completion-weighted leading eta derivatives at `rho` and
`1-conj(rho)` are exact conjugates up to `(-1)^m`. The corresponding norm
identity is also checked. This is the genuine completed local coupling, but it
is compatible with off-critical zeros and supplies no inequality between the
unweighted arithmetic moments.
Lean now proves that every logarithmic-time moment
`integral t^n*exp(-s*t) dmu(t)` of the fixed infinite eta measure is integrable
for `Re(s)>0`, and that it is exactly `(-1)^n` times the `n`th derivative of
the eta Laplace partition. At every nontrivial zero, that partition has the
full genuine zeta-zero multiplicity, all lower derivatives vanish, and the
leading moment is nonzero. The completed local coupling is therefore proved
as an explicit completion- and spectral-parameter-weighted relation between
the leading moments at `rho` and `1-conj(rho)` for arbitrary multiplicity.
Lean now splits every such moment into the explicit eta support and its
omitted logarithmic gaps, and proves the full positive-half-line value exactly
as `n!/s^(n+1)`. At a zero of multiplicity `m`, the gap moments equal the full
moment for every `k<m` and differ for the first time at `k=m`. The completed
partner identity is checked as an exact relation between these first nonzero
gap-moment defects. The next hard input must prove an independent quantitative
inequality for those explicit gap-interval defects that cannot hold at
complementary off-critical tilts.
Lean now expands every gap moment as an absolutely convergent sum over the
literal intervals `(log(2n+2),log(2n+3)]`. The positive real envelope is
computed as `n!/sigma^(n+1)`, and the first gap gives the strict saving
`(log 3-log 2)*(log 2)^n*exp(-sigma*log 3)`. This yields a checked one-sided
upper bound for the first nonzero defect at every zeta zero. It is not the
missing rigidity: the next hard input is a complementary-tilt comparison or
lower bound that combines with this saving to force `sigma=1/2`.
Lean now packages that nonzero leading defect canonically and combines its
first-gap bound with the exact completed partner symmetry. The two raw defect
norms have the exact reciprocal completion-weight ratio, while their common
positive completed magnitude is bounded by the explicit first-gap envelope at
both complementary tilts. This closes the purely symmetry-driven comparison;
the remaining hard input must be an independent matching lower bound or strict
tilt incompatibility that excludes `sigma != 1/2`.
Lean now retains phase through arbitrary finite support prefixes. For every
`0<theta<1`, it splits the full order-`m` moment exactly at any cutoff `N` and
bounds the literal tail by
`exp(-(1-theta)*sigma*log(2N+1))*m!/(theta*sigma)^(m+1)`. The resulting
nonnegative finite lower certificates converge to the exact nonzero defect
norm and are eventually positive. Their completed versions at complementary
zeros converge to the same positive magnitude while satisfying the opposite
first-gap upper bounds. The remaining hard input is now a uniform
tilt-separating estimate on these finite phase-sensitive prefixes; convergence
alone is compatible with an off-critical pair.
Lean now proves those finite order-`m` prefixes are signed iterated derivatives
of the genuine finite positive eta Laplace partition. It defines their full
complex completed partner residual, including parity and conjugation, and
rewrites it exactly as the two discarded support-tail errors. Its norm is
bounded by the sum of the two explicit completion-weighted `theta`-split tail
envelopes, so the complex residual tends to zero. This is the phase-sensitive
finite arithmetic target; the next hard input must obstruct that decay
uniformly away from `sigma=1/2`. The proved decay itself is compatible with a
hypothetical off-critical zero and is not such an obstruction.
Lean now also chooses the split as
`theta_N=(m+1)/(sigma*log(2N+1))` after its explicit admissibility threshold.
The resulting checked tail envelope retains the full exponent `sigma` with
only a `log(2N+1)^(m+1)` loss and tends to zero. Lean propagates this sharper
bound to the finite lower certificates and to the complete complex partner
residual at both complementary tilts. This improves the quantitative
interface but supplies no independent lower or phase incompatibility.
Lean now inserts the exact derived eta completion into the infinite positive-
measure Laplace energy. Pointwise in the open strip, the resulting weighted
energy is exactly `|xi(s)|^2`; hence the functional equation gives a checked
complementary equality between explicit weighted sums of squared tilted
cosine and sine moments of the same arithmetic measure. Arbitrary finite
Gaussian windows of this energy are genuinely integrable, nonnegative, and
exactly symmetric under `sigma ↔ 1-sigma`. The completion weight depends on
the ordinate, and both sides vanish at a zero, so a new eta-specific
coercivity or phase estimate is still required.
Lean now proves the corresponding Gaussian Gram identity directly for the
fixed infinite eta measure, including sigma-finiteness, joint domination,
both Fubini orders, and the Gaussian Fourier evaluation. The raw infinite
Gram is an explicit nonnegative double integral with kernel
`exp(-sigma*(t+u))*exp(-(t-u)^2/(4*tau))`. Combining it with the completed
symmetry gives an exact balance law: the raw Gram at `sigma` minus the raw
Gram at `1-sigma` is the common completed energy integrated against the
difference of the two reciprocal completion weights. There is no remainder;
the measure is nonzero and supported at strictly positive logarithmic time,
so Lean now proves this raw Gram is strictly decreasing in `sigma`. It follows
that the global distortion is positive left of `1/2`, zero exactly at `1/2`,
and negative right of `1/2`. This zero-centered sign law is unconditional but
does not constrain a zero. Lean now localizes the infinite Gram at an arbitrary
ordinate `gamma` and proves the exact arithmetic kernel is the positive
zero-centered envelope multiplied by `cos(gamma*(u-t))`. It connects the
localized complementary norm difference, the reciprocal-completion-weight
distortion, and the difference of the two oscillatory arithmetic kernels in
one checked identity. Positive cosine phase preserves strict antitonicity in
`sigma`; negative phase strictly reverses it. At every nontrivial zeta zero
the localized energy integrand vanishes at its center, but the full integral
has no automatic sign. Lean now quantitatively controls the phase loss:
`|cos x-1| <= x^2/2` and the Gaussian estimate
`d^2*exp(-d^2/(4*tau)) <= 4*tau` give an explicit product-measure bound
`|G_(sigma,gamma)(tau)-G_(sigma,0)(tau)| <=
sqrt(pi/tau)*2*gamma^2*tau*M_sigma^2`. Hence localization is an
`O(sqrt tau)` perturbation at short proper time, and the localized completion
distortion converges to the signed zero-centered distortion. This is genuine
phase control. Lean now also handles the zero-sensitive opposite limit: after
division by `sqrt(pi/tau)`, dominated convergence identifies the localized
norm at `tau -> infinity` with the exact squared eta partition value at its
center ordinate. At every nontrivial zero this limit vanishes at both
complementary tilts, and so does the normalized localized completion
distortion. This leading vanishing is compatible with off-critical zeros. The
first multiplicity-sensitive asymptotic is now complete. If the zero has exact
multiplicity `m`, Lean proves every product difference moment below order `2m`
vanishes and the order-`2m` moment is exactly
`(-1)^m * choose(2m,m) * |M_m(rho)|^2`. The Gaussian Taylor sign cancels this
sign, giving the explicit strictly positive coefficient
`choose(2m,m) * |M_m(rho)|^2 / (4^m*m!)`. A sharp global exponential Taylor
remainder, an integrable product-measure majorant, and dominated convergence
prove that this is the actual limit of `tau^m` times the normalized localized
eta Gram. The corresponding actual scaled completion-distortion limit is the
difference of the coefficients at complementary zeros. Lean proves that this
difference vanishes exactly when their explicit completion weights agree.
Lean now packages those weights into a nonvanishing analytic reflection
multiplier `B(s)` for the literal positive eta Laplace partition. It proves
`P(1-s) = B(s)P(s)`, the exact reciprocal and conjugation laws, and the
explicit spectral--Gamma--eta factorization of `B`. Its squared norm is the
complementary weight ratio, so the actual distortion coefficient vanishes
exactly when `|B(rho)|^2 = 1`; the critical line implies this condition. The
horizontal logarithmic derivative of `B` is now computed throughout the open
strip. Lean cancels its apparent endpoint poles using the digamma recurrence
and rewrites it as a symmetric shifted-digamma term plus two explicit dyadic
resolvents. The same-ordinate log norm is antisymmetric about `1/2`, and its
horizontal derivative is exactly the real part of this pole-free expression.
Lean now proves that real part strictly positive throughout the whole open
strip at every absolute ordinate at least `8`. Hence the same-ordinate log
norm is strictly increasing there, and `|B(s)|^2 = 1` is equivalent to
`Re s = 1/2` in this high-ordinate region. For every nontrivial zero satisfying
that explicit height hypothesis, vanishing of the actual first localized
distortion coefficient is therefore equivalent to the critical-line
equation. Lean now also computes the exact squared norm of `B(1+it)` on the
outer boundary. Away from `t=0` and the explicit dyadic resonances, it proves
that norm strictly greater than one for every positive or negative ordinate.
The low-height proof uses exact Taylor and hyperbolic inequalities plus a
rational polynomial certificate; the high-height proof is elementary. Lean
then constructs a holomorphic reciprocal extension `F` with `F=1/B` in the
open strip. The eta zeros fill every dyadic outer-boundary singularity, and
Lean proves `|F(1+it)|<1` for every real `t`. The high-ordinate multiplier
estimate controls the horizontal sides of the low-height rectangle. A checked
maximum-modulus argument, with strictness forced by `F(1)=0`, proves throughout
the entire open strip that `|B(s)|<1`, `=1`, or `>1` exactly as `Re s<1/2`,
`=1/2`, or `>1/2`. Thus the low-ordinate rigidity gap is closed. At every
nontrivial zero, vanishing of the actual first localized distortion
coefficient is now equivalent to the critical-line equation without a height
hypothesis. The remaining work must derive that vanishing, or equivalently
unit norm at zeros, from an independent arithmetic or phase constraint. That
open input may not be assumed.
Lean now transfers this complete multiplier sign law back to the literal
leading Gaussian coefficients. At every nontrivial zero `rho`, the partner-to-
original coefficient ratio is exactly `|B(rho)|^2`; consequently the partner
coefficient is smaller, equal, or larger exactly when `Re(rho)` is left of, on,
or right of `1/2`. The remaining target is therefore the independent equality
of these two positive arithmetic coefficients. The exact ratio and its sign
classification do not supply that equality.
The high-ordinate analytic estimate is now quantitative. Lean sharpens the
horizontal derivative of `log |B(s)|` to the uniform lower bound `1/200` when
`|Im(s)|>=8`, and the real mean-value theorem transfers it to
`(1/100)*|Re(rho)-1/2| <= |log(a(rho#)/a(rho))|` for the two positive leading
coefficients. This is a coercive interface: an independent arithmetic upper
bound on the logarithmic ratio would control zero displacement. No such upper
bound, and no independent equality, is currently proved.
Lean now supplies a first non-circular finite upper bound for that same ratio.
A phase-sensitive finite eta moment prefix minus its rigorous tail envelope is
a lower certificate `L_N(rho)`, while the first-gap estimate gives an explicit
upper envelope `U(rho#)`. Whenever `L_N(rho)>0`, Lean proves directly from the
raw moment definition that `a(rho#)/a(rho) <= (U(rho#)/L_N(rho))^2`; existing
convergence makes the positivity condition eventual. For a right-half zero at
absolute ordinate at least `8`, this yields
`Re(rho)-1/2 <= 100*log((U(rho#)/L_N(rho))^2)` eventually. This is a genuine
finite arithmetic certificate, but no theorem yet makes its right side zero
or asymptotically small enough to imply RH.
Lean now replaces the coarse partner envelope by a phase-sensitive
prefix-plus-tail upper certificate `V_N` as well. The two squared quotients
`(L_N(rho#)/V_N(rho))^2` and `(V_N(rho#)/L_N(rho))^2` eventually enclose the
exact coefficient ratio; both converge to it and their width tends to zero.
The cutoff-balanced near-sharp version retains the full horizontal exponent.
Lean then proves a necessary correction: every valid finite upper enclosure
is strictly above `1` for a right-half zero, including an on-line zero, because
prefix-plus-tail is strictly larger than prefix-minus-tail. Thus the proposed
one-cutoff target `upper_N<=1` is vacuous and must not be pursued. Define the
intrinsic self-slack
`delta_N=(V_N(rho)/L_N(rho))^2-1`; Lean proves `delta_N -> 0` and proves that
`upper_N(rho,rho#)<=1+delta_N` is exactly the finite comparison
`V_N(rho#)<=V_N(rho)`. For a zero in the closed right half-strip, eventual
validity of this near-sharp finite-upper monotonicity is equivalent to the
critical-line equation. No theorem currently proves the arithmetic direction
of that equivalence.
Lean now also exploits a fact absent from those uncentered certificates: at a
zero of multiplicity `m`, every eta logarithmic moment below `m` vanishes.
Recentring the leading moment at `a_N=log(2N+1)` therefore preserves it exactly
while changing the literal tail integrand from `t^m` to `(t-a_N)^m`. A checked
translation of the Gamma integral yields the unconditional envelope
`exp(-Re(rho)*a_N)*m!/Re(rho)^(m+1)`, with no logarithmic-power loss and no
cutoff condition. It is strictly smaller than the balanced near-sharp bound
whenever the latter is valid. The centered finite lower and upper certificates
enclose the exact nonzero defect for every cutoff, converge to it, and have
width at most twice this new envelope. This sharpens the arithmetic interface;
it does not provide the missing complementary sign constraint.
The centered prefixes are now also coupled through the completed functional
equation. Lean defines their full complex finite partner residual and rewrites
it exactly as a signed sum of the two literal centered support tails, retaining
completion factors, parity, conjugation, and phase. Its unconditional envelope
is the sum of the two completion-weighted centered Gamma tails, tends to zero,
and is strictly below the older near-sharp completed-residual envelope whenever
both former cutoffs apply. This closes the representation step; decay alone is
compatible with an off-line zero, so the open step is an independent
eta-specific phase or sign theorem for this exact residual.
Lean also polarizes the completed finite prefix norm defect exactly as the
residual norm square plus twice the real cross-phase between the original
completed conjugate prefix and the residual. Consequently a negative norm
defect requires a strictly negative cross-phase; the nonnegative
residual-energy term cannot supply it.
Lean now translates every discarded centered tail by
`a_N=log(2N+1)`. The resulting measure is proved almost everywhere supported
on `u>0`, and the relevant Laplace and separated Fourier--Laplace integrands
are proved absolutely integrable. At `rho` and `1-conj(rho)`, the two tails are
exact complementary real tilts `rho.re` and `1-rho.re` of this same measure at
one Fourier frequency. Conjugation is reduced to frequency reversal and the
single relative cutoff phase `exp(2*I*rho.im*a_N)`. The completed residual is
exactly a common unit phase times one named coupled core, so their norms are
equal. Lean further combines the two moments into one absolutely integrable
function on that common measure. After extracting the critical half-tilt its
pointwise form is
`u^m*exp(-u/2)*(A_N*exp(delta*u)*exp(-I*gamma*u)
+B_N*exp(-delta*u)*exp(I*gamma*u))`, where
`delta=rho.re-1/2`. The residual norm is exactly the norm of this single
interference integral.
Lean now exploits the literal alternating interval geometry across cutoffs.
Writing `Delta_N=log(2N+3)-log(2N+1)`, the shifted tail measure at `N` is
exactly Lebesgue measure on its first interval `(0,w_N]` plus the shifted tail
at `N+1` translated by `Delta_N`, with `0<w_N<Delta_N`. Every shifted moment
therefore obeys an exact finite binomial transport formula. The completion and
phase factors align across both complementary tilts, producing a triangular
work law for the actual residual. Lean now closes that lower-order hierarchy:
for every `j<m`, vanishing of all complete eta moments through order `j`
forces the centered tail to be exactly the negative of its literal finite
centered prefix, at both complementary zeros. Hence
`R_N-R_(N+1)=head_(m,N)+sum_(j<m) choose(m,j)*Delta_N^(m-j)*P_(j,N+1)`,
where the head is supported on the single explicit interval `(0,w_N]` and
every `P_j` is a finite eta-prefix coupling with the original completion,
parity, conjugation, and phase data. No lower-order infinite tail remains.
The present sign-bearing target is an eta-specific coercive estimate or
cancellation law for this completely finite arithmetic identity. A valid next
step must retain the distributional zero contributions in any Green or
integration-by-parts argument; erasing them would merely erase the detector.
These estimates are not RH and do not exclude a finite or sparse off-line
divisor; a restatement, hidden limit interchange, or conditional implication
is not a substitute.
Lean has since isolated the top transported term, represented its remaining
prefix as one shifted-tail interference integral, and squared it into an exact
Hermitian Gram identity. Splitting that integral into the two complementary
components proves that the cross-phase defect is already bounded at the full
endpoint scale; the sole remaining target is the squared difference of their
magnitudes. The sharp centered-tail theorem now gives both component limits.
For every hypothetical zero with `Re(rho)>1/2`, the slower partner-normalized
amplitude difference tends to an explicit positive constant, and Lean proves
that the exact endpoint-scaled squared difference tends to positive infinity.
Thus the current frontier is an independent eta-arithmetic theorem forcing
that endpoint-scaled difference to remain bounded. Its off-line divergence is
proved; the required arithmetic boundedness is not.
Lean now also packages a Hilbert-space alternative. The squared magnitude
mismatch is invariant under the reflected partner, is identically zero at
every critical-line zero, and is nonsummable over cutoffs at every off-line
zero by the sharp odd-endpoint p-series threshold. Its local summability is
therefore equivalent to `Re(rho)=1/2`, and universal summability is explicitly
proved equivalent to RH. This is an equivalence, not progress on its open
direction. The concrete new research target is an eta-specific Gram, Bessel,
or orthogonality argument establishing that literal finite-arithmetic
summability without using zero locations.
Lean now removes the apparent infinite-tail and nonlinear-norm barriers from
that target. Lower-moment vanishing rewrites both component magnitudes as
literal completion-weighted finite centered prefixes. Their magnitude
difference is exactly the signed difference of their squared energies divided
by their total amplitude, even when that denominator is zero. The signed
energy numerator also equals the nonnegative top-prefix Gram energy plus one
explicit polarized cross phase. Hence the live target is square-summability of
this normalized signed finite energy defect; its arithmetic proof remains
open.
Lean now further collapses every binomially defined centered finite prefix to
one literal centered integral over the finite positive eta logarithmic
measure. The two completion-weighted complementary finite terms are integrals
of explicit integrable features on that common measure. Their signed energy
difference is exactly one integrable real rank-one Gram kernel over the product
measure, with every Fubini and conjugation step checked. Thus the live target
is square-summability of this signed finite eta Gram integral divided by the
total finite amplitude. The representation is unconditional; the summability
estimate remains conjecture-strength.
Lean now gives this finite Gram energy an exact consecutive-cutoff transport.
Its one-step work is the signed energy of the partner and conjugate increments
plus two explicit cross-flux terms against the successor features. A checked
absolute estimate contains only those increment energies and flux norm
products. Both component amplitudes tend to zero, so the work telescopes and
its ordered tail sums recover the signed energy, the normalized defect, and
the amplitude mismatch. The open target is a weighted eta-specific
summability or coercivity estimate for this local ledger; no sign for the flux
is currently proved.
Lean now removes the abstract consecutive differences from that ledger. Every
absolute-coordinate centered eta tail satisfies the exact head-interval plus
binomial successor-tail transport. Below the analytic zero multiplicity,
complete-moment vanishing changes all successor tails into literal finite
prefixes and cancels the top order. Both partner and conjugate energy
increments are therefore explicit completion-weighted works containing one
negative new support interval and only strictly lower-order successor
prefixes. The checked absolute energy-work bound has been rewritten entirely
in terms of these finite arithmetic increments and their successor fluxes.
Lean now proves those two component-increment series absolutely summable at
every nontrivial zero. The exact cutoff-shift asymptotic supplies the additional
endpoint power for the head and every lower-prefix transport term. Consequently
the increment energies, successor cross-flux products, and absolute signed
energy work are summable, and every energy tail has a genuine `HasSum`
reconstruction. This unconditional result is not the RH criterion: the total
amplitude in the normalized defect tends to zero. The current frontier is a
weighted coercivity or cancellation estimate that controls the quotient
`E_N / S_N` strongly enough to make its square summable without assuming zero
locations.
Lean now isolates the exact first weight needed for that strengthening. A
generic weighted-tail theorem applied to the absolute `HasSum` reconstruction
shows that summability of `(2N+1) * |J_N|` forces
`(2N+1) * |E_N| -> 0`. The amplitude imbalance is pointwise bounded by
`|E_N|`, while its checked sharp asymptotic diverges at this endpoint scale for
every off-line zero. Hence the weighted work series is summable exactly on the
critical line, and its universal summability is equivalent to RH. Treat this
as a reduction: the live arithmetic task is to prove the first-moment bound
without assuming zero locations, not to cite the equivalence as progress on
that open direction. Lean now discharges the local increment-energy portion
of that task. The literal extra cutoff-shift power proves both component
increments have summable `(2N+1)`-weighted squared norms, hence their signed
increment energy has a finite first absolute moment unconditionally. Since
`J_N` is exactly that increment energy plus the successor cross flux `F_N`,
the weighted flux series is summable exactly when the weighted work series is.
Thus the remaining RH-equivalent arithmetic target is specifically
`sum_N (2N+1) * |F_N| < infinity`: an eta-specific cancellation or coercivity
estimate for the successor coupling. Lean now realizes `F_N` exactly as the
integral of one explicit real Hermitian kernel over the finite positive eta
logarithmic measure. The kernel pairs the head-plus-lower-prefix arithmetic
increment with its completed successor feature. Its phase-free envelope is
integrable, dominates it pointwise, and gives a nonnegative cancellation
reserve satisfying `|F_N| + reserve_N = integral envelope_N`. Partner
reflection swaps the components and makes the signed energy, increment
energy, work, and flux odd; the absolute flux is invariant. The open estimate
is therefore the first moment of these literal finite kernel integrals. Do not
replace it by summability of the phase-free envelope: that loses precisely the
cross-component and within-integral phase cancellation that the proof needs.
Lean now splits each explicit finite work into its unique slow term and a
remainder. At multiplicity one the negative head is the slow term. At every
higher multiplicity it is the single top lower-order transport term, with
exactly one factor of `Delta_N`; the head and every strict lower term left in
the remainder have shift degree at least two. The two endpoint decays then
prove unconditionally that `sum_N (2N+1) * |R_N| < infinity` for the completed
remainder flux. Since `F_N = L_N + R_N`, Lean proves that the leading-flux
first moment is summable exactly when the full flux first moment is, locally
exactly on the critical line and universally exactly under RH. This is still
a reduction. The current open theorem is the eta-specific cancellation or
coercivity estimate for the isolated degree-one leading current `L_N`.
Lean now realizes that current by an exhaustive literal kernel construction,
without a simplicity assumption. If the analytic multiplicity is one, `L_N`
is the integral of a real kernel on the translated new-head measure times the
successor finite eta measure. If the multiplicity is at least two, `L_N` is
the integral of the degree-one-shifted Hermitian kernel coupling the order
`m-2` and order `m-1` centered features on two copies of the successor finite
eta measure. Integrability and both exact integral identities are checked.
The multiplicity-selected integral equals `L_N` for every zero and cutoff;
its first-moment summability is locally equivalent to the critical line and
universally equivalent to RH. The live arithmetic task is therefore to
control these explicit boundary-head and adjacent-moment kernels, not a hidden
abstract increment. Lean now factors the higher-multiplicity adjacent kernel
pointwise into a strictly positive cutoff scale, an almost-everywhere strictly
negative odd centered monomial, one cosine phase, and one complementary
horizontal-tilt bracket. The bracket is identically zero on the critical line;
off the line it has one explicit crossover, with its sign completely fixed by
the oriented distance from that point. The sum coordinate of the finite
product support lies in the proved window `(0, 2*a_(N+2))`. Consequently the
remaining higher-multiplicity cancellation can only come from the cosine and
this single horizontal crossover. Controlling their integral arithmetically,
without importing zero-location information, remains open.
Lean now also places the two completed finite-prefix terms in an exact
two-dimensional hyperbolic coordinate system. After the existing parity is
aligned, partner reflection swaps the two terms through conjugation; the even
coordinate is conjugation-even and `I` times the odd coordinate is likewise
sent to its componentwise conjugate. The signed finite eta energy is exactly
the Hermitian quadratic form of this feature against one fixed `2 x 2`
signature matrix. The corresponding complex-symmetric conjugate-pair block is
proved to be a positive rank-one real block minus a positive rank-one
imaginary block. Lean separately proves that the ordinary Hermitian Gram pair
has a plus sign and is positive semidefinite, preventing those two
constructions from being conflated. This is the eta-specific seam for the
finite-window rank/inertia strategy suggested by the zeta23 architecture.
The next legitimate step is to aggregate these features over finite cutoff and
zero windows and derive trace/Frobenius information from the literal eta
arithmetic; abstract rank bounds alone do not control the open current.
Lean now performs that first aggregation without introducing abstract zero
data. Any finite cutoff family is packed into one feature on `d × Fin 2`, every
cutoff slice retains the exact signed eta energy, and the packed feature obeys
the literal conjugate-partner law. Over the project's genuine symmetric
finite spectral zero windows, with analytic multiplicity, the resulting
complex-symmetric matrix splits exactly as
`onLine + (offReal - offImag)`. The three named blocks are proved positive
semidefinite where appropriate, and the complete matrix is Hermitian. The
rank layer is now also internal: each literal outer-product summand has rank
at most one, giving separate bounds for the full, on-line, off-line real, and
off-line imaginary blocks by their genuine zero-window cardinalities.
Reflection proves the exact count `#full = #critical + 2 * #upper` on every
nonnegative symmetric window. Lean now closes the corresponding inertia
layer as well. A directly checked positive-spectral-subspace argument proves
`n₊(P-N) ≤ rank(P)` for positive semidefinite `P,N`. Hence the actual
off-line hyperbolic block has positive index at most `#upper`, and the complete
eta window satisfies `n₊(full) ≤ #critical + #upper`. The next sharply
separated layer now has exact scalar identities as well. The on-line real
trace is the multiplicity-weighted squared norm of the packed eta features;
the off-line trace is the explicit real-coordinate mass minus
imaginary-coordinate mass. The complete squared Frobenius mass is an
entrywise sum of squared norms of coherent multiplicity-weighted zero sums.
All are finite and literal. Lean now also adapts the attributed Apache-2.0
rank--trace theorem from Anthropic's zeta23 development and applies it to the
actual decomposition with the on-line block as `P` and the off-line
difference as `Q`. For every `c > 0`, the resulting checked inequality is
`c*M_on - (c^2/4)*#critical + 2*c*M_off - c^2*#upper ≤ F`, where `F` is the
literal coherent Frobenius mass. At `c=2` this becomes
`2*M_on + 4*M_off - 4*#upper - F ≤ #critical`. Thus the finite zero-side
linear-algebra closure is instantiated, not merely abstract. The remaining
obligation is to obtain estimates for this ledger from the eta arithmetic
without replacing the coherent sums by phase-free termwise bounds. The
rank--trace theorem itself is still infrastructure, not the missing
arithmetic estimate. Lean now also specializes the multiplicity-aware
rank--trace refinement. Critical-line reflection makes the on-line
complex-symmetric block exactly the required positive Gram matrix. For
`x_rho = m_rho*||v_rho||^2` and
`k_c(x)=c^2-max(c-x,0)^2`, the checked literal ledger is
`2*c*(M_on+M_off)-F ≤ sum_(rho critical) k_c(x_rho)+c^2*#upper`.
At `c=2` this retains one nonlinear term for every actual critical zero,
including its analytic multiplicity and packed eta feature norm. No bound on
that sum or on `F` is inferred. This exhausts the imported finite-dimensional
rank--trace layer. Lean now expands the literal coherent Frobenius mass exactly
as the double genuine-zero sum
`sum_(rho,sigma) m_rho*m_sigma*Re(<v_sigma,v_rho>^2)`. This is a signed
phase-preserving pair correlation, not a sum of absolute squares. It exposes
the diagonal and cross-zero interference on which an eta-arithmetic estimate
must act, but supplies no such estimate. Further progress must prove
cancellation or coercivity for this named finite pair correlation without
discarding its complex phase, or connect it to an independently controlled
arithmetic form. Lean now separates that sum exactly as `F=D+O`, where
`D=sum_rho m_rho^2*||v_rho||^4` is nonnegative and `O` is the same signed
phase-bearing correlation restricted to distinct ordered pairs. Frobenius
positivity gives the sharp formal floor `O >= -D`. The multiplicity-aware
`c=2` ledger is now written directly with `-D-O`, so `O` is the only
cross-zero term left in the finite inequality. The required aggregate bound
on this ledger remains open; the algebraic floor alone gives no zero-location
constraint. Lean now opens each packed-feature correlation into the two
literal completed finite-prefix channels `P` and `Q`. The even/odd
hyperbolic construction proves exactly
`<v_sigma,v_rho>=2*sum_j(conj(P_sigma,j)P_rho,j+
conj(Q_sigma,j)Q_rho,j)`; every mixed `P`--`Q` term cancels algebraically.
Consequently both `D` and `O`, and the full multiplicity ledger, are expressed
in same-channel completed eta-prefix variables. This is the first
eta-arithmetic refinement of the zero-pair ledger, but it remains an identity:
no signed distinct-zero estimate is inferred. The two surviving channels are
now further compressed to one original completed finite-prefix channel
`A_rho,j`. Its ordinary Gram kernel
`H_sigma,rho=sum_j conj(A_sigma,j)A_rho,j` satisfies Hermitian swap symmetry.
Lean proves the partner channel is `A_(rho#),j`, the aligned channel is
`conj(A_rho,j)`, and hence the packed correlation is exactly
`2*(H_(sigma#),(rho#)+conj(H_sigma,rho))`. The diagonal, off-diagonal,
coherent mass, and multiplicity ledger are all rewritten through this one
kernel and its reflected copy. Controlling the signed squares of that
reflection coupling remains open. Lean now factors the original channel as
`A_rho,j=W_rho*M_rho,j`, where `W_rho=C(rho)*rho` is the fixed completed
spectral weight and `M_rho,j` is the literal order-`m_rho-1` cutoff-centered
finite eta moment. Its Gram kernel is therefore
`H_sigma,rho=conj(W_sigma)W_rho*B_sigma,rho`, with the purely finite
arithmetic kernel `B_sigma,rho=sum_j conj(M_sigma,j)M_rho,j`. The complete
feature correlation, diagonal, off-diagonal mass, and ledger are rewritten
with the `W` factors explicit. The live estimate is now concentrated in the
reflection coupling of the finite arithmetic kernels `B`. Every centered
moment is now also expanded exactly into its retained logarithmic interval
integrals, making `B` a literal finite cutoff/interval triple sum. The same
expansion is propagated through both masses and the terminal ledger; the open
problem is a signed estimate for this explicit interval correlation, not an
additional algebraic unpacking step. Lean now also evaluates each interval by
an explicit finite integration-by-parts polynomial: every atom is an
odd-endpoint complex power minus an even-endpoint complex power with literal
logarithmic coefficients. The terminal ledger therefore has a fully finite
arithmetic endpoint form. The next live experiment is an aggregate
separated-frequency estimate on that form, while retaining the signed
zero-pair phase. Lean now proves the full generalized Montgomery--Vaughan
weighted Hilbert inequality internally: `mvDiag_thirteen` gives the diagonal
constant `13`, and `mvHilbert_twentySix` gives the bilinear constant `26`.
Lean further proves that the first `K` literal eta frequencies `log(k+1)` are
injective with admissible uniform gap `1/K`, and specializes the bilinear
theorem as `pairedEtaFiniteLog_mvHilbert_twentySix`. This closes the elementary
frequency-spacing side but is not yet an estimate for the eta ledger. The next
matrix-hybrid layer is now concrete as well. Advancing every member of an
arbitrary packed cutoff family by one gives an exact matrix work identity for
the genuine multiplicity-weighted zero-window block: the block difference is
the arithmetic feature-increment outer product plus both successor cross
terms, entry by entry. Lean identifies that feature increment with the existing
head-plus-prefix arithmetic increment and proves its leading/remainder split
in both hyperbolic coordinates. Lean now transports this split through the
full matrix current. For each genuine zero, both the leading current and the
collection of all terms containing a remainder factor as a sum of two literal
outer products, hence have rank at most two even after analytic multiplicity.
Their complete window sums have rank at most twice the number of represented
zeros, and their sum is exactly the original matrix work. The outer products
remain the project's complex-symmetric transpose products; no complex-linear
Hermitian compression is inferred. Lean now adds a continuous Gaussian
proper-time layer without making that identification. The kernel matrix
`exp(-u*(lambda_i-lambda_j)^2)` is proved positive semidefinite for `u>0`, and
its quadratic form is exactly the previously checked finite Gaussian
arithmetic double sum after the proved positive rescaling. Schur compression
therefore preserves every positive eta constituent. At the literal packed
cutoff nodes `log(2*N+1)`, Lean proves the explicit entrywise heat derivative,
commutation with the genuine multiplicity-weighted zero sum, preservation of
the on-line plus off-line-real minus off-line-imaginary decomposition and
Hermitian symmetry, and commutation with the complete leading/remainder matrix
work law. These are finite identities; no infinite operator or cancellation
estimate is inferred at that stage. Lean now closes the finite kernel-transform
bridge in two exactly equivalent parameterizations. For every nonzero gap
`Delta`, both the oriented square-root heat integral and the direct odd
proper-time integral `integral Delta*exp(-u*Delta^2) du` are proved exactly
equal to `Delta⁻¹`; coincident-frequency entries are explicitly zeroed before
integration, so the nonintegrable diagonal is not silently totalized. The
direct kernel reverses sign under index swap. Applied to any complex-symmetric
matrix it therefore yields a checked skew-symmetric transform, retaining the
ordered channel colour. The Gaussian kernels and compressions obey their
exact additive semigroup laws. The first `K` centered eta cutoff nodes
`log(2*N+1)` are injective and uniformly separated by `1/(2*K)`, and the
checked Montgomery--Vaughan constant-26 bound is proved directly for both heat
representations. Lean now applies that inequality blockwise to the two literal
transpose outer products in each genuine zero's leading current, including
analytic multiplicity. The complete finite-window block is the exact complex
signed zero sum before the triangle inequality, with an explicit sum of
constant-26 envelopes. The aggregate transform is skew-symmetric: both
same-colour block sums vanish and the two mixed-colour blocks are negatives.
Lean now opens the surviving `0,1` block back into the literal completed eta
colours. If `p,q` are the partner and aligned leading increments and `P,Q`
their successor features, every zero contributes exactly
`2*I*m_rho*(H(q,p)+H(q,P)+H(Q,p))`, where `H` is the direct odd-heat transpose
form. All partner--partner and aligned--aligned terms cancel algebraically.
The same reduction is now proved before time integration. At every proper
time, the complete window is the exact complex signed sum of the corresponding
three-colour forms; the full matrix trajectory is pointwise skew, and the
same-colour blocks vanish pointwise. Lean then proves that the reciprocal-gap
Hilbert block is the positive-time integral of this richer scale-resolved zero
sum. Thus the Gaussian--Hilbert bridge and rank-two coefficient interface are
closed without discarding orientation, phase, channel, or heat-scale data.
The abstract finite Hermitian spectral layer now has its own continuous
signed heat carrier. Lean proves the `u^(-1/2)`-weighted signed current
integrable, its normalized integral exactly equal to `n_+ - n_-`, and the
ordinary heat trace convergent to the zero index. Positive inertia is therefore
reconstructed exactly from the continuous observables. This is not yet an eta
or zeta theorem. The finite projection layer now names the ordered cross-scale
leakage before any inequality, factors it as a transition Gram, and proves
that adjunction reverses scale order. A second projection retains two distinct
loss channels: compressed first-projection leakage and finite-compression
leakage. Their exact two-stage matrix and trace ledgers, same-scale positivity,
and transition Frobenius identities are checked. The next hybrid interface
now feeds the literal multiplicity-weighted eta zero-window matrix into the
complete spectral heat and signed spectral heat flows. Lean proves the exact
signature integral, nullity limit, positive-inertia reconstruction, and the
continuous form of the existing `#critical + #upper` eta inertia bound. This
does not yet improve the zero proportion. The next slice must wrap the checked
cross-scale carrier around this literal eta heat flow. That finite coordinate
instantiation is now checked: every decidable packed cutoff/colour selection
is a Hermitian idempotent projection, the ordered leakage is opened into the
literal sum over omitted coordinates, and the same matrix remains an exact
transition Gram with scale-reversing adjoint, same-scale positivity, Frobenius
trace identity, zero criterion, and mass-balance ledger. This is not the
infinite eta-support projection. The next work must evaluate the retained
spectral-heat path entries arithmetically and measure their effect on the
multi-scale certificate ceiling before any further collapse.
The literal eta window now also carries every matrix-valued spectral heat
moment `A^k exp(-uA^2)`. Lean proves the exact order/scale product law,
even-order positivity, the derivative hierarchy `dH_k/du=-H_(k+2)`, and a
positive-semidefinite Gram matrix for arbitrary finite families of orders and
scales. Each Gram entry is simultaneously a combined higher moment and the
trace product of the two separate flows. Their zero-scale boundary is now
connected exactly to the existing eta arithmetic ledger: `H₀(0)` is the
packed coordinate dimension, `H₁(0)` is the on-line plus signed off-line
trace mass, and `H₂(0)` is the fully evaluated endpoint diagonal plus signed
off-diagonal correlation. The last quantity is also the negative initial
derivative of the ordinary eta heat trace. Positive heat times, genuinely
mixed scales, and the transition paths remain unevaluated. The next gate is
to evaluate or sharply bound those retained quantities, then solve the
resulting certificate extremal problem without assuming the desired
zero-location conclusion.
The abstract degree-four ceiling experiment is now exact. For any finite
nonnegative weighted spectral model with moments `(1, 1, 4/3, 2, 13/4)`, Lean
uses the explicit Christoffel witness `1-(7/4)x+(2/3)x²` to prove zero mass at
most `5/36` and certificate at least `13/18`. A checked nonnegative three-atom
model attains equality, so those five moments alone have a sharp ceiling below
one. They are also exposed as the zero-scale jet of a continuous weighted heat
hierarchy. This is not an eta instantiation. Future work must derive the extra
moments or positive-scale heat data from literal eta arithmetic and show that
they exclude the sharp model before claiming a stronger zeta-zero proportion.
The quadratic witness is now also transported through heat time as the exact
linear combination of orders zero through four at one common scale. Its
certificate is monotone from `13/18` and converges to the exact model
certificate. The sharp three-atom model nevertheless remains exactly at
`13/18` for every nonnegative scale because both nonzero atoms are roots of
the witness. Therefore reweighting the same collapsed channel by heat is not
new information. The next observable must be eta-backed and nonvanishing on
at least one sharp root channel; a separate heat trace, signed current, or
genuine cross-scale correlation is admissible, but its arithmetic value must
be proved rather than postulated.
The independent ordinary heat channel now has an exact separator theorem.
The first-moment normalization forces `H₀(u)` strictly above zero mass at
every finite scale, while `H₀(u)` converges to zero mass at infinity. Hence
the certificate is strictly above `13/18` exactly when some nonnegative scale
has `H₀(u)<5/36`. The sharp three-atom model stays strictly above this
threshold at every finite scale. The next arithmetic gate is therefore not
another abstract reweighting: it is construction of the correct normalized
eta model plus a proved ordinary-heat crossing, or another independent
observable with a comparably explicit separator criterion.
The literal eta positive-time hierarchy now retains its complete matrix-power
carrier. Lean proves a genuine convergent `HasSum` expansion
`H_k(u) = sum_m (-u)^m/m! * rtrace(A^(k+2m))` for every Hermitian matrix and
instantiates it on the multiplicity-weighted eta zero-window block. In
particular, the independent ordinary eta heat trace is the exact series of all
even coherent matrix-power traces. This removes any hidden positive-time
spectral collapse, but only powers zero through two currently have explicit
eta arithmetic evaluations. The next information-preserving step is to open
the higher powers as literal closed eta paths and obtain a normalized crossing
or obstruction from those signed correlations.
That path expansion is now checked. For every finite matrix Lean recursively
retains every ordered intermediate coordinate and proves the closed-path sum
equal to the corresponding power trace. Each eta edge is then opened as the
literal complex multiplicity-weighted zero-window sum of completed finite eta
features. The ordinary eta heat trace is a genuine convergent series of all
even closed path correlations, with cutoff, colour, phase, multiplicity, and
path order intact. Its length-two coefficient is proved exactly equal to the
existing endpoint diagonal plus signed off-diagonal arithmetic mass. Higher
path estimates remain open; applying absolute values edgewise would discard
the new information and is not an acceptable substitute.
The first higher projection path is now explicit as well. The product of three
coordinate-compressed eta heat flows is the longer-time compressed flow minus
three separately named channels: first-gap, second-gap, and two-gap. Lean
opens each entry as its ordered retained/omitted double path sum. At equal
scale the two one-gap paths are adjoints with equal real trace, while the
two-gap path factors through the complementary compressed heat as a positive
weighted transition Gram and is positive semidefinite. The live estimate must
use cancellation in the paired one-gap trace together with the nonnegative
two-gap reserve; bounding both one-gap paths separately by norms would undo
the purpose of this slice.
The phase-separation route now has its first checked rigidity theorem. For any
finite set of distinct unit-modulus complex modes, Lean proves that a linear
combination of their geometric sequences can converge to zero only when every
coefficient vanishes; equivalently, those full sequences are linearly
independent. The proof uses repeated shift differences and preserves the
complex phase. Lean now connects this abstraction to literal eta arithmetic:
for every odd base `q > 1`, the cutoff `(q^n-1)/2` tends to infinity, its odd
endpoint is exactly `q^n`, and the sharp complex eta-tail normalization becomes
the `n`th power of one fixed mode. At every nontrivial zero the literal
multiplicity-minus-one centered prefix inherits an explicit nonzero complex
geometric asymptotic. Lean now proves that any two distinct frequencies can
collide at at most one prime base. Thus every finite injective frequency family
admits an odd prime base at which all normalized modes are distinct, with a
specialization to every finite same-real-part zeta-zero layer. The raw inverse
decay mode now restores the real coordinate as its exact norm. Lean proves that
one odd prime separates these raw modes across an arbitrary finite zeta-zero
window, and that their first window-cardinality coordinates form a
nonsingular Vandermonde matrix. Lean now transfers that finite limiting block
through the sharp complex asymptotics. For every finite zeta-zero window, one
odd prime base makes all sufficiently late square matrices of literal
multiplicity-aware centered eta prefixes nonsingular. This establishes a 100%
raw finite information-separation carrier. Lean now transports that carrier
into the actual completed two-channel hyperbolic features: the original
channel is a nonzero completion-row scaling of the literal prefix matrix, the
aligned channel is its entrywise conjugate, and one fixed complex-linear
projection recovers the aligned channel from every packed even/odd feature.
Consequently, for every finite zeta-zero window, one odd prime makes all
sufficiently late packed certificate features linearly independent. Lean now
retains analytic multiplicity by scaling every zero column with its positive
square-root multiplicity and forms the corresponding coordinate matrix times
its conjugate transpose. This matrix is exactly the sum of the literal
multiplicity-weighted Hermitian outer products `v v*`, is positive
semidefinite, and eventually has rank equal to the number of represented
distinct zeros. It remains rigorously distinct from the complex-symmetric
`v vᵀ` block used by the signed inertia certificate. Lean now couples the
two without identifying them. On every nonnegative symmetric spectral window,
the Hermitian Gram is exactly `onLine + offReal + offImag`, whereas the signed
block is `onLine + offReal - offImag`. Hence their difference is exactly twice
the positive imaginary off-line block and their sum is twice the positive
on-line-plus-real block; both are positive semidefinite. At the same eventual
geometric blocks, the Hermitian Gram retains full represented rank. Pulling the
same multiplicity-weighted synthesis matrix `C` back to zero-index space now
gives the square metric `K = Cᴴ C`. Actual packed-feature linear independence
makes `C` injective, so Lean proves that `K` and `K⁻¹` are both positive
definite for one odd prime and every sufficiently late block. Lean now pulls
the signed coordinate block back as `B = Cᴴ Signed C`. Congruence gives
`K² - B` and `K² + B` positive semidefinite, and normalization by `K⁻¹`
produces a Hermitian matrix `A = K⁻¹ B K⁻¹` with both `I - A` and `I + A`
positive semidefinite. One odd prime makes this contraction conclusion hold
at every sufficiently late block of each nonnegative finite spectral window.
Lean now determines this normalization exactly. Critical-line reflection
induces a permutation matrix `P` on the enumerated window, the actual synthesis
obeys `P Cᴴ = Cᵀ`, and the signed coordinate block is `C Cᵀ`. Therefore
`B = K P K` and complete two-sided whitening gives `A = P`. In particular,
`A² = I` and its trace is the number of fixed reflection indices. This proves
that full whitening cancels all eta amplitudes and cannot be the arithmetic
observable by itself. The next obligation is to retain the coupled pair
`(K,P)` through mixed traces, one-sided normalization, or an equivalent
information-preserving construction. Lean now checks the first scalar layer:
`m₀ = Re tr(K)` is exactly the positive Hermitian eta trace and
`m₁ = Re tr(PK)` is exactly the signed eta trace. Their difference is twice
the imaginary off-line mass and their sum is twice the on-line-plus-real mass,
so `-m₀ ≤ m₁ ≤ m₀`; on nonempty separated windows `m₁/m₀ ∈ [-1,1]`.
Lean now retains the higher powers and first cross-scale version as well. For
geometric blocks `n,m`, the carrier `Mₙₘ = P(Cₙᴴ Cₘ)` is exactly `Cₙᵀ Cₘ`,
has `Mₙₘᵀ = Mₘₙ`, and exposes literal multiplicity-weighted eta correlations
entrywise. At equal scales every `Re tr((PK)^r)` is the real part of a complete
ordered closed zero-index path sum; order zero is the distinct-zero count and
order one is `m₁`. The two-step cross-scale word is a checked symmetric
double-edge sum. The next obligation is to prove the positive normalization
needed to place these moments inside the finite certificate model. Lean now
constructs the exact packed-coordinate support for that step. The literal
Hermitian carrier is `S=CPCᴴ`, while `Q=CK⁻¹Cᴴ` is positive semidefinite,
Hermitian, and idempotent whenever `K` is positive definite. Lean proves
`QS=SQ=S`, `tr(Q)` equals the represented distinct-zero count, and
`Re tr(QS^r)=Re tr((PK)^r)` for every order including zero. Thus the packed
realization no longer pads the mixed moment model with a spurious zero
eigenspace, and it still retains the amplitudes in `K`. Lean now flattens every
finite family of supported powers `QS^k`; their column Gram is positive
semidefinite and its entries are exactly the mixed moments at summed orders.
It then normalizes by the distinct-zero count `N` and mean positive eta mass
`m₀/N`. The resulting dimensionless moments
`ν_r=N⁻¹(N/m₀)^r Re tr((PK)^r)` form a positive-semidefinite Hankel matrix for
every finite order family, with `ν₀=1`, `ν₁=m₁/m₀`, and
`ν_(a+b)^2≤ν_(2a)ν_(2b)`. Lean now also proves why this mixed spectrum cannot
by itself supply the certificate's distinguished zero atom: positive `K` makes
`PK` invertible. The semantically correct count channel is instead the pair of
reflection projections `E₊=(I+P)/2` and `E₋=(I-P)/2`. They are orthogonal
positive-semidefinite idempotents; `tr(E₋)` is exactly the upper off-line-pair
count, and `1-2 tr(E₋)/N` is exactly the critical-zero proportion. Compressing
the actual eta metric gives positive carriers `E₊KE₊` and `E₋KE₋`. Under the
already checked positive-definiteness hypothesis, `ker(E₊KE₊)` is exactly the
reflection-odd subspace, its nullity is the upper off-line count, and the two
compressed traces are exactly the on-line-plus-real and off-line-imaginary eta
masses. Lean now extracts the literal uniform eigenvalue-atom model of
`E₊KE₊`: its nonnegative nodes are the eigenvalues divided by their positive
mean, its ordinary and heat moments are exact normalized matrix traces, and
its zero mass is exactly the upper off-line-pair fraction. Its certificate is
therefore the literal critical-zero fraction. Lean also proves that this
fraction is strictly greater than `13/18` exactly when the normalized ordinary
heat trace of `E₊KE₊` crosses below `5/36` at some nonnegative scale. The next
bridge now writes `W=C E₊`, proves `WᴴW=E₊KE₊`, and transports its nonzero
spectrum to `WWᴴ=C E₊ Cᴴ`. The latter is exactly the positive on-line plus
off-line-real eta block. All positive moments transfer without loss, while
ordinary heat has one exact ambient-cardinality padding correction. Lean also
expands that coordinate heat into a convergent series of ordered even paths
whose intermediate packed coordinates and on-line/off-line-real edge colours
remain explicit. Lean now proves that the coordinate carrier has rank exactly
`#critical + #upper-off-line` and derives
`rtrace(A)^2 ≤ rank(A) * frobSq(A)` from finite Cauchy--Schwarz on its nonzero
eigenvalues. Its first two moments are exactly the real length-one and
length-two coloured path sums. Therefore
`31*N*Re(path₂) < 36*Re(path₁)^2` is a checked sufficient premise for a
critical-zero proportion above `13/18`, while
`N*Re(path₂) ≤ Re(path₁)^2` is a checked sufficient premise for the
finite-window `18/18` conclusion. These implications do not prove either
premise. The existing geometric feature-separation theorem discharges the
positive-definiteness condition for one odd prime base at every sufficiently
late block. Lean now opens those two paths one step further as a literal
reflection-even eta frame, indexed by critical zeros and upper off-line pairs.
Its length-one mass is the weighted sum of squared atom norms; its length-two
frame potential is the complete weighted double sum of squared real eta
correlations. Every pair term is checked nonnegative, with both atom colours
retained through the proof. Lean now splits that potential into diagonal
self-mass and distinct-pair correlation and defines the complementary
decorrelation reserve as the weighted sum of
`norm_a²*norm_b²-correlation(a,b)²` over ordered distinct coloured atoms.
Complex Euclidean Cauchy--Schwarz proves every reserve summand nonnegative,
and Lean proves the exact conservation law `mass²=potential+reserve`. The
`13/18` premise is therefore exactly
`(31*N-36)*potential < 36*reserve`; the finite-window `18/18` premise is
exactly `(N-1)*potential ≤ reserve`. Lean now builds the corresponding
square-root-weighted frame synthesis, identifies its Gram with the coordinate
carrier, and uses the checked carrier rank to prove all literal frame atoms
linearly independent at every separated block. Hence every distinct pair has
strictly positive Gram-determinant reserve. The total reserve is positive
exactly when the frame has at least two atoms, and one odd prime base makes
this characterization hold at every sufficiently late block. Lean now also
retains the exact complex correlation of length-`M` unit geometric mode blocks
and proves `|corr|²|conj(w)z-1|²≤4`. Every finite injective unit-mode family
has a checked positive minimum phase gap, giving a uniform `O(M⁻²)` bound
for all distinct-pair squared coherences; one collision-free odd prime
instantiates this on any same-real-part zeta-zero layer and on the critical
window. Lean now performs the first arithmetic transport: explicitly
normalized literal eta-prefix vectors converge to the unit-mode vectors, and
their complex correlations, squared norms, and squared coherences converge as
well. Hence one prime and one positive gap give the eventual simultaneous
bound `literalCoherenceSq*gap² < 4/M²+ε` for every distinct pair in a finite
same-real-part layer, including the critical window. Lean now proves that the
two hyperbolic coordinates are an injective realification of this complex
channel, with an exact inverse, correlation law, and norm law. The literal
critical-line packed cutoff feature is exactly the realification of the
completed original eta channel. Consequently the phase-normalized packed
same-layer coherence is bounded by the full complex coherence and inherits
the eventual simultaneous `4/M²+ε` estimate. Lean now removes the same-layer
restriction from the convergence interface: under one common tilt `σ`, every
literal block converges to a geometric mode of exact radius
`q^(σ-Re(rho))`, and correlations, norms, absolute coherence, and packed real
coherence converge without erasing that radius. At `σ=1/2`, critical modes
have radius one, while an upper off-line representative and its reflected
partner retain one shared unit phase and strictly reciprocal radii. The actual
upper off-line frame atom is exactly half the injective realification of the
sum of those two completed channels, and its coordinates reconstruct that sum.
Lean now identifies the two underlying literal critical-shifted modes with the
abstract reciprocal-radius pair. Their cross-correlation is exactly the window
length; their full two-coefficient norm square retains the signed interference
term; no nontrivial coefficient pair cancels; and every off-line pair has
strictly positive Gram reserve at each length greater than one. Lean now turns
that reserve into an explicit quantitative lower bound: every complex
combination is bounded below by `(A*B-M^2)/(A+B)` times the squared coefficient
norm, and this determinant-over-trace constant is proved positive for the
literal shifted zero/reflection modes. The actual cutoff-dependent completion
coefficients must also reach this inequality. Lean now completes the exact
algebraic part of that transport: after common
coordinate tilt, each completed channel is its normalized literal prefix times
one explicit nonzero coefficient containing the completion weight, sharp
prefix limit, and inverse cutoff row scale. After lossless coordinate recovery,
the actual upper frame atom is exactly the sum of the two normalized reflected
prefix columns with both coefficients retained. Lean now closes the uniform
perturbative step: a generic signed two-vector Gram ledger gives the
determinant-over-trace bound, the literal finite-prefix coefficient converges
to the positive reciprocal-mode constant, and one eventual half-limit estimate
holds simultaneously for all complex coefficient pairs. Substitution of the
actual moving completion coefficients yields an explicit positive lower bound
and strict noncollapse for every sufficiently late recovered upper frame
channel. Lean now also discharges the conditioning gap between that recovered
channel and the certificate metric. Pointwise multiplication by the common
critical coordinate tilt is bounded by its explicit finite weight energy,
that energy is strictly positive, and the half-scaled two-coordinate
realification of an actual upper atom is proved to have exactly the norm square
of its unweighted recovered complex reflection sum. Dividing by the tilt
energy therefore transfers the coercive lower bound and strict noncollapse to
the literal packed upper frame atom itself. Lean now opens the next
cross-atom interface without discarding complex phase. The packed correlation
of two literal upper atoms is exactly the real part of their recovered complex
reflection-sum correlation, and that complex carrier is expanded into the
four completed original-channel eta Gram kernels at the two zeros and their
reflections. For arbitrary finite complex vectors, the real-correlation
reserve is proved exactly equal to the full Hermitian Gram reserve plus the
square of the imaginary correlation. Thus every actual
multiplicity-weighted upper--upper reserve summand has a checked two-part
nonnegative ledger with all four arithmetic channels retained. Lean now also
preserves the nonunitary critical tilt at correlation level. Its inverse
squared-modulus diagonal recovery metric makes the correlation of tilted
vectors exactly equal to the original Hermitian correlation. The two
reflected/original prefix colours of each upper atom therefore form a literal
`2 × 2` metric correlation matrix, contracted against the exact moving
completion-coefficient vectors. That contraction is the unweighted
upper--upper correlation, every matrix entry converges to the corresponding
explicit shifted-mode metric correlation, and the full weighted certificate
summand is exactly the contraction Gram reserve plus its imaginary square
times the positive multiplicity weight. Lean now evaluates the limiting
metric matrix itself. The inverse squared-modulus metric cancels the common
critical tilt entrywise, leaving four explicit finite geometric sums of the
raw eta decay modes. Every relevant relative mode lies strictly inside the
unit disk, and Lean proves the phase-and-radius estimate
`norm(entry)*norm(relativeMode-1)≤2`. With arbitrary positive slack this bound
holds eventually and simultaneously over the complete finite upper window
and all four colour entries of the literal prefix matrix. Lean now contracts
these estimates against the exact moving completion coefficients. The norm of
the actual unweighted complex upper--upper reflection-sum correlation is
eventually bounded, simultaneously over the entire finite upper window, by
the four-term sum of coefficient-norm products times `(2+epsilon)/gap`; every
gap is proved strictly positive. The literal packed real correlation inherits
the same envelope. Lean now names the transported atom-coercivity lower bound
and proves it strictly positive. Combining the two atom bounds with the square
of the correlation envelope gives an unconditional eventual lower bound for
every actual multiplicity-weighted upper--upper reserve:
`weight_rho*weight_zeta*(lower_rho*lower_zeta-envelope^2)`. The conclusion is
simultaneous over the complete upper window and is summed without loss over
all ordered distinct upper pairs. The difference need not yet be positive.
Lean now proves the exact complete colour decomposition: critical--critical,
critical--upper, upper--critical, and upper--upper. Every sector is
nonnegative, the diagonal terms vanish exactly, and the upper sector is the
ordered-distinct aggregate above. Thus the explicit upper lower bound reaches
the complete certificate reserve, and combining it with global reserve
nonnegativity gives the eventual certified floor `max 0 upperLower`. Lean now
substitutes that floor into both certificate theorems. One checked odd-prime
choice simultaneously makes the literal eta Gram positive definite, so at all
sufficiently late blocks the strict floor inequality implies `>13/18` and the
endpoint floor inequality implies `18/18`. Those two inequalities remain open
antecedents. Lean has now audited the longer-block behavior and proved that the
current pointwise coercivity-minus-triangle floor eventually vanishes
uniformly in the block start. It therefore moves upstream: the exact signed
four-colour contraction retains all sixteen ordered interactions, and its
complete window aggregate is the literal upper--upper reserve. The natural
original-colour normalization is proved to collapse to one colour, so Lean
now supplies an exact polar--hyperbolic alternative. Each completion pair is
factored into a common positive geometric mean, two reciprocal positive radial
colours, and two unit phases; every raw contraction is reconstructed exactly.
Each literal signed pair reserve is a strictly positive scale times a
nonnegative balanced reserve, and the complete signed window is exactly the
corresponding scale-weighted balanced aggregate. The existing eventual
odd-prime `>13/18` and `18/18` interfaces transport unchanged. Reflection now
also exposes one universal cutoff scale: the two coefficient norms in every
completion pair have product equal to a fixed leading product times
`q^(-n)`, so every ordered-pair reserve contains the same `q^(-2n)` factor.
Lean removes it from the complete reserve and multiplies the frame potential
by the matching positive factor, proving both certificate targets equivalent
to their coefficient-normalized forms. The reflected radial colour still has
square equal to the exact coefficient-ratio norm and tends to zero, so the
true reciprocal hyperbolic imbalance remains visible. The live obligation is
an eta-arithmetic bound on this scale-free carrier strong enough to prove one
of the threshold antecedents; neither is yet proved.
Lean now prevents that shrinking colour from being erased by a one-scale
contraction. The two reflected completion coefficients advance by distinct
complex step modes for every `q > 1`, so their adjacent-start `2 × 2` matrix
is nonsingular. Two coefficient probes recover an arbitrary colour vector,
and four left/right probes recover the entire literal normalized-prefix colour
metric exactly. The `(0,0)` probe is the existing eta contraction; the other
three vary the adjacent coefficient rows against that same fixed-start metric,
not a silently frozen prefix at `n + 1`. No conditioning or arithmetic bound
follows from inversion alone. The live obligation is a quantitative estimate
on this scale-free multi-start carrier that yields `13/18`, then `18/18`.
Lean now removes the cutoff-dependent inverse from that interface. The moving
adjacent-start matrix factors exactly as `D_n*V`, with every completion
coefficient in `D_n` and only the zeroth/first step modes in `V`. Distinct
reflection modes make `V` nonsingular for `q > 1`, independently of `n`.
Inverting the four probes through `V` recovers `D_zeta^* K D_rho`, whose
entries are exactly the literal coefficient-weighted signed-colour terms.
This recovery propagates through all sixteen interactions, the complete
upper reserve, universal scale removal, and both certificate interfaces. It
still supplies no bound on the probes. The live task is a finite-window
conditioning bound and eta-arithmetic estimate for this scale-free carrier.
Lean now also rechecks the complete pinned multiplicity-aware Zeta23 chain.
The exact external `HD(1)` theorem is instantiated for the literal simple
critical-line count over the analytic-multiplicity denominator and bridged to
the project-native simple dyadic window. Beyond that external baseline, the
project now proves two ordered unconditional literal constants
`HD(1) < C₀ < C₁`; the stronger one uses uncapped three-column coercivity and
strictly improves the preceding project certificate. No `13/18` theorem is
claimed.

## Active harmonic-cost goal (2026-09-20)

The user explicitly refocused the active goal on finishing the existing
harmonic-cost route. Retain u^(N+1)(H_N+C_N)->-m^2 c(u), the proved
frequency-sector and complete high-prime-count savings, and the coupled
lower-count response plus tapered wing. Initially target simple exposed
zeros with 1/2<u<exp(-2/3). Every new lemma must reduce this specific unpaid
arithmetic budget or discharge a necessary contradiction hypothesis.
Preserve signs, phases, exact support and endpoint weights. The independent
cofinal floor and the first restricted zero exclusion remain open.

`ZetaRieszWingReserve` gives an actual positive normalized wing block of
at least 15m^2/544, using exposed-zero phases and independent prime completion,
on the smaller interval 1/2<u<exp(-11/16). `ZetaRieszWingHighOrders` pays the
opposite high-leg wing by C(N+1)^2 exp(-N/1024). Its finite high-leg bound is
height-uniform and independent of zeros; the whole product uses the exposed
complete low-moment bound. Remaining wing orders obey k<=floor(13N/32) and
5(N+1-k)<4N. The partition is exact at every sufficiently large order.

`ZetaRieszHarmonicWindow` independently pays both complete lower-count outer
tails by one geometric bound, uniform in all heights, count thresholds and
radii up to the stated ceiling, for every fixed full complex filter. The
window is 25N/16<log n<=5N/2 over the original harmonic range; it narrows to
7N/4<log n<=9N/4 on the wing-reserve range. The smaller count sum stays
coupled to the unpaid middle wing. Their sum plus the positive reserve
tends to -m+m^2c(u). For simple exposed zeros the sufficient cofinal floor
has eta<1-c(u)+15/544; that floor remains an explicit unproved premise.
Do not extend the wing estimates to the full original interval, assume
simplicity or exposure for all zeros, double-count overlapping frequency
savings, or claim a zero-free region from these component results.

`ZetaRieszJointCofactor` now independently bounds the original unpaid wing
plus its complete signed composite companion by C_gamma(N+1)^2 exp(-N/64),
for 1/2<=u<exp(-2/3), at each fixed abs(gamma)>1. One constant works across
the radius interval; the starting order may depend on u. The constant is
not evaluated or uniform in height. The actual prime set, unpaid orders,
factorial weights and signs remain. Complete squarefree cofactor decay
retains the mark size; the full saturation correction, clipped prime
prefix, repeated-prime diagonal and unit term are all paid. No zero or
cancellation premise enters this joint estimate. Do not claim separate
decay of either summand. The source now survives in the original masked
finite lower-count response MINUS the complete composite companion, plus
the existing positive reserve on its smaller interval. The independent
floor for that arithmetic difference remains open.

`ZetaRieszJointAllocation` now proves the exact multinomial prime-incidence
identity: the complete companion is a bounded fraction theta_N(n) of each
original signed atom, with 0<=theta<=1. The complete infinite companion
outside 7N/4<log n<=9N/4 has a height-uniform geometric bound on
0<=u<=exp(-11/16). The remaining finite multiplier is exactly 1_S-theta;
all old masks and the negative off-mask correction remain. Never silently
replace it by 1-theta everywhere.

Module `ZetaRieszCancellingSector` proves `actual_sector_geometric` in
namespace `ZetaRieszJointAllocation`; it pays the retained eligible-prime sector
17/64<=log(n/p)/log n<=11/32. Both exact unpaid binomial tails give
0<=1-theta<=3 exp(-N/140), and a summable arithmetic tilt turns this into
a source-normalized geometric bound uniform in height, count threshold
and radius up to exp(-11/16), for N>=320. `remainingRemainder` removes only
that proved sector and retains the same source plus positive reserve.
The independent cofinal floor is still open. No restricted contradiction
or new zero-free region is claimed. See `docs/zeta-riesz-joint-allocation.md`.

The complete off-mask correction is now discharged by the subsequent
batch. `ZetaRieszWeightedCount` pays all high-count labels with arbitrary
dominated coefficients. `ZetaRieszBalancedCompanion` bounds the assigned
fraction by omega(n)*exp(-N/64) when all eligible selected primes have at
most half the total logarithm; its whole companion contribution decays.
`ZetaRieszMaskSupport.window_mem_originalMask` proves every old mask on the
actual lower-count subcutoff window. Any remaining nonzero off-mask label
would force an unselected large prime and hence the already paid balanced
case. Counts below three and nonsquarefree labels are exactly zero.

`ZetaRieszMaskSupport.residualMask_eq_retained` leaves precisely the original
mask minus the paid sector, with multiplier 1-theta between zero and one.
`tendsto_arithmetic_sub_retained_moving` pays all intervening errors jointly
for arbitrary moving heights, independently of zeros; the uniform interface
`eventually_all_heights_arithmetic_error` gives one starting index for every
height at each positive tolerance and fixed eligible radius. The endpoint
`tendsto_retained_add_reserve` retains the exact source and reserve. The
signed floor for `retainedRemainder` is open. Do not keep listing an off-mask
correction as unpaid, infer decay of the original balanced carrier from
decay of its companion, or count recovery of the same Euler/source identity
as an independent bound. All eleven allocation/mask modules belong to the
same checked chain as the exact reserve and dominant-prime continuation.

`ZetaRieszReserveWeights` evaluates both actual reciprocal marginals,
including the integer endpoints.
`ZetaRieszWingReserve.tendsto_reserve_exact` evaluates the complete reserved
wing as m^2 v(u), where
v(u)=log(19/17)+(1-1/(-2u log u))*log(15/13). Consequently
`ZetaRieszMaskSupport.tendsto_retained_exact_source` gives the retained
carrier itself the limit -m+m^2 c_ret(u), with
c_ret(u)=log(32/13)/(-2u log u)-log(19/13).
`retainedCost_lt_thirtyseven_fortieths` proves c_ret(u)<37/40 throughout
1/2<=u<=exp(-11/16). The source theorem still requires the strict upper
endpoint and exposed-zero hypotheses. For a simple exposed zero the
retained real part is eventually below -3/40. An independently proved
cofinal floor at -3/40 would now suffice. This replaces the weaker coarse
reserve allowance in the active budget, but does not prove that floor,
a restricted contradiction, or a new zero-free region. Work on the signed
retained carrier; do not report its source-forced negativity as an
independent arithmetic estimate.

The latest batch independently pays the entire dominant-prime sector
of that unassigned carrier. `ZetaRieszDominantAllocation.dominantSector_bound`
gives `(r_H^N+r_L^N)*zetaMoebiusLogMajorantMass(12001/12000)` at N>=320,
uniformly in height, count cutoff and 1/2<=u<=exp(-11/16), where
r_H=(503/1000)*(12000/5999)*exp(-1/160)<1 and r_L=exp(-1/2000)<1.
The missing low-cofactor allocation tail keeps its factorial weight and
the actual prime cutoff together; dropping that correlation loses the
saving. `nondominant_prime_log_lt` proves that every prime factor of every
nonzero surviving label has log(p)<13/20*log(n), from dyadic index 32.
This replaces the previous sector's upper prime-log endpoint restriction.
The new `nondominantRemainder` retains the original masks, signed coefficient,
phase and fraction 1-theta. `tendsto_arithmetic_sub_nondominant_moving`
pays all aggregate reduction errors for arbitrary moving heights, and
`tendsto_nondominant_exact_source` keeps the same exact cost and 3/40 deficit.
The current open floor is for this smaller carrier; balanced products and
their cross-count correlations remain unpaid. Do not claim decay of the
dominant integers with their original unallocated coefficients. See
`docs/zeta-riesz-dominant-sector.md`. No restricted contradiction is proved.

The local continuation `ZetaRieszReflectedLinear` evaluates the complete
Riesz coefficient whenever every prime logarithm is between D/2 and D,
where D=log(n)-L>=0. Composite divisors then lie beyond the reflected
cutoff. The exact coefficient is
`-(log(n)/L)*(-1)^omega(n)*((omega(n)-1)*L-(omega(n)-2)*log(n))`.
On the actual nondominant support this class has 3<=omega(n)<=9.
`ZetaRieszOneSidedArithmetic.nondominantRemainder_lower` gives an independent
one-sided real bound for the actual remaining carrier at every order and
height. Only adverse phases of the evaluated class are charged; the other
labels retain their antichain allowance. The whole new budget is no larger
than the old one. For four primes in 24L/17<=log(n)<=8L/5, the charge is at
most one quarter of its previous antichain allowance, uniformly in phase.
`nondominantRemainder_lower_with_four_credit` lifts this to
`Re R_j >= -B_j + (3/4)*B_4,j` on the full original support. This is a
75-percent saving on that specified subfamily's charge, not on the whole
carrier. The new complete budget has NOT been bounded by 3/40, cofinally or
otherwise. Do not describe this finite arithmetic inequality as the needed
uniform floor or a restricted contradiction. See
`docs/zeta-riesz-one-sided-arithmetic.md` and the supporting
`one-sided-arithmetic` explorer endpoint.

The quantitative audit now rules out that exact improved allowance as an
endgame target. `ZetaRieszAllowanceGrowth.complement_tendsto_atTop` and
`improved_allowance_tendsto_atTop` prove that, for every fixed real height
and every 1/2<u<=exp(-11/16), both B_j-B_4,j and B_j-(3/4)*B_4,j tend to
positive infinity on the original dyadic schedule.
`eventually_complement_growth` supplies c(u,y)*(2u)^N/(N+1)^4 with c>0.
Balanced three-prime products near log(n)=2N survive every original mask,
count cutoff and paid sector. Their unassigned fraction is eventually at
least 1/2. Actual prime-window asymptotics provide enough such products
with cosine at least 1/2; their four-prime credit is zero.
`not_frequently_improved_allowance_le_three_fortieths` rules out even a
cofinal subsequence satisfying the requested ceiling. Do not keep listing
an upper bound on this fixed allowance as open or attainable by extending
the divisor-sign evaluation: that does not change its definition. This
is an obstruction theorem, not a signed floor, restricted contradiction or
zero exclusion. The signed carrier and evaluated source remain valid;
any sufficient estimate must retain cancellation between labels beyond
this positive allowance. See `docs/zeta-riesz-allowance-obstruction.md`.
The supporting `allowance-obstruction` explorer endpoint exposes the
negative result. Keep the main default at the unchanged signed source and
its open floor; do not present the obstruction as a zero exclusion.

The active RH explorer default is `harmonic-remainder`, now ending at
`tendsto_nondominant_exact_source`. Supporting views `joint-allocation`,
`exact-wing-reserve` and `dominant-prime-sector` expose the paid comparison,
full reserve and independent dominant-sector bound. The former
conditioned-energy and owner/cycle routes remain supporting views. This
explicit branch change supersedes older per-slice instructions to keep
the conditioned-energy default. Keep the zero-free and certificate defaults
and both top-ten lists unchanged. The exact ledger is
`docs/zeta-riesz-harmonic-wing.md`. Work locally without subagents and
amortize required gates over coherent compatible mathematical batches.

### Concrete wide-owner test (2026-09-23)

The requested `10001/20000` radius and `27/40`, `11/8`, `27/55`,
`1+1/262144` completion parameters now have a checked go/no-go audit in
`docs/zeta-riesz-wide-owner-audit.md`. `ZetaRieszWideOwnerAudit` proves the
original completion exponent at most `-1/25000`, preserves the old
allocation factor while assigning triples to their unique largest-prime
owner, and proves the entire newly unallocated triple mass geometrically
small at source scale, including every original mask and arbitrary moving
height. `ZetaRieszWideCompanion` pays the full complementary moment and all
saturation/prefix/diagonal corrections at rate `exp(1-N/200000)`.

The terminal result is a completion obstruction, not a zero exclusion.
`ZetaRieszWideOwnerObstruction.eventually_re_wideComplete_le` proves the
normalized complete companion has real part at most `-m^2/40` under the
original exposed-zero hypotheses. Adding back the old reserve still
leaves real part at most `-m^2/5000`; nondecay is proved on the actual
dyadic schedule. The exact difference from the owned finite carrier is
retained in `ownerCompletionCorrection`, with no independent vanishing
claim. Stop expanding this direct completion route after this no-go
result. Do not discard that correction, count the old reserve twice,
claim the owned masked companion itself has been evaluated, or weaken
`LocalizedTypeIIBound`. This is not an impossibility theorem for future
signed cancellation inside the correction. The public zero-free region,
RH frontier, README and top-ten lists remain unchanged. Work locally
without commits, pushes or subagents.

### Literal quarter-gap skew test (2026-09-23)

`docs/zeta-riesz-skew-allocation-audit.md` records the concrete rank-two
test from `7a659cb`. `ZetaRieszSkewFactorial` proves the exact three-leg
factorial identity and finite nonowner partition of
`ownerCompletionCorrection`; no composite cofactor is completed and no
pair incidences are averaged. For the box `25*(h+1)<=N`, `j-l>=N/4`, the
old unassigned factor and the skew order mass have joint bound
`3*exp(-N/8100)`. `ZetaRieszSkewCarrier.skewResponse_bound` turns this into
a source-normalized geometric bound with a checked rate below one for
`0<=u<=10001/20000`, uniformly in arbitrary moving heights on the original
dyadic schedule. Its norm cannot supply any fixed positive reserve.

Keep the allocation distinction exact: weight-one nonowner correction
rows split into the old allocated fraction and the unassigned fraction.
`tendsto_raw_sub_allocated` proves their difference vanishes; it does NOT
prove either weight-one or allocated response vanishes separately. The
full correction remains unestimated. Do not claim the numerical 0.0084
reserve survives the original allocation, or that a source was bounded
by moving it into that correction. Stop the quarter-gap reserve attempt.
The wider N/5 box is not ruled out by this theorem. Neither a restricted
zero exclusion nor a general obstruction to all rank-two estimates has
been proved. Keep `LocalizedTypeIIBound`, all public frontiers and the
top-ten lists unchanged. The user authorized committing and pushing this
checked slice on 2026-09-23; apply the publication gates below. Continue
to work without subagents.

### Literal allocation-safe rectangle (2026-09-24)

The Riesz continuation from `ae056b0` is developed in the current tree;
do not reset or discard the intervening literature work. The user confirmed
that the numerical positive reserve means minus the selected contribution
to `ownerCompletionCorrection`. Keep the quarter-gap no-go unchanged.

`docs/zeta-riesz-rectangle-reserve.md` records the concrete rectangle
`21N<=40j<=23N`, `N<=100(h+1)<=4N`, with every requested original mask.
`ZetaRieszSkewAllocation.eventually_rectangleReserve_ge` now proves the
literal reserve is eventually at least `1/160` at source scale on the
original dyadic schedule, for `1/2<u<=10001/20000` under the original simple
exposed-zero hypotheses. The old allocated fraction and every literal mask
error have independent geometric decay, uniform in arbitrary moving
heights. Three separate prime legs and exact finite lattice counting pay
the comparison; no composite cofactor or global all-order product is used.

Do not turn this into a whole-carrier floor. The rectangle is also a genuine
suballocation of the largest-prime owner and that negative owned copy is
proved nondecaying. The exact correction partition and narrow-carrier
ledger keep `rectangleCorrectionRest` explicit: it contains the remaining
original completion differences, other nonowner incidences and unselected
factorial orders. The reserve removes a duplicate incidence; it is not an
extra positive term in the direct finite carrier. The `~0.00487` source gap
is not an independently proved budget for those remaining terms.

The component and geometric tests pass, but the strict contradiction test
does not: the joint lower bound for the rest remains open. This is not a
general rank-two impossibility theorem. Stop any shortcut that discards
the matching owned copy or assumes the remaining correction is small.
Keep `LocalizedTypeIIBound`, the main RH/default zero-free/certificate
frontiers and both top-ten lists unchanged. Expose the new estimate as a
supporting `harmonic-rectangle-reserve` endpoint. Work without subagents.

## Current theorem-push commit gate

The user authorized committing and pushing ALL accumulated local work on
2026-10-02, explicitly including the semiprime side investigation. This
supersedes local-only holds for this publication. Register every proof module,
run the tracked hook and all applicable publication gates, refresh the
campaign Latest Update and verify exact-SHA CI/Pages. The semiprime algebra is
part of the ordinary library; its probes/benchmarks remain optional and
separate from the RH campaign. No generic factoring exponent or independent
native floor is claimed. The current sufficient thresholds are the checked
-399/5000 floor and42/25 ceiling. Publish the explicit open credited-cost
premise honestly, preserve all previous positive/no-go results, and do not
rerun the exhaustive certificate merely for this batch. No subagents are
authorized. After this publication, resume local floor work unless the user
provides a further commit instruction.

That publication is COMPLETE at
`194a361762f404a8f4473298b25d96fbae0bb56e`: exact-SHA workflow
37057705249 and Pages passed, as did deployed desktop/mobile README,
zero-free, numerical-certificate and RH-explorer checks. Subsequent work
is LOCAL ONLY until a new publication request; no subagents or wider gates.

### Quantitative joined-null crossing payment (local, 2026-10-02)

`ZetaRieszQuantitativeNullStep` gives an explicit guaranteed reduction of
the SAME whole native cost, with every count/period assembled first. Let
D be its signed adverse correlation, Z the exact zero-block debit, and
H the quadratic crossing price. The mathematical step is
`max(D-Z,0)/(2H)` and its guaranteed saving is `max(D-Z,0)^2/(4H)`;
both are zero at H=0. Every crossing is paid; count three is retained.
The phase-aligned higher-count direction also vanishes exactly on every
coherent prefix and on the complete cutoff-zero period for positive y>=54.
Do not silently extend that height statement to negative y.

The finite prime probe found that almost-zero baseline blocks can make
H huge. The new `crossingCost_le_near_far` charges those blocks linearly
with their actual signs, and uses the quadratic price only outside the
chosen nonnegative margin threshold. `native_floor_with_threshold_gain`
and its best-orientation version prove a sharper floor for the original
`joinedPhysical`, with EXACTLY the former nativeError. Threshold zero
recovers the original guarantee. Savings are alternatives capped by the
same nativeCost; take a maximum, never sum credits against that price.

The optional `scripts/probe_riesz_quantitative_null_step.py` tests the
inequalities by exact rational replay and enumerates complete constructed
prime universes on request. Their masks/allocation/phases are retained,
but they are NOT the whole native population or a density sample. The
probable primes, floating phase and large-cutoff log interpolation are
not certified. Several cases have ZERO gain. A finite gain fraction is
not a cofinal cost estimate or a proved native source-scale saving.
The early probe orders retain the original ceiling K, not the eventual
K/864 crop; they are not current cropped-native population measurements.
The new exact boundary test proves that D<=Z forbids improvement along
every positive step of ONE direction; both orientations forbid every
real step on that line. This does not forbid joint directions, whose
zero-face debits must be recomputed after adding them, or the floor.

The quantitative magnitude of the native signed correlation and the
cofinal bound `nativeCost - paidGain <= 399/5000` remain OPEN. No new
floor/ceiling, zero exclusion or RH claim. Continue focused Lean/namespace
lint/transitive-axiom checks locally, preserving every older audit and the
public default endpoint. See `docs/zeta-riesz-quantitative-null-step.md`.

### Joined six-direction native credit (local, 2026-10-02)

`ZetaRieszJointNullCredit` now joins the four complex log/log-square null
directions and both cubic directions BEFORE measuring the same near/far
crossing debit. The original imaginary tilt is fixed. Count three remains
in the baseline and log/log-square directions, and is never corrected by
the cube. Every new moving vector is an exact finite null, including all
endpoints; no coefficient-size analytic error is introduced.
`native_floor_with_joint_gain` applies to the same joinedPhysical with the
same nativeError. `nativeJointGain_cubic` recovers the previous cubic gain,
and `nativeJointGain_le_cost` forbids spending any credit twice.

The compiled `nearDebit_overlap_eq` identifies the exact cancellation:
Z(V)+Z(W)-Z(V+W) = sum_near (|V|+|W|-|V+W|)/2 >=0.
All labels/counts/periods are assembled BEFORE these absolute values.
The signed adverse correlation remains exactly additive. Thus a joint
direction can cancel the very zero-face debit that forbids either line
separately. This is not omission of any original zero/near block.

The optional quantitative-null probe now holds the tilt fixed and tests
all six corrections jointly. All twelve constructed-universe cases have
positive joint guarantees, including four with no saving on the previous
phase-aligned cubic line. The floating guarantee fraction is roughly
0.6%-23.8% of those FINITE rescaled costs; it is NOT a native budget or
source-scale exponential saving. Probable primes, log interpolation,
early original count ceiling K and incomplete native-population coverage
remain explicit. Do not extrapolate these percentages to cofinal orders.

The exact remaining target is nativeCost-nativeJointGain<=399/5000
cofinally. `false_of_cofinal_joint_gain` is a conditional endpoint only.
No independent numerical floor, ceiling, zero exclusion or RH proof.
Continue local scoped Lean/namespace-lint/transitive-standard-axiom work
without commits/subagents/wider gates or public endpoint changes. See
`docs/zeta-riesz-joint-null-credit.md` and its audit.

The subsequent local exact-payment pass proves
`native_floor_with_joint_credit`, using max(signed adverse correlation minus
FULL actual crossing cost,0), with the SAME nativeError. It recovers the
old exact cubic credit and dominates the threshold guarantee at its SAME
rescaled step. These are alternative credits funded by one baseline cost;
never add them. The independent cofinal nativeCost-nativeJointCredit bound
399/5000 is still OPEN. No new imaginary tilt, population or error appears.

The optional --cost-audit solves/replays rational primal/dual bounds for the
FLOATING joined matrices. Nine order256/640/1536, seed317, height54/65/100
matrices have exact dual directional correlations zero, covering EVERY
real six-vector, with relative primal-dual gap at most8.9e-9. Their finite
remaining fractions are about52.1%-88.6%; at1536 they are53.0%-67.2%.
Two of three fractions rise from640 to1536. These are NOT native cost
bounds or an asymptotic no-go: primes/logs/phases/coverage are uncertified,
the inventories change and the early original ceiling K is retained.
Do not extrapolate the table, equate a rounded matrix to native arithmetic,
or keep coefficient-hunting as though it supplied the missing rate.
The actual masked signed native aggregate still needs an independent
quantitative bound. All previous positive results/no-gos remain unchanged.

### Population-density and phase controls (local, 2026-10-02)

The optional `probe_riesz_closed_inventory.py` enumerates every subset of
ONE sixteen-prime union, including the mixed products omitted by the older
two-pool probes. At N=256/640, seed317 it retains891/1313 labels, with
879/1301 mixed products and largest shares up to0.564. Joining counts saves
about35%-55% of their split price, but adding mixed products INCREASES the
pure-pool subfamily price in all six height comparisons on that SAME
inventory/scale. These are sparse floating/probable-prime populations,
not density samples, native costs or asymptotic bounds. Pool closure does
not supply free favorable credit.

The optional `probe_riesz_factored_population.py` implements Kalai's
inclusive-chain rejection sampler. Its ideal law is uniform in each
computed integer bin, conditional on exact primality/randomness; exact
integer bin-size weights estimate the finite literal population density.
All original allocation/count/owner/physical/radial masks and the complex
phase are retained. Nonsquarefree draws are sampled before the original
mask. Finite N=32/64,K=16 inputs are NOT cofinal native dyadic points and
do not use the eventual crop or source-limit hypotheses.

Four512-draw batches retain126-170 labels, counts3-10 and owner shares
roughly0.224-0.641. Signed sampling errors are comparable to their means.
The sampled clipped costs are upward biased in the ideal model, not
deterministic bounds. Exact rational chain regressions check528 labels
at ceilings1-32 and every subinterval acceptance law; these are PYTHON
regressions, not Lean proofs or large-prime certificates.

Both half-sample pooling and independent random-phase controls are now
required diagnostics before promoting a percentage to evidence of special
arithmetic correlation. All twelve observed count-saving fractions lie
within their respective31-control ranges. The four batches use124 random
phase assignments shared across heights, giving372 comparisons, not372
independent native populations. The controls are NOT proof carriers.
Small sample costs and aggregation savings do not establish the independent
native floor or refute all arithmetic cancellation at later orders.

Accepted factorizations are cached in .lake with product/interval checks,
so repeated controls avoid regenerating samples. Keep both probes outside
ordinary builds/CI. Large primality, floating phases/weights/bin endpoints,
allocation clipping, cutoff interpolation and sampling error remain
uncertified. This pass adds NO Lean declaration or native credit. The
cofinal nativeCost-nativeJointCredit<=399/5000 target is still OPEN.
Continue locally without commits/subagents/wider gates. See
`docs/zeta-riesz-population-cancellation-probe.md` and its audit.

### Count-three tangent cubic credit and boundary gate (local, 2026-10-02)

`ZetaRieszTangentCubicCredit` retains the WHOLE cubic defect rather than
discarding count three. `cubicMoment_eq_three` identifies its exact complex
moment with the original three-prime population; `thirdMoment_three_primes`
gives -6log(p)log(q)log(r). The direction perpendicular to that whole moment
has exactly zero total, including all early/late integer cutoffs. It does
NOT vanish label by label, and no adverse-subset imaginary null is assumed.

`native_floor_with_tangent_credit` improves the SAME joinedPhysical cost
comparison with EXACTLY the old nativeError. All masks and phases remain.
The credit is the MAXIMUM of the old six-direction credit and the new
actual saving against ONE baseline price; never add them. Zero new
coefficient recovers the old credit. The independent cofinal bound
nativeCost-nativeTangentCredit<=399/5000 remains OPEN. This conditional
endpoint is not a numerical floor, ceiling or zero exclusion.

The new `no_free_unit_cutoff_direction` isolates a two-moment restriction:
when the whole profile moment and common zeroth weight moment are
noncollinear and the first profile difference is nonzero, no nonzero
single profile direction can BOTH have zero whole defect and vanish at
the first cutoff. Pay that boundary or cancel it jointly. The determinant
condition is explicit; it is NOT asserted cofinally on native arithmetic
and does not forbid other joined directions.

The optional tangent probe checks 500 rational cubic differences and500
exact perpendicular-moment regressions. At seed317, N256/640, heights
54/65/100 the seventh direction gives only about0.0018%-0.0607% additional
saving of the REMAINING FINITE rescaled price. Exact rational primal/dual
replay is only for the floating matrices, not prime arithmetic. All six
duals have exact zero correlations and retain at least99939/100000 of
the former six-direction finite price for EVERY real coefficient vector;
the relative gap is below1.94e-8. This is not an asymptotic/native no-go.
Sparse
two-pool coverage, probable primality, phases/logs, early original count
ceiling and common rescaling remain uncertified. The preliminary1536
seven-direction solve failed numerically; draw no arithmetic verdict
from that failure. Keep the earlier population/phase-control audit and
all prior no-gos. These tests do NOT justify further coefficient hunting
as though it supplied the missing global rate.

Work locally without commits/subagents/wider gates or public endpoint
changes. See docs/zeta-riesz-tangent-cubic-credit.md and its source-hashed
audit. The actual whole signed correlation bound remains the goal.

### Cubic canonical-crossing payment (local, 2026-10-02)

`ZetaRieszCubicSieveCost` uses the exact forbidden-prime factors at
sigma=23/32. For primes through N^3 their product is at most
exp((64/9)*N^(27/32)); after the unchanged all-count outer mass and source
normalization it is eventually absorbed into exp(-N/250000).
`ZetaRieszCubicCutoffRows` proves an INDEPENDENT bound on the SAME original
signed complete-row packet through secondPrime(B)<=N^3, across all counts
and radial shells. No zero, prime-density approximation, Type-II estimate
or whole-floor premise enters. Its full literal phase, moving length,
factorial allocation, roughness, count, physical/core masks, overflow and
rounded endpoint remain. The signed density main is cancelled BEFORE its
outer error costs are normed.

The quadratic N^2 packet was ALREADY paid by PolynomialCutoffRows. Do not
count its rediscovery as progress. `extraRows` is the exact set difference,
identified by N^2<secondPrime(B)<=N^3; `extraPacket_eq_sdiff` retains its
original integer/divisor incidence formula. Its source-normalized signed
sum tends to zero. Incidence injectivity and non-overlap with old owner
rows and cancelled interior/crossing/affine blocks are checked. REPLACE
the quadratic credit; never add both complete packets. The exact affine
rest ledger and the whole-carrier comparison retain earlier shared costs
once. Under the original stated crossing predicates, every crossing in
the cubic cap is paid or in a restored zero block. Unpaid crossings in
that branch have secondPrime>N^3; this is not a claim about every remaining
label or every Riesz-hinge configuration.

The optional cubic probe constructs original-core five- and seven-prime
labels beyond N^2 at N640/1536, retaining the actual phase/allocation and
nonzero hinge. Those early native count crops are empty. The length bound
fails at640 and holds at1536; the eventual decay theorem certifies neither
finite order. The crude sufficient scalar absorption diagnostic is around
10^40, NOT a certified packet starting index or deficit percentage.
Record log magnitudes instead of treating floating underflow as zero.
Keep the probe outside builds/CI. The independent WHOLE floor-399/5000,
ceiling, zero exclusion and native cost-minus-credit bound remain OPEN.
All earlier no-gos remain. See docs/zeta-riesz-cubic-cutoff-payment.md and
docs/riesz-cubic-cutoff-payment-audit.json. Continue local scoped Lean,
root-import lint/axiom validation without commits/subagents/wider gates
or public endpoint/README changes.

### Paid original incidences in the native whole-floor price (local, 2026-10-03)

`ZetaRieszPaidIncidenceFloor` puts the already-paid cubic signed rows into
the CURRENT native whole-floor inequality, before complete-period pricing.
`pairHinge_eq_profile_diff` identifies the literal hinge with the same
corrected cutoff profile at p*b and b. The checked incidence map is
injective, joins original products/divisors, and retains phase, moving
length, roughness, squarefree, physical and allocation masks.

The whole native allocation uses ALL intermediate primes; the paid row
uses the canonical OWNER allocation. Keep them distinct: this is a signed
correction, not identical atom deletion. The original paid packet is
restricted to the current K/864 count crop only after an independent
factor-two partial coefficient bound pays the difference using
NearCriticalCountPayment. The partial-hinge majorant is reused from
UnsignedDivisorError; do not claim its wrapper as new mathematics.
`tendsto_nativePaidPacket` proves REAL signed source-scale decay, not
complex norm decay or small absolute cutoff variation.

`nativePrunedCost` prices the joined native increment MINUS the paid
increment, retaining the imaginary tilt and joined null/tangent terms.
`eventually_joined_floor_pruned` funds its signed total by nativePaidBudget
and reuses nativeError. The added increment vanishes exactly before the
hinge, so it adds no early-cutoff debit. Subtraction may increase the
price: `nativePrunedPrice` takes the MINIMUM of the previous credited
price and the new price plus its payment. Charge that payment once; never
add the alternatives as separate credits. The resulting whole-carrier
floor is checked and cannot be weaker than the previous one.

The explicit cofinal numerical premise nativePrunedPrice<=399/5000 is
still OPEN. Its conditional contradiction endpoint does not prove a
floor, ceiling or zero exclusion. The optional original-incidence probe
has zero FUNDED gain in all six cases after paying the actual signed
total, despite some raw price reductions. At N640/1536 the native count
crop is empty, so no native population coverage, deficit percentage or
cofinal saving can be inferred. Keep logs of source amplitudes and retain
this negative diagnostic. The probe stays outside builds/CI.
See docs/zeta-riesz-paid-incidence-floor.md and
docs/riesz-paid-incidence-floor-audit.json. Keep all earlier results/no-gos
and public endpoints; continue locally without commits/subagents/wider
gates, using focused Lean, root-import namespace lint and axiom checks.

### Exact zero-response direction in the whole floor (local, 2026-10-03)

`ZetaRieszZeroResponseFloor` applies the existing all-rank spectrum-gap
cancellation to whole labels BEFORE native complete-period pricing.
`IntegerGap X n R` is the finite integer test R|n, count(R)>=2 and
forall d|n/R, X<=d OR d*R<=X. Under squarefreeness it proves
riesz(log X,n)=0. This reuses SmallCofactorCancellation; do not present
the underlying gap identity as a new discovery. The native zeroLabels
use the canonical two least primes, with no polynomial prime-size cap,
and retain the current count crop, core, phase, factorial and physical
masks. physicalCutoff agrees EXACTLY with the moving Riesz length.

The COMPLETE complex zero response and sum_zeroIncrement are checked.
An arbitrary moving signed coefficient r may multiply this direction
without a funding price or growth condition. Orders zero/one remain;
the added base increment vanishes before the hinge. Keep the earlier
null/tangent directions joined with it. nativeStep and zeroIncrement
use the ALL-prime allocation; nativePaidIncrement still has its distinct
OWNER allocation. The independently paid rows, native count/endpoint
budget and nativeError are charged once and unchanged.

The checked whole-carrier floor uses zeroClearedPrice=min(previous
nativePrunedPrice, blockCost(nativeStep-nativePaidIncrement-r*zeroIncrement)
+nativePaidBudget). Coefficient0 recovers the previous price exactly.
The saving equals HALF the difference of the joined period variations;
no prime/divisor/count is norm-priced before its group. The cofinal
numerical price<=399/5000 is still OPEN; its conditional endpoint is not
a zero exclusion or proved whole floor/ceiling.

The probe supplies an important refinement: on four frozen finite
integer samples, raw deletion improves 11/12 comparisons, but FORCED
deletion after the earlier complex/cubic credits worsens ALL12. Do not
count those raw reductions twice. Jointly rebalancing the zero direction
with the old corrections gives further FLOATING feasible gains in all12,
with the old tilt fixed. These are small nonnative orders, sampling
importance weights, probable primes, floating phases/interpolation/LP;
no cofinal rate, native credit magnitude or deficit fraction follows.
The gap classification uses exact integers, never a small floating
Riesz value. Keep both negative controls and the optional probe outside
builds/CI. See docs/zeta-riesz-zero-response-floor.md and
docs/riesz-zero-response-floor-audit.json. Continue locally without
commits/subagents/wider gates, preserve all no-gos and public endpoints,
and use scoped Lean, root-import lint and transitive axiom checks.

### Weighted complex zeros and affine tails in the whole floor (local, 2026-10-03)

`ZetaRieszWeightedZeroFloor` retains both parts of the exact complex zero
response. Arbitrary moving LABEL-dependent complex coefficients may act
on the zero correction, with no boundedness/growth hypothesis or funding
cost. The original sourceWeight, masks, factorial orders and nonzero
carrier phase are unchanged. The old real/tilted direction is an exact
special case. The full previous price remains an alternative, and zero
coefficients recover it. Its generic after-null API requires a PROVED
zero total on the original native cutoff axis; never hide this premise.

`ZetaRieszClosedTailFloor` extends the same principle INSIDE nonzero
labels. Put R=the two least primes of the WHOLE label and B=n/R. Select
complete divisor blocks (d,e) with d|B, e|R and physicalCutoff<=d. The
checked coprime incidence injection gives each original divisor once;
tailDivisors is a literal subset of n.divisors. On every such block the
original corrected profile is affine in log e, so the constant and first
Möbius moments cancel exactly. This reuses the affine moment identity;
do not present that identity itself as newly discovered. The application
to the actual native whole-period price, including nonzero-response
labels, is new. No polynomial prime cap, owner/cofactor completion, mask
deletion, factorial lower-order restriction or parity truncation appears.
The complete complex pairing is zero before taking real parts/norms.
tailIncrement has exact zero total and no new early-cutoff debit.

The whole floor uses tailPrice=min(weightedPrice,
blockCost(nativeStep-nativePaidIncrement-weightedIncrement-tailIncrement)
+nativePaidBudget). Every count/period is joined before pricing. The
distinct all-prime and owner allocations, all previous null/tangent
directions, count/endpoint payment, signed-row budget and nativeError
are retained and charged ONCE. This is not an additive second credit.
The cofinal native price<=399/5000 remains OPEN. The simple conditional
contradiction endpoint is not a zero exclusion. The ceiling is also open.

The optional weighted-zero probe reuses frozen order32/64 samples. All12
prices improve after freeing the complex coefficient, all12 improve
again with label-dependent coefficients, and all12 improve again when
closed affine-tail blocks inside nonzero labels are available. Two
closed-tail costs are near FLOATING zero. Old candidates are explicitly
repriced as feasible choices with unchanged tilt/old-null bounds. The
phase-aligned coefficient acts ONLY on an exact zero correction. Do not
infer that the base carrier phase has been removed. Counts/masks/sample
importance weights are retained, but these are NONNATIVE finite orders:
no native count crop/paid-owner budget, primality/interval/LP certificate,
cofinal rate, population coverage or native deficit fraction is proved.
The new unpaid target remains active hinge crossings joined across counts
and radial periods, not another positive majorant. See
docs/zeta-riesz-weighted-zero-floor.md and
docs/riesz-weighted-zero-floor-audit.json. Continue locally, no
commits/pushes/subagents/wider gates; scoped Lean/lint/axiom checks apply.

### Exact whole-period crossing step (local, 2026-10-03)

`ZetaRieszTailMedianFloor` resolves the actual crossing price on the SAME
joined signed feedback direction. Complete-period roots are `-T_c/V_c`,
weighted by `abs(V_c)`; an originally zero period remains a root at zero
with its full direction weight. Zero direction has zero weight. The
finite weighted median minimizes the whole blockCost over EVERY real step,
not just a small stable step. This is the standard median/L1 principle
applied to the literal native cost, not claimed new general mathematics.

`medianCredit_eq_crossing` is signed correlation minus ALL actual crossed
groups. `medianCredit_ge_feedbackCredit` retains every quadratic threshold
rebate on the SAME current aggregate/direction. Exact rational regressions
raise16/41 to4/5 and1/2 to1. Credits telescope solely across successive
repriced states. `medianAccumulated_le_excess` proves null steps cannot
remove the adverse part of the unchanged total; iteration is no proof of
its arithmetic size. Different successive trajectories do not necessarily
dominate one another: `medianPrice` retains the ENTIRE old feedbackPrice
as an alternative and spends only its own cost-funded rebate.

The compiled native signed floor retains every original count, factorial
order, support/physical/allocation mask, phase, old null/tangent and distinct
paid owner row. It has the SAME nativePaidBudget/nativeError, charged once.
The canonical rule acts on every original native squarefree label without
a new per-label fit. `canonicalMedianPrice<=399/5000` COFINALLY remains OPEN;
no numerical whole floor, ceiling, zero exclusion or RH contradiction.

The optional hash-frozen order32/64 probe keeps the full original base,
importance weights, earlier nulls and tilt. Twelve steps improve all12
finite costs by about7%-72%. Restricting ONLY new columns to owner
share<60069/100000 and second least>N^3 still improves all12 by3.6%-31.8%.
Those14/11/20/22 columns span counts4-6 and are NOT a complete exclusively
unpaid inventory. Older fixed-count supply ledgers are alternatives, not
free extra credits. The64-step scan still nearly plateaus in some cases.
All SVD residuals/zero faces are retained in the actual floating cost;
these figures are not certificates, native/cofinal points, applied native
budgets, population coverage or fractions of the endgame deficit.

See docs/zeta-riesz-tail-median-floor.md and
docs/riesz-tail-median-floor-audit.json. Continue locally without
commits/pushes/subagents/wider gates or public endpoint changes. Use focused
strict Lean/build, compiled ordinary root plus explicit module, namespace
lint and transitive standard-axiom checks. The next actual obligation is
the native minimum's signed arithmetic size, not another step-size saving.

### Joined rough-owner counting comparison (local, 2026-10-03)

`ZetaRieszRoughOwnerComparison` bounds the centered comparison error on
complete ORIGINAL owner rows M<a<=X<p, with every cofactor count joined.
The exact owner binomial selector, all factorial orders and full product
phase are unchanged. Squarefreeness/forbidden-prime holes stay solely in
the counting measure. The main is ONE signed rough-density scalar times
the signed weight sum MINUS the literal ordinary-prime cofactor head.
The unit channel is retained generically and exactly zero on these shells.
Never discard or norm-pay that prime head: its sign changes with height.

Explicit geometry is N>=32, 0<M<X<=2M, X<p, R<=M, R^4<=M^3,
L-log p<=log(R+1), exp(N/2)<=M, eligible owner and log p<=L.
The checked source rate is (2u)^N exp(-N/128)<=exp(-7N/1000).
The ALREADY proved weighted sieve cost through N^3 is subexponential;
eventually all such exclusions fit inside exp(N/1000). Owners aggregate
with their harmonic cost. With log Q<=203N/100 the WHOLE signed comparison
error is bounded by C_(u,y)*(N+1)*(1+203N/100)*exp(-3N/500), tending to zero.
This pays ONLY the counting difference, NOT the signed main or whole floor.
Do not claim the underlying counting framework is newly discovered.

`owned_rows_injective` keeps each unique-owner physical label once.
`eventually_owned_count_boundary` retains the ACTUAL native count crop
using the existing independent allowance on the deleted incidences, with
all supplied masks preserved. It supplies no duplicate count credit.
Remaining physical/radial/core mask alignment and owner<whole-cofactor
geometry are not assumed paid. The signed main needs an independent joint
bound; nativePrice<=399/5000, whole numerical floor/ceiling and zero exclusion
remain OPEN. The median/null floors are alternatives, not extra credits.

The optional twelve TOY integer-cofactor cases check the exact divisor
expansion and exhibit the prime-head sign. Their large-cofactor/core-window
hypotheses FAIL; they are neither native points nor applications of the
geometric theorem. The16–52 variation ratio is not a floor-gap saving.
See docs/zeta-riesz-rough-owner-comparison.md and its scoped audit JSON.
Continue locally without commits/pushes/subagents/wider gates or public
endpoint changes. Focused strict Lean/build, compiled ordinary root plus
explicit module, namespace lint and transitive standard-axiom checks apply.
Next: bound the signed density-minus-prime main jointly while retaining
the actual remaining masks; do not introduce another positive main allowance.

### One-small-prime owner comparison (local, 2026-10-03)

`ZetaRieszTaggedOwnerComparison` extends the same geometric centered
comparison to actual owner rows with exactly ONE prime from T in the
cofactor. A retained tag r is in V⊆T; all others T.erase r are forbidden.
The tagged measure is exactly sieve(T.erase r)-sieve(T). With r<=M<a,
the ordinary-prime cofactor heads CANCEL EXACTLY, since a tagged prime
cofactor would equal r. This does NOT delete the head in an unmarked row.
Keep the entire signed rough-density difference times the signed smooth
phase sum as ONE main. Its independent bound remains OPEN.

The old exact owner factorial selector, every order and product phase are
retained. `tagged_riesz_two_hinges` retains R_b(a/r)-R_(b-log r)(a/r),
with both signs and cutoffs. `tagged_rows_injective` proves the tags and
owners do not duplicate physical labels. If T contains every prime through
N³ and retained tags exceed N², `tagged_physical_prime_support` gives the
ORIGINAL lower physical prime mask and the upper bound below the owner.
`eventually_tagged_count_boundary` uses the SAME existing native count
payment on actual incidences; it is not an additional count credit.

On the declared complete rows, with the preceding comparison geometry
and N³<=M, the joined centered ERROR is O_(u,y)(N^5 exp(-3N/500)),
with an explicit eventual bound and Tendsto theorem. Only the ERROR gets
the polynomial tag count. Neither the main nor the whole floor is paid.
Owner<whole-cofactor, arbitrary partial rows and other core-mask alignment
remain outside this theorem. No new native threshold or contradiction.

The two actual core endpoint radial factors have checked source rate
exp(-N/200000), including the successor factorial order. This boundary
audit is not an interior signed integral/discrete bound. The continuous
old-owner-selector probe has a long transient (sampled source norm about
0.91 at N=65536); never claim the main already small from the probe.
Its density scalar, discrete transport and original remaining masks are
NOT proved by that model. The twelve integer toys fail the large-cofactor
and original core hypotheses; no geometric theorem is applied to them.

See docs/zeta-riesz-tagged-owner-comparison.md and its scoped audit.
Next attack the signed smooth weight sum across complete total-log windows,
including exterior boundaries and the exact allocation; keep both signed
cutoff terms together. Native floor -399/5000 and ceiling42/25 stay OPEN.
Continue LOCAL ONLY, no subagents/wider gates/public endpoints/commits/pushes.

### Signed complete-core least-tag cancellation (local, 2026-10-03)

`ZetaRieszOwnerPhasePrimitive`, `ZetaRieszOwnerLatticePhase`,
`ZetaRieszTaggedOwnerPhase` and `ZetaRieszTaggedCoreWindow` now independently
bound the SIGNED main and the LITERAL complete tagged-owner rows. This
supersedes the preceding open-main statement ONLY on their explicit
complete-core geometry. All factorial orders, the exact old binomial
allocation and the full product phase remain. Sum the entire phase first:
its finite polynomial primitive leaves only the original1.95N/2.03N
endpoints, with checked source rate exp(-N/200000). Ordinary integer
sampling retains both floor endpoints and has an additional exp(-N/4)
cost. This is not generic masked prime-density/Abel transport.

The SAME signed tagged Riesz density scalar joins across capped dyadic
rows before its norm is used. The literal global bound is
20u*C*(6+abs(y))*(N+1)^6*exp(-3N/500)
+10*(N+1)^5*ownerSamplingBudget(u,y,N), tending to zero for fixed y.
The bound uses0<=u<=10001/20000, abs(y)>=54, N>=64 eventually, eligible
owners with1<=log p<=4N/3 and log p<=L, log Q<=2.03N, N^3<=M_p,
X_p<p,0<R_p<=M_p, R_p^4<=M_p^3 and L-log p<=log(R_p+1).
M_p/X_p are the EXACT floored original core endpoints. Do not silently
extend this saving to partial/internal-mask windows.

`leastTagExclusions` forbids only primes SMALLER than the retained tag.
The exact least-tag partition therefore covers cofactors with arbitrarily
many small primes, instead of the former exactly-one-small restriction.
`selectedRows_sum` joins them into disjoint literal owner/cofactor pairs.
If T contains every prime through N^3 and retained tags exceed N^2,
the original lower physical mask is proved; a<p gives the upper cofactor
prime mask. Owner logs in[51N/50,5N/4] give X_p<p and nondominance
throughout the full core. Do not claim all other original masks aligned.

`eventually_cropped_selected_core_bound` retains the ACTUAL native count
ceiling on the unchanged dyadic schedule. Its signed budget is
taggedCoreBudget(u,y,N_j)+the SAME existing count allowance, tending to zero.
Each label and its count payment occur once; this is not an extra count
credit. The native cutoff-price ledger has NOT yet spent this family.
The previous global nonowner credit is also not recreated or doubled.

Fully N^3-rough cofactors have no tag, and their ordinary-prime cofactor
head remains signed/unpaid. Owner<whole-cofactor geometry, partial rows
and remaining native-mask alignment remain outside this payment. The
whole floor -399/5000, ceiling42/25, zero exclusion and RH remain OPEN;
no fraction of the floor deficit or finite native threshold is claimed.
Do not return to divergent restAllowance or selected-mode norm payment.

The optional probe has20 floating continuous cases,3 integer toys and
an exact least-tag partition regression (352 labels,65 with several small
primes, no duplicates). The continuous N=1048576 norm around4.98e-5 omits
the arithmetic density/masks and is NOT a native certificate. Integer
toys fail original core geometry; high owner slope1.30 is not claimed to
satisfy the full nondominant mask. Preserve the earlier tracked
probe_riesz_owner_phase.py; this slice's script is uniquely named
probe_riesz_owner_phase_primitive.py. See docs/zeta-riesz-owner-phase.md
and docs/riesz-owner-phase-audit.json for the scoped checks and snapshots.
Continue LOCAL ONLY without subagents, commits/pushes, public endpoints,
root registration or wider gates. Next apply this literal signed payment
to the exact native mask/price ledger, then attack the fully rough and
partial-window remainder while keeping its ordinary-prime head joined.

### Native small-tag rows are now spent (local, 2026-10-03)

`ZetaRieszSmallTagNativeFloor` completes the preceding mask/ledger task
on its EXPLICIT complete-owner population. Owners are actual intermediate
primes with51N/50<=log p<=5N/4; the complete cofactor window is the exact
1.95N/2.03N core. The least cofactor prime is in(N^2,N^3], every larger
small prime remains allowed, and the ACTUAL native count ceiling remains.
`rows_injective` prevents duplicate labels. The original masks, squarefree
labels and absence of cancelling/dominant interior pieces are proved by
`eventually_labels_subset_native`, not assumed or completed.

The comparison cutoff is explicitly floor(exp(N/2)). The stronger exact
lower endpoint floor(exp(1.95N-log p))>=exp(2N/3), R^4<=M^3, N^3<=M
eventually and L-log p<=log(R+1) follow from native length bounds
5N/4<=L<=139N/100. The signed estimate is for the ORIGINAL FULL
residualCoefficient allocation. It uses the previous signed row/count
budget plus the existing global nonowner error ONCE on this subset.
`eventually_packet_bound`, `budget_tendsto` and `tendsto_packet` prove
its source-normalized REAL signed total tends to zero independently
of any hypothetical zero. Complex norm decay is not claimed.

`paidIncrement` uses the SAME native cutoff profile and complex logarithmic
nulls; its total is exactly the paid real packet. The main null-corrected
increment is now on the actual native squarefree labels minus this
population. The whole free tangent correction stays joined, not paid as
an extra credit. Remove these signed rows BEFORE complete-period clipping;
do not charge their possibly large absolute cutoff variation.

`eventually_joined_floor_pruned` is a whole-carrier floor with explicit
remaining restCost+budget+nativeError. This alternative uses ZERO imaginary
tilt because the independent row payment is real. The prior tilted price
is retained as another valid alternative. `price` takes their minimum;
`price_le_previous` and `gain_nonneg` prove no regression or double spending,
NOT a positive percentage of the global deficit. No monotonicity of
clipped period costs under population deletion is presumed.

The cofinal numerical premise price<=399/5000 remains OPEN, as do the
whole floor, ceiling42/25, zero exclusion and RH. The endpoint
`false_of_cofinal_price` is CONDITIONAL. Fully N^3-rough cofactors have
no tag and retain their ordinary-prime subtraction; other owner geometries
and partial windows are not covered by this payment. Next keep those
remaining counts/crossings joined while attacking their signed cost.
Preserve all earlier positive/no-go results and concurrent semiprime work.

See docs/zeta-riesz-small-tag-native-floor.md and its scoped audit JSON.
Continue LOCAL ONLY without commits/pushes, subagents, root registration,
public README/explorer/endpoint changes or wider gates. Strict leaf source,
targeted build and compiled ordinary-root plus explicit-leaf namespace
lint/transitive-axiom checks are the relevant gates for this slice.

### Rough rows and prime head are now paid jointly (local, 2026-10-03)

`ZetaRieszRoughPrimePairCancellation` proves an INDEPENDENT real signed
bound for the literal fully N^3-rough population PLUS its exact ordinary-
prime head. Owners have51N/50<=log p<=5N/4, the entire1.95N/2.03N core
window is retained, and every native count/physical/allocation mask is
proved. No selected-zero, exposure or unproved cancellation premise is
used. Do not infer separate packet or head decay from this joint result.

`core_joint_comparison` joins all radial shells with the SAME signed
cutoff scalar and prime head. Only after the complete integer-lattice
phase sum is paid is the scalar bounded. Owners aggregate harmonically.
`jointBudget` is8uC(6+abs y)(N+1)^3 exp(-3N/500) plus8(N+1)^2 times the
previous ownerSamplingBudget; it tends to zero. Native count and restricted
nonowner errors are each included once on this rough population.
`eventually_packet_joint_bound` and `tendsto_packet_add_nativeHead` keep the
original FULL residualCoefficient allocation. Only real decay is proved.

`eventually_nativeHead_eq_prime_pairs` removes the sieve EXACTLY on prime
cofactors above N^3, exposing one weighted signed prime-pair sum with full
cos(y(log p+log q)) phase and smooth owner allocation. It is NOT the joined
markedWeight that vanishes on two-prime labels. That old theorem does not
pay this head. Never drop it or take termwise absolute prime allowances.

`labels_disjoint_smallTags` proves the old paid small-tag labels and these
rough labels do not overlap. `eventually_step_sub_paid` proves the remaining
main is exactly on native squarefree labels minus BOTH populations, with
whole free tangent corrections joined. `eventually_joined_floor_pruned`
spends both signed totals BEFORE complete-period clipping and retains
restCost+nativeHead+combinedBudget+the SAME nativeError. The head is signed,
not norm-paid. `price` keeps the better old/new price; `price_le_previous`
proves no regression, NOT any positive percentage of the global deficit.

The cofinal price<=399/5000 premise remains OPEN. No whole floor, ceiling,
restricted contradiction, zero exclusion or RH is claimed. Next attack
nativeHead jointly with the remaining signed cutoff periods and owner/
window exteriors; do not separate the composite counts again. Preserve
all previous positive/no-go results and concurrent semiprime work.
See docs/zeta-riesz-rough-prime-pair-cancellation.md and its focused audit.
Continue LOCAL ONLY without commits/pushes, subagents, root registration,
public README/explorer/endpoint updates or wider gates. Use strict leaf,
targeted build and compiled ordinary-root plus explicit-leaf lint/axiom
checks; preserve the prior frozen proof/probe snapshots.

### Every cofactor geometry in the owner window is paid jointly (local, 2026-10-03)

`ZetaRieszAllTagNativeFloor` applies the existing signed counting bound to
ALL least tags through N^3, including primes<=N^2. The previous native
instantiation discarded those low tags unnecessarily: the exact native
window/count theorem supplies every physical/deletion mask without that
restriction. `budget_eq_previous` proves the quantitative error budget
is UNCHANGED. Full boundedShare allocation, phase and count crop remain.
`eventually_addedPacket_bound` and `tendsto_addedPacket` isolate ONLY the
new labels (all old small-tag labels removed) and independently pay their
real signed contribution by twice the old source-small budget. No zero,
exposure, phase approximation or new arithmetic hypothesis is used.

`owner_rows_complete` proves that all small-tag rows plus fully rough
rows cover EVERY squarefree composite cofactor in the1.95N/2.03N core
window and native count crop, for51N/50<=log p<=5N/4. There is no remaining
small/rough/least-prime restriction on these rows. Disjointness is exact.
`eventually_full_packet_joint_bound` proves abs(fullPacket+nativeHead)
is bounded by the SAME previous combinedBudget, tending to zero. Only
real JOINT decay is proved; never infer either summand or a complex norm
decays separately. No bound outside the displayed owner range is given.

`ZetaRieszPrimeHeadPeriods.sum_headIncrement` realizes the SAME signed
prime correction on its actual one-sided integer hinge axis. Its smooth
owner/prime sum remains unchanged and is NOT the markedWeight that vanishes
on two-prime labels. Only zero native increments extend to the physical
endpoint. `cost_eq`/`price_le_signed_overlap` prove the exact global cost
gain is same-sign COMPLETE-period overlap MINUS negative head mass.
Keep that full crossing cost. Do not price positive overlap alone.

The all-tag `eventually_sum_fullPaidIncrement` and whole-floor theorem
spend the entire owner population ONCE before period clipping, retaining
all outside-owner labels, whole null/tangent columns and the SAME paid
nativeError. Head and outside-owner remainder stay JOINTLY signed. Older
floors are alternatives, never stacked overlapping credits. The cofinal
price<=399/5000 remains OPEN; the conditional simple-zero endpoint is not
a zero exclusion. Ceiling42/25 and RH also remain open. This is concrete
population cancellation, not a claimed percentage of the global deficit.

The optional prime-head period probe exhausts a TOY interval, retains its
actual finite joint error and never applies the eventual rate. Two of six
floating tests improve finite costs by about3.7%/7.5%, four do not. These
are not native core/population/certification results. Preserve all old
proof/probe snapshots, no-gos, semiprime work and public endpoints.
See docs/zeta-riesz-all-tag-native-floor.md,
docs/zeta-riesz-prime-head-periods.md and the combined focused audit.
Continue LOCAL ONLY with strict leaf/targeted builds and compiled ordinary
root plus explicit-leaf lint/axiom checks; no subagents, commits/pushes,
root registration, public endpoints or wider gates.

### All high owners paid before the balanced remainder (local, 2026-10-03)

`ZetaRieszBalancedOwnerFloor` combines the complete51N/50..5N/4 owner
payment with the existing `ZetaRieszJointOwnerEnvelope` literal geometric
bound on ONLY the labels outside that payment. The added quantitative
cost is6*divisorSquareDirichletMass(1+1/262144)*(N+1)*exp(-N/25000).
`remaining_high_coefficient_eq_zero` proves every other high-owner label
has zero ORIGINAL residual coefficient, using actual masks and the exact
all-tag/rough cofactor coverage. No cofactor is completed.

`eventually_high_packet_joint_bound` and `tendsto_high_packet_add_head`
pay EVERY squarefree native label withlog(largestPrime n)>=51N/50,
jointly with the SAME signed prime head. This is an INDEPENDENT real
arithmetic bound, with all native counts, physical masks, full allocation
and phase retained. No least-prime/roughness subclass remains. Do not
claim either summand or its complex norm decays separately.

`sum_highPaidIncrement`/`step_sub_highPaid` spend that entire payment
ONCE on the original cutoff axis. Zero-response labels are removed by
their exact total, not charged by cutoff variation. Whole free null and
tangent columns remain joined. `mem_restLabels` makes the remainder
exact: original native squarefree labels withlog(largestPrime n)<51N/50.
`rest_owner_share_lt` proves owner share<34/65, from the39N/20 core
lower endpoint. This is an actual reduction of the unpaid population,
NOT a claimed percentage of the global floor deficit.

`tendsto_rest_sub_head_sub_native` retains the remaining balanced real
sum MINUS the same head as the full source-equivalent object. The
whole-floor `eventually_joined_floor_pruned` keeps SAME nativeError and
the new independent budget. Older prices are alternatives, not stacked
credits. `price_le_previous` assumes no monotonicity under deletion.
The cofinalprice<=399/5000 remains OPEN, as do the floor,42/25 ceiling,
restricted contradiction, zero exclusion and RH. The next target is
SIGNED cancellation in that balanced remainder-minus-head; do not
return to an absolute head allowance or the divergent balanced-triple
positive allowance. See docs/zeta-riesz-balanced-owner-floor.md and
docs/riesz-balanced-owner-floor-audit.json.

Preserve every previous positive/no-go proof and frozen snapshot,
concurrent semiprime work and public endpoints. Continue LOCAL ONLY:
strict leaf/targeted build, compiled ordinary root plus explicit-leaf
lint and all-declaration standard-axiom audit; no subagents, root
registration, commits/pushes, public endpoints or wider gates.

### Whole balanced allocation correction paid (local, 2026-10-03)

`ZetaRieszBalancedAllocationPayment` applies the EXISTING generic9/16
allocation-tail theorem to EVERY label left by the high-owner payment.
`rest_prime_log_le` uses largest share<34/65 to cover every prime leg.
`assigned_subset_bound` pays the complex norm of the allocated DIFFERENCE
on any subset of the entire balanced remainder, at all native counts and
arbitrary phase height. Its independent budget is4*radiusCeiling*(N+1)*r^N*M,
where r<9991081/10000000<1 and M is the finite original majorant mass at
1+1/262144. No fixed count39, least-share band, new mask or zero hypothesis
is used. This specializes existing arithmetic, not a newly discovered
generic binomial theorem. No small finite-order constant is claimed.

`unallocated_sub_rest_norm_bound` pays ONLY the exact allocation correction.
`tendsto_unallocated_sub_head_sub_native` keeps the ORIGINAL balanced
coefficient sum MINUS the SAME signed prime head source-equivalent to
the whole native carrier. Neither main summand is paid independently.
`sum_step`/`eventually_joined_floor_paid` spend that payment in the actual
floor BEFORE period clipping; the main has no boundedShare allocation,
all counts/crossings are joined and the old whole native tangent columns
and SAME nativeError remain. The high-owner budget is retained once.
Earlier prices remain alternatives; no clipping monotonicity or stacked
credit is assumed. No percentage of the floor deficit is asserted.

The next target remains the SIGNED original balanced sum-minus-head.
The cofinal wholeprice<=399/5000, floor, ceiling42/25, restricted
contradiction, zero exclusion and RH are OPEN. Never treat the conditional
`false_of_cofinal_price` as a proved bound. See
docs/zeta-riesz-balanced-allocation-payment.md and the focused audit.
Preserve all old positive/no-go proofs, snapshots, semiprime work and
public endpoints. Continue LOCAL ONLY: strict leaf/targeted build,
frozen compiled ordinary root plus explicit-leaf lint/all-declaration
standard-axiom audit; no subagents, root registration, commits/pushes,
public updates or wider gates.

### Paid radial strips spent on the balanced allocation-free main (local, 2026-10-03)

`ZetaRieszBalancedRadialPayment` reuses the EXISTING all-mask radial bound
from `ZetaRieszLargeOrderCore` on the ORIGINAL balanced coefficient sum.
`central_sub_unallocated_norm_bound` independently pays ONLY the discarded
radial difference by C*exp(-N/1000000), uniformly in all heights and retained
counts. C is the original finite constant, not a claimed small finite-order
value. There is no new generic phase or radial cancellation estimate.

`centralLabels` retains every native mask and log(owner)<51N/50 while
requiring1.971N<log n<=2.029N. `central_owner_share_lt` tightens every owner
share to340/657; `central_prime_log_lt` covers every prime leg. Do not call
the narrower window a percentage of the unpaid source/floor deficit.
The SAME full signed nativeHead remains, with its full original radial
support. `tendsto_central_sub_head_sub_native` keeps central-minus-head
source-equivalent. Never infer either term or its complex norm is paid.

`sum_step` and `eventually_joined_floor_paid` spend the radial difference
ONCE before whole-period clipping, keeping the high-owner/allocation
budgets, whole native free columns and SAME nativeError. Older funded
prices remain alternatives; no clipping monotonicity or stacked credits.
The cofinal signed price<=399/5000 is OPEN, as are floor, ceiling42/25,
restricted contradiction, zero exclusion and RH.

The optional balanced-joint probe uses TOY length -2N log u atN6/7, not
native dyadic orders/moving integer length/deletion masks. Baselines show
finite cross-count/head cancellation. All six radial-pruned tests fail to
improve the finite price after charging their ACTUAL signed removed total.
No eventual budget is applied at those toy orders. Preserve their prior
source/output snapshots. The old owner-window payment requires exterior
radial endpoints; no square-root-owner extension through an interior
factorial-saddle endpoint is proved here. See the local doc and focused audit.

Preserve old positive/no-go proofs, frozen snapshots, semiprime work and
public endpoints. Continue LOCAL ONLY: strict leaf/targeted build, frozen
compiled ordinary root plus explicit-leaf lint/all-declaration standard-
axiom audit; no subagents, root registration, commits/pushes, public updates
or wider gates.

### Joint prime-head quadratic transport (local, 2026-10-03)

`ZetaRieszPrimeHeadTransport` keeps the SAME nonzero signed ordinary-prime
head. Each literal p,q atom is transported to its actual four-divisor
quadratic prefix, whose log-square response is2*log p*log q/(N+1).
`pair_cofactor_lt_owner`/`native_pairOrbit_eq_divisors` retain the canonical
q<p geometry. No marked-weight two-prime vanishing is used to delete it.
`sum_quadraticHead` preserves the original total, and `sum_direction` makes
the old-minus-quadratic update an EXACT null. The common endpoint contains
all pair products; the old increments added beyond its previous endpoint
are exactly zero and do not change the original cost.

`central_floor_with_gain` spends the proved crossing-square credit for
both orientations. `coupledDirection` goes further: add the free main-
profile update and the head update BEFORE computing any zero-face debit
or crossing. `coupledCredit_eq_cost_saving` identifies the full signed
correlation minus EXACT crossing cost with the actual whole cost saving.
`central_floor_with_coupled_credit` and `eventually_joined_floor_coupled`
spend that joint credit in the CURRENT floor. All counts, physical/owner
and rough-prime masks, phase, head allocation, old whole native tangent
columns and high-owner/allocation/radial/native-error budgets remain.
No separate head norm, assumed clipping monotonicity or stacked credits.

The optional N6/7 toy probe retains all signed totals and checks the exact
finite crossing identity in FLOATING arithmetic. Joint quadratic savings
are positive in all11 nonzero-baseline tests, up to48.1% of toy cost; this
is NOT a percentage of the native floor deficit. Toy length -2N log u is
not native integer length/schedule/deletion masks; no eventual budget is
used. Preserve exact analytic zeros below the hinge with its piecewise
formula, and preserve the old optimized choice when solver roundoff meets
an already-zero price. Do not suppress nearly-zero optimized groups to
claim a larger crossing-square saving. Exploratory total-label/two-column
directions are not part of the proved quadratic transport.

The cofinal bound on WHOLE cost minus coupled credit<=399/5000 remains
OPEN, as do floor,42/25 ceiling, restricted contradiction and RH. Neither
an exact null nor a finite LP saving proves the needed native credit size.
Do not count a new conditional endpoint as a numerical bound. See
docs/zeta-riesz-prime-head-transport.md and the focused audit. Preserve all
old positive/no-go proofs, snapshots, semiprime work and public endpoints.
Continue LOCAL ONLY: strict leaf/targeted build, frozen compiled ordinary
root plus explicit-leaf lint/all-declaration standard-axiom audit; no
subagents, root registration, commits/pushes, public updates or wider gates.

### Least-prime critical-shell signed payment (local, 2026-10-03)

`ZetaRieszCriticalPrimeFloor` pairs the actual two least primes and joins
all subset ranks. On the exact least-prime gap, the original response is
log(r) times the integer Mobius sum over the remaining critical divisor
shell. `criticalDivisors_eq_singleton` proves that2*log n<3L and ANY
prime in that shell force the entire shell to be that singleton, including
exclusion of every composite competitor. The exact Riesz response is
-log(r), regardless of total-count parity; no completion or density is used.

`native_budget` discharges the strict budget for central native labels
atN>=65536 using the existing length lower bound. IMPORTANT:
`native_primeCritical_count_le_four` then limits this family to counts3/4
on the actual balanced owner geometry. Do not call it a higher-count
payment. Active least-prime crossings and composite-critical shells remain.
`favorable_sum_nonneg` and `central_joint_floor_of_favorable` spend the
nonnegative ORIGINAL-phase subfamily directly in the balanced floor,
keeping the SAME full signed head and every original central mask.
The adverse complement's cofinal signed allowance is still OPEN.

The optional critical-shell probe uses toy length -2N log u atN6/7/8,
full complex phase and SAME full head. All18 frozen signature regressions
pass; this is not a native dyadic/moving-length/deletion-mask certificate.
Do not apply eventual budgets there, infer native savings percentages, or
count an exact null update as a change to the actual signed total.
See docs/zeta-riesz-critical-prime-floor.md and its focused audit.
Floor399/5000, ceiling42/25, contradiction, zero exclusion and RH remain
OPEN. Preserve all old positive/no-go proofs/snapshots, semiprime work and
public endpoints. Continue LOCAL ONLY with strict leaf/targeted build,
frozen compiled root plus explicit-leaf lint/all-declaration axiom audit;
no subagents, root registration, public updates, commits/pushes or wider gates.

### Joint signed phase transport (local, 2026-10-03)

`ZetaRieszJointPhaseTransport` assembles EVERY original central balanced
label and the SAME full signed prime head before estimating paired phases.
`joint_transport_eq` retains the complete row/column amplitude residual,
including all unmatched phases. `central_joint_error` proves
abs(centralRest.re-nativeHead-(U-M))<=E, where M is the SIGNED centered
first phase moment and E=sum(w*abs(delta)^3)/24. No separate count price,
absolute first moment, deleted unmatched contribution or prime completion.
Every original central/head mask and the full product phase remain.

`cubicCost_le_small_gap` pays at most epsilon^2/24 of the absolute angular
transport when every nonzero pair gap<=epsilon. The deterministic native
CDF coupling is nonnegative; no complete cover, small imbalance or
unproved marginal identity is assumed in the floor. Its residual ledger
remains explicit. `eventually_joined_floor_transport` spends only the
previous funded high-owner/allocation/radial/native errors; `price` takes
a minimum with the previous funded alternative, never stacked credits.

The optional N6/7/8 floating toy probe retains all counts, original phases
and SAME full head; all18 frozen complex-total regressions pass. The old
absolute-chord matching improves none of12 previous optimized prices.
Keeping the signed first moment improves all8 genuinely adverse cases;
4 favorable cases retain positive signed lower bounds. Solver-roundoff
improvement of an already-zero price is NOT a saving. Cubic charges are
about1e-12 to1.2e-7, but adverse unmatched/first-moment terms survive.
Toy length -2N log u is NOT native damped integer length, native dyadic
schedule or all deletion masks. No eventual budgets or cofinal/native
margin percentages are inferred. The greedy floating execution is not
an interval-certified evaluation of the Lean CDF sums. Outside builds/CI.

The actual new open obligation is the JOINT cofinal bound on U-M and the
whole price<=399/5000; native cofinal smallness of E is also unproved. Do not pursue further chord/cubic price refinements
as a substitute for that arithmetic estimate. A small cubic defect does
not remove a negative signed total. Floor, ceiling42/25, contradiction,
zero exclusion and RH remain OPEN. Preserve all old proofs/no-gos,
frozen snapshots, semiprime work and public endpoints. Continue LOCAL
ONLY: strict leaf/targeted build, frozen compiled ordinary root plus
explicit-leaf lint and all-declaration standard-axiom audit; no subagents,
root registration, commits/pushes, public updates or wider gates.
See docs/zeta-riesz-joint-phase-transport.md and its focused audit.

### Actual prime-head per-leg pole payment (local, 2026-10-03)

`ZetaRieszPrimeHeadPolePayment` applies the existing shifted-center
operator to BOTH actual prime legs, with the SAME full signed correction,
complementary allocation and product phase. `head_prime_logs` proves
log p>=51N/50 and log q>7N/10 from the original integer pair interval.
All kept factorial slots, INCLUDING orders0/1, satisfy the upper-order
multiplier estimate. `filteredMass_kernel` is the exact product of leg
kernels, not the failed total-order filter or a cofactor completion.

`filteredHead_error` pays the entire source-normalized operator CHANGE
by10*(N+1)^3*exp(-N/2) for0<=u<=10001/20000,54<abs(y),N>=64, uniformly
in height. `budget_lt_native` certifies this budget<10^(-40) for ALL
N>=256. This is a DIFFERENCE estimate, not payment of the signed head
itself. No generic relative error is multiplied by a shrinking-share
carrier envelope; the actual two exponential prime lower bounds supply
the saving. `tendsto_central_sub_filteredHead_sub_native` retains the
whole source. `eventually_joined_floor_of_joint` keeps every prior
high-owner/allocation/radial/native error plus this new budget ONCE.

The optional toy probe retains the unchanged balanced main, SAME head
and every complementary factorial order. All12 frozen complex-total
regressions atN6/7/8,y65/100 pass. The adverse joint bias survives and
the real operator correction can have either sign. No native/eventual
budget is applied at toy orders; no floor improvement or cofinal/native
margin percentage is inferred. The toy moving-length/deletion masks
are still not native. No hard-masked complete-leg phase transfer is
proved, and small-prime legs of the balanced main are NOT paid by this
head-only estimate. Preserve EVERY previous modal/low-order/cutoff no-go.

The independent joint signed floor399/5000, ceiling42/25, contradiction,
zero exclusion and RH remain OPEN. See
docs/zeta-riesz-prime-head-pole-payment.md and its focused audit.
Continue LOCAL ONLY: strict leaf/targeted build, frozen compiled ordinary
root plus explicit-leaf lint/all-declaration standard-axiom audit; no
root registration, public updates, commits/pushes, subagents or wider
gates. Preserve all prior proof/probe/doc snapshots and semiprime work.

### Whole balanced/head shared-incidence cancellation (local, 2026-10-03)

`ZetaRieszHeadSharedCancellation` applies exact two-prime saturation to
the ACTUAL central native/head intersection. For1/2<=u<=10001/20000 and
N>=65536, any two prime logs>7N/10 give original coefficient zero at
every total count>=4. In particular a head-cofactor prime occurring below
the main owner cancels the entire label. `higher_count_profile_eq_owner`
joins ALL surviving higher-count shared incidences into ONE unique-owner
profile before norms/reals, with arbitrary original correlated weights.
`nonownerShared_source_floor` pays the corresponding whole sector by zero;
`centralRest_eq_without_nonownerShared` removes it exactly. SAME full head,
all original masks, low factorial orders and full phase remain.

This is an application of existing saturation, not a second payment of
already-zero labels. Do not call the owner profile bounded or infer the
cofinal floor. Nonowner TRIPLES, the surviving higher-count owner profile,
nonshared main labels and global cross-group correlations remain open.

The optional interference probe exhausts the TOY N6/7/8 windows at180
height/window points and checks18 frozen complex-total regressions. Count
cross terms cancel within least-prime groups at every tested point, but
global cross-count and owner/head correlations can REINFORCE. A separate
28-point height stress test up to10000 also finds POSITIVE within-least-prime
cross terms at11 points. Do not turn the first scan's negative local sign
into a universal or eventual estimate. Its4 frozen regressions pass, but
the toy stress test is not a native asymptotic no-go either. No uniform
orthogonality/independence is proved. Incidence energy is NOT whole energy.
Toy lengths/orders/deletion masks are not native; no eventual budget,
cofinal saving percentage, floor or zero exclusion follows. Preserve all
old proof/probe/audit snapshots and no-gos, including the operator payment
being a DIFFERENCE estimate. See docs/zeta-riesz-head-shared-cancellation.md
and its focused audit. Floor399/5000, ceiling42/25, contradiction and RH
remain OPEN. Continue LOCAL ONLY: strict leaf/targeted build, frozen compiled
root plus explicit leaf lint/all-declaration standard-axiom audit; no root
registration, public updates, subagents, commits/pushes or wider gates.
Preserve concurrent semiprime work.

### Shared-owner completion boundary audit (local, 2026-10-03)

`ZetaRieszOwnerCompletionAudit` tests the owner-free completion suggested
by the higher-count shared-incidence cancellation. For native N>=65536,
1/2<=u<=10001/20000, every SAME original correction pair satisfies
log q<=101N/100 and the new ordinary-prime cofactor response is EXACTLY
R_(L-log q)(p)=L-log q>=3N/8>0. Its amplitude is at least the original
(L-log p)*ownerWeight, with the allocation retained. The two channels
have the IDENTICAL product phase and reinforce before any label sum.
`originalPair_boundary_norm_add` proves this directly with the literal
head, radial kernel, allocation and sieve. This is NOT a bound on their
whole signed sum, nor evidence that different labels cannot cancel.

STOP the owner-free completion as an automatic payment: its count-one
ordinary-prime boundary survives. The joined marked-weight two-prime
zero theorem does not apply to this different literal divisor response.
Do not charge this boundary to the squarefree counting error or move it
into an anonymous completion correction. The SAME full original head,
nonowner TRIPLE boundary and off-head prime pairs must stay explicit.
The nonowner higher-count exact zeros remain available without a second
credit. No new carrier or cofinal floor has been proved by this audit.

The optional N6/7/8 audit keeps all counts and full complex phase, checks
18 frozen-total regressions and matches every old head label in the
tested main window exactly once. New and old positive amplitudes reinforce
on these identical labels. The model density is SQUAREFREE INTEGER density,
not prime density. The old head always retains its FULL radial window.
Toy length/orders/deletion masks are not native; no eventual budget,
cofinal rate or floor-margin percentage follows. The probe's separate
prime/triple boundaries remain unpaid even when its counting error is small.

See docs/zeta-riesz-owner-completion-audit.md and its focused audit.
The independent whole signed floor399/5000, ceiling42/25, contradiction
and RH remain OPEN. Preserve all previous positive/no-go proofs and frozen
artifacts, concurrent semiprime work and public endpoints. LOCAL ONLY:
strict leaf/targeted build, frozen compiled ordinary root plus explicit
leaf lint/all-declaration standard-axiom audit; no root registration,
public updates, commits/pushes, subagents or wider checks.

### Joint circular phase-discrepancy test (local, 2026-10-03)

`probe_riesz_joint_phase_discrepancy.py` joins ALL original balanced toy
counts and the SAME full signed head before computing the centered circular
CDF energy. All18 frozen complex-total regressions pass. Its whole Cauchy
price improves0/12 previous funded prices and0/18 cubic signed prices.
The first harmonic contributes about48%..98% of the measured energy and
is the actual unresolved complex joint sum. Bounding only the higher
harmonics cannot pay that signed bias. This is a failed finite candidate,
NOT a native/cofinal no-go for every phase-energy argument. No new Lean
infrastructure, arithmetic saving, cofinal floor or zero exclusion follows.
Toy length/orders/deletion masks are not native; previous eventual budgets
are not applied. Keep this probe optional, outside builds/CI, and preserve
all original masks, phases, signed amplitudes and frozen evidence. See
docs/riesz-joint-phase-discrepancy-audit.json. Keep the whole independent
floor399/5000 and ceiling42/25 OPEN; continue LOCAL ONLY.

### Whole joint prime-sign constraint (local, 2026-10-03)

`ZetaRieszJointPhaseConstraint` proves EVERY original central label has a
prime outside the SAME full head support. Fix head signs to one and average
the remaining multiplicative signs jointly: the entire main averages to
zero, while the head stays fixed. `exists_joint_le_neg_head` and
`arbitrary_sign_allowance_ge_head` show a bound valid for arbitrary prime
signs must pay at least the height-zero head. These signs are NOT one fixed
logarithmic character. No fixed-height/cofinal no-go, head growth theorem,
new arithmetic floor saving or zero exclusion follows. All18 toy complex
regressions pass; the native geometry theorem is separate from that probe.
The next estimate must use ACTUAL logarithmic prime correlations in the
whole main-minus-head sum. Do not replace those with arbitrary/independent
phases or claim the sign average bounds the actual carrier. Keep floor
399/5000 and ceiling42/25 OPEN. Preserve earlier proofs, snapshots, semiprime
work and public endpoints; LOCAL ONLY with focused leaf validation.
See docs/zeta-riesz-joint-phase-constraint.md and its focused audit.

### Global squarefree completion boundary test (local, 2026-10-03)

`ZetaRieszGlobalCompletionBoundary` proves on EVERY original head pair at
N>=65536 that the full semiprime response is R_L(pq)=log(pq)-L and exceeds
the allocated head coefficient by at least17N/100. The SUBTRACTED global
semiprime atom has the opposite sign to the SAME full head. Join before
norms: `boundary_sub_head_norm` loses exactly the old head norm, and
`matched_boundary_real_floor` gives its literal whole-population bound.
`boundary_re_eq_neg_literal` checks the actual coefficient/kernel/sieve.
No separate head payment, low-order deletion, mask replacement or exposed
zero premise is used. This is different from the earlier smaller-prime
cofactor completion, whose R_(L-log q)(p) boundary reinforces the head.

The optional global toy completion has18 main/head complex regressions;
its companion has18 head regressions and retains every matching pair.
Do NOT call their finite norm-price saving a native/cofinal floor saving.
The global ledger still retains ordinary primes, unmatched semiprimes,
raw high-owner terms and the signed bulk main. No native all-mask global
completion or source-o(1) payment of those boundaries is proved. The old
high-owner payment has its allocation; do not apply it to raw high owners.
STOP global completion as an automatic floor proof when these terms remain.
See docs/zeta-riesz-global-completion-boundary.md and its focused audit.
Keep floor399/5000, ceiling42/25 and RH OPEN. Preserve prior proofs/probes,
semiprime work and public endpoints; LOCAL ONLY, focused leaf/root-compiled
validation, no root registration, commits/pushes, subagents or wider gates.

### Completed all-count bulk paid in the central native ledger (local, 2026-10-03)

`ZetaRieszGlobalBulkPayment.completedCore_real_bound` independently pays
the REAL signed completed squarefree bulk on1.95N<log n<=2.03N, for
N>=64,1/2<=u<=10001/20000 and54<=|y|. All counts including ordinary
primes/semiprimes are joined, with native moving floor-defined length,
full factorial kernel and actual phase. Its explicit budget is
7*ownerSamplingBudget+2u*Ccount*(4+|y|)*N(N+1)*exp(-N/200), tending to0.
The full signed integer-density phase main is paid by exact exterior
phase endpoints; no prime/PNT/Type-II/zero premise or absolute positive
main allowance is imported. This is real-part decay, not complex norm
decay. It supersedes ONLY the earlier status that the COMPLETED bulk was
unpaid; no earlier negative audit or boundary obstruction is removed.

`ZetaRieszGlobalCentralPayment` preserves the prime-restored coefficient
majorant and pays the completed bulk's own strips outside1.971..2.029.
Its exact finite ledger is Gcentral=Mcentral+P1+P2+Rejected, hence
Mcentral-SAME full head=Gcentral-joinedBoundary. P1 is every central
ordinary prime; P2 is every central squarefree semiprime; Rejected is
EVERY squarefree count>=3 label failing the EXACT native central mask.
All original count/physical/owner/deletion/nondominant failures, including
raw high owners, retain their unallocated coefficients and full phases.
The head retains its ORIGINAL wider radial support. No failure is dropped.

`eventually_native_boundary_bound` gives
abs(nativeScaledCore.re+joinedBoundary.re)<=nativeBoundaryBudget->0,
spending completed bulk, old balanced radial/allocation differences and
allocated high-owner payment ONCE each. Raw high-owner completion labels
are NOT paid by the allocated residual theorem. Restore signs honestly:
the earlier matched subtracted semiprime boundary equals -P2 on its
matching labels; do not assign its saving to unmatched pairs. Keep P1,
P2, Rejected and SAME head joined before any new price.

The remaining floor requires an INDEPENDENT cofinal upper bound
joinedBoundary.re<=399/5000+o(1). No such bound, separate prime/semiprime
payment, whole floor, ceiling42/25, restricted exclusion or RH is proved.
STOP completion as an automatic floor proof while this boundary remains.
The optional full-phase primitive probe is a continuous INTEGER-density
main diagnostic, not a prime sum or literal carrier. Its exact native
rational-floor length and ideal endpoints are distinguished from the
Lean-paid literal lattice; no unspecified counting/radial constant is
numerically set to one, no percent floor-deficit saving is inferred.
Preserve all prior snapshots/no-gos, semiprime work and public endpoints.
Continue LOCAL ONLY: strict leaves/targeted builds, frozen compiled root
plus explicit-leaf14-linter/all-declaration standard-axiom checks; no
subagents, root registration, commits/pushes, public updates or wider gates.
See docs/zeta-riesz-global-bulk-payment.md and its focused audit.

### All balanced completion-mask failures paid together (local, 2026-10-03)

`ZetaRieszGlobalBoundaryPruning` strengthens the SAME signed global boundary
ledger. Below the actual count ceiling, every balanced central SF label
with physical primes belongs to the EXACT native central population.
All original deletion masks follow from window_mem_originalMask; ownerlog
<51N/50 rules out BOTH cancelling and dominant sectors. For a physical
failure, log n<=2.029N<2L and p>=X force count<=2 if its original coefficient
is nonzero. Thus EVERY count>=3 physical failure is EXACTLY zero. Do not
apply this zero statement to ordinary primes or semiprimes.

All remaining balanced completion failures have high count. The existing
ARBITRARY-support count theorem gives ONE uniform-height norm budget
(203/50)*radiusCeiling*(N+1)*exp(-N/10000000)->0 for their entire sum.
Its eventual start is unevaluated; j>=1024 is not claimed a practical
native threshold. Spend this COMPLETION count-tail error once, keeping
all original factorial orders, moving floor/phase and prior native budgets.

The exact remaining prunedBoundary is P1+P2+rawHigh+SAME full head.
rawHigh contains EVERY SF central label of count>=3 with ownerlog>=51N/50,
with no count/physical/deletion/nondominant/allocation support restriction.
Physical failures remain harmless zero slots. Its coefficient is the
ORIGINAL unallocated one; the prior allocated-high-owner theorem does NOT
pay it. The head keeps its wider original window; P1/P2 keep the actual
contracted central window. `eventually_native_pruned_bound` pays all
balanced mask failures inside the whole native ledger by adding ONLY the
proved countAllowance to nativeBoundaryBudget. No masked carrier is
completed at an individual cofactor and no ordinary-prime source is dropped.

The required independent upper bound prunedBoundary.re<=399/5000+o(1)
remains OPEN. Keep ordinary primes, semiprimes, raw high owners and SAME
head joined before further signed estimates. No separate norm prices,
whole floor,42/25 ceiling, restricted exclusion or RH is claimed.
The optional N256 exact-divisor diagnostic uses the native rational floor
and integer d<X comparisons, checking zero log profiles at counts3..12;
ordinary-prime and semiprime controls remain nonzero. SymPy primes are
exploratory, not Lean certificates; no eventual count budget or low-count
native membership is assumed at this early order. Preserve ALL earlier
audits/probes, including old toy physical cutoffs that differ from the
native squared cutoff. Continue LOCAL ONLY with strict leaf/targeted
build and frozen-root14-linter/all-declaration standard-axiom validation,
without subagents, root/public updates, commits/pushes or wider gates.
See docs/zeta-riesz-global-boundary-pruning.md and its focused audit.

### Global central-semiprime/full-head cancellation (local, 2026-10-03)

`ZetaRieszGlobalHeadCentralPayment` moves the SAME full head onto its
unique physical product labels, with exact factorial allocation, sieve,
physical support, native moving length and phase. Its positive coefficient
is bounded by the opposite semiprime completion coefficient. Thus ONLY
the head's radial strips outside1.971..2.029 are paid by the existing
all-mask rate exp(-N/1000000), forN>=65536 and1/2<=u<=10001/20000,
uniformly in height. The head itself is NOT a vanishing error.

Every projected head label is a central SF semiprime, counted once. Join
its opposite coefficients BEFORE norms. `full_semiprime_head_bound`
proves norm(P2central+SAMEfullHead(y))<=D2-H0+2E_N, whereD2 is the entire
central semiprime atom price, H0 the original full zero-height head mass,
andE_N=radialConstant*exp(-N/1000000). Relative toD2+H0 this saves
TWO head masses minus2E_N. The two radial uses pay actual-height transfer
and zero-height credit transfer, not two independent head payments.
`prunedBoundary_upper` and `eventually_native_floor_with_semiprime_credit`
spend this cancellation inside the current whole native ledger. Ordinary
primes and raw high owners remain ONE signed unpriced scalar; no allocated
high-owner payment is applied to them. Original native budgets stay once.

This is a genuine global same-label credit plus a new geometric radial
mask payment, NOT a bounded cofinal allowance. NeitherD2-H0 nor the
remaining prime/raw-owner scalar is proved small. Do not promote their
atom price to a floor strategy or infer a percentage of the399/5000 gap.
The independent whole-boundary upper bound, floor,42/25 ceiling,
restricted exclusion and RH remain OPEN. The optional toy probe passes18
frozen complex regressions, retains every outer signed head label and
never applies theN>=65536 theorem toN6/7/8. Its length/deletion/schedule
are distinguished from native data. Preserve all proofs/no-gos, snapshots,
semiprime work and public endpoints. LOCAL ONLY: strict leaf, targeted
build, frozen compiled root plus explicit-leaf14-linter/all-declaration
standard-axiom audit; no subagents, root registration, commits/pushes,
public updates or wider gates. See docs/zeta-riesz-global-head-central-payment.md.

### Post-head positive price obstruction (local, 2026-10-03)

`ZetaRieszGlobalHeadPriceAudit` proves that the EXACT global positive
allowance D2-H0+2E from the preceding semiprime/head bound diverges,
including on the native dyadic moment sequence. Ordinary primes in the
disjoint boxes N<log p<=N+1 andN+1<log q<=N+2 yield distinct central SF
semiprimes untouched by the head owner threshold. The actual moving
length gives coefficient norm>=1. A proved fixed-width PNT LOWER count
and full factorial normalization supply the explicit eventual envelope
(u*exp(-9/2)/216)*(2u)^N/(N+1)^3. The PNT starting order is unevaluated.
No cofinal subsequence of this allowance meets ANY fixed ceiling.

This is a no-go for the positive PRICE ONLY, not divergence of the actual
signed sum. Preserve the true global same-label head credit and every
radial payment, but STOP optimizing/reusing this price to close the floor.
All unmatched-label/cross-count/full-period cancellations must stay signed.
The optional scalar crossing nearN472391.52 at the radius ceiling is NOT
a certified native threshold. Its whole-boundary toy probe passes45
frozen complex regressions and retains every raw high count, full head
and exterior phase endpoint. ToyN6/7/8 use ideal length/deletion/schedule;
no native eventual theorem or percentage floor saving is inferred.
See docs/zeta-riesz-global-head-price-audit.md and its focused audit.

### All incomplete phase periods paid in the native floor (local, 2026-10-03)

`ZetaRieszGlobalPeriodEdgePayment` pays every partial central phase period
and exterior endpoint, simultaneously at ALL counts. Width2*pi/|y|<=1
for54<=|y|. A fixed additive total-log shift changes only the finite tilt
constant; the common rate remains exp(-N/1000000). The generic theorem
holds for everyN>=64, finite dominated support and all such heights.
No phase is frozen or norm-paid on a complete interior period.

`wholePeriodBoundary` joins complete-period selections of every central
ordinary prime, every central SF semiprime, raw high owners at EVERY
count with their ORIGINAL unallocated coefficient, and the SAME full
head's physical product labels with exact owner allocation/sieve/phase.
All other masks remain in their original support; no count restriction
or physical removal is imposed on raw high owners. ForN>=65536 the
head's existing majorant applies. Its real phase agrees with the old
pruned boundary's real-cast head convention. One finite constant pays
the four edge families by4*C*exp(-N/1000000); do NOT setC numerically.

`eventually_native_wholePeriod_bound` spends this payment in the ORIGINAL
whole native ledger: abs(nativeScaledCore.re+wholePeriodBoundary)<=
nativePrunedBudget+wholePeriodBudget->0. This ALTERNATIVE signed ledger
does not spend the semiprime/head atom-price saving or its two radial
credits again. The complete-period joined signed scalar still needs an
INDEPENDENT cofinal upper bound<=399/5000+o(1). No such bound, whole
floor,42/25 ceiling, restricted exclusion or RH is proved. The optional
toy probe only motivates the now-proved edge payment; its small signed
periods are not an asymptotic arithmetic bound.

Preserve ALL prior positive results/no-gos/snapshots and semiprime work.
Continue LOCAL ONLY: strict leaves, targeted builds, frozen compiled
root plus explicit leaf14-linter/all-declaration standard-axiom checks;
no subagents, root registration, commits/pushes, public updates or wider
gates. See docs/zeta-riesz-global-period-edge-payment.md and its audit.

### All raw high-owner counts paid jointly (local, 2026-10-03)

`ZetaRieszUnallocatedOwnerPhase` proves the FULL factorial integer phase
payment with no owner allocation, for genuine owner logs through7N/5.
`ZetaRieszUnallocatedOwnerPayment` joins EVERY squarefree composite
cofactor count with its EXACT unallocated prime correction before
estimating. Its per-owner bound is ownerBudget/p, where ownerBudget is
7*ownerSamplingBudget plus2*u*countingConstant*(4+|y|)*N*(N+1)*exp(-N/200).
Harmonic aggregation over ALL owners costs at most1+7N/5; the joined error
is independently geometric times a fixed polynomial. No zero/PNT/bilinear
hypothesis, count split, old allocated weight or rough sieve is used.

`ZetaRieszGlobalHighOwnerPayment` identifies these rows with the literal
unique-largest-prime raw labels, preserving every factorial order and
product phase. Owners above the actual moving length contribute EXACT
zero at allcounts>=3. The sole funded radial transfer connects the full
wide window to native rawHighLabels. This pays rawHigh.re PLUS the exact
highPrimeCorrection, NOT rawHigh or the original head separately.

The SAME native ledger now has abs(nativeScaledCore.re+lowCountBoundary)
<=nativePrunedBudget+radialBudget+(1+7N/5)*ownerBudget->0. The retained main
is P1central.re+P2central.re+SAMEfullOriginalHead-highPrimeCorrection.
Only ordinary-prime and distinct prime-pair sums remain unpaid. The new
correction has extended owner interval throughL, unallocated coefficients
and the original wide window; do NOT equate it to the allocated/sieved
head or discard it. Do not spend old head-price/period credits again in
this alternative ledger. Its independent cofinal upper bound<=399/5000
is OPEN. No whole floor,42/25 ceiling, restricted exclusion or RH follows.
Do not revive the proved-divergent positive semiprime/head allowance.

Preserve every preceding positive/no-go theorem and snapshot, and all
semiprime work. Continue LOCAL ONLY without subagents, root/public updates,
commits/pushes or wider gates. Strict leaves/targeted builds and frozen-root
14-linter/all-declaration standard-axiom checks apply. The optional exact
row/phase probe uses frozenTOY orders6/7/8 and ideal length/old masks,
not native data or an evaluated eventual threshold. See
`docs/zeta-riesz-global-high-owner-payment.md` and its focused audit.

### Low-count signed endpoint payment (local, 2026-10-03)

`ZetaRieszLowCountSignedBoundary` joins the actual retained P1central,
P2central, SAME original head and full unallocated highPrimeCorrection
on their unique physical labels BEFORE estimating. Original head labels
are a subset of the correction labels and their allocated/sieved weights
are pointwise bounded by that full correction. On correction pairs,
completedCoefficient-correctionCoefficient is EXACTLY
-log(n)*log(smallerPrime)/L. The complete joined coefficient is real,
between-log(n) and0, with no dropped phase, owner, physical, sieve,
allocation or radial condition. Its divisor-log cap is used ONLY for edges.

ONE periodEdgeConstant*rate^N payment now covers all partial-period and
outer-window terms of the four-component low-count main jointly.
`eventually_native_signed_period_bound` spends this once with the prior
nativeLowCountBudget; their sum tends to zero. No previous head-price
credit or old four-component period payment is spent again. The remaining
target is the NET signed complete-period lowCountPeriods<=399/5000+o(1)
cofinally. This bound is OPEN, as are the whole floor,42/25 ceiling,
restricted zero exclusion and RH. A negative real coefficient is not
enough: its negative-cosine phases contribute positively. Do NOT revive
the divergent positive semiprime/head atom allowance.

The optional frozenTOY orders6/7/8 probe passes27 complex regressions and
checks the exact joined coefficient range[-log(n),0]. The small signed
period totals are diagnostics, NOT native/eventual certificates. Preserve
all preceding positive/no-go results, immutable snapshots, concurrent
semiprime work and public endpoints. Continue LOCAL ONLY, no subagents,
commits/pushes, root registration, public updates or wider checks; strict
leaf/targeted build, frozen-root plus explicit-leaf14-linter and
all-declaration standard-axiom audit apply. See
`docs/zeta-riesz-low-count-signed-boundary.md` and its focused audit.

### Unpaid low-count period coupling probe (local, 2026-10-03)

The optional `probe_riesz_low_count_period_coupling.py --low-count-only`
enumerates ONLY ordinary primes and distinct prime products in the current
remaining boundary. It retains every toy log phase and older radial,
physical, sieve and finite allocation condition. Original head and full
unallocated correction are joined on each pair BEFORE diagnostics. All27
frozen full-divisor regressions pass; held-out toy order9 is additional
uncertified data. No native eventual theorem is applied to these toy orders.

On52 heights per order, median prime/joined-pair period correlations are
about-.951,-.991,-.986,-.990 forN6/7/8/9. Subtracting an uncertified smooth
density comparison does not remove the pattern atN6/7/8. This motivates
JOINT arithmetic cancellation; it is NOT a proved sign rule or floor.
The stress scan through height51200 weakens local opposition while signed
cancellation across periods still matters. Bound the NET lowCountPeriods,
not each period or a positive-period cost. Do not spend the diagnostic
cross-count/cross-period credits as native payments or percentages of the
global endgame gap. An admissible sign-bias diagnostic is not a single-height
logarithmic character and proves no arithmetic estimate.

Perfect opposition alone allows the canonical simple source1-c_ret(U)
about.0798718, still ABOVE399/5000=.0798. The remaining~7.18e-5 source gap
is not a proved arithmetic cost saving. The current independent cofinal
floor and42/25 ceiling remain OPEN. No new Lean theorem/axiom, zero
exclusion, public endpoint, root registration, commit/push or wider gate
is introduced in this numerical pass. Preserve all paid budgets/no-gos
and concurrent semiprime work. See
docs/zeta-riesz-low-count-period-coupling.md and its immutable numerical
audit; keep the probe outside CI. Continue locally on the actual joined
signed estimate, without subagents or positive atom-price optimization.

### Whole-floor signed tail feedback (local, 2026-10-03)

`ZetaRieszTailFeedbackFloor` chooses coefficients from the actual adverse
COMPLETE-period correlations of the literal affine-tail null columns.
For V=sum_i w_i*g_i*Z_i, the checked signed correlation is exactly
sum_i w_i*g_i^2. Nonnegative column weights may be their inverse complete
period square norm; a zero column gets weight zero. `canonicalPrice`
uses every native squarefree label and computes its coefficients from
this rule. Phase alignment occurs ONLY in the exact null correction;
the original nonzero sourceWeight is unchanged. The Gram identity is
standard; its application to the current arithmetic price is the result.

The WHOLE near-period debit and far crossing price are paid AFTER the
columns/counts have been joined. `feedbackCredit` is the resulting
explicit correlation-square saving; no zero face is omitted. Credits
accumulate only across successive repriced steps, never independently
from a fixed baseline. Column mixtures may change at each step;
`nativeColumns_mix` preserves exact literal support. Exact joint near-row
annihilation removes their debit, but approximate projections must charge
their full actual residual. No useful native projection is assumed.

The direct native floor subtracts tailCost, adds successive paid credits,
and retains the SAME nativePaidBudget and nativeError. All original
allocation/count/physical/factorial/phase masks and the distinct paid-owner
allocation remain, charged once. The previous tailPrice remains an
alternative; zero steps recover it. `feedbackPrice<=399/5000` COFINALLY
is still an OPEN arithmetic premise. The conditional simple-zero endpoint
is not a zero exclusion or RH proof. The whole ceiling also remains open.

Optional common-rule cross-seed testing does not give uniform transfer;
in-sample label-fit improvements must not be promoted to a coefficient
principle. The explicit feedback rule lowers all12 frozen finite prices
without a new LP/per-label fit. After12 steps its boundary-paid formula
credits are about3.9%-26.1% of those finite starting costs, or3.9%-43.6%
with joint near-row mixtures and every residual charged. These are NONNATIVE
order32/64 samples: no native count crop/paid-owner budget, interval/primality/
LP/SVD certificate, population bound, cofinal rate or fraction of the
endgame deficit. Longer iteration nearly plateaus on some cases; an exact
null cannot reduce the adverse total of the original signed sum.

The extra `--unpaid-column-audit` restricts ONLY the new correction
columns to owner share<60069/100000 and second least prime>N^3, preserving
the full original signed base. It avoids two previously paid geometries,
but is not a complete unpaid-mask inventory and asserts no eventual
payment at these small orders. The retained14/11/20/22 labels span counts
4-6; all12 prices still improve, with formula credits about1.8%-14.7% of
the same finite WHOLE starting costs. Do not promote the unrestricted
4%-44% figures to savings on the exclusively unpaid native population.
The generic native theorem permits this column restriction with no base
population deletion or additional paid-owner budget.

See docs/zeta-riesz-tail-feedback-floor.md and
docs/riesz-tail-feedback-floor-audit.json. Continue locally, no
commits/pushes/subagents/wider gates or public endpoint changes. Focused
Lean/build, compiled-root namespace lint and transitive axiom checks apply.

The latest local research task works upstream of `SignedCrossing`:
`ZetaRieszSignedConvolution` joins the literal M0, M1 and exact signed
crossing across all selected periods/counts, then reindexes `a=d*b` with
`mu(a)*mu(d)=mu(b)`. Its exact bilinear identity retains the product phase,
factorial kernel, original prime/cofactor masks and owner allocation.
`core_sub_convolution_bound` reuses the single global geometric nonowner
payment; no new bound on the signed main is asserted. The Selberg/Suzuki
bridge retains the full clipped remainder and the required total `mu(a)`
factor. Centered quadratics cancel exactly on all squarefree cofactors
with at least three factors, but their nonpolynomial cutoff remainder
remains OPEN. Do not replace it by a Friedlander--Iwaniec bilinear
hypothesis or count this infrastructure as a numerical floor.

The optional signed-convolution probe joins literal finite atom periods
at orders 8/10. Its annulus-compatible count is ZERO: those tests are
algebra regressions, not the current core or growing-count population.
The same caveat applies to the previous order-6/8/10 crossing probe.
Continue locally without commits, subagents or wider publication gates.
Keep the published RH endpoint unchanged. The next useful result must
bound the WHOLE signed clipped convolution/prime-pair combination at
source scale, with the remaining real -79/1000 floor still OPEN.

`ZetaRieszUnsignedDivisorError` now bounds the unsigned-leg comparison
ERROR on shells `exp(N/10)<=M<X<=2M`. The full squarefree coprimality
sieve, owner allocation, factorial order and physical product phase are
retained. After summing all outer prime counts the rate is
`2*u*exp(-2357/102400)<=49/50`; joining at most `N+1` shells costs only
`errorConstant*(8+abs(y))*(N+1)^3*(49/50)^N`, which tends to zero.
`ownedShellDiscrepancy_eq_literal` identifies the original owner incidence
under explicit finite ownership geometry. Saturated active rows force
`d<p`. The inherited core masks are checked by
`mem_core_of_strict_prime_share`; arbitrary selected high-count divisor
incidences have independent source-o(1) payment. These are concrete
comparison/count-boundary savings, NOT an independent signed floor.
The signed density main, `d<exp(N/10)` boundary and unsaturated rows'
remaining prime-factor ownership restrictions are unpaid. Do not claim
the whole core has been replaced by its density model or charge these
terms separately by positive allowances. Preserve all prior no-go audits
and the published RH endpoint. Iterate locally without commits/subagents
or wider publication checks.

`ZetaRieszSaturatedRowFloor` applies the unsigned-leg comparison to
original saturated core rows. Explicit endpoint geometry checks all
window, owner, physical and allocation masks; the original count cutoff
is retained and its exact high-count extension is independently paid.
At most `N+1` selected shells have a count-boundary cost bounded eventually
by `highCountConstant*(N+1)^2*(49/50)^N`. Their squarefree-counting error
has the previous `(N+1)^3*(49/50)^N` bound. Selected incidences are literal
subsets of the original cofactor antidiagonals, without duplicate owners.
`eventually_joined_floor_with_signed_rows` gives an actual whole-carrier
comparison floor: one signed density-row sum plus every unselected
literal incidence, minus `joinedRowErrorBudget -> 0`. The nonowner payment
occurs once. This does NOT prove the independent numerical floor. The
selected-row theorem by itself does not construct a canonical partition;
the following module now supplies one for its displayed eligibility.
Keep the density main and its remaining small/unsaturated incidences joined.
Preserve the published endpoint and iterate locally without commits,
subagents or wider publication gates.

`ZetaRieszClippedAllocationPayment` independently pays the shortened rows
with log(p)>=507N/400, disjoint from `freeRows`. The literal nondominant
and radial masks force cofactor share in [7/20,47/125]; exact binomial
tilts give ownerWeight<=3*exp(-N/600) after order320. All counts and radial
periods together cost at most `162*(N+1)^4*(999/1000)^N -> 0` at source
scale. `residual_row_boundary` leaves only log(pb)>37N/20 or
log(p)+L_N<203N/100, with log(p)<507N/400. The final comparison is
`eventually_joined_floor_with_residual_rows`, keeping these two SIGNED
boundary geometries joined with `canonicalRemaining - endpointRows`.
Its error budget tends to zero. The -79/1000 floor for the remainder,
multiplicity ceiling and zero exclusion are still OPEN. Do not turn this
two-sector main payment into a whole-carrier norm/floor claim.

`ZetaRieszCanonicalOwnerRows` now constructs the eligible saturated large
unsigned-divisor rows directly. The rounded lower endpoint is the maximum
of the `N/10`, core lower-window and strict nondominant owner-share
thresholds; the upper endpoint intersects the original upper core window
with cofactor saturation. A disjoint clamped dyadic grid with at most
`N+1` shells recombines both the literal row and its SIGNED density exactly.
`literal_row_covered_or_endpoint` proves that every incidence satisfying
these displayed original eligibility conditions is included, except
possibly its single rounded lower-endpoint integer. All such rounded
atoms together are paid by
`endpointConstant*(N+1)*(23/25)^N -> 0`, with the actual core mask, sieve,
allocation and phase retained. `eventually_joined_floor_without_endpoints`
is an independent whole-carrier COMPARISON inequality, with no externally
chosen row geometry. Its remaining joined signed expression is NOT
independently bounded by -79/1000. Small unsigned divisors, unsaturated
rows and all original incidences outside the displayed eligibility stay
explicit in `canonicalRemaining`; do not say the whole literal core has
been replaced by a density. Preserve the published endpoint, all no-gos,
and local-only validation without commits, subagents or publication gates.

`ZetaRieszFreeRadialRows` now pays the SIGNED main on every original
canonical row with log(pb)<=37N/20, log(p)<=507N/400 and
203N/100<=log(p)+L_N. Its exact unsigned-log Fourier integral retains
the complete owner factorial allocation; no owner prime or prime cofactor
is completed. Summable 1/d^2 lattice variation and literal endpoint
rounding transfer this to the actual integer row. All outer counts have
only harmonic mass. The source-scaled sum is bounded by
`9*(33+4*abs(y))*(N+1)^4*freeRate^N`, with a proved `freeRate<1`, for
fixed abs(y)>=54, N>=32 and L_N>=11N/8. The slowest radial rate at the
radius ceiling is about 0.9999886; no evaluated starting order is claimed.
`eventually_joined_floor_with_clipped_rows` removes this main sector once,
leaving the original unselected incidences and the shortened SIGNED rows
joined. This is genuine main-term cancellation but not the independent
-79/1000 whole floor. Preserve the published endpoint and all earlier
negative audits; continue focused local validation without commits,
subagents or wider publication gates.

`ZetaRieszJointOwnerEnvelope` now keeps the owner-tail tilt and radial
factorial kernel together. The exact radial shift T->T-P/41 at tilt41/40
pays every original owner with log(p)>=243N/200, improving the previous
507N/400 density cut. All previously unpaid selected density rows cost
`162*(N+1)^4*exp(-N/20000) -> 0`, disjoint from the two earlier sectors.
`eventually_joined_floor_with_lowOwner_rows` keeps the smaller-owner
density boundaries joined with canonicalRemaining-endpointRows.
The same theorem is applied directly to the ORIGINAL literal prime sum:
its selected all-count population costs
`6*divisorSquareDirichletMass(1+1/262144)*(N+1)*exp(-N/25000) -> 0`.
Full original masks, allocation and complex phase remain. The Rankin
count cost is absorbed in the joint saving before atom norms are summed.
`coreResponse_eq_paid_rest` is exact; `joined_sub_literalCoreRest_bound`
and `tendsto_joined_sub_literalCoreRest` pay only this original population,
without another nonowner payment or any prime/density completion.
`literal_rest_owner_cut` proves that every nonzero original remaining
dyadic-core atom has log(largestPrime)<243N/200. Do NOT count the literal
and density bounds on overlapping rows as two credits in one ledger.
The independent whole -79/1000 floor for either joined rest remains OPEN.
The optional scalar-rate probe is floating exploration, not prime-count
transport, a starting order, or a numerical floor. Preserve all no-gos
and the published RH/zero-free/certificate endpoints. Continue locally
without commits, pushes, subagents or wider publication gates.

`ZetaRieszFineDivisorRows` now pays the ORIGINAL signed saturated
full-window incidences down to unsigned log threshold N/1000, replacing
the earlier N/10 threshold on this displayed population. The smaller
summable tilt 65537/65536 pays the full squarefree-coprimality comparison
and every outer count at rate exp(-N/10000). Original integer rounding
is paid at the same rate; the signed main uses the existing complete
owner/radial Fourier cancellation, before any norm. Eligible rows have
log(pb)<=1949N/1000, log(p)<243N/200 and log(p)+L_N>=203N/100.
The original core/count mask and exact allocation remain. A disjoint
clamped grid retains every incidence once; count-cutoff overflow is paid
independently. `eventually_abs_fineLiteralRows_bound` and
`tendsto_fineLiteralRows` bound the ACTUAL selected signed prime sum,
not only its density model. `coreConvolution_re_eq_fineRemaining` is
exact, and `tendsto_joined_re_sub_fineRemaining` removes only this paid
population from the whole joint real carrier. All unselected incidences,
including smaller unsigned legs and unsaturated rows, remain explicit.
The rounded lower endpoints are now independently paid by
`18*(N+1)^3*exp(-9*N/10000)`, retaining the original core mask and sieve.
`fine_rows_closed_eq` joins the row with that exact boundary;
`fine_endpoint_not_selected` rules out a duplicate incidence credit and
`fine_literal_row_covered` proves the displayed eligible population has
no rounding gap. `tendsto_joined_re_sub_closedFineRemaining` leaves the
exact signed remainder `fineRemaining-fineEndpointRows` source-equivalent
to the whole joint carrier. `unit_unsigned_not_selected` explicitly keeps
the unsigned unit and balanced-triple obstruction. The independent
-79/1000 floor is still OPEN.
Use this as an alternative to overlapping old row ledgers, not another
credit on an already-paid incidence; the global nonowner payment is
used once. Scalar probes do not certify a starting order or a floor.
The optional `probe_riesz_fine_remaining.py` factors actual sampled
integer labels and retains the common phase of unit/nonunit incidences.
Small-order negative covariance is diagnostic only; those tests are not
cofinal and fail the eventual length hypothesis. Do not promote their
observed cancellation or sample means to an asymptotic signed bound.
Preserve all public endpoints/no-gos; continue locally without commits,
pushes, subagents or wider publication gates.

`ZetaRieszOwnerSafeRows` independently pays a new ORIGINAL unsaturated
all-count population. Its concrete cone is N/2<=log(p),
31N/20<log(pb)<=1949N/1000, log(p)<243N/200 and
log(p)+L_N<203N/100, with every earlier physical/core/count, squarefree,
coprimality, phase and owner-allocation mask unchanged. The whole closed
unsigned row lies strictly below p; saturation was only needed for this
ownership fact. An auxiliary 31N/20 cutoff appears solely in the finite
ownership proof, never in an arithmetic atom or the actual Riesz length.
The signed radial/Fourier main is joined before its absolute value is
taken. `eventually_abs_ownerSafeLiteralRows_bound` has the SAME independently
proved fineRowBudget; rounded original endpoint atoms have the SAME
18*(N+1)^3*exp(-9N/10000) bound. Original incidences are disjoint from the
saturated fine payment. `ownerSafe_unsigned_gt_one` keeps the unit unpaid
even at the closed endpoint. `eventually_abs_joined_sub_ownerSafeRemaining_bound`
gives the whole REAL carrier error budget
joinedRowErrorBudget-rowErrorBudget+2*(fineRowBudget+fineEndpointBudget),
which tends to zero; shared carrier/nonowner errors occur once.
The actual signed remainder, independent -79/1000 floor and 3/2 ceiling
remain OPEN. Do not promote this payment to a complex packet-decay or
zero-exclusion claim. The optional exact-cone integer probe is diagnostic:
orders20/24/28 are not cofinal and fail the eventual length hypothesis.
Use scoped Lean/namespace-lint/axiom checks; keep publication and public
explorer endpoints unchanged. Continue locally without commits or subagents.

`ZetaRieszUnifiedSignedRows` combines the actual singleton large-owner
payment with both closed divisor-row payments in ONE signed ledger. The
variable-population bound pools the arithmetic mass over all labels;
it does not add a nonowner error or cost per owner. Closed-row credits
are disjoint from the large-owner labels, including rounded endpoints.
Every nonzero unpaid owner on the actual dyadic core has log(p)<243N/200.

`ZetaRieszEdgeDivisorRows` independently pays a further literal signed
band: 1949N/1000<log(pb)<=3899N/2000, N/2<=log(p)<243N/200,
with the original ownership, physical, core/count, phase and allocation
masks. Counting exponent 17/32 pays unsigned legs above exp(N/2000);
the old exponent 3/4 does not give source decay at that threshold.
The all-count comparison rate is at most exp(-N/10000), the signed main
uses the original radial/Fourier payment, and rounded endpoints cost
18*(N+1)^3*exp(-N/2500). `eventually_abs_edgeLiteralRows_bound` is an
estimate on the ACTUAL sum, independent of any zero hypothesis. Closed
incidence credits are disjoint from both older row families and the whole
large-owner payment. `eventually_abs_joined_sub_edgeRemaining_bound`
keeps one signed remainder with source-o(1) error; it is not the numerical
-79/1000 floor. Unit/small-divisor and other unselected geometries remain
unpaid. All old theorem scopes and no-gos are retained. Optional integer
probes are diagnostic and not cofinal; they certify no floor or starting
order. Keep local scoped validation and unchanged public endpoints.

`ZetaRieszLowOwnerRows` extends the same signed full-window mechanism to
7N/25<=log(p)<N/2 and 7N/4<log(pb)<=3899N/2000, retaining the original
unsaturated, owner, physical/core/count, allocation, squarefree/coprimality
and full phase masks. An auxiliary 7N/4 cutoff certifies that every
unsigned integer of the CLOSED original row is below p; it never replaces
the Riesz length. `full_window_geometry_of_owner_gap` extracts the exact
common ownership criterion log(pb)+log(p)>203N/100. The concrete paid cone
is a sufficient subregion, not a claim that every row satisfying that
criterion is paid. `eventually_abs_lowOwnerLiteralRows_bound` independently
bounds the ACTUAL signed real sum by the existing edgeRowBudget, with the
same source-geometric rounded endpoint payment. Nonzero closed incidences
have count>=5 and are disjoint from all previous row credits and whole
large-owner labels. `eventually_abs_joined_sub_lowOwnerRemaining_bound`
keeps shared errors once and replaces the prior rest by one smaller signed
scalar. This does not establish its numerical -79/1000 floor. Balanced
triple unit incidences, small-divisor and unselected ownership geometries
remain unpaid. The optional 1335-digit six-prime N=1536 example is a
transcription diagnostic, not a Lean nonemptiness or cofinal certificate;
its moving-length inequality is met. Continue locally with scoped Lean,
namespace-lint and axiom checks; no commits, subagents or wider gates.

`ZetaRieszOwnerGapRows` now pays the entire original ownership-gap
population with log(pb)+log(p)>203N/100, log(pb)<=3899N/2000 and
log(p)<243N/200, retaining all original masks and signed phases. Its
row-dependent auxiliary cutoff certifies geometry only. All four older
closed-row families are proved subsets; replace their credits with the
single edgeRowBudget+edgeEndpointBudget payment rather than adding them.
The whole large-owner population remains disjoint. The exact signed
ownerGapRemaining differs from the whole real carrier by one shared
carrier/nonowner cost plus the two independent population payments,
all source-o(1). Its numerical -79/1000 floor is still OPEN.
Under the explicit original owner/outer/core predicates,
unselected_unsigned_geometry proves log(d)<161N/2000 or
log(p)<log(d)+2N/25. Outside the first boundary, the Riesz support yields
log(p)<147N/200. Do not apply that latter ceiling to the short-leg/unit
boundary or drop any hypotheses. Unit and other remaining incidences
stay joined. The additional four-prime N=1536 probe is diagnostic, not a
Lean nonemptiness, cofinal rate or floor certificate. Preserve all prior
theorems/no-gos and public endpoints. Continue locally without commits,
subagents or wider checks.

`ZetaRieszShortDivisorCancellation` removes complete affine divisor
blocks from the actual unpaid short boundary with EXACTLY zero error.
The canonical candidate is the two smallest cofactor primes. Each
selected block includes its unsigned unit, retains the original common
phase/factorial/allocation weight and every label/count/physical mask,
and is disjoint from the paid owner-gap rows and whole large-owner labels.
`ownerGapRemaining_eq_sum_sdiff` changes no existing error budget.
The surviving two-prime block is exactly one signed cofactor tent,
`-mu(a)*primePairTent(log r,log s,log a-L_N)`. Its marked prime no
longer appears in this arithmetic factor. `re_literal_prime_block_floor`
uses the complete SIGNED prime observation before its absolute value,
not a sum of separate prime norms. Its aggregate cost remains OPEN.
For a cofactor small block with log(R)<=B*log(N+1), the uncancelled unit
is eventually confined to `T-L_N-B*log(N+1)<log(p)<T-L_N` under the
explicit original predicates. Rough labels without such a small block,
the reflected tent crossing, other short incidences and the remaining
near-owner region stay unpaid. The polynomial threshold is unevaluated;
no relative deficit percentage or -79/1000 floor is proved. Optional
six/seven-prime N=1536 probes verify the transcribed tent identity and
show opposite signs; they are not Lean nonemptiness/counting certificates.
Continue locally with scoped Lean/lint/axiom checks and unchanged public
endpoints; no commits, subagents or wider publication checks.

`ZetaRieszShortDivisorOrbits` extends that EXACT zero payment to every
disjoint based block `d=e*delta`, with `e|a/R` and `delta|R` for the
canonical two-smallest-cofactor-prime block. Squarefreeness proves the
blocks partition the original antidiagonal uniquely. All complete affine
blocks inside the short boundary cancel with the ORIGINAL weight at `p*a`;
do not evaluate the phase or allocation at the auxiliary cofactor `a/e`.
The enlarged selection contains the previous unit-based blocks, is
disjoint from both existing paid populations, and changes neither
ownerGapRemaining nor its error budget. Its whole source-scaled norm is
EXACTLY zero, at every finite count, order and height.
Every surviving short incidence has a base in either
`H-log(R)<=log(e)<H`, with `H=T-3899N/2000`, or
`log(a)-L_N-log(R)<log(e)<log(a)-L_N`. For polynomial small blocks these
are logarithmic-width strips. The reflected strip has eventual owner band
`9N/16<log(p)<131N/200` under the stated core and moving-length hypotheses.
This is support localization, NOT payment of either crossing population.
Rough blocks and other near-owner incidences remain signed and unpaid;
the independent -79/1000 floor remains OPEN. The N=1536 nine-prime
diagnostics show 16 of 21 short incidences cancelling in one label and
zero previous-payment overlap; this is neither a global proportion nor
a Lean nonemptiness/counting or cofinal certificate. Preserve the previous
no-gos and endpoints. Continue locally without commits, subagents or wider
checks, using scoped Lean/lint/axiom validation.

`ZetaRieszShortCutoffRows` independently pays the fixed block `6=2*3`
short-cutoff crossing on whole ownership-safe original rows. The exact
incidences are `(e*delta,B/delta)` with `6|B`, common phase/allocation at
`p*B*e`, and the cutoff `log(delta)<log(pB)-3899N/2000` is independent of e.
Sum the clipped block first into cutoffMultiplier, bounded by four; then
apply the signed whole-row cancellation. Do not norm-pay individual divisor
or prime-count terms. The comparison uses exponent 17/32 and unsigned gap
1/2016, with source rate at most exp(-1/10000); the fixed log(6) crossing
strip fits that gap eventually. All original masks, both hinges, count
cutoff, coprimality, moving length, factorial kernel and allocation are
retained. High-count weighted overflow and original rounded endpoints are
independently paid. literalCutoffPacket has a proved independent source-o(1)
bound, and cutoffRemaining removes it with shared payments charged once.
The canonical owner and gcd tag prove no incidence duplication; selected
incidences lie strictly outside every previous owner-gap row credit and
every previously zero-cancelled affine orbit. Reverse original-incidence
coverage retains the closed integer endpoints. For this SAME fixed-block
cutoff crossing below the old owner ceiling, every unselected nonzero
incidence eventually has count>=25 and log(p)<161N/2000. Counts 3--24
are covered by the all-count signed payment under the stated original
predicates; do not infer a norm bound for a separately count-truncated
packet. These residual support restrictions do not pay its cost.
Inside that tiny-owner remainder, the strict cutoff keeps exactly divisors
1 and 2 on log(2)<log(pB)-3899N/2000<=log(3). Both actual hinges are
saturated after N>=32; their opposite Mobius signs cancel EXACTLY.
literal_middle_cutoff_population_eq_zero pays the whole selected complex
population, retaining the original core/count masks, physical owner,
allocation and product phase at p*B*e. No ownership-gap hypothesis or
error cost is needed for this zero payment. The remaining cutoff edge
pieces and all reflected/rough geometries still lack a global floor.
The numerical -79/1000 whole floor remains OPEN. This payment applies only
to the exact fixed-block ownership-safe strip; do not generalize it to
arbitrary small blocks, reflected crossings, rough labels or all ownership
geometries. All previous no-gos and public endpoints remain unchanged.
Continue locally without commits, subagents or wider checks, using scoped
Lean/namespace-lint/transitive-axiom validation.

`ZetaRieszRoughCutoffRows` now EXTENDS the fixed-six crossing payment to
the canonical two-smallest-cofactor-prime block whenever its second prime
is at most sqrt(N). Keep the exact additional roughness mask on the
unsigned variable: the forbidden set is `(p*B).primeFactors` union all
primes at or below the second frozen prime. Its extra comparison cost is
at most 3^floor(sqrt(N)); `rough_cost_geometric` absorbs that into
exp(-N/20000), after N>=1600000000 for THIS scalar inequality only.
This is not a validated finite starting order for the whole packet.
The actual moving length, phase, factorial allocation, core/count masks,
coprimality, high-count overflow and rounded endpoints remain original.
`eventually_literalCutoffPacket_bound` independently pays the joined
signed all-count packet; it assumes no hypothetical zero or bilinear
cancellation theorem. Original canonical orbits automatically satisfy
the roughness mask, and reverse coverage, gcd injectivity, non-overlap
with earlier owner-gap credits and zero affine orbits are proved.
`roughCutoffRemaining` REPLACES the fixed-six subtraction; do not add both
credits. Its explicit source-o(1) comparison shares older costs once.
Under the stated original predicates, an unselected nonzero small-pair
crossing eventually has count>=25 and log(p)<161N/2000. This is a support
restriction, not a cost bound on that signed rest. The exact middle-strip
zero payment also extends to EVERY canonical pair, including rough pairs:
`log(minFac B)<log(pB)-3899N/2000<=log(secondPrime B)` retains only the
unit and least prime. For the tiny-owner geometry both hinges equal
log(p), so the complete original weighted population cancels exactly.
No smallness, whole-owner-gap or fixed-height premise is needed for that
zero equality. Cutoff edges, reflected crossings and other unselected
owner/rough geometries remain unpaid; the numerical -79/1000 floor is OPEN.
Optional N=256 actual-prime regressions on pairs (2,5), (3,7), (5,11),
(7,13), and 36-prime tiny-owner labels including (43,47) check floating
transcription only. They do not prove population mass or a cofinal floor.
All 402 public theorems in this 17-module local batch have transitive axiom
records; scoped affected namespace lint passes all 14 linters.
Keep public endpoints and all no-gos unchanged. Continue locally without
commits, subagents or wider gates; scoped Lean/lint/axiom checks suffice.

`ZetaRieszLowerRadialPayment` independently pays the ENTIRE literal owner
population with log(n)<=197N/100, at the exact source-geometric rate
exp(-N/100000), uniformly for 0<=u<=10001/20000 and arbitrary height.
The finite arithmetic mass is zetaMoebiusLogMajorantMass(1+1/1048576).
The rational power certificate is checked in Lean; a floating saddle
calculation is not the proof. norm_lower_partial_sum_bound also pays ANY
retained original owner-divisor suballocation in that strip, with factor
two and its original allocation/phase. No zero premise, prime-count
restriction or hidden signed estimate is assumed. centralConvolution is
only the strict radial restriction of the SAME original owner atoms;
coreBand itself is unchanged. The remaining main window is
197N/100<log(n)<=203N/100. central_unsigned_gap proves log(d)>41N/2000
when log(pb)<=3899N/2000 there; this support gain is not a payment of a
new rough canonical-pair packet. centralRemaining retains the preceding
large-owner/closed-row/canonical-cutoff credits exactly once and adds
lowerBudget once to the comparison error. Those older payments still
contain their original lower-boundary pieces: do NOT claim that they
have been restricted to the central window or infer partial-row decay
from whole-row decay. The independent numerical -79/1000 floor remains
OPEN. Optional N=256/640 five-prime original-mask regressions are
diagnostic only; the N=256 36-prime edge test shows that two adjacent
canonical cutoff blocks can REINFORCE, not cancel. It does not rule out
every joint pairing or certify a population/source bound. No relative
deficit percentage or validated finite starting order is asserted.
Keep local scoped validation, all no-go results and public endpoints;
no commits, subagents or wider checks during this iteration.

`ZetaRieszPrimeWeightedSieve` keeps the ACTUAL forbidden-prime factors
`1+p^(-17/32)+p^(-34/32)` in the squarefree error. The product for primes
up to N^2 is at most `exp(2*countMass(65/64)*N^(31/32))`; it is not
`3^pi(N^2)`. Its combination with the existing comparisonRate is
eventually at most exp(-N/20000). `ZetaRieszPolynomialCutoffRows` applies
this to the SAME original canonical-pair cutoff rows and proves their
literal signed all-count packet source-o(1), including incidence-weighted
count overflow and original rounded endpoints. The second-prime cap is
now N^2; all other whole-window ownership/crossing predicates, the moving
length, original phases, allocation, physical/core masks and roughness
mask are retained. The proof uses the old unsigned gap; it does not infer
partial-row cancellation from the newly paid lower radial strip.
sqrt_cutoffRows_subset proves the old selector is contained in the new
one. REPLACE its old credit; never add both. Canonical incidence
injectivity, reverse original coverage and disjointness from older row
credits and zero affine orbits are proved for the enlarged packet.
For active unselected crossings satisfying the stated original physical
and owner predicates with secondPrime<=N^2, the remaining owner is tiny
and count is >=25 eventually. Rough pairs beyond N^2, tiny-owner cutoff
edges, reflected crossings and other unselected signed geometries remain
unpaid. polynomialCentralRemaining is the EXACT original central main
minus the retained prior credits and the enlarged packet, each once;
its comparison budget includes lowerBudget once and tends to zero.
Its independent numerical -79/1000 floor remains OPEN. No finite
starting order or fraction of the whole floor deficit is certified.
Optional actual-prime regressions at N=256/640 exercise canonical pairs
beyond sqrt(N), including (257,263) and (65519,65521). The finite prefix
cost samples do NOT yet satisfy the eventual comparison rate; zero
floating observations from underflow are not cancellation evidence.
The optional probe stays outside builds/CI. All 471 public theorem
records in the current 20-module local batch are audited; the 93 affected
public proofs and three namespaces pass scoped axiom/lint checks.
Keep all no-gos, the README and published explorer endpoints unchanged;
iterate locally without commits, subagents or wider checks.

`ZetaRieszCrossingOrbitCancellation` closes the TINY-OWNER EXCEPTION in
the canonical artificial-cutoff branch by restoring COMPLETE based
orbits, not by pairing only their clipped edges. CrossingOrbit selects
log(e)<T-3899N/2000<=log(eR) with T-log(e)+log(p)<=203N/100.
Failure of that whole-row owner condition forces log(p)<161N/2000.
The canonical block satisfies log(R)<=2log(p), so the actual length
bound L<=3N/2 makes both original hinges saturated on EVERY member for
N>=32 and u>=1/2. All four ORIGINAL observations share the same full
phase/factorial/allocation weight; their Mobius signs cancel exactly.
source_scaled_crossing_population_norm_eq_zero is an independent ZERO
norm bound for the whole literal selected population, across all counts
and heights together. It is not a claim that every tiny-owner LABEL
vanishes. Polynomial pair smallness is NOT required for this zero payment.
Original antidiagonal membership, based-orbit disjointness, non-overlap
with old cancelled interiors, old owner-gap rows, large-owner labels
and the paid polynomial packet are proved. Original masks remain intact.
eventually_polynomial_crossing_paid_or_cancelled says every active
canonical short-cutoff crossing in the N^2 pair cap, under its displayed
original predicates, is either geometrically paid or in a restored zero
block. There is no remaining tiny-owner/count exception in THAT branch.
polynomialCentralRemaining_eq_sum_sdiff removes the old interiors and
these new blocks directly from the SAME central owner atoms. Every old
whole-support credit and its comparison budget is unchanged, charged once;
no new scalar carrier or positive allowance is introduced. Ownership-safe
crossings beyond N^2, reflected Riesz-hinge crossings and other unselected
original signed rows still need arithmetic bounds. The -79/1000 WHOLE
floor, ceiling, zero exclusion and certified deficit percentage remain
OPEN. A remaining restored-cutoff survivor has log(p)>161N/6000, which
is only support information. The optional original-label probe restores
the prior N=256 36-prime reinforcing-edge example: clipped value about
-33.28000122314927, complete blocks exactly zero in the regression.
A fully rough 36-prime example with pair (65537,65539), beyond N^2,
also satisfies the original masks and full-block cancellation. Floating
regressions and logged underflow are not source/floor certificates; the
zero population theorem is the Lean proof. The optional script is outside
ordinary builds/CI. The restored-cutoff slice initially had 496 public theorem records
in 21 modules; 44 affected public proofs and both affected namespaces were
scoped-audited. Keep no-gos, README and public endpoints unchanged; continue
locally without commits, subagents or wider checks.

The affine extension now removes complete unpaid based blocks beyond the
artificial short cutoff as well. `UnpaidAffineOrbit` keeps the exact two
hinge-affinity conditions, the failed whole-window based-owner gap and the
original owner ceiling, and excludes the old short-interior selector.
`source_scaled_affine_population_norm_eq_zero` proves zero cost for the
ENTIRE selected original population, at all orders, heights and counts.
`crossingDivisors_subset_affine` replaces the restored-crossing credit;
do not add both populations. The new blocks are disjoint from the old
interior and previous owner-gap, whole-large-owner and canonical polynomial
cutoff payments. `polynomialCentralRemaining_eq_affine_sdiff` applies this
exact deletion to the SAME current floor ledger, with its budget unchanged.
No prime-density replacement, phase freezing, count allowance or new carrier
is introduced. The optional same-label regressions include long blocks
outside both earlier selectors, including a fully rough example.
The enlarged local batch has 511 public theorem records in 21 modules;
59 affected public proofs pass the scoped axiom/lint audit. Genuine hinge
crossings and other unselected signed rows still require an independent
joint estimate. The numerical floor, ceiling and zero exclusion remain OPEN.

The user's latest request authorizes committing and pushing ALL accumulated
local work once this slice and the publication gates pass. It supersedes
the local-only holds above for this publication. Run the tracked hook,
ordinary root integrity/lint/build checks, refreshed explorers and browser
checks without exhaustive numerical-certificate verification. Keep the
published conditional endpoint and all previous no-gos; update Latest Update
to report the actual supporting savings and the still-open numerical floor.
No subagents are authorized. Resume local signed-floor work after publication.

That publication is now COMPLETE at
`ec0473dfab685561c2fdca7f08ff449684bcca07`. Exact-SHA CI run `36820350501`
and Pages passed, followed by published desktop/mobile checks of all three
explorers and the live GitHub README. The 511-record accumulated signed-row
batch is the checked remote snapshot. Continue the floor locally; no further
commits, subagents or wider publication gates are authorized by that completed
request. Run focused Lean, ordinary-root-import lint and transitive axiom
checks for each local module. Keep the published endpoint and README unchanged
until the next authorized publication.

`ZetaRieszHingePairCancellation` pairs two adjacent canonical four-incidence
blocks into the SAME eight original incidences with the SAME label, full
phase/factorial/allocation and masks. For alpha=log r, beta=log s, v=log q,
P=log p, D=log(a/e)-L, S=alpha+beta+v and v<=D<=alpha+beta, the exact response
is -w*mu(a/e)*(S-2D+max(0,S-P-D)). KEEP the other-hinge counter-term. If both
first hinges are saturated, the separate second-hinge ramp allowance is
W=alpha+beta-v; the middle-half condition |D-S/2|<=W/4 reduces that sector's
price to W/2 times the actual signed prime moment. This is NOT a percentage
of the whole floor deficit. Without saturation the TRUE cancellation centre
is S/2+max(0,S-2P)/6. The original two-hinge coefficient costs <=W/2 within
W/6 of this centre, including close-owner labels; this half-WIDTH bound is
not a claim that every unsaturated sector gets a factor-two saving.

The full prime-row bound retains (S-2D)*M0 + (S-D)*M0_clipped - Mlog_clipped
as ONE signed expression, with the actual clipped prime set and no separate
positive boundary price. Common prime support also factors all selected
bases into one signed Mobius constant/log profile Q_E, but that factorization
does NOT remove cofactor-dependent prime holes. The correlated version keeps
each original P(e), counts and radial periods; its total numerical cost is
still unpaid. Strict genuine overlap lies in the CURRENT retained original
antidiagonal, outside both previous affine zero selectors. Based-orbit
disjointness and non-overlap with failed-owner, whole-large-owner and the
canonical polynomial packet are checked under their displayed predicates.
No completed cofactor or new scalar carrier is used; polynomialCentralRemaining
remains the authoritative ledger.

Optional actual-prime dyadic probes at (N,K)=(640,16),(1536,32) retain all
core masks and include rough close-owner examples where the other hinge
changes the cancellation centre. The N=1536 all-base spread-log diagnostic
has 3,842 selected bases over four cofactor counts and strong signed profile
cancellation, while the clustered-log diagnostic has 42,504 reinforcing
bases of one count. Neither is a source-scale population bound. Logged
underflow is NOT cancellation evidence. middle_half_no_prime_shift proves
that further prime insertion cannot have BOTH ends inside that narrow
selector; retain its exterior boundary instead of iterating masked affinity.
The probe is optional and outside builds/CI. See docs/zeta-riesz-hinge-pair.md
and docs/riesz-hinge-pair-audit.json. All 39 public proofs pass the focused
warning-as-error build and ordinary-root-import namespace lint/axiom audit;
only the three permitted standard axioms occur. The whole floor, ceiling, finite starting
order, certified deficit percentage and new zero exclusion remain OPEN.

`ZetaRieszHingeAllocationPayment` now pays the OWNER allocation on the whole
selected genuine failed-gap hinge population. With B=(n/largestPrime n)/e,
log B>=L, the failed gap gives 2 log p+log B<=2.03N. The existing eventual
L>=11N/8 bound forces log p<=131N/400; the current 1.97N<log n core then makes
EVERY original prime log at most log n/6 and forces omega(n)>=7. The unchanged
unpaid factorial orders have total owner mass <=exp(-N/8), proved by a 1/2
binomial tilt. Only one owner is selected, so its error has no count factor.

For ANY original divisor-incidence submask on `hingeLabels`, the allocated
minus unallocated coefficient has one global source-scale allowance
(503/500)*zetaMoebiusLogMajorantMass(2049/2048)*hingeAllocationRate^N, with
hingeAllocationRate=(503/1000)*(2048/1023)*exp(-1/8)<9/10. This pays ONLY the
allocation difference. Do not norm-pay the unallocated signed hinge, drop
either hinge, complete a cofactor, remove prime holes or add an old low-count
credit. `retained_hinge_allocation_bound` and `central_hinge_allocation_bound`
apply to the CURRENT original antidiagonal after the affine zero deletions.
`polynomial_remaining_hinge_allocation_bounds` transfers both signed sides
directly in polynomialCentralRemaining, leaving all older credits unchanged
and subtracted once. The remaining selected phase weight is exactly
(log n/L)*K_N(s0,n); its joint signed constant/log prime moments remain unpaid.

All 19 new public proofs pass the focused warning-as-error build and the
ordinary-root-plus-module namespace lint/transitive axiom audit. Only the
three allowed standard axioms occur. Optional log-domain original-order and
actual-prime dyadic regressions are outside builds/CI; see
docs/zeta-riesz-hinge-allocation.md and docs/riesz-hinge-allocation-audit.json.
The fixed majorant mass and effective starting order are NOT evaluated.
Do not mistake error rates per unit of that mass or an underflowed sample
for a bound on the retained source. Together with the earlier hinge-pair
slice this is 58 checked local public proofs in two modules. No commits,
subagents, wider gates, new zero exclusion or whole floor/ceiling claim.

`ZetaRieszPolynomialOwnerPayment` now pays the complete original population
with largestPrime(n)<=(N+1)^32. Its arbitrary partial-incidence coefficient
has eventual source norm <=(39/40)^N, uniformly in all moving heights,
allocations and original masks. The Rankin exponents63/64 and129/128 give
Euler cost exp(2*countMass(129/128)*(N+1)^(3/4)); a fixed tilt33/64 absorbs
this with rate(10001/20000)*(64/33)*exp(1/256)<39/40. The exponent16 candidate
was NOT counted as a new cofinal saving: the original dyadic count ceiling
already makes that smooth-owner population eventually empty. Keep exponent32.
The starting order and comparison mass are not evaluated. Its 16 public
proofs, optional original-mask probe and audit are documented in
docs/zeta-riesz-polynomial-owner.md and docs/riesz-polynomial-owner-audit.json.

The latest global floor endpoint is `ZetaRieszReducedCountPayment`:
`eventually_remaining_reducedCount_bounds` lowers the paid count threshold
from omega>=K_j to256*omega>=K_j, for the SAME dyadic schedule and ALL share
geometries/radial periods. b=exp(log(17/16)/256), b^N<=K^omega; the complete
Euler count mass is exp(2*K*countMass(1000001/1000000))/b^N. q=499999/1000000
gives r=(10001/20000)/(q*b)<1 and paidCountRate=(1+r)/2<1. The whole literal
partial-incidence population has ONE independent budget
(203/50)*(10001/20000)*(N+1)*paidCountRate^N, with every original phase,
allocation, count/radial/physical mask and both hinges retained. No hidden
Type-II, prime-density or hypothetical-zero estimate is assumed.

The terminal ledger keeps all earlier credits unchanged and spent once,
adding only this geometric error and the previous hinge-allocation error;
both tend to zero. Its remaining main satisfies256*omega<K, and genuine
hinges satisfy7<=omega<K/256. This is a threshold reduction, NOT a percentage
bound on signed mass or a closed floor. Lower counts and the still-retained
growing counts require their independent joint estimate. Do not reuse old
count credits, resurrect restAllowance, or sum overlapping smooth-owner and
count-population credits without a disjoint ledger. No scalar carrier was
introduced. Its 15 public proofs, optional probe and audit are recorded in
docs/zeta-riesz-reduced-count.md and docs/riesz-reduced-count-audit.json.
The comparison mass/starting order remain unevaluated; finite samples and
underflow are not certificates. This brings the local batch to89 checked
public proofs in four modules. Keep focused warning-as-error validation,
ordinary-root-plus-module namespace lint and all public axiom checks. No
commits, subagents, wider gates, floor/ceiling or new zero exclusion claim;
preserve the published README and explorer endpoints.

`ZetaRieszLowOffsetPairFloor` adds an independent signed saving on a NEW
low-offset region, including near-balanced seven-prime geometries missed
by the previous overlap selector. For D=log(a/e)-L, 0<=D<=log r and
P+D<=log r+log s, the two old four-divisor blocks have exact responses
w*mu(a/e)*X and -w*mu(a/e)*Y, where X=log r+log s-P-2D and Y=P+D-log q.
If X<=5Y and Y<=5X, joining them costs <=2/3 of their separate REAL-part
allowance for every original complex phase. This is a ONE-THIRD sector
allowance saving, NOT a fraction of the whole floor deficit or a bound on
the aggregate remaining price. Both original hinges remain: the adjacent
block crosses the first hinge even though it lies below the cofactor hinge.

The exact retained prime row is mu(a/e)*[(S-3D)*M0-2*Mlog], with its literal
prime endpoints/holes and no countwise or positive boundary allowance.
`low_offset_pair_subset_retained` places both blocks after the CURRENT
affine zero deletions. `global_retained_low_offset_floor` leaves all other
labels/incidences signed. `eventually_remaining_low_offset_floor` is a
DIRECT floor-ledger comparison for polynomialCentralRemaining after the
reduced count crop/allocation payment; all older credits and both geometric
errors stay unchanged and occur once. LowOffsetData is finite arithmetic
geometry, not a hidden signed discrepancy hypothesis. No new scalar carrier.

The optional actual-prime regressions at N=640/1536 keep seven factors and
all original core masks; joined/separate ratios are about0.437/0.553 and
the old overlap selector fails. These small samples are NOT below the new
reduced count threshold. The large-order ratio about0.651 is ONLY ideal log
geometry, without prime construction or population mass certification.
Underflow is not cancellation. No effective start or aggregate floor is
claimed. See docs/zeta-riesz-low-offset-pair.md and
docs/riesz-low-offset-pair-audit.json. Its 15 public proofs pass focused
warning-as-error compilation, ordinary-root-plus-module namespace lint and
transitive axiom checks, giving104 checked local public proofs in five
modules. The whole floor/ceiling and restricted contradiction remain OPEN.
Keep local-only work, no commits/subagents/wider gates, and published
README/explorer endpoints unchanged.

`ZetaRieszSymmetricPeriodPayment` now removes the EXACT `k!` ordering
overcount from squarefree cofactor masses and applies the saving AFTER
the original signed prime period has been summed. The full prime phase,
factorial weight, both Riesz hinges, owner allocation and selected masks
are unchanged. `sum_symmetricCost_le_six_factorial` reduces the ENTIRE
complete-period budget for total counts>=7 (cofactor counts>=6) by at
least720, including moving count sets. This is not a percentage of the
whole floor deficit and does not pay clipped or owner-masked prime holes.
The saving applies to the ordered tuple cover ONLY: existing exact Euler
count masses already count each label once; do not divide those by k!.

The new uniform constants are logMassConstant(k)/k!<=144^k and
variationConstant(k)/k!<=576^k. symmetricCost(k)<=2,000,000*2048^k;
the entire selected band throughK costs<=2,000,000*4096^K. When
4096^(4K)<=v its joint signed cost is<=2,000,000*v^(-1/4) times the SAME
radial unit. periodCountCeiling(N)=Nat.log4096(N+1)/4 tends to infinity;
`growing_counts_floor` has no fixed-count eventual threshold. The final
`radial_periods_floor` sums counts AND radial periods before pricing;
`eventually_radial_periods_supply_floor` charges any already-checked
positive supply paying those same radial units by an arbitrarily small
fraction. Its supply comparison remains explicit. No bilinear estimate,
prime-density approximation or exposed-zero assumption is hidden.

This is a RELATIVE signed complete-period floor, not source-o(1) decay
or the numerical-79/1000 floor. The old0.398..0.985 cofactor cap and
canonical prime owner gap remain; every whole selected prime fibre must
belong to the original allocation set. Do not fill its literal holes,
double-charge overlap with the earlier fixed-count3..55 supply, or apply
its vanishing relative cost to the diverging(2u)^N envelope. The explicit
band grows slowly and has no effective start; old fixed-count estimates
are stronger at modest orders. Genuine hinge crossings, owner/cutoff
holes and higher counts still require their independent signed bound.
The current polynomialCentralRemaining ledger and published endpoints
are unchanged. No whole floor/ceiling, contradiction or zero exclusion.

All19 new public proofs pass focused warning-as-error build and ordinary
root-plus-module namespace lint/all public transitive axiom checks; only
the three permitted standard axioms occur. The optional rational finite
symmetry/constant log-domain probe is outside builds/CI; see
docs/zeta-riesz-symmetric-period.md and
docs/riesz-symmetric-period-audit.json. This gives123 checked local public
proofs in six modules. Continue locally without commits, subagents or
wider publication gates, preserving all previous no-gos and the README.

`ZetaRieszHigherRankHingeFloor` now extracts the common cancellation
mechanism and strengthens the SAME current floor ledger. All incidences
share the original n=p*a phase/factorial/allocation. For R=a/e, k=omega(R),
S=log R, P=log p and D=S-L, a lower cutoff admitting only the unit and an
upper cutoff admitting only unit/single primes evaluate the entire based
block as w*mu(R)*(S-(k-1)P-kD). `subset_single_layer_difference` proves
the same identity for arbitrary finite positive increments, not only primes.
The controlling property is the active subset layers, not a fixed count.

The canonical first block has amplitude X=log Q-P-2D and ALL its other
ranks have opposite amplitude Y=(k-2)*(P+D)-(S-log Q). Under3X<=5Y and
3Y<=5X, `higher_rank_quarter_floor` prices their combined real response at
one quarter of the separate two-GROUP real allowance. This is a75% SECTOR
saving, not a whole-deficit fraction. `rank_quarter_of_band` gives an
explicit interval for every rank; equal increments cancel at D=P/k.
`norm_linear_orbit_le` costs the joined single-layer response at most
||w||*(k-1)*P instead of an exponential divisor cover. This norm is AFTER
all ranks are summed, and is not a source-scale population payment.
`reinforcing_endpoint_response` shows that this linear price is sharp at
D=P in the abstract equal-increment model. Do not infer uniform zero cost.

The original e|d filter retains whole canonical pair orbits. The old
short/affine zero deletions remain zero after filtering, including their
literal boundaries; `retained_based_sum_eq_full` gives the current retained
response with no reused credit. `eventually_remaining_higher_rank_floor`
keeps all old credits and both allocation/count geometric errors unchanged
and subtracted once. Choose ONE base per physical label: maximal based
blocks can overlap. Do not add this price to an overlapping old low-offset
or complete-period sector. The exact prime row stays ONE signed constant/
log moment on its actual prime mask; its aggregate arithmetic cost is open.

All22 public proofs pass focused warning-as-error compile/build and
ordinary-root-plus-module namespace lint/transitive axiom checks, giving
145 checked local public proofs in seven modules. The optional exact
rational and actual-prime probe is outside builds/CI; see
docs/zeta-riesz-higher-rank-hinge.md and docs/riesz-higher-rank-hinge-audit.json.
Actual seven-/ten-prime ratios0.077..0.147 pass the quarter selector;
fourteen-/twenty-prime ratios0.613..0.923 fail it. Small literal samples are
not below the eventual reduced count threshold, and floating source-weight
underflow is not a certificate. The whole floor/ceiling and restricted
contradiction remain OPEN. Continue locally without commits/subagents/
wider gates, retaining the published README/explorer endpoints and no-gos.

`ZetaRieszLogShellPeriodFloor` consolidates the complete signed prime-period
and close-owner boundary payments using previously lost comparable-log
support. The current HigherRankData implies ALL cofactor prime logarithms,
including the base primes, lie in [P/2,P]. The exact based response also has
the common total-log centre log(e)+k*L/(k-1), independent of the individual
cofactor prime geometry. Neither statement fills clipped prime support.

Any actual prime shell H<=log(p)<=4H, H>=1, has reciprocal mass at most
M=5*log(4). An arbitrary selected squarefree count-k population supported
there has mass <=M^k/k!, with no tuple overcount. After the literal signed
complete prime fibre is summed, ALL selected counts cost at most
1207600*exp(4*M)*v^(-1/2) times amplitude(N,v)/v. The old cofactor cap,
owner gap, phase-grid orientation and whole-fibre membership remain.
No extra count ceiling appears, but the cap still excludes tiny owners;
do not infer that all high-count physical geometries have been covered.

The close-owner boundary payment now has NO count ceiling. The actual
near-tied pair lies in one short logarithmic window with reciprocal mass
<=2/H; its two-prime cost is <=4/H^2. The remaining squarefree shell mass,
log(b.minFac)<=4H and the literal radial inequality v<=8H*(k+2) give one
all-count original atom-norm budget 24576*exp(4*M)/v relative to the SAME
radial unit. Original submasks/allocation/phase remain. H>=10000 and the
short radial/close-owner geometry are retained; other holes are not paid.
`signed_period_with_boundary_floor` joins both arithmetic estimates, and
`radial_periods_with_boundary_floor` aggregates all selected counts and
radial periods with relative rate O((N+1)^(-1/2)). This is NOT source-o(1)
or the numerical floor. A disjoint literal cover and actual retained-supply
comparison still have to enter the current polynomialCentralRemaining
ledger without reusing older credits. Wider prime-log spreads, tiny-owner
prime periods and other hinge-selector/clipped boundaries remain open.
Do not multiply this relative rate by the divergent (2u)^N envelope.

All24 public proofs pass focused warning-as-error direct/build and the
ordinary-root-plus-module namespace lint/transitive axiom checks; only
the three allowed standard axioms occur. The optional actual finite prime
mass, exact rational symmetry and cost probe is outside builds/CI; see
docs/zeta-riesz-log-shell-period.md and docs/riesz-log-shell-audit.json.
The constants are coarse; no effective start or deficit fraction is
certified. This gives169 checked local public proofs in eight modules.
The whole floor/ceiling and restricted contradiction remain OPEN. Continue
locally without commits/subagents/wider gates or published endpoint changes.

`ZetaRieszTinyOwnerPeriodFloor` extends the signed original owner-prime
floor beyond the old log(a)<=.985*v cap. Its exact original atom retains
the selected owner factorial sum, both Riesz hinges and the complex phase.
Only squarefreeness/count>=2, actual ownership gap P0=v-pi/y-log(a),
whole prime-fibre membership and the old phase-grid orientation enter.
No fixed positive owner share or upper count is assumed. With all cofactor
prime logs in[H,4H], H>=5000, jointPeriodCost<=5/H^2. The exact two-hinge
response, quarter-period cutoff variation and original squarefree shell
mass give the signed count price481*(2*M)^k/(H*k!), M=5*log(4).
Every selected count is summed into one constantC=481*exp(2*M)=504365056.

All dyadic owner-log shells cost at most2*C/H0, with NO factor for the
number of shells. `retained_single_layer_shell_exists` derives an actual
shell cover for the whole cofactor support on current HigherRankData,
including base primes; it does not assert a whole-prime-period cover.
`radial_dyadic_shells_floor` joins counts/shells/radial periods before
charging their SAME radial units. H0=8*log(N+1) gives relative price
126091264/log(N+1)->0. This is NOT absolute source-scale decay.
`eventually_period_shell_cost_paid` connects that price to the SAME
existing selected supply and scale, costing at most1/256 of its value
eventually. Its original scale/phase hypotheses remain. A compatible
disjoint literal cover is still required before spending half the
retained1/128 reserve; no original credit is silently reused.

The current polynomialCentralRemaining is unchanged. Other clipped
prime periods, selector/physical boundaries, wider log spreads and the
whole-ledger cover remain OPEN. The previous close-owner boundary
payment is not silently identified with these missing boundaries.
Do not multiply a relative price by the divergent(2u)^N envelope.
The constants are coarse; no effective order or global deficit fraction
is certified. All19 public proofs pass focused warning-as-error
direct/build, ordinary-root-plus-module namespace lint and transitive
axiom checks (only the three allowed standard axioms). The optional
curvature/count/shell probe and audit are outside builds/CI; see
docs/zeta-riesz-tiny-owner-period.md and
docs/riesz-tiny-owner-period-audit.json. This brings the local batch to
188 checked public proofs in nine modules. No whole floor/ceiling,
restricted contradiction or new zero exclusion. Continue locally
without commits/subagents/wider gates or published endpoint changes.

ZetaRieszClippedOwnerPeriodFloor now consolidates complete signed owner
periods and their actual clipped-start boundary, including the genuine-hinge
A=empty main after its independently paid allocation error. The previous
owner-allocation period lemma required p in A and was not applicable to this
main. selectedAmplitude_full retains EVERY factorial order;
unallocated_fibre_floor / unallocated_all_counts_floor prove the correct
full-kernel signed inequality directly. unallocated_retained_atom_eq and
unallocated_retained_real_eq_parts preserve all old zero-orbit deletions
inside the literal antidiagonal, so no credit is restored or spent twice.

On a canonical n=p*a in a phase period, ownership failure at its lower
endpoint forces log(p)-log(q)<1/8 for a genuine cofactor prime q.
owner_start_clipped_close and no_close_owner_period_gap hold at arbitrary
counts. The close-owner shell payment now requires ONLY cofactor primes
in[H,4H]; the owner may cross its upper endpoint. Its remaining k-factor
mass M^k/k!, actual close-pair mass4/H^2 and least-prime log<=4H give one
boundary price1536*(2*M)^k/(H*k!), M=5log4. The 1/H is retained instead of
being replaced by k/v. ALL counts cost1536exp(2M)/H radial units; both
missed sign selections cost one original atom, not two.

The joined main-plus-boundary constant isC=2017*4^10=2114977792.
unallocated_dyadic_period_floor / unallocated_radial_period_floor join
all selected counts, dyadic shells and radial periods before pricing,
with no cofactor cap, count ceiling or number-of-shells factor.
Retainingv>=N+2 gives cost2C/[H0*(N+2)] against the SAME positive
factorial supply units. H0=8log(N+1) yields relativeO(1/(NlogN));
eventually_joined_radial_cost_paid uses at most1/256 of the SAME selected
supply with its old scale and phase-window hypotheses explicit.
This remains a RELATIVE payment, not source-o(1) norm decay. Never price
it against the divergent(2u)^N envelope or double-spend that supply.

hinge_whole_fibre_mem_intermediate proves physical mask compatibility for
actual retained hinges withlog(p)>32log(N+1), log(N+1)>=1 and the original
length bound. Canonical ownership, coprimality, squarefree cofactor and
count relations are general. Actual whole-fibre selection, owner gaps,
comparable cofactor logs and phase-grid orientation remain explicit in the
signed estimate. A label shell cover still does NOT prove a compatible
disjoint complete-fibre cover after all current masks and old credits.
Other selector/radial clips, wider prime-log spreads and the global cover
remain OPEN. polynomialCentralRemaining and all published endpoints are
unchanged. No wholefloor/ceiling, restricted contradiction or zero exclusion.

All33 public proofs pass focused warning-as-error direct/build and
ordinary-root-plus-module namespace lint/all public transitive axioms,
with only the three permitted standard axioms. This brings the local
batch to221 public proofs in ten modules. The optional finite ownership,
exact squarefree symmetry and joined-price probe is outside builds/CI;
its finite primes do NOT meet the eventual Chebyshev threshold and no
effective order/global deficit fraction is certified. See
docs/zeta-riesz-clipped-owner-period.md and
docs/riesz-clipped-owner-period-audit.json. Continue locally without
commits, subagents, wider publication gates or README endpoint changes.

`ZetaRieszRadialPeriodPayment` now removes BOTH constant-width radial
period clips directly from the SAME polynomialCentralRemaining ledger.
ForN>=1000, the1.97N+1 and2.03N-1 layers lie in the enlarged1.971N
and2.029N tails. Exact rational hundredth-power certificates and the
summable reference exponent1+1/1048576 give one source-normalized
rate exp(-N/1000000), uniform at u<=10001/20000 and every height.
The literal partial-incidence estimate allows arbitrary original
divisor submasks and label-dependent allocations. The new main crops
these endpoint labels after the existing reduced-count crop; every old
credit remains subtracted once. Its total displayed error tends to zero
on the original cofinal schedule. These are GLOBAL independent payments.

Buffered labels have their entire phase period inside the original radial
window. On an original same-cofactor row meeting a genuine hinge in that
period, the owner remains below one sixth of the total log even across
the hinge-selector boundary. completed_hinge_owner_sum_bound pays its
allocation switch globally with the old geometric rate and no count/row
factor. This does not fill other prime/count/physical masks. See
docs/zeta-riesz-radial-period.md and docs/riesz-radial-period-audit.json.

`ZetaRieszBroadOwnerPeriodFloor` consolidates the signed main and ACTUAL
ownership clips across every selected count and arbitrary cofactor
prime-log spreads above an explicit cutoff. The old comparable-log
[H,4H] restriction is replaced by[a,4H], with5000<=a<=H andH>=10000.
prime_interval_mass_le proves the actual prime reciprocal bound
log(b/a)+1/a, with leading coefficientONE. This is a positive cofactor
mass estimate AFTER signed prime-period cancellation, not generic
PNT/Abel transport of the retained carrier. Exact squarefree symmetry
keepsM^k/k!, and exp(2*(log(4H/a)+1/a))<=32H^2/a^2 prevents the
count exponential from losing the two-power prime-period saving.

Actual clipped witnesses retain their location above the SAME owner-log
scale. Every count and both missed sign selections cost one boundary
atom. The joined period price is64544H/a^2 timesF_N(v)/v.
Summing all dyadic owner scales withsumH_j<=2v and all radial periods
gives the single signed budget129088/a^2 times sumF_N(v). The subsequent
normalization audit WITHDRAWS the previous claim that this pays1/256 of
the actual supply at a=log(N+1): F_N(v)=amplitude N v has degreeN+1,
but period_grids_cost_paid usesF_N(v)/v. The actual supply-unit price is
129088*v/a^2. Both earlier Lean theorems are valid individually; they do
not compose without this extra radial factor. Preserve the sharper old
comparable-log bound on its own support and never duplicate supply
credits or multiply a relative price by(2u)^N.

The current core does NOT by itself imply that EVERY cofactor prime is
aboveN^2 merely because its allocation uses intermediatePrimes.
The lower cofactor-prime cutoff, complete original fibres, disjoint
literal cover, selected phase grids, old-credit compatibility and
small-prime/exterior selector populations still need proof before the
new joined relative estimate pays the whole floor. Keep those obligations
explicit. See docs/zeta-riesz-broad-owner-period.md and
docs/riesz-broad-owner-period-audit.json. The optional exact symmetry/
constant probes are outside builds/CI. Tiny finite probe primes do not
meet the eventual Chebyshev threshold; no starting order or fraction of
the whole floor deficit is certified.

Both modules pass the focused warning-as-error direct/build and ordinary
root-plus-module namespace lint/all public transitive axioms, with only
the three allowed standard axioms. Their20+18 new proofs bring the local
batch to259 public proofs in twelve modules. These are supporting global
and relative savings; the independent whole-79/1000 floor,3/2 ceiling,
restricted contradiction and new zero exclusion remain OPEN. Continue
locally without commits, subagents or wider publication checks; keep
the README and published endpoints unchanged.

### Small-block consolidation and literal ownership clips (local)

`ZetaRieszSmallCofactorCancellation` joins arbitrary squarefree divisor
blocks containing the canonical least-prime pair AFTER BOTH old zero
deletions, with the original complex weight unchanged. Odd blocks have
an exact midpoint reflection zero and a quantitative distance bound.
Small primes do not generically disappear: clustered large-prime logs
can isolate one reinforcing divisor/count layer. Their useful extra
property is a gap between successive layers. If the changing hinge
misses those layers on the WHOLE prime period, the full response is
constant and its cutoff-variation debit disappears exactly.

The resulting flat-response row floor has price120b/H^2 times
(2M)^k/k! times amplitude(N,v)/v, where log(minFac(cofactor))<=b.
All selected counts may grow and EVERY small cofactor prime is retained.
An exact finite prime head belowexp(5000) and the leading-one tail mass
bound give exp(2M)<=smallPrimeHeadCost*H^2. The head constant is finite,
positive and unevaluated. Thus the all-count flat price is120*headCost*b
in the actual amplitude/v units. The empty allocation applies only on
the population already covered by the global hinge-allocation payment.

`ZetaRieszSmallOwnerBoundary` proves that deleting the actual two near-
tied large owners preserves the small least prime. Its literal fixed-
count boundary price is384b/H^2 instead of1536/H: a factorb/(4H) saving.
It retains original allocation and phase. Both missed sign selections
spend ONE atom. After all counts and small primes are joined, the flat
main plus actual ownership boundary has price504*headCost*b. A joint
four-cutoff layer-gap criterion also makes the whole original allocated
complex boundary atom EXACTLY zero. It may consolidate already-deleted
zeros but creates no additional supply credit.

IMPORTANT NORMALIZATION: amplitude(N,v) has degreeN+1; the positive
radial supply usesamplitude(N,v)/v. The previous broad all-radial
coefficient129088/a^2 againstamplitude is129088*v/a^2 in supply units.
Do NOT compose broad_radial_supply_floor with the standalone
eventually_broad_radial_cost_paid without that factor. The earlier
documentation's combined1/256 supply payment has been withdrawn.
small_flat_radial_supply_floor now uses the CORRECT units and joins
all counts, dyadic owner scales and radial periods. Its positive price
504*headCost*b*(1+logG/log2) still grows for b=log(N+1), G=4(N+1).
Lean proves that actual price tends to infinity and cannot fit any
fixed supply fraction. The price divided byN+1 tends to zero only in
the wrong, one-degree-higher units; it pays no literal packet. This is
a no-go for this positive majorant, not for a sharper signed floor.

The optional small-block and ownership probes are outside builds/CI.
Order640 literal labels pass the original core mask but fail the later
reduced-count crop and effective Chebyshev threshold; growing equal-log
models are not actual-prime populations. Underflow is not cancellation.
An ownership gap case vanishes while the last active small-block hinge
can retainlog(2) and a negative arithmetic coefficient. The next estimate
must retain joint signs across those active cofactor/count crossings;
do not pretend a relative amplitude price is an actual supply payment.
The complete original fibre cover, other physical/selector holes and
disjointness from all prior credits remain explicit obligations.

The18+16 public proofs pass focused warning-as-error direct/build,
ordinary-root-plus-module14-linter checks and every public transitive
axiom audit, with onlypropext,Classical.choice,Quot.sound. This brings
the unpublished batch to293 public proofs in fourteen modules. See
docs/zeta-riesz-small-cofactor.md, docs/zeta-riesz-small-owner-boundary.md
and their source-hashed auditJSON files. Whole floor/ceiling, restricted
contradiction and new zero exclusion remain OPEN. Continue locally
without commits, pushes, subagents or wider publication checks; preserve
the README and published default endpoints.

### Active count transport and total-log population prices (local)

`ZetaRieszCrossCountTransport` joins opposite Mobius ranks at NEARBY
logarithmic bases of the SAME original label. Both hinges, the original
complex phase, factorial kernel, owner allocation and masks remain.
The half-count involution price prevents charging each pair twice. The
other hinge may be checked inactive separately for different matched
pairs. Retained original orbit identities are proved AFTER BOTH old
zero deletions. The direct `polynomialCentralRemaining_transport_floor`
keeps the unmatched signed sum, explicit total transport cost and the
four old independent credits once. No source-scale transport-cost bound
or numerical whole floor is asserted. The same relation lifts over
arbitrary common background factors and count ranks, with disjoint
placement still required. Clustered active layers may have only ONE
parity; Lean prohibits universal opposite-parity matching and proves
their possible full reinforcement, uniformly at growing counts.

The user next required the global matching/unmatched costs. The checked
`ZetaRieszParityLayerCost` now prices a broad STRUCTURED population by
complete signed prime periods while retaining its total logarithm.
The cofactor log scaleJ is independent of the owner scaleH, withJ<=H.
On the retained core, the cofactor carries more thanv/4. Count tilting
therefore gives8exp(4M-v/(32J)); the uniform owner payment is32/v.
The LITERAL unique-owner factorial allocation is kept in the signed
main. Both missing sign selections spend ONE original boundary atom.
The joined price is221440exp(4M)/v timesamplitude(N,v)/v.

EVERY small prime is retained. For prime logs<=B OR in[J/W,4J], with
B>=5000,W>=1,J>=10000W, the exact finite head and leading-one prime
interval mass giveexp(4M)<=gappedHeadCost*B^4*W^4. All selected counts,
dyadic owner scales and radial periods are joined into ONE price:
221440*gappedHeadCost*B^4*W^4*(1+logG/log2)/(N+1), in the ACTUAL
amplitude/v supply units. ForB=W=32log(N+1),G=4(N+1), Lean proves
gappedSupplyPrice=O(log^9(N)/N)->0; it fits any fixed positive reserve
fraction eventually. FixedW givesO(log^5(N)/N). The head constant is
finite, positive and UNEVALUATED; no effective starting order is claimed.
Never turn this relative supply payment into source-o(1) by multiplying
it by the divergent(2u)^N envelope. Any reserve must be disjoint from
old credits, and every original complete fibre/mask cover remains required.

This does NOT cover the intermediate intervalB<logp<J/W. An optional
continuous log-geometry probe adds one mesoscopic prime to a cluster:
all66 active blocks still have ONE parity and the label misses the
structured spectrum condition. It is not a literal-prime or population
certificate. Simply enlarging the head is no rescue for this majorant:
large_head_price_lower proves thatB^2>=N+1 makes even its single-period
correctly normalized price grow at least linearly. This is an audit of
the positive price, not impossibility of a new signed arithmetic bound.

The full total matching cost, unrestricted unmatched layers, intermediate
log scales, complete original fibre/physical cover and fresh reserve
compatibility remain OPEN. Do not report the new structured-population
inequality as the independent-79/1000 floor or as a zero exclusion.
The23+20 public proofs pass focused warning-as-error direct/build,
ordinary-root-plus-explicit-module namespace lint and ALL public
transitive axioms, with onlypropext,Classical.choice,Quot.sound. This
brings the unpublished batch to336 public proofs in sixteen modules.
See docs/zeta-riesz-cross-count-transport.md,
docs/zeta-riesz-parity-layer-cost.md and their source-hashed auditJSON.
Optional probes remain outside builds/CI. Continue locally without
commits, pushes, subagents or wider publication gates; preserve README
and published default endpoints.

### Intermediate-scale populations and joined signed cancellation (local)

The user required enumeration and signed cancellation for the denser
intermediate populations. `ZetaRieszIntermediateScaleCost` retains the
ACTUAL intermediate primes E={p in U:B<logp<J/W}, rather than deleting
them or enlarging the small-prime head. The exact marked finite Euler
budget is t^m exp(4M_good+4M_E/t). At t=16, m<=floor(log(N+1)/4),
the literal signed owner-prime periods and their ownership clips have
ONE global relative-supply price O(log^9(N)/N^(1/20))->0. The permitted
intermediate count tends to infinity. Both missed sign selections spend
ONE original boundary atom. All true units are amplitude(N,v)/v.
Actual prime support, complete original fibres and allocation remain
explicit. Retuning a positive marker cannot universally extend this:
when m>=logx and ACTUAL M_E>=logx/2, every t>=1 costs at least sqrtx
in the correctly normalized allowance. This is not a signed no-go.

`ZetaRieszDenseShellCost` removes the factor-count ceiling for dense
clusters. Assign intermediate primes to their UNIQUE dyadic LOG bins,
with the upper endpoint included. One shell has exp(4M)<=32, without
any restriction on how many primes it contains. Exact occupied-pattern
partitioning retains arbitrary complex weights and places every original
label once; divisor deletion inherits its pattern. Among the ENTIRE
available grid of at most2logx+1 bins, all patterns with at mostlogx/16
occupied bins cost at mostexp(1)sqrtx. `global_all_pattern_floor`
derives the literal signed main+clips inequality over ALL patterns,
counts, owner scales and radial periods, with relative cost
O(log^9(N)/sqrtN)->0. It does not assume a bilinear signed bound.
A population confined to one union of at mostlogx/8 bins also has the
uncapped signed bound. These relative costs require a fresh disjoint
supply reserve and original full-fibre cover; never turn them into
absolute source-o(1) via the divergent(2u)^N envelope.

`ZetaRieszSeparatedParityFloor` covers a different widely spread
configuration. Both exact two-prime finite differences are joined BEFORE
estimating. If distinct background divisor logs are at leastlogr+logs
apart, at most ONE tent pays either original hinge. The ENTIRE retained
divisor response therefore has floor-2|Re w|min(logr,logs), independently
of count. BOTH previous zero deletions and original phase/allocation
remain. `superincreasing_divisor_log_gap` proves this separation from
the ACTUAL squarefree prime-log inequalities
logp>=logr+logs+sum_{smaller q}logq. The global original-label theorem
keeps the total weighted population cost explicit and UNPAID.

`ZetaRieszDenseSmallTopFloor` bounds an overlapping dense population
by RETAINING the original count tilt. When ALL cofactor prime logs<=4J
and512Jlogx<=v, the true cofactor window loga>=v/4 forcesomega(a)>=32logx.
The exact signed complete-period price is3848exp(4M-v/(32J))/H.
The actual finite whole-prime mass hasM<=C_head+logx, so the rate is
O(N^-12) per selected owner scale. ALL owner scales and radial periods
have ONE global relative costO(logN/N^12)->0, without ANY factor-count
or occupied-bin ceiling. If4J<H, the original near-owner clip is proved
EMPTY from its literal cofactor support; no boundary is simply dropped.
Both parities, both hinges and changing original allocation remain.
The new nonempty-boundary variant needs onlyJ<=H: its literal clipped
norm price retains12288exp(4M-v/(8J))/H. Both missed sign selections spend
ONE boundary atom, and the joined global price is16136 in place of3848,
with the sameO(logN/N^12) rate. HOWEVER the later unpaid-ledger audit
proves these labels were ALREADY in the old whole high-count tail.
Do not count this as new unpaid coverage or spend a reserve for it again.

Use this priority classification for dense intermediate labels:
(1) remove the old spent tail FIRST; small-top labels already belong there;
(2) counts5logx+2<=omega(n)<countThresholdN: new signed count-tilt
    period cost, with ALL share spreads, bins and crossing parities;
(3) few occupied bins below that count band: all-pattern signed cost;
(4) many bins at lower counts, separated divisor windows: count-free tent cost,
    with population funding still open;
(5) many bins at lower counts, overlapping windows with BOTH active parities:
    opposite-rank transport costs/coverage and unmatched layers open;
(6) many bins at lower counts, overlapping windows with ONE active parity:
    local universal matching impossible, further cross-label/prime-period
    cancellation still needed.
Use cases in this order to avoid double spending. Inactive responses are
exactly zero. Few-bin clusters can be one-parity: they are covered by (3), not rejected
because local matching fails. Incomplete physical fibres and spent supply
credits are separate mask/ledger obligations. This taxonomy is not a
proof that the remaining classes are empty or source-small.

`ZetaRieszUnpaidCountTiltFloor` now targets a GENUINELY unpaid count band.
The exact old threshold is8Nat.clog2(N+1), at most16logx forN>=7.
Every squarefree unpaid original label has smaller count. Counts8 up
to that threshold avoid EVERY old head, four-prime supply and tail;
complete owner fibres therefore have no previously-spent holes there.
`owner_fibre_count` retains actual squarefreeness and count at arbitrary
count, WITHOUT the old fixed-count cofactor-share cap.
`retained_literal_count_floor` reindexes the signed period bound onto
original integer labels without duplicating marked/count incidences.

Sum the signed prime period FIRST; THEN keep the hard lower count:
sum_{k>=5logx}(2M)^k/k!<=exp(5M-5logx log(5/2)). Lean certifies
log(5/2)>=9/10, and the ACTUAL finite prime universe hasM<=C_head+logx.
For unpaid labels the old upper count suppliesv<=128Hlogx, so this
sqrtx population price becomes a vanishing true-supply cost.
Actual near-owner clips keepk=omega(n)-2. Both missed sign selections
spend ONE boundary norm; the combined constant is2017=481+1536.
`global_lower_count_floor` joins ALL selected counts, owner scales and
radial periods at the conservative priceO(log^2N/sqrtN)->0, independently
of bin count, prime-log spread and local parity matching.
`eventually_count_cost_paid_by_same_supply` uses the SAME quantitative
four-prime supply selection from the published whole floor, spending at
most1/256 of its remaining1/128 reserve; no new phase-window witness.
Whole original dense-band fibre coverage and final signed-ledger
placement remain unproved: do NOT claim the literal whole-floor count
threshold has been lowered or a numerical floor/zero exclusion exists.
Lower growing counts with overlapping many-bin crossings still need
joint signed cancellation. Numerical budget scans are diagnostic, with
the unevaluated exact arithmetic head factored out, NOT prime density.

The31 new/extended public proofs pass focused warning-as-error direct/build,
ordinary-root-plus-explicit-module namespace lint and ALL public
transitive axioms, with onlypropext,Classical.choice,Quot.sound. The
unpublished batch now has420 public proofs in twenty-one modules. See
docs/zeta-riesz-intermediate-scale-cost.md,
docs/zeta-riesz-dense-shell-cost.md,
docs/zeta-riesz-separated-parity-floor.md,
docs/zeta-riesz-dense-small-top-floor.md,
docs/zeta-riesz-unpaid-count-tilt-floor.md and their source-hashed audits.
The optional dense-population probe checks actual finite prime/squarefree
identities and the global pattern price; growing log-layout models are
NOT constructed primes and certify no physical masks or population
cost. Probes remain outside ordinary builds/CI. No effective starting
order is claimed; the fixed arithmetic head is unevaluated.
Whole matching/unmatched costs, independent whole floor/ceiling,
restricted contradiction and new zero exclusion remain OPEN. Continue
locally without commits, pushes, subagents or wider publication gates;
preserve README and published default explorer endpoints.

The eight-module floor batch, from `ZetaRieszPairChamberFloor` through
`ZetaRieszFiveSignCoverFloor`, is published at
`03a0f31be04d2737a4b2811e2532c32e79a18c69`. Exact-SHA CI run
`36736054868`, Pages, the published README and all three desktop/mobile
explorers passed. The frozen numerical certificate is unchanged. The
published default RH endpoint removes ALL originally unpaid five-prime
labels from the signed remainder and retains 1/128 of the SAME supply.
That publication request is complete. The user's latest instruction is to
continue the floor locally, reusing the signed-period machinery at other
counts. No further commits, subagents or wider gates are authorized by the
completed request. Run focused Lean/root-import lint and axiom validation.
The numerical -79/1000 floor, 3/2 ceiling and zero exclusion remain OPEN.

### Entire unpaid dense-count band covered and funded (local)

`ZetaRieszDenseCountCoverFloor` closes BOTH pending obligations from the
unpaid-count tilt component: the actual whole-fibre/ownership-crossing
cover, and its final placement in the authoritative joinedPhysical floor.
`eventually_joined_floor_without_dense_band` removes ALL original
squarefree labels with omega>=8 and
5log(N+1)+2<=omega<countThreshold(N), retaining every old mask, phase,
allocation, head credit and the original five-prime payment. The SAME
quantitative four-prime supply spends at most1/256, with1/256 retained.
No new supply witness or unproved signed arithmetic estimate enters.

Original cofactors seed the finite owner fibres. Extensions retain the
literal dyadicPrimeCount cutoff and lie in the same original core/band.
Canonical second ownership prices the near-owner clips uniquely across
dyadic scales and radial periods. Both sign grids retain their exact
unmatched populations; their unused opposite-sign boundary is empty.
Every unmatched original label is radial exterior, large owner share,
or owner log<=20000. The last alternative is eventually impossible by
the old upper count ceiling and core length; the other two have their
existing source-geometric payments. The global nonowner payment restores
the full allocation. There is NO anonymous unpaid boundary in the
whole dense-band floor. Its positive period units are paid RELATIVELY
by the actual supply, not asserted to decay after source normalization.

The new literal count ceiling is proved: `remaining_count_cases` gives
omega=3,4,6,7 or8<=omega<5log(N+1)+2 for every squarefree label in the
actual remaining set(E\E5)\denseBand. This is a genuine whole-ledger
saving; it does NOT prove the numerical-79/1000 floor. Count four includes
the funding supply, so subsequent low-count payments must preserve that
ledger and cannot spend it twice.

Current priority enumeration AFTER exact zeros and all spent populations:
(1) fixed counts3,4,6,7 outside the old paid selections;
(2) lower growing counts with few intermediate factors/occupied log bins:
    existing all-pattern signed bounds, but original-fibre cover and
    disjoint whole-floor funding remain;
(3) many bins with separated divisor windows: count-free two-hinge tent
    floor, but total actual weighted population cost remains;
(4) many bins with overlapping crossings of BOTH parities: exact
    opposite-rank transport, with global coverage/distance/unmatched cost
    still open;
(5) many bins with overlapping crossings of ONE parity: universal local
    matching is false, so further cross-label/count/prime-period signed
    cancellation is required;
(6) final numerical aggregate of those populations and all retained
    credits against-79/1000, with an independent arithmetic bound.
Apply these tests in order. Ownership clips are part of each relevant
signed period payment, not another separately charged parity population.
Few-bin clusters may have one parity; they still receive the all-pattern
price. Old small-top dense labels were already spent and earn no new credit.

The optional actual-prime incidence/endpoint probe also scans the remaining
positive count PRICE with the unevaluated head factored out. It peaks near
2log(N+1), where its optimized post-owner power is+1, whereas the proved
5log(N+1) tilt has negative power. This motivates additional SIGNED central
cancellation, not another marker tweak or a claimed arithmetic no-go.
No effective starting order, numerical whole floor/ceiling, restricted
contradiction or new zero exclusion is asserted.

This module adds48 public proofs; the local unpublished batch now contains
468 public proofs in twenty-two modules. Focused checks, ALL public axiom
results and source hashes are recorded in
docs/riesz-dense-count-cover-floor-audit.json; the full obstacle table is
docs/zeta-riesz-dense-count-cover-floor.md. Keep probes outside ordinary
builds/CI. Continue locally without commits, pushes, subagents or wider
publication gates; preserve README and public default explorer endpoints.

### Whole lower-count few-bin population covered and funded (local)

`ZetaRieszFewBinCoverFloor.eventually_joined_floor_without_dense_or_few_bins`
removes the actual lower growing-count few-bin population from the SAME
joinedPhysical floor alongside the existing five-prime and upper-count
payments. Every old head credit, joined-prefix/pair saving, phase and
allocation remains. The SAME quantitative four-prime supply spends at
most1/512 and retains1/512; no second witness or assumed arithmetic
cancellation is introduced. The original positive units are paid
RELATIVELY, not asserted source-o(1).

The new literal mask has8<=omega(n)<5log(N+1)+2 and at most
floor(log(N+1)/16) occupied bins of the canonical cofactor above
B=max(5000,32log(N+1)). It counts ALL such cofactor bins, not merely
the older owner-dependent intermediate gap. This is a stronger selection
than that older test; do not claim all labels satisfying the older test
are covered. Every small prime and every crossing parity remains.
Owner extension keeps the exact cofactor, occupied pattern and original
dyadicPrimeCount mask. Canonical second ownership pays the real clips
uniquely. Both actual sign grids are covered; unmatched radial/share
pieces are source-geometric and the small-owner exception is eventually
impossible. Global nonowner payment restores the original allocation.

The compiled `remaining_configuration_cases` is exhaustive for the SAME
actual remaining squarefree set(((E\E5)\denseBand)\binBand): counts3,4,6,7
OR8<=omega(n)<5log(N+1)+2 with MORE than floor(log(N+1)/16) cofactor bins.
Further priority targets are now:
(1) fixed low counts outside old selections, preserving count-four funding;
(2) many bins with separated divisor-log windows: total actual weighted
    price after the count-free two-hinge tent cancellation;
(3) many bins with both active parities: total matching distance,
    injective coverage and weighted imbalance;
(4) unmatched one-parity layers: cross-label/count/prime-period signed
    cancellation, since universal local matching is false;
(5) independent numerical aggregate against-79/1000, THEN the separate
    multiplicity ceiling. Do not introduce another representation unless
    it yields a signed inequality for these remaining populations.

The optional probe retains original small actual-prime cofactor stability
and arbitrary allocation/phase in the signed pattern partition. Remaining
integer-log MODELS exhibit strong mixed-parity cancellation AND unmatched
one-parity responses. They certify no prime existence, exact moving
integer length, global population bound, effective start or numerical
floor. They remain outside ordinary builds/CI.

This module adds50 checked public proofs: the unpublished local batch is
now518 public proofs in twenty-three modules. Direct/targeted Lean checks,
all14 namespace linters, ALL public standard-axiom checks and source hashes
are in docs/riesz-few-bin-cover-floor-audit.json. The exhaustive remaining
obstacle table is docs/zeta-riesz-few-bin-cover-floor.md. The whole floor,
ceiling, contradiction and new zero exclusion remain OPEN. Preserve all
prior no-gos and README/default explorer endpoints. Continue locally
without commits, pushes, subagents or wider publication gates.

### Fixed and growing populations share the current whole floor (local)

The STRONGEST current local ledger is now
`ZetaRieszJoinedPopulationFloor.eventually_joined_floor_combined_populations`.
The existing HighSignCoverFloor ledger already pays counts3,5,6 and7..55;
these are not fresh mathematical targets. Its balanced-triple refund and
fixed-band favorable credit must not be lost or spent twice when using
the new dense-count/few-bin payments. Accordingly dense56Band and bin56Band
are the original new populations restricted to count at least56.

The selected whole fibres preserve that lower count from the SAME original
seed. Every original count, physical, owner, allocation and radial mask,
canonical second-owner clip and both sign grids remains. Unmatched pieces
have the existing geometric bounds. The old fixed band and both new
populations are disjoint. The SAME quantitative supply retains
65/128-1/256-1/512=257/512. This fraction is a retained SUPPLY CREDIT,
not a numerical source-normalized floor constant. No new supply witness
or assumed signed arithmetic estimate is introduced.

The compiled exhaustive `remaining_configuration_cases` now says:
count FOUR, OR56<=omega(n)<5log(N+1)+2 with MORE than floor(log(N+1)/16)
occupied large-log canonical cofactor bins. Use this exact combined
remaining set(((E\Epaid)\dense56Band)\bin56Band), where
E=coreBand\tripleRestSpent, Epaid contains3,5,6,7..55. The earlier component
count3/4/6/7 enumeration remains true only for its earlier ledger.

All remaining floor obligations, in priority order:
(1) count four outside old spent selections, JOINTLY with its retained
    actual supply and head credits; no duplicate charge of count-four funding;
(2) many-bin growing counts with separated divisor windows: total weighted
    two-hinge tent cost, beyond the proved count-free pointwise bound;
(3) many-bin overlapping opposite parities: global matching distance,
    injective coverage and weighted imbalance/unmatched mass;
(4) unmatched one-parity layers: cross-label/count/owner-period SIGNED
    cancellation, since universal same-label matching is false;
(5) independently aggregate the real remainder and credits against
    -79/1000-o(1). Only then invoke the floor contradiction criterion.
The ceiling remains subsequent. Do not treat paid ownership clips or
source-o(1) analytic errors as anonymous new obstacles. Do not introduce
another representation unless it gives a provable signed inequality.

The optional current probe uses count58..65 integer-log MODELS satisfying
the new remaining count/bin inequalities. Exact subset polynomials show
strong mixed cancellation, while separated count57 responses can have
either sign. Shared-grid additive coincidences are not proved prime
correlations; these models certify no actual prime population, exact
moving integer length, original phase/factorial/allocation price, effective
start or numerical floor. They are outside ordinary builds and CI.

This consolidation adds18 public checked proofs; together with the preceding
few-bin payment the current unpublished batch has536 public proofs in
twenty-four modules. Focused direct/targeted/root-import checks, all14
namespace linters, ALL public standard-axiom audits and source hashes are
in docs/riesz-joined-population-floor-audit.json. See the exact remaining
obstacle table in docs/zeta-riesz-joined-population-floor.md. The numerical
whole floor, ceiling, contradiction and new zero exclusion remain OPEN.
Keep all prior results/no-gos and public README/default explorer endpoints.
Continue locally without commits, pushes, subagents or wider publication gates.

### Rejoined funding and separated divisor packing (local)

The latest request is to close floor estimates1–5 in turn. That request is
NOT completed: no independent numerical-79/1000 floor, multiplicity ceiling,
restricted contradiction or new zero exclusion has been proved. Continue
locally without commits, pushes, subagents or wider publication gates.

`ZetaRieszRejoinedPopulationFloor.eventually_joined_floor_rejoined_populations`
combines the existing SharpSupply/WholeFixedCount/RejoinedSupply alternative
with BOTH new growing-population payments, using the SAME four-prime
funding witness. The whole original fixed band3..55 includes count four.
Its funding supply/head labels remain in that actual signed aggregate;
they are never credited twice. The exact additional charge is
`growingDebit kappa N = (unpaidCountSupplyPrice N + intermediateSupplyPrice N)
/(128*kappa)`. The remaining debit is
`tailCost c N + fixedEpsilon + growingDebit kappa N`. Its N-dependent
components tend to zero RELATIVELY. The older257/512-credit ledger remains
available; the two inequalities are not asserted to dominate each other.

In THIS additional ledger, every nonzero remaining label has
56<=omega(n)<5log(N+1)+2 and MORE than floor(log(N+1)/16) occupied bins
of the canonical cofactor above the original bin head. There is no separate
count-four label remainder, but estimate1 is NOT closed at source scale:
the actual funding debit still needs joint compensation. Preserve the
existing GlobalDebitAudit theorem proving that even the N^-4 tail debit
of admissible actual supplies is unbounded at source scale. Fixed epsilon
may not be replaced by an arbitrary moving epsilon; relative price decay
may not be called an absolute floor or source-o(1) payment.

`ZetaRieszSeparatedPackingFloor.divisor_log_gap_packing` gives
`(2^omega(B)-1)*log R <= log B` for separated background divisors, with
R the canonical least-prime pair and B its original cofactor complement.
Both Riesz hinges, every Mobius rank, original phase/allocation and both
old zero deletions are joined first. The additional signed packing floor
costs `abs(Re w)*log B/(2^omega(B)-1)`. The old two-tent-height bound remains
available and may be sharper in other geometries. The exact original
count identity is omega(n)=omega(B)+3, so the current count56+ background
has at least53 primes. This gives a coefficient price below10^-15 of the
actual weighted background log, NOT an absolute population bound.

`source_scaled_current_separated_floor` applies that price DIRECTLY to
the original residual-coefficient packet, with the SINGLE established
geometric nonowner error. Its whole actual weighted population still
needs an independent source-scale payment. Estimates2–5 remain open:
separated population price; overlapping weighted transport/coverage;
cross-label/prime-period cancellation of unmatched parity; final numeric
aggregate. Do not claim closure from the tiny local packing coefficient.

The optional rejoined-estimates probe evaluates the already-proved actual
tail-debit lower bound and tests multiscale one-parity MODELS satisfying
the remaining count/bin inequalities. Fifty-nine-factor, twelve-bin
models have signed/unsigned response ratio one in either real common-phase
direction. These are NOT actual prime labels, exact integer moving length,
factorial/allocation population estimates or counterexamples to a whole
floor. Many bins alone are not evidence of automatic active parity mixing.
The probe stays outside ordinary builds and CI.

These two modules add16 public proofs to the prior536-proof local batch.
Focused direct/targeted/root-import compilation, both14-linter namespace
audits, ALL public standard-axiom checks and source hashes are recorded in
docs/riesz-rejoined-population-floor-audit.json and
docs/riesz-separated-packing-floor-audit.json. The exact scope and status
table is docs/zeta-riesz-rejoined-population-floor.md. Preserve every older
positive result/no-go and README/public default explorer endpoints.

### Moving-rank packing budget audit (local)

The user request to close floor estimates1–5 remains uncompleted. The
independent numerical floor is OPEN. Four additional public proofs in
`ZetaRieszSeparatedPackingFloor` audit the common positive period payment:
on `1<=rank(N)<=5log(N+1)+2`, `2^rank<=4(N+1)^4`, so
`1/(2^rank-1)>=1/[4(N+1)^4]`. The canonical current background derives
this rank from the original squarefree count56+ label. Its source-scaled
common period envelope tends to positive infinity for every fixed u>1/2,
y>=54, even with moving rank. This is NOT a lower bound for the actual
weighted separated population or a counterexample to the whole floor.
Do not pay estimate2 by replacing that population with periodUnits and
then cite its small packing coefficient as a source-scale saving.

The optional probe evaluates the strongest remaining rank
`rank<5log(N+1)-1`: the positive-envelope lower-bound formula regrows
from about10^-18.73 at N=100000 to10^15.74 at N=1000000. Neither quantity
is an actual signed carrier value. The fixed-count funding debit still
requires joint signed compensation; global weighted transport and
cross-label/prime-period cancellation of unmatched layers remain OPEN.

The smooth-owner discrepancy theorem covers only complete shells with
owner larger than the full cofactor and retains its signed main. Current
count/bin/physical masks are not paid by it. The squarefree zero-extension
absolute variation obstruction also survives rectangle removal. Do not
reuse either comparison as a whole-floor proof. The latest focused
packing audit covers15 public proofs and brings the local batch of26 modules to556
public proofs, with no numerical floor/ceiling or new zero exclusion.
Preserve prior results/no-gos, public endpoints and local-only workflow.

### Literal masked-carrier comparison (local)

`ZetaRieszLongCutoffError` derives a new unconditional comparison for
the actual masked carrier; the numerical-79/1000 floor and estimates1–5
remain OPEN. The signed squarefree prefix now has error
`C X^(3/4) D^(5/16)`, hence `C X^(63/64)` when `D^4<=X^3`.
The original core proves this range for the translated hinge, including
every active jump of its literal owner column at N>=32.

Centering against `rho=SquarefreeCounting.density(empty)>0` puts the
squarefree indicator inside BOTH arithmetic reference sums. The exact
`beforeSquares_eq_literal` bridge excludes repeated owners and retains
all original masks. Squarefree holes do not enter this new variation
cost. No count/owner/physical support is completed. The terminal
`literal_joined_carrier_estimate` assembles ALL counts, owners and both
hinges: `abs(rho*J-M)<=3*C*exp(-N/128)*V`, where M keeps the
untranslated Riesz hinge and the signed density-profile scalar together,
and V is the displayed total variation BEFORE squarefree holes. The
remaining owner/count/cutoff/allocation variation and signed main are
NOT paid at source scale. Do not call the exponential prefactor alone
a masked-error payment or a floor; preserve all earlier envelope no-gos.

The stronger follow-up `literal_whole_carrier_estimate` also puts
repeated-owner holes inside the reference measure. Its variation uses
RAW `maskedWeight(ownerRows B)`, with neither squarefree nor repeated-owner
zero extensions. The exact ratio `(p+1)/p` restores a common density;
the terminal bound is `abs(rho*J-Mhat)<=6*C*exp(-N/128)*Vraw`, with the
displayed additional hinge factor `(2+c_positive)*c_positive`. Mhat keeps
the untranslated hinge and the owner-conditioned signed scalar joined.
The remaining count/canonical-owner/physical/radial/allocation/phase
variation and signed main are still UNPAID. None of estimates1–5 is closed.

Finite prime exclusions can also enter the measure exactly. For excluded
primes through N² the cost is `exp(O(N^(17/32)))`, and its comparison
prefactor is eventually `<=exp(-N/256)`. This is NOT a payment of actual
variation or the excluded population. The whole original core does NOT
require all primes>N²; F empty in the general theorem gives the whole
squarefree carrier. Preserve this scope and all prior no-go results.
The optional `probe_riesz_long_cutoff_cost.py` evaluates only this rate
prefactor and is outside ordinary CI. Do not count it as a floor certificate.

Its 39 public proofs pass focused warning-as-error direct/targeted/root
checks,14 namespace linters and all public standard-axiom audits. See
docs/zeta-riesz-long-cutoff-error.md and
docs/riesz-long-cutoff-error-audit.json. The local batch is now27 modules
and 595 public proofs. Keep public README/default explorer endpoints
unchanged and continue locally without commits, pushes, subagents or
wider publication checks.

### Whole-core owner payment and current publication

`ZetaRieszCoreOwnerPayment` adds18 checked public proofs. The accumulated
batch now has28 modules and613 public theorem records. It pays the actual
source-normalized norm, with arbitrary bounded complex submasks, of every
core label having an eligible prime share at least751/1250=60.08%. The
previous refined threshold was601/1000=60.1%. The exact missing binomial
mass is at most(9/4)exp(-1033N/10000000), using tilt103/100; the tighter
summable reference exponent1+1/1048576 yields an allowance proportional
toexp(-N/1000000). Its arithmetic mass constant and effective start are
unevaluated. This is a true source-o(1) payment across ALL counts, phases
and correlated masks, not a relative price or percentage of the floor gap.

`eventually_rejoined_floor_without_large_owners` applies it to the SAME
existing signed ledger, preserving every credit/debit and funding witness.
The nonzero remaining labels have count56..<5log(N+1)+2, more than
floor(log(N+1)/16) occupied cofactor bins, and EVERY prime share below
60.08%. All five final arithmetic estimates and the numerical floor,
ceiling, contradiction and new zero exclusion remain OPEN. See
docs/zeta-riesz-core-owner-payment.md and its full18-proof audit.

The latest user request authorizes committing and pushing ALL accumulated
floor work after this slice. It supersedes the local-only holds above for
this publication. Complete the tracked hook, compiled status, explorers,
actual browser preview and GitHub README renderer checks; push the passing
commit and track its exact-SHA CI. No subagents are authorized. After
publication continue the floor locally while CI runs. The user explicitly
asks for a mechanism shared across counts/share geometries/periods: do not
return to threshold tuning or call a positive local price a global payment.

### Additional whole-core owner payment (local)

`ZetaRieszSharpOwnerPayment` pays the additional original core owner-share
strip `60069/100000 <= largestShare < 751/1250`. Its nine public theorems pass
focused warnings-as-errors compilation, ordinary root-import validation,
all 14 namespace linters and transitive axiom checks (only `propext`,
`Classical.choice`, `Quot.sound`). Every count, bin, phase, physical/allocation
mask and bounded complex correlated submask is retained. This is a small
actual source-o(1) population payment, not a fraction of the global deficit
or a new signed cancellation estimate.

The exact missing factorial mass is bounded by `(9/4)exp(-10013N/100000000)`.
The fixed summable reference exponent `1+1/134217728` leaves the absolute
source-scale allowance
`(9/4)*radiusCeiling*exp(-N/10000000)*zetaMoebiusLogMajorantMass(referenceExponent)`.
Its arithmetic mass constant and effective numerical start are unevaluated.
`eventually_rejoined_floor` spends this allowance on the SAME complete
funded ledger with the original credits, funding witness and debit;
no supply credit is reused. The old stronger rate stays available on the
old sector. Every remaining prime share is now below `60069/100000`.
This does not assert that cropping labels decreases the joined phase
energy or its one-sided price; those costs retain all funding correlations.

The many-bin question still requires a joint arithmetic estimate, not
threshold tuning. Occupied deletion bins reconstruct the same signed
two-hinge response, so they are not independent columns. Even a fixed
contraction per `O(log N)` bins is only polynomial and cannot defeat `(2u)^N`.
Keep the signed cross-label/count/period/funding correlations upstream of
any L² price. No whole-floor constant, ceiling, contradiction or new zero
exclusion is proved. See docs/riesz-sharp-owner-payment-audit.json.
Continue locally without commits, subagents or wider publication gates;
the public endpoints and every previous positive result/no-go remain.
New local modules are assigned to the shared arithmetic family; generated
publication assets are deferred to the next authorized publication.

### Signed cutoff periods and exact null profiles (local)

`ZetaRieszCutoffPeriodFloor` proves a direct lower inequality on the SAME
whole funded carrier after every label/count/period and funding coefficient
has been joined. It groups complete signed cutoff increments before adverse
clipping. The exact price saving is half the variation cancelled inside
groups; groupedCost is uniformly at most the former negativeCost for the
SAME weights and profile. No source-scale bound on this price is inferred.

Both logarithmic and squared-log divisor moments vanish on all selected
squarefree count3+ labels, including funding labels. Arbitrary coefficients
of these null moments change only the profile, never the original carrier.
The unit logarithmic correction with zero quadratic term is EXACTLY flat
below L: all cutoffs with log(k+1)<=L are inactive. Thus the previous
coherent first/rough-prefix cost need not be charged. This does NOT make
post-hinge cost small or imply that changing profiles monotonically reduces
the price. The signed post-hinge/funding correlation remains UNPAID.

eventually_joined_period_floor retains the SAME funding witness, the old
global positive-part credits, tailCost+epsilon+growingDebit, and original
source-o(1) error. Epsilon is FIXED under the existing quantifiers, not a
new epsilon_N sequence. Its17 public proofs pass scoped direct/targeted
Lean, ordinary root imports,14 namespace linters and standard-axiom checks.
The optional actual-integer probe uses only orders4..6 and L=11N/8; it is
not the native count56+ support, physical prime masks or funding witness.
No additional population is paid, fixed power saving or79/1000 floor is
proved. See docs/riesz-cutoff-period-floor-audit.json. Keep local, preserve
all earlier results/no-gos and public endpoints, and defer wider gates.

### Actual post-hinge cross-label correlation audit (local)

`ZetaRieszManyBinCorrelationAudit` tests the EXISTING sharp-prefix energy
after the early cutoffs have been removed. Exact prime insertion gives
sharp(k,p*a)=sharp(k,a)-sharp(floor(k/p),a). A canonical owner extension
preserves the literal cofactor and every occupied-bin restriction. Owner
primes in one quotient cell therefore have identical actual prefix columns
even for an arbitrarily prescribed many-bin cofactor. Their full signed
phase/allocation/funding weights stay in the common moment sum_p w(p*a).
phaseEnergy_owner_cell_lower and diagonal_coefficient_owner_cell_lower
retain this coherent contribution at a genuine post-hinge active cutoff.
The energy lower bound is for that SAME fibre only. Other cofactors may
cancel it after joining; cropping the full carrier does not give an energy
lower bound or monotonic price comparison.

This is an obstruction to automatic diagonalization valid for arbitrary
weights, NOT a native many-bin arithmetic counterexample or a refutation
of a bound for the actual carrier. Occupancy provides neither weighted
anti-concentration nor different total-log frequencies. The earlier rate
audit also remains: a fixed discount per O(log N) bins is only polynomial.

The optional actual-integer post-hinge probe uses orders4..6 and the same
test length11N/8. Signed off-diagonal energy is negative in5 of9 cases,
but positive in4; joint/diagonal energy ranges from0.2151 to4.5001.
An actual common-cofactor example p=907,911, a=210, k=5500 has sharp=1
on both labels inside the test radial/owner window and same-sign phase.
It has count5 and does NOT satisfy the native physical/many-bin masks.
No percentage of the asymptotic floor gap, funding credit, exponential
saving or population payment follows from either diagnostic. The7 public
proofs pass scoped Lean/root/lint/standard-axiom checks. See
docs/riesz-many-bin-correlation-audit.json. The next useful estimate must
bound the actual signed POST-hinge cross-cofactor/count/funding aggregate;
all five final arithmetic estimates and the whole floor remain OPEN.
Keep local without commits, subagents or wider publication gates.

### Many-bin joint-energy rate test (local)

`ZetaRieszManyBinRateAudit` strengthens the automatic-discount no-go:
for every fixed u>1/2 and constants A,B,
exp(-A log(N+1)^2-B log(N+1))*(2u)^N tends to positive infinity,
also along the ORIGINAL dyadicMomentOrder sequence. An inverse N^c
discount PER occupied bin is therefore still insufficient for that
positive envelope, even after any fixed polynomial denominator. The
specialization uses the actual cofactorBins definition and its existing
physical prime-log bound. This is NOT a lower bound for the signed carrier
or a no-go for a joint arithmetic cancellation theorem.

The exact existing phaseEnergy is D+C, where D retains its diagonal
label terms and C retains EVERY signed off-diagonal term, original phase,
mask and funding coefficient. energy_saving_iff_cross proves
E<=r*D iff C<=-(1-r)*D. Starting from poly(N)*(2u)^N, an L2-relative
payment needs an energy-ratio exponent exceeding 2log(2u), up to polynomial
factors. At the outer radius, 1/10001<=log(2u)<=1/10000. This is a rate
test for that envelope, NOT an assertion about the actual diagonal growth.

The optional rates/reference-Gram probe is outside ordinary CI. Its exact
rational diagonalization checks through 64 and floating complete reference
Möbius-lcm sum through 100000 are NOT the native count56+ masked population
or funding witness. The floating 5.78-million-order crossover is not an
interval certificate. The primary Ramaré–Zuniga-Alterman constant Gram
bounds are documented with their original scope; they are not imported
as a Lean arithmetic input or a carrier power saving.

No new source-scale population, independent signed estimate, numerical
floor, ceiling or zero exclusion is proved. The next useful bound must
control the whole POST-hinge weighted cross-cofactor/count/funding sum,
or its complete signed cutoff periods, without treating occupancy as
weighted dispersion. Nine public proofs receive scoped direct/targeted
Lean, ordinary-root import, namespace lint and standard-axiom audits;
see docs/riesz-many-bin-rate-audit.json. Keep all prior no-gos, public
endpoints and local-only workflow; no commits/subagents/wider gates.

### Literal inner-hinge cross-count transport (local)

`ZetaRieszInnerHingeTransport` proves an actual finite signed pair floor
on the original arithmetic atoms. On its exact inner-hinge geometry,
the coefficient is mu(b) times one linear cutoff at every composite
cofactor count. Replacing owner p by actual primes p',r flips parity:
the pair equals mu(b)*(tau*W-tau'*W'), with both ORIGINAL allocations,
full phases and arbitrary signed funding multipliers retained. The price
is the joined difference, not a2^count divisor allowance. The cutoff and
total-log gap is exactly log(p'*r)-log(p). The identity requires the
stated genuine primes; it proves no existence of native admissible partners.

The disjoint-matching lower inequality keeps all unmatched original
labels SIGNED and spends each pair once. A global application still needs
valid partner capacity, the actual total allocation/funding mismatch,
and the signed unmatched/supply bound. Many-bin occupancy supplies none
of these automatically; no global payment or floor is claimed. Seven
public proofs pass scoped Lean/root/lint/standard-axiom checks. See
docs/riesz-inner-hinge-transport-audit.json and
docs/zeta-riesz-inner-hinge-transport.md.

The optional probe checks finite actual integer count4/5..12/13 pairs,
native moving length and allocation, with pair/separate norms about
0.00084..0.04493 for equal funding. Reversing a funding sign removes that
cancellation. Its inserted small primes FAIL the OLD fixed parity packet's
rough-prime mask, not the current whole core's mask. The core imposes an
upper physical cutoff; N^2 controls allocation eligibility. Small primes
are not thereby forbidden. The probe does not certify unpaid count56+
many-bin membership, native dyadic support or the original funding witness.
No finite percentage is an asymptotic floor saving. Keep local without
commits/subagents/wider gates and preserve all earlier results/endpoints.

### Signed owner-allocation pair floor (local)

`ZetaRieszOwnerPairFloor` keeps the allocation change signed until two
original opposite-parity atoms have been joined. On cofactor shares
x>=3/8, the actual lower factorial tail is <=2 exp(-N/25), and the owner
weight is increasing up to that error. Every owner left by the current
SharpOwnerPayment crop has cofactor share >3/8. Shrinking the owner while
inserting a positive cofactor factor increases that share; an inserted
prime below binHead preserves every occupied cofactor bin exactly.
`manybin_owner_eligible` proves that any occupied cofactor bin makes the
canonical owner eligible for the original allocation on central labels.

For a negative ORIGINAL weighted first atom F and ordered shares, the
pair floor is -norm(F+G)-2 exp(-N/25) norm(F). Both original complex phases
and signed funding coefficients remain in F,G. This replaces an absolute
allocation-difference charge with one exponentially small lower-tail price.
Globally that price is <=2 radiusCeiling B exp(-N/50) times the finite
majorant mass at1+1/262144. The original rejoined funding coefficients are
eventually bounded by B=4+abs(epsilon), with epsilon FIXED and every overlap
retained. A relative supply-debit limit is NOT a bound on the supply charge.

`matching_original_floor` applies to the WHOLE ORIGINAL signed carrier.
It reuses the existing nonowner error once on matched labels; it keeps
the ORIGINAL signed unmatched sum. Matching disjointness, native support,
owner eligibility, share ordering and negative-first orientation are
explicit hypotheses. No new admissible matching or global bound for the
joined pair gaps/unmatched/supply terms is proved. This pays one error
component geometrically across counts/periods, not a new whole population
or the floor. Do not infer coverage or weighted L2 dispersion from bins.
The finite probe's count4/5..12/13 tests are diagnostics, not native
count56+ or dyadic/funding certificates. See docs/zeta-riesz-owner-pair-floor.md
and docs/riesz-owner-pair-floor-audit.json. Continue locally without commits,
subagents or wider gates; retain all previous audits and public endpoints.

### Total literal inner-hinge matching cost (local)

`ZetaRieszInnerHingeGapPayment` proves a count-free coupled log-gap price
for opposite-Moebius-sign original inner-hinge atoms, with BOTH complex
phases subtracted before taking a norm. It covers owner replacement and
cofactor prime splitting, including cofactors already containing2. Every
actual primality, coprimality, squarefree and InnerHinge condition remains
explicit; many-bin occupancy does not imply this support or partner existence.

For any disjoint same-funded matching with actual log gaps<=exp(-N/1000),
matched labels<=Q, logQ<=3(N+1), L>=1 and norm(original w)<=B,
`global_literal_gap_cost` proves the TOTAL source-scaled joined mismatch
<=168 radiusCeiling B(1+abs(y))(N+1)^3 exp(-N/1250) at the unchanged radius.
There is no count/bin multiplier. The price tends to zero for fixed B,y.
`replacement_interval_log_gap` only converts an ACTUAL prime-replacement
interval into the needed gap; it proves no short-interval prime theorem.
`integer_log_gap_lower` proves that distinct positive local integer factors
have gap>=1/max(a,b), so the target forces log(max(a,b))>=N/1000. Occupied
bins do not imply this linearly large log span for a single replacement.
Do not claim a one-prime split uniformly covers sublinear-log configurations;
larger-block parity replacements still need literal masks and capacity.

`matching_original_floor_of_small_gaps` applies this to the WHOLE ORIGINAL
residual sum, retaining its ORIGINAL signed unmatched contribution. It
reuses the prior exp(-N/50) lower-allocation-tail and global nonowner payment
once. Original owner eligibility, ordered shares and negative-first
orientation are required. The eventual original funding envelope4+abs(epsilon)
does not prove partner funding equality; preserve the SAME fixed epsilon
and every credit/debit overlap. No native matching coverage, independent
signed unmatched/supply bound, new whole population payment or floor is proved.

The optional small-count disjoint-pair probe shows a real capacity issue:
no single insertion prime supplies enough partners in its negative-first
owner cells, while joining insertion primes does in those examples.
Cofactor splitting with common primes2,3,5,7,11 leaves unmatched monotone
boundaries despite excess total partner cardinality (106/111 and24/27).
These are finite floating diagnostics, not native count56+ many-bin/funding
or asymptotic coverage certificates. See docs/zeta-riesz-inner-hinge-gap-payment.md
and docs/riesz-inner-hinge-gap-payment-audit.json. Thirteen public proofs pass
focused Lean/root/lint/standard-axiom checks. Continue locally without commits,
subagents or wider gates, preserving all previous results and public endpoints.

### Fixed-owner joint pair cost without ordering (local)

`ZetaRieszFixedOwnerPairFloor` pays the allocation DIFFERENCE on any
literal opposite-parity inner-hinge pair with the SAME actual largest
prime. The exact original owner weight is 2(N+1)-Lipschitz on [0,1];
fixed-owner shares differ by at most the actual total-log gap. Both
phases are joined first. No ordered-share, negative-first or3/8-share
restriction is needed for this fixed-owner estimate. All original
factorial orders and both endpoints remain. Preserve the old moving-owner
theorem and its hypotheses.

For every disjoint matching satisfying the displayed literal geometry,
original equal funding, norm(w)<=B and gaps<=exp(-N/1000),
`global_fixed_owner_cost` bounds the TOTAL owner-only matched norm by
[168 radiusCeiling B(1+abs(y))+2 radiusCeiling B M(1+1/262144)]
(N+1)^3 exp(-N/1250). The positive majorant is used only AFTER the
actual exponential gap has been included. `matching_original_signed_error`
removes this matching from the WHOLE ORIGINAL signed sum, adding the
existing global nonowner cost ONCE; the signed unmatched sum is unchanged.
This controls both real directions, but constructs no native matching.

The optional unordered fixed-owner probe covers111/111 and27/27 earlier
finite parents, replacing old ordered coverage106/111 and24/27. Ten
pooled cofactor families retain300/300 and93/93 coverage AFTER deduplicating
424 partner incidences to376 labels and121 to109. These low-count finite
tests have test funding1 and no native count56+ many-bin/dyadic/funding
certificate. Do not infer cofinal coverage, signed unmatched/supply control
or a numerical floor from them. Seven public proofs pass focused
Lean/root/lint/standard-axiom checks. See
docs/zeta-riesz-fixed-owner-pair-floor.md and
docs/riesz-fixed-owner-pair-floor-audit.json. The whole floor and ceiling
remain OPEN. Continue locally without commits, subagents or wider gates;
retain every prior result, negative audit and public endpoint.

### Balanced inner-hinge cells and the signed period imbalance (local)

`ZetaRieszSignedCellFloor` pays the complete balanced variation of actual
inner-hinge cells without an opposite-parity partner or matching-capacity
assumption. Each reference is an ACTUAL admitted label with the same
canonical owner and second prime. All cofactor counts can mix. Equal
`logCell` indices supply the actual exp(-N/1000) gap without any prime-count
or continuum-transport premise. References can repeat: their repeated
norms are not multiplied by the cell cardinality in the error bound.

`original_cell_error` has the explicit matchingBudget geometric price,
including the previous global nonowner error ONCE. `sum_cofactor_cells`
retains each actual sum of mu(b) with the reference's full complex phase
and owner allocation. `floor_after_cells` places these signed imbalances,
the untouched original population and SAME supply debit in the native
whole-floor comparison. It does not bound the imbalance, assert native
cell balance, pay a whole new population or prove the -79/1000 floor.

The optional complete-period probe factors all integer cofactors in its
test intervals and retains all observed counts, rounded L, full original
allocation and phase. Order80 tests at heights54/65/100 have joint/period
diagonal energy3.0521/3.9373/4.7809, so cross-period covariance reinforces.
These finite labels have ZERO above-head bins and fail the native eventual
length hypothesis: they are not count56+ many-bin, dyadic/funding or
asymptotic counterexamples. Floats/large-prime tests are not certificates.

The Matomäki--Radziwiłł factorization method and Menon's2026 refinement
provide averaged/logarithmic savings, not the required fixed-height masked
source estimate. Do not treat occupancy as weighted dispersion, automatic
orthogonality or a fixed power saving. The remaining arithmetic target is
the joined signed cell-imbalance/non-inner-hinge/supply sum. See
`docs/zeta-riesz-signed-cell-floor.md` and its focused nine-proof audit.
Preserve every previous no-go, README and public endpoint. Continue locally
without commits, subagents or wider publication checks.

### Actual whole-floor diagonal is geometrically paid (local)

`ZetaRieszDiagonalPayment` proves an exponential bound for the diagonal
of the EXISTING sharp-prefix energy across all actual counts/bins/phases.
Full original allocation, phase and funding coefficients remain in w.
On literalWindow with |q|<=B, L>=1, u<=radiusCeiling and logX<=3(N+1),
`weighted_diagonal_bound` gives
D<=16*radiusCeiling^2*B^2*M(3/2)*(N+1)^3*exp(-3N/4).
The actual reciprocal-square label weight and the fixed summable
divisor-square mass pay this component; no many-bin orthogonality is
assumed. M(3/2) is finite but not numerically evaluated in this slice.

`weighted_diagonal_price` pays sqrt(D*profileEnergy) by
8*radiusCeiling*B*sqrt(M(3/2))*(N+1)^2*exp(-3N/8)->0.
`adverse_crossCost_le` proves removing only the diagonal never enlarges
the existing adverse-prefix cost; the reverse comparison differs by
at most this geometric price. Favorable COMPLETE cutoff increments
remain uncharged; adverse selection is AFTER joining funded labels.
No count/bin/period cross term is priced separately.

`eventually_joined_cross_floor` retains the native unpaid/paid/radial
sets, ALL overlaps, SAME positive supply witness and debit
tailCost+epsilon+growingDebit. It proves the whole-floor lower bound
-sqrt(max(adverseCrossEnergy,0)*adverseProfileEnergy)-err, err->0,
including diagonalPrice(4+abs epsilon,N) once. The independent numerical
bound on that WHOLE signed cross cost remains OPEN. Enough is <=79/1000
cofinally with vanishing slack. Do NOT require near-total negative
covariance relative to the tiny diagonal, or call this a paid new
population / proved whole floor. This does not invalidate the earlier
rate audit of polynomial discounts on the positive L1 envelope.

The optional actual-integer adverse-cross probe at orders4..7, heights
54/65/100 finds7 positive and5 negative aggregates, with reinforcing
and canceling period terms. It uses L=11N/8 and lacks native physical,
moving-length, many-bin and funding certification. These float tests
are not cofinal evidence or interval certificates; keep them out of CI.
Fifteen public proofs have focused Lean/root/lint/standard-axiom checks
recorded in docs/riesz-diagonal-payment-audit.json; details in
docs/zeta-riesz-diagonal-payment.md. Preserve all previous no-gos and
published endpoints. Continue locally without commits, subagents or
wider publication gates.

### Actual large shared-factor cross pairs are geometrically paid (local)

`ZetaRieszSharedFactorPayment` pays ALL actual adverse ordered cross
pairs with log(gcd(n,m))>N/1000, across every native count/bin/phase and
funding overlap. The exact common-factor convolution and squarefree
divided labels give reciprocal-pair mass
exp(2logX/262144)*M(1+1/262144)^2*exp(-N/2000)*M(3/2).
No prime-density/short-interval count or bin orthogonality is assumed.

`weighted_largeShared_bound` gives
|largeSharedEnergy|<=sharedConstant(B)*(N+1)^3*exp(-N/4000),
sharedConstant=16*radiusCeiling^2*B^2*M(1+1/262144)^2*M(3/2)*exp(6/262144).
`weighted_shared_price` pays sqrt(abs(largeSharedEnergy)*adverseProfileEnergy)
by sqrt(4*sharedConstant(B))*(N+1)^2*exp(-N/8000)->0. The fixed masses
are finite but unevaluated; no effective starting order is asserted.

The exact partition retains the ORIGINAL adverse cutoff selection,
all smaller-gcd signs, phase/allocation and original physical/count
support. Do NOT reselect adverse cutoffs separately on the partitions.
`eventually_joined_small_shared_floor` adds sharedPrice(4+abs epsilon,N)
ONCE to the previous errors. It keeps SAME supply witness/debit and
ALL funded overlaps. The remaining actual signed smallSharedEnergy
cost still needs <=79/1000+o(1); the whole floor/ceiling remain OPEN.

`common_cofactor_large` and `cropped_cofactor_large` put every coherent
same-cofactor owner pair in the paid partition after the actual owner
crop and original radial window, at every count/bin pattern. Sparsity
and reciprocal weights pay them; their prefix columns remain coherent,
so the arbitrary-weight operator no-gos are NOT invalidated. This is
payment of a cross-correlation family, not a new whole label population.

The optional complete integer/Gram probe at orders4/5, heights54/65/100
finds4 positive and2 negative smaller-gcd aggregates. These tiny-order
remaining pairs are coprime; same-cofactor terms are negative. Removing
paid shared pairs can increase a finite cost; do NOT assert monotonic
improvement. Native moving-length, physical, many-bin, dyadic and supply
certification are absent. Float tests are diagnostic only and outside CI.
Twelve public proofs pass focused Lean/root/lint/standard-axiom checks.
See docs/zeta-riesz-shared-factor-payment.md and its audit. Preserve
all previous results/no-gos/public endpoints and continue locally without
commits, subagents or wider publication gates.

### Nearby actual-label cross correlations are geometrically paid (local)

`ZetaRieszNearLabelPayment` pays all remaining smaller-gcd cross pairs
with |n-m|<=exp(-N/1000)*min(n,m), across every native count/bin/phase.
The exact symmetric-incidence capacity bound gives each actual label n
at most2*epsilon*n distinct neighbours, with no prime-interval premise.
Reciprocal divisor weights then give pair mass
2*epsilon*exp(logX/262144)*M(1+1/262144). This is a common counting
principle across all configurations, not another count-specific estimate.

`weighted_nearEnergy_bound` proves
|nearEnergy|<=nearConstant(B)*(N+1)^3*exp(-N/2000),
nearConstant=32*radiusCeiling^2*B^2*M(1+1/262144)*exp(3/262144).
The squared source growth is included. `weighted_near_price` pays its
cost by sqrt(4*nearConstant(B))*(N+1)^2*exp(-N/4000)->0.
The fixed convergent mass is unevaluated; no finite starting N is claimed.

`smallSharedEnergy_eq` and `eventually_joined_separated_floor` preserve
the ORIGINAL whole funded adverse selection, phases/allocation/support,
all funding overlaps, SAME positive supply witness and debit. Diagonal
and large-gcd errors remain; nearPrice(4+abs epsilon,N) is spent ONCE.
No adverse cutoff is reselected after partitioning. Removing a negative
family can increase the finite remaining cost; do not assert monotonicity.

The one remaining complete signed cross sum has log(gcd)<=N/1000 and
relative distance>exp(-N/1000). `separated_log_gap` gives
|log n-log m|>exp(-N/1000)/2; this DECREASING gap is not fixed-height
orthogonality. Its source cost <=79/1000+o(1) remains OPEN. Do not add
the old257/512 supply credit: the full fixed-count sum already includes
the same supply, and rejoined_supply_sum spends it exactly once.

The optional complete integer/Gram probe at orders4/5, heights54/65/100
checks capacities and signed partition. The literal exponential cutoff
includes all smaller-gcd pairs at these tiny orders. A separate rational
1/1000 cutoff is diagnostic ONLY and finds2 positive/4 negative separated
aggregates. These test labels lack native moving-length/physical/many-bin/
dyadic/funding certification. No asymptotic or interval claim follows.
Keep probes outside CI. Thirteen public proofs have focused Lean/root/
lint/standard-axiom checks in docs/riesz-near-label-payment-audit.json;
details in docs/zeta-riesz-near-label-payment.md. Whole floor/ceiling,
contradiction and new zero exclusion remain OPEN. Continue locally
without commits, subagents or wider publication gates; preserve every
previous result/no-go and public endpoint.

### Exact whole-floor post-hinge energy price (local)

`ZetaRieszPostHingeEnergy` bounds the actual unit-log-corrected profile
price by (logX-L)_+, retaining its partial hinge interval and zero endpoint.
Each literal nonpositive step obeys k*Delta_k^2<=-Delta_k; telescoping
gives the cap without an endpoint/harmonic allowance. The ORIGINAL adverse
subset keeps the same cap; no label/count/bin/phase energy is discarded.

The exact moving floor-dependent length obeys
L_N>=-2Nlogu-2log(N+1). For u<=10001/20000 and N>=65536, Lean proves
L_N>=277N/200. The actual cutoff supremum of EVERY core subset has
logX<=203N/100, so adverseProfileEnergy<=129N/200. This explicit threshold
certifies ONLY the profile component, not an effective arithmetic-floor
start or the unevaluated earlier geometric constants.

`eventually_joined_calibrated_floor` applies that price to the SAME whole
native funded carrier: floor>=-sqrt((129N/200)*max(separatedEnergy,0))-err,
err->0. Original support/phase/allocation, all funding overlaps, positive
supply witness, debit and earlier diagonal/shared/near errors remain ONCE.
The independent sufficient energy condition E<=3/(320(N+1)) is OPEN.
`cost_le_of_numeric_energy` and `real_floor_of_numeric_energy` show that
condition would give -39/500-o(1), strictly above -79/1000. Do NOT label
these conditional numerical endpoints an independent arithmetic bound.

This is a smaller whole-floor price, not an exponential cancellation
estimate, extra paid population or proof of automatic many-bin dispersion.
The complete remaining signed separated/smaller-gcd aggregate is unpaid.
The NEXT substantive slice must bound that actual signed energy or the
joint floor directly; do not spend another slice tuning its universal
profile price or adding a merely conditional energy premise.
Do not reselect adverse cutoffs after partitions or reuse the supply credit.
The optional native-length integer/Gram probe is outside CI, and lacks
count56+/physical/dyadic/funding certification. Earlier L=11N/8 common-mean
projection tests retained>99.5% energy and increased the finite cost in
all6 cases; this weak diagnostic was not made a proof mechanism.

Thirteen public proofs receive focused warnings-as-errors Lean/root import,
14 namespace linters and all-public standard-axiom audits. See
docs/zeta-riesz-post-hinge-energy.md and its audit. Preserve prior results,
no-gos, published endpoints and local-only work: no commits, pushes,
subagents or wider publication gates. The actual floor/ceiling remain OPEN.

### Actual all-period phase alignment is geometrically paid (local)

`ZetaRieszPhaseOrbitPayment` pays a further part of the SAME actual
separatedEnergy, across all prime counts, bins and radial periods.
The paid pairs have |log n-log m-2*pi*k/y|<=exp(-N/1000)/(1+abs y).
`phaseNear_of_resonance` proves the finite index union misses NO possible
phase period on the original finite label range. The window is exponential;
do NOT describe this as payment of a fixed/polynomial phase window.

The reciprocal row capacity is <=4*epsilon+exp(-l), including the actual
integer endpoint. It is independent of the multiplicative period position.
The symmetric reciprocal-capacity estimate gives a geometric saving
without prime density, count-wise norms or bin orthogonality. On the
existing literal support and logX<=3(N+1), weighted_orbitEnergy_bound gives
abs(orbitEnergy)<=C(B,y)*(N+1)^4*exp(-N/2000), including actual squared
source growth. C=80*radiusCeiling^2*B^2*(8*(ceil(abs y)+1)+1)*M(sigma)*
exp(3/262144), sigma=1+1/262144. It is finite but unevaluated, and depends
on FIXED y. The price sqrt(4C)*(N+1)^3*exp(-N/4000) tends to zero.

separatedEnergy_eq retains the ORIGINAL adverse cutoff selection on both
parts. The native eventual floor is now
-sqrt((129N/200)*max(nonOrbitEnergy,0))-err, err->0.
SAME supply witness, fixed epsilon, funding overlaps/debit and previous
diagonal/shared/near errors remain ONCE. Do not reselect adverse cutoffs
or spend a favorable count/supply a second time. The outside-band signed
aggregate, its independent 3/(320(N+1)) sufficient budget, final floor,
ceiling and zero exclusion remain OPEN. An exponentially decreasing phase
gap is not fixed-height orthogonality; do not infer nonOrbitEnergy<=0.
Removing negative paid pairs may increase a finite residual cost.

The optional actual-integer probe retains the exact moving cutoff, phase,
divisor columns and empty allocation at orders4/5. Native nearLabel already
includes every tested pair, so the nontrivial distance strip1/1000 is
explicitly diagnostic ONLY. All six diagnostic phase-band aggregates are
positive; outside-band aggregates are negative; two costs strictly improve
and four were already zero. These floats certify no native physical/count56+
many-bin/dyadic/funding or cofinal/interval result. Keep probes outside CI.
Seventeen public proofs have focused Lean/root/lint/standard-axiom checks
in docs/riesz-phase-orbit-payment-audit.json. Preserve every prior no-go,
public endpoint and local-only work; no commits/pushes/subagents/wider gates.

### Direct all-count floor without the auxiliary debit (local)

`ZetaRieszDirectPhaseFloor` applies the existing signed prefix estimate to
ORIGINAL coreResponse BEFORE count-tail cropping, positive-part credits or
funding. Every original count, phase, physical mask and allocation remains.
It pays the previous diagonal/large-gcd/near-label/phase-band families once
with B=1, then uses the existing geometric core/joined bridge. No new
physical carrier, supply choice, epsilon or relative debit enters.

For N>=65536, u>0, u<=10001/20000 and abs(y)>=3, joined_floor proves
Re(source*joinedPhysical)>=-sqrt((129N/200)*max(E_direct,0))-joinedError.
E_direct is nonOrbitEnergy of ALL original core labels with q=1, selected
adverse cutoffs ONCE before any pair split. joinedError consists only of the
four original geometric prices and the actual core/joined difference;
joinedError_bound bounds the latter by2*(19/20)^N*M(1+1/256).
tendsto_joinedError gives error->0, and eventually_joined_floor gives the
same comparison on the native dyadic schedule. No exposed zero is assumed.

This direct comparison preserves cancellation across the ENTIRE original
count tail. It spends none of the old positive-part/funding credits.
It removes the need to cancel an AUXILIARY debit in this estimate, not the
arithmetic obstruction or a new source-scale label population. The old
GlobalDebitAudit still applies to the funded route; it does NOT prove the
combined funded energy diverges. Do not assert E_direct<=E_funded.

The independent direct energy budget3/(320(N+1)), numerical -79/1000 floor,
ceiling and contradiction remain OPEN. No new numerical floor margin or
signed cancellation rate is certified. The NEXT substantive slice should
attack the combined original signed core or E_direct; do not add another
universal price calibration or merely conditional premise. The prior
funded witnesses/budgets remain valid but are DIFFERENT statements.

Nine public proofs receive scoped warnings-as-errors direct/targeted Lean,
ordinary-root import,14 namespace linters and all-public standard-axiom
checks. See docs/zeta-riesz-direct-phase-floor.md and its audit. The optional
native-order funding-debit formula probe computes no signed carrier/energy
and certifies no effective supply start; keep it outside builds/CI.
Preserve all earlier mathematical sources/no-gos and published endpoints.
Continue locally without commits, pushes, subagents or wider gates.

### Signed opposite-phase credit after all counts and cutoffs are joined (local)

`ZetaRieszAntiphaseCredit` fixes the SAME direct whole-core adverse set,
then sums its divisor Gram G(n,m) BEFORE selecting any credit. In the
already unpaid nonOrbit population, opposite total-label phases with
G>=0 give an explicit NONNEGATIVE reserve, subtracted from the whole cost.
All original counts/tails/physical/allocation/radial masks remain. No supply,
clipped count sum, owner completion or new physical carrier enters.

nonOrbitEnergy_eq_rest_sub_reserve_add_leakage proves EXACTLY
E_direct=signedRest-reserve+leakage. The reserve retains the signed joined
Gram and squared cosines; it is never norm-paid away. Its NATIVE SIZE is
not bounded below. Only the squared cosine mismatch is paid absolutely.
The finite odd-period union omits no pair in the original label range.

The logarithmic tolerance is exp(-N/10000)/(1+abs y), wider than the old
norm-paid phase band. Pair capacity supplies one width and the squared
phase mismatch supplies two. antiphase_source_rate certifies the combined
factor (2u)^(2(N+1))*exp((3/262144-3/10000)*N)
<=4*radiusCeiling^2*exp(-N/20000). Thus leakage<=C_y*(N+1)^4*exp(-N/20000)
and its price sqrt(4*C_y)*(N+1)^3*exp(-N/40000) tends to zero. The convergent
divisor mass is unevaluated; FIXED y and no effective starting N are claimed.

joined_floor/eventually_joined_floor now keep max(signedRest-reserve,0)
inside the native whole-floor price129N/200, with all prior direct errors
once plus leakagePrice. This is a new signed credit inequality, NOT a
numerical -79/1000 floor or a proof of monotonic improvement over the old
EXACT signed energy. That energy already retained all these signs.
The bound on the ACTUAL signedRest-reserve, sufficient budget3/(320(N+1)),
ceiling, contradiction and zero exclusion remain OPEN. Do not spend the
next slice calibrating this price, adding an assumed budget or asserting
occupancy forces a large reserve; attack the remaining joined signed cost.

The optional actual-integer probe at orders4/5, heights54/65/100 has positive
credit in all6 cases and5 smaller prices compared with DISCARDING that
credit. The sixth worsens under the crude leakage bound. All6 ORIGINAL
remaining energies were already negative; no old floor improvement or
native margin is measured. Original annulus/physical/dyadic/growing-count
conditions are absent, and the native near-label strip covers all tested
pairs. Its nonzero1/1000 distance strip is diagnostic ONLY. Keep floats
outside CI. See docs/zeta-riesz-antiphase-credit.md and its scoped audit.
Preserve prior sources/no-gos/public endpoints and staged semiprime files.
Continue locally without commits, pushes, subagents or wider gates.

### Native-mask reflected-phase diagnostic (local, no new floor theorem)

`scripts/probe_riesz_reflected_phase_gram.py` constructs tiny probable-prime
subsets at actual native orders256/640 and cutoffs8/16. Original masks,
physical length, allocation and phase are checked NUMERICALLY. Divisor
reflection passes273312 integer interval/label checks, independently of the
floating Riesz integral regression. The joined Gram includes whole-label
Moebius parity, but the reflected prefixes have either sign. Do not infer
Gram positivity, negativity or orthogonality from count parity alone.

Twelve cases show both positive-Gram antiphase and negative-Gram aligned
credits, with highly variable coverage; seven remaining energies are
positive and five negative. Complete log-period grouping saves<0.08% of
atomic adverse variation in eleven cases and about1.67% in one. These
are diagnostics, NOT a rigorous no-go for arithmetic cancellation or a
certified saving for the native whole floor. No new Lean proof or numerical
floor margin landed in this pass. See the antiphase note and
docs/riesz-reflected-phase-probe-audit.json.

The constructed subset selects ITS OWN entire adverse set, not the original
full-core adverse set. Amplitudes are rescaled for underflow; displayed
energies cannot be compared with3/(320(N+1)). No density/full population,
count56+/many-bin, eventualN>=65536, formal primality, interval or cofinal
bound is certified. Keep the probe optional and outside builds/CI. Do not
turn a second band credit or another regrouping identity into a claimed
global saving: the actual joined signed estimate remains OPEN.
Preserve all mathematical sources/public endpoints and staged semiprime
files. Continue locally without commits, pushes, subagents or wider gates.

### Sharper global count payment in the original whole floor (local)

`ZetaRieszSharperCountPayment` independently pays EVERY original selected
label with768*omega(n)>=K on the unchanged N=8(j+4)K, K=2^(j+3) schedule.
For j>=64, K*log K>=N/12 gives K^omega>=exp(N/9216). The literal finite
Euler count moment with q=499999/1000000 and sigma=1000001/1000000 pays
all share geometries, radial periods, phases and correlated coefficient
masks satisfying the existing factor-two majorant. Its Euler slack is
eventually<=exp(N/1000000). count_rate_bound is a rational/analytic
certificate for (radiusCeiling/q)*exp(-1/9216+1/1000000)<=exp(-1/200000).
The entire count allowance is(203/50)*radiusCeiling*(N+1)*exp(-N/200000).
No zero or cancellation hypothesis enters; NO effective starting order
or numerical value of the convergent count mass is claimed.

countCeiling=K/768+1 with integer division, asymptotically TWO-THIRDS of
the former K/512 endpoint. This measures the count interval, NOT a third
of the remaining carrier mass or floor deficit. The new geometric rate
is slower in exchange for paying more original labels. The exact existing
coreResponse_sub_count identity keeps all original masks and allocations;
nonsquarefree labels vanish exactly. No supply debit/favorable credit is
spent, no labels are completed, and no new physical carrier is introduced.

eventually_joined_floor bounds the ORIGINAL joinedPhysical at original K
using the complete signed nonOrbitEnergy on coreBand at countCeiling,
with error->0. The four original pair prices, original core/joined bridge
and new count payment occur ONCE. Do not assert E_small<=E_original: its
signed cross terms and actual adverse set differ. The actual complex
carrier difference is what is independently paid. All lower counts remain
joined with their original phase and weights. The signed budget3/(320(N+1)),
numerical -79/1000 floor, ceiling, contradiction and zero exclusion remain
OPEN. Next work should attack that remaining whole signed estimate.

Thirteen public proofs receive focused direct/targeted warnings-as-errors,
ordinary-root,14 namespace linter and standard-axiom checks. See
docs/zeta-riesz-sharper-count-payment.md and its scoped audit. Preserve all
earlier proofs/no-gos, published endpoints and staged semiprime files;
only the arithmetic moduleFamilies map is extended. Continue locally
without commits, pushes, subagents or wider publication gates.

### Negative joined Gram with aligned phase (local)

`ZetaRieszAlignedNegativeCredit` supplies the complementary branch to the
old positive-Gram/antiphase credit. The SAME actual adverse cutoff set is
selected once on the entire remaining core, then its complete signed Gram
is joined. Negative Gram at aligned total-label phase gives an exact
negative reserve plus squared mismatch. All even periods use log-width
exp(-N/10000)/(1+abs(y)), outside the already paid thinner band. The two
credits are disjoint by Gram sign, not prime-count parity.

`aligned_contribution_upper_bound` independently bounds the entire literal
branch ABOVE by C_y*(N+1)^4*exp(-N/20000). This is one-sided, NOT a norm
payment or a native lower bound for the reserve. Only its squared mismatch
is bounded absolutely; both negative reserves stay signed. The whole floor
comparison targets ORIGINAL joinedPhysical at ORIGINAL K, using the actual
remaining core below K/768+1. All earlier paid costs occur once, with two
additional leakagePrice terms tending to zero at fixed height.

Crucially, `combinedMain_eq_previous_sub_leakage` proves that the combined
main equals the PREVIOUS signed main minus alignedLeakage. Its previous
negative interactions were already retained. The reverse comparison pays
only that geometric mismatch. Thus a second band credit is NOT a free
global energy saving and cannot replace the missing native budget. The
joint rest minus BOTH reserves still needs <=3/(320*(N+1)); floor, ceiling,
contradiction and zero exclusion remain OPEN. Do not build further credit
ledgers without a bound on the whole joined quantity.

Seventeen public proofs receive focused direct/targeted warnings-as-errors,
ordinary-root, namespace lint and standard-axiom checks. See
docs/zeta-riesz-aligned-negative-credit.md and its audit. Preserve all prior
mathematical sources/no-gos, public endpoints and staged semiprime files;
only arithmetic moduleFamilies is extended. Continue locally without
commits, pushes, subagents or wider gates.

### Quadratic null-profile cost audit (local)

`ZetaRieszNullProfileAudit` tests whether the exact count-three log-quadratic
null moments can reduce the whole original floor cost. `flat_early_iff`
proves that preserving just the first TWO inactive increments, for
X>=3 and L>=log3, forces linear=1 and quadratic=0. A nontrivial quadratic
correction cannot preserve the old protected low-cutoff geometry for free.

The concrete candidate4/3,-1/(3N) retains the original Riesz response
exactly. For N>=4 its first step is <=-log2/4. The ACTUAL same signed prefix
has common moment M=sum_S w at cutoff one, so candidate_phaseEnergy>=M^2
and candidate_negativeCost>=max(M,0)*log2/4. The native theorem uses the
original core and exact source-normalized weights at N>=65536. These are
necessary COMPARISON-COST bounds, not carrier-deficit lower bounds or a
proof that M grows. The magnitude of M remains UNPAID.

The optional native-order constructed-subset probe compares continuous
least-profile and fixed candidate corrections AFTER all labels/counts are
joined. At N256/640, twelve cases/two seeds have profile factor savings
around77-78%, but the least-profile Cauchy price increases in ELEVEN cases
and the fixed candidate does likewise. Fitting the atomic cost gives at
most5.98% saving in these tests, with nine unchanged. These use log
interpolation, common amplitude rescaling and tiny probable-prime subsets;
no full-population, interval, count56+/many-bin, eventual-order or cofinal
budget certificate is provided. This is NOT an asymptotic no-go.

Do not pursue this smaller profile factor alone as an independent whole
floor saving; first bound the newly activated common moment jointly. All
existing flat-profile bounds remain unchanged. Nine public proofs have
focused direct/targeted Lean/root/lint/standard-axiom checks. See
docs/zeta-riesz-null-profile-audit.md and its scoped audit. Keep the probe
outside ordinary builds/CI. Preserve all prior proofs/public endpoints
and staged semiprime files; work locally without commits, pushes,
subagents or wider publication gates. The numerical floor remains OPEN.

### Coprime/count joint cancellation test (local)

`ZetaRieszCoprimePlateauAudit` proves that after the last proper divisor
and before the label, the actual sharp prefix is -mu(n), with the strict
reflected cutoff (n-1)/k<minFac(n). On a population sharing this geometry,
the coherent channel is the WHOLE signed sum mu(n)*w(n), with every
original phase/allocation weight retained. Its exact energy and one-sided
pairing are proved; the favorable moment sign is not norm-priced.
The native size of this moment and the whole remaining energy are UNPAID.
The explicit coprime squarefree triples1001,7429 have equal columns at
active post-hinge cutoff500 and positive ordered cross contribution1/250
after diagonal deletion. These use unit test weights, NOT native core
phase weights. Coprimality alone cannot justify cutoff orthogonality.

The optional full-subset finite-universe probe keeps all counts and
original masks at native N256/640. It joins the adverse set ONCE, then
computes the ACTUAL remaining small-gcd count matrix after old nearness/
phase masks. Remaining mixed-count terms reinforce in8/12 cases and
cancel in4; same-count terms are negative in11/12. Complete-energy ratios
range0.476..1.395; complete and remaining matrices are DISTINCT. Large
shared-factor terms in the former cannot be counted as main-gap savings.
Cutoff-period reductions are only0.034%..0.228% of these subset prices.
None is a full-population, density, interval, count56+/many-bin, eventual
or floor certificate. Common amplitude rescaling prevents direct budget
comparison. Do not apply the eventual K/864 crop at these small orders.

This pass proves NO new global main-term saving or -79/1000 floor.
The original SmallGcdPayment comparison and independent3/(320(N+1))
target remain unchanged. Do not assume count-joining, coprimality or bin
occupancy gives automatic decay, or turn the observed same-count negatives
into free credits. Attack the ACTUAL weighted Möbius/phase cross-count
estimate with all masks joined. Eight public proofs have focused direct/
targeted/root/lint/standard-axiom checks; see the coprime-plateau doc/audit.
Preserve all earlier sources/no-gos, staged semiprime files, README and
published endpoints. Continue locally without commits, pushes, subagents
or wider publication gates.

### Exact endgame source slack audit (local)

The user requested checking whether the floor/ceiling choice was harder
than needed. `ZetaRieszEndgameSlack` proves 23/25<c_ret(u)<4601/5000
throughout the unchanged 1/2<=u<=10001/20000 interval. The exact source is
-m+m^2c_ret(u). Parametric conditional endpoints require a STRICT gap:
floor-a-o(1) suffices for a simple source when a<1-c_ret(u); ceiling
b+o(1) suffices for every multiple source when b<4c_ret(u)-2.
The double source is proved minimal for all integer m>=2.

Checked weaker rational targets are floor -399/5000=-0.0798 and ceiling
42/25=1.68, versus the preserved old -79/1000 and 3/2 endpoints. With
the SAME 129N/200 profile cap, the current wideRemainingEnergy budget
may be 987/(100000(N+1)), 5.28 percent looser than 3/(320(N+1)).
cost_le_of_relaxed_energy and eventually_relaxed_floor_of_energy prove
that this EXPLICIT OPEN arithmetic premise gives the relaxed floor for
original joinedPhysical, with every paid error included ONCE and o(1).
The ceiling is 12 percent looser. These are target relaxations, NOT a
percentage of arithmetic progress or a proved floor/ceiling/zero exclusion.
Do not spend effort achieving an unnecessarily stronger fixed threshold
when a direct radius-dependent floor strictly above c_ret(u)-1 suffices.
Equality at the source with merely vanishing errors is insufficient.

Endpoint diagnostics give simple sources -0.07992934/-0.07987180 and
double sources 1.68028264/1.68051281. They are numerical diagnostics;
the Lean rational interval bounds certify the sufficient targets. The
independent central signed estimate remains OPEN. Preserve the old
endpoints and all no-gos; no Type-II target is renamed or weakened.
Nine public proofs have focused direct/targeted Lean/root/lint/standard-
axiom checks; see the endgame-slack doc/audit. Preserve previous sources,
staged semiprime files, README and public explorer endpoints. Continue
locally without commits, pushes, subagents or wider publication gates.

### Wider global phase-period correlation payment (local)

`ZetaRieszWidePhasePayment` pays the ACTUAL remaining cross pairs within
log width exp(-N/4500)/(1+abs(y)) of every original total-log phase period,
widening the previous exp(-N/1000)/(1+abs(y)). Arbitrary additional pair
masks are bounded directly, not by signed-energy monotonicity. Source
growth and divisor loss are included:2log(2U)+3/262144-1/4500<=-1/100000.
The source-normalized norm is <=C(B,y)(N+1)^4exp(-N/100000), and its
price sqrt(4C)(N+1)^3exp(-N/200000) tends to zero for every fixed height.
Fixed constants and effective starting orders are UNEVALUATED.

The exact current SmallGcdPayment energy is partitioned with the SAME
whole-population adverse cutoff set. The new payment retains only old
remaining pairs, including log(gcd)<=N/4096, and is disjoint from every
prior phase/near/shared-factor/diagonal payment. The native floor theorem
keeps original joinedPhysical, dyadic schedule, count crop and all masks.
The phase-separated main remains SIGNED and its numerical budget is OPEN.
Removing a negative paid term may increase that remainder; no energy
monotonicity, fraction of deficit removed, occupancy orthogonality or
free favorable reserve is asserted. This is a new independent geometric
payment, not the arithmetic floor or a zero exclusion.

Twelve public proofs pass focused direct/targeted warnings-as-errors,
ordinary root import,14 namespace linters and all-public standard-axiom
checks. The optional finite-subset probe preserves original weights/masks
and selects adverse cutoffs ONCE; it uses probable primes, rescaling and
log interpolation, not a full-core/source-budget certificate. Keep it
outside ordinary builds/CI. Its twelve N256/640 cases have1858..6830
newly selected ordered pairs; the new signed term is positive in six
and negative in six, so the signed remainder increases in six. This
confirms no energy-monotonicity claim; it is not a native mass certificate.
See the wide-phase-payment doc and audit.
Preserve all previous Lean sources/no-gos, staged semiprime files, README
and public endpoints; continue locally without commits, pushes, subagents
or wider publication gates. The next requested audit is the EXACT source
slack in the sufficient floor/ceiling and its numerical energy target.

### Finite divisor mass and additional global phase payment (local)

`NatDivisorSquareHarmonic` proves the finite reciprocal divisor-square
mass <= H_X^4 <= (1+log X)^4 for every masked S in[1,X]. Exact common-lcm
summation eliminates the fixed auxiliary Dirichlet growth loss and its
unevaluated infinite constant. `ZetaRieszFinitePhasePayment` applies this
to ALL literal phase periods and counts and widens the paid neighbourhood
from exp(-N/4500)/(1+abs y) to exp(-N/4900)/(1+abs y).
The exact source exponent satisfies2log(2U)-1/4900<=-1/245000;
the checked norm is <=20480U^2B^2phaseCount(y)(N+1)^8exp(-N/250000).
The profile price sqrt(4C)(N+1)^5exp(-N/500000) tends to zero.

Arbitrary additional pair masks are bounded directly. The native exact
partition uses the SAME whole-population adverse cutoffs, excludes every
previously paid pair, and retains all original weights/support. Its direct
joinedPhysical floor keeps remainingEnergy SIGNED and charges all old
errors ONCE. The independent remaining numerical target987/(100000(N+1)),
floor-399/5000, ceiling and zero exclusion remain OPEN. No native fraction
of deficit, energy monotonicity, starting order or phase-credit size is
certified. Removing a negative paid term can increase the signed remainder.
Do not turn this sparse-family payment into a whole-energy bound.

See docs/zeta-riesz-finite-phase-payment.md and its audit. Optional finite
probes remain outside CI and retain all constructed-subset counts/masks;
rescaling/log interpolation and probable primes are not a carrier proof.
Preserve every prior Lean source/no-go, staged semiprime files, README and
public endpoints. Continue locally without commits, pushes, subagents or
wider publication gates; use focused Lean/root/lint/standard-axiom checks.

### Whole phase credit retained in the current energy floor (local)

`ZetaRieszJointCreditFloor.core_negativeCost_bound` proves the necessary
COST comparison: original negativeCost<=sqrt(max remainingEnergy0*129N/200)
plus every independently paid pair price ONCE. It reuses the exact SAME
whole-population adverse cutoffs throughout the diagonal/gcd/near/phase/
stronger-gcd/wider-phase partitions. No energy monotonicity or reserve
lower bound is used. This is the comparison that the prior complex
projection note requires before adding nativeCredit to an energy floor.

`eventually_joined_floor_with_credit` now proves for ORIGINAL joinedPhysical
Re(P)>=nativeCredit-sqrt(max remainingEnergy0*129N/200)-e_j. Its error is
exactly all pair prices plus nativeError, including the literal WHOLE
imaginary/core-transfer correction. `tendsto_joinedError` proves e_j->0
under the exposed source for EVERY multiplicity; no adverse-subset null.
The nonnegative global phase credit is no longer discarded. Its actual
native magnitude, the signed energy budget and arithmetic floor remain OPEN.

The next explicit independent target is the JOINT cofinal inequality
sqrt(max remainingEnergy0*129N/200)-nativeCredit<=399/5000.
`false_of_cofinal_cost_sub_credit` connects that unproved premise to the
relaxed simple-exposed contradiction. Do not demand separate energy and
credit bounds if their joint inequality suffices. The old987/(100000(N+1))
energy-only sufficient target and the multiple ceiling stay available.
No source percentage, zero exclusion or new carrier is asserted.
See docs/zeta-riesz-joint-credit-floor.md and the shared finite-phase audit.
Preserve old sources/no-gos/public endpoints and staged unrelated work;
continue locally without commits/pushes/subagents or wider publication gates.

### Complex divisor-log nulls in the whole signed floor (local)

`ZetaRieszComplexNullFloor` retains BOTH exact null profiles with complex
coefficients, every label/count and EVERY early/late cutoff. A single vector
in [-4,4]^5 is chosen after joining complete cutoff periods. Null moments
vanish LABEL BY LABEL for squarefree count>=3, so even moving imaginary
coefficients change no literal carrier. Only the one bounded WHOLE imaginary
tilt has the existing correction; no adverse imaginary null is inferred.

`bestCost_le_old` proves the new actual signed cost never exceeds the prior
best directional cost. `native_floor` strengthens the ORIGINAL carrier
floor with the SAME nativeError. `eventually_joined_floor_with_credits`
retains old nativeCredit PLUS nativeGain before the same signed remaining
energy price and joinedError. The necessary COST comparison pays each credit
and each geometric pair error ONCE. Neither credit's native magnitude is
proved; no signed-energy monotonicity or source decay is asserted.

The perpendicular coefficients A=a*i*conj(M)/norm(M), B=b*i*conj(M)/norm(M)
annihilate every flat prefix with Phi a real multiple of M. The checked
`first_cutoff_zero` kills the actual cutoff-one coherent penalty regardless
of its size. `orthogonal_floor` removes only exact zero increments, retaining
ALL other early cutoffs. This bypasses that common-channel cost for these
complex corrections; the prior REAL NullProfileAudit stays valid unchanged.
It does NOT prove the whole core rough or control all other early prefixes.

The direct cofinal nativeCost<=399/5000 budget remains EXPLICITLY OPEN.
The old signed-energy-minus-credit target, ceiling, source and all no-gos
remain. A whole negative source still requires a positive cost even after
the new nulls; do not try to norm-pay it to zero. No RH or exclusion claim.

The optional constructed-universe LP probe reduces 7/12 old period costs
at N256/640 by about3.75..32.74 percent; five do not improve. Coherent-free
corrections improve4/12 by5.02..17.48 percent. These are rescaled floating
probable-prime subsets with interpolated large period edges, NOT native
source-budget, interval, count56+/many-bin, uniform or cofinal certificates.
Imaginary subset corrections remain literal and can worsen its price.
A further N1536/one-seed test gains12.42 percent at height65 and zero at54/100;
the coherent-free restriction gains zero in all three. No uniform rate is
supported; do not extend this coefficient search without a quantitative
mechanism for the ACTUAL native cross-phase null gain.
Keep the probe outside builds/CI. See the complex-null-floor doc/audit.
Preserve all old Lean sources/no-gos, README, public endpoints and staged
unrelated work. Continue locally without commits/pushes/subagents or wider
publication gates; use focused Lean/root/lint/standard-axiom verification.

### Signed structure/cancellation detector (local numerical research)

The user requested a detector to probe shared structure across the floor,
rather than further isolated sector payments. The optional
`scripts/probe_riesz_structure_detector.py` scans original native order/count
ceilings, moving Riesz length, allocation orders, core total-log window and
several prime-log geometries. It joins the full signed subset hinge BEFORE
evaluation. Complete cardinality layers collapse using integer binomial
incidences; small mixed populations use complete subset enumeration. An
unresolved crossing layer stays explicitly unresolved, with enclosures;
do not silently assign it a sign or omit it from an asserted sum.

The broad scan contains15,552 continuous-log configurations, counts3..63,
three radii and core slices, and two perturbation seeds. These are MODEL
geometries, not native prime densities or a complete cover of the core.
Only14,544 responses resolve within the selected combinatorial budget;
the remaining1,008 scale-spread configurations are recorded. Separate
actual probable-prime regressions retain integer cutoff membership. The
`--labels-json` adapter accepts arbitrary factored labels, retains original
masks/phase/full factorial atoms, joins every selected label before real
projection, and removes duplicate labels. None of these finite samples
certifies the native population or cofinal floor.

Complete phase-period MODEL tests retain the two hinges and the moving
owner/allocation/radial weights. The full `log(n)/L` factor and fixed-cofactor
density constant must be retained. Join counts and periods BEFORE adverse
clipping. A computed partial-node integral is not the model integral:
incomplete results have null main values/cancellation scores, are excluded
from candidate ranking, and keep the exact unresolved-node audit. Quadrature
refinement is evidence only, not an interval certificate or source saving.
Do not spend model cross-count cancellation percentages as floor credit.

The self-contained local HTML map is generated beside each scan JSON; it
allows count/geometry inspection with scope and coverage visible. Keep it
outside ordinary builds/CI and leave README/public explorers frozen. See
`docs/riesz-structure-detector-audit.json` for recipes, source snapshots and
validation. No new Lean theorem, native arithmetic budget, zero exclusion
or contradiction is claimed. Preserve all earlier positive/no-go results;
continue locally without commits, pushes, subagents or wider gates.

### Generic unpaid-only signed-pattern probe (local)

The user's latest steering is to probe only areas not already bounded.
Use `scripts/probe_riesz_generic_patterns.py` for new generic scans; it
rejects paid/out-of-support records BEFORE subset calculation. Default
whole count is >=56 and <5log(N+1)+2, with ORIGINAL/current count ceilings,
literal occupied cofactor bins >floor(log(N+1)/16), owner <60069/100000,
and retained window/physical/allocation tests. Its additional roughness
condition selects a rough MODEL subset; the whole core has no such lower
prime cutoff. Do not redefine the native carrier by this sampling filter
or claim a complete native-complement cover. Default native index1024 is
in the proved near-critical count-payment regime. Smaller indices are
explicit pre-asymptotic model regressions. Paid examples require
`--include-paid-diagnostics` and remain excluded from discovery/ranking.

Arbitrary positive log vectors require no named theorem-family label.
Exact finite-input moments cover all subsets and both true parities;
automatic full/sparse lattice discovery retains every exceptional subset.
Signed recursive finite differences can cancel complete inactive/affine
subtrees. Exhausting the recursion budget NEVER resolves an uncertain
response. Keep the full moment enclosure and exclude it from ranking.
Exact sensitivity groups are local fixed-total invariants only until an
UNSIGNED subset knot crosses a hinge; signed polynomial cancellation does
not remove that boundary. Full phase, both hinges, original allocation
and moving length stay explicit. Do not confuse the density-model radial
kernel with the separately reported literal source-weight amplitude.

`ZetaRieszSubsetMomentBounds` adds5 public pointwise moment/chord/signed-bin
proofs, checked by strict Lean/target/root/lint/standard-axiom validation.
It is not a correctness proof of the Python implementation, prime transport
or a native floor payment. The optional checks include213 independent
small exact enumerations,180 signed-recursion comparisons,15 sensitivity
checks, sparse exceptional subsets and canceled unsigned boundaries.

A pre-asymptotic whole-count57/58 MODEL split has opposite coefficients
about1.4433 and-1.2234 at fixed total log/owner/phase. This supplies no actual
prime partners, allocation/funding matching or source-scale credit. At
native index1024 four surviving many-bin model targets vanish; stressing
both sides of the actual inner hinge yields four zero and four tiny negative
responses, with complete subset coverage and exact refinement agreement.
Eight arbitrary nonlattice unpaid profiles remain unresolved and unranked.
No generic sign or population-density law is established by these tests.

See docs/zeta-riesz-generic-patterns.md and its JSON audit. The native
nativeCost<=399/5000 premise, ceiling and contradiction remain OPEN.
Only a bound for the actual signed weighted crossing aggregate can spend
this structure. Preserve all prior results/no-gos, public files and staged
unrelated work. Continue locally without commits/pushes/subagents or wider
publication gates; keep probes outside ordinary builds/CI. The possibility
of a hybrid finite certificate stays available, with its required analytic
reduction still open.

### Joined clipped insertions on unpaid geometry (local)

`ZetaRieszClippedInsertionFloor` proves the exact inserted response
`-min(tau',log r)` with `0<=tau'<=log(minFac b)` on the OLD base. Keep
short inserted primes; the older inserted InnerHinge condition does not
cover them. The literal finite-family floor charges the clipped coverage
shortfall AFTER summation and ONE joined complex transport norm. Native
prime partners, funding, support and fractional capacity are not supplied.

The owner-family theorem reuses the existing favorable allocation gain,
with its already payable `2exp(-N/25)` lower tail. Every partner phase must
actually have the favorable real sign and its owner cofactor share must
increase. No absolute allocation variation is needed in that case. Do
not spend this tail, a partner or old native population credit twice.

For a common smooth complex amplitude, the checked centered-transport
theorem cancels a PROVED first log-gap moment and gives the quadratic cost
`M*rho^2*sum c`. Second derivatives, actual centered funding and support
remain explicit obligations. Do not differentiate a hard mask or infer
the native moment/prime inventory from bin occupancy or complete-leg phase.

The optional unpaid-only clipped probe has45 complete MODEL families at
native index1024, whole counts56/57/64/65/301 and51..70 occupied bins (paid
ceiling45). It rejects18 paid records before subset computation. All300
finite-binary inserted responses resolve;225 are short insertions excluded
by the older inner condition. Thirty constructed two-sided inventories have
exact rational coverage and zero first gap moment. Their small relative
complex costs are NOT native prime partners, global capacity, interval or
source-budget certificates. Every actual finite-binary gap, original phase,
factorial ratio, allocation enclosure and moving-length error is retained.
The numerical transport uses the unallocated smooth amplitude; the full
allocated transport is not numerically evaluated. Budget exhaustion leaves
the family unresolved. Constant gap radii do not beat `(2u)^N` globally.
See the clipped-insertion doc/audit.

The eleven public Lean proofs have focused strict/build/root/lint/standard
axiom checks. The independent nativeCost<=399/5000 floor, ceiling and RH
contradiction remain OPEN. Preserve all prior proofs/no-gos, public files
and staged unrelated work. Continue locally without commits/pushes/subagents
or wider publication gates; probes remain outside ordinary builds/CI.

### Insertion capacity and global centered transport (local)

`ZetaRieszInsertionCapacity.response_eq_average` joins ALL finite insertion
counts into the exact Bernoulli hinge average for independent real weights
in[0,1]. It proves nonnegativity, the original-hinge upper bound, mean-deficit
and empty-channel lower bounds. Strict weights below one leave a positive
residual. The arithmetic bridge retains the squarefree old base and actual
prime logarithms. These are COEFFICIENT inequalities; do not replace native
correlated prime inventory, allocation or masks by product weights.

`ZetaRieszCenteredInsertionPayment.global_centered_cost` differentiates the
actual full factorial amplitude AND phase, cancels a PROVED first total-log
moment and sums over distinct original labels. With nonnegative coefficients,
row mass<=3(N+1), actual gaps<=exp(-N/5000), L>=1 and log Q<=3(N+1), its total
source price is<=72U(2+abs y)^2(N+1)^3exp(-N/4000), which tends to zero. There
is no candidate/count multiplicity in the price. The signed floor theorem
requires exact coefficient coverage; native membership, partner COLUMN
capacity, original allocation/funding and the signed unmatched remainder
are application obligations. Do not claim a paid native population yet.

The unpaid-only optional probe has27 complete MODEL families,18 paid skips,
whole counts56..365 and51..70 old occupied bins. Exact integer probability
numerators retain all2^64 subsets in the largest pool. Nine small signed
enumerations and maximally generous fractional matches respect each node's
specified product-weight capacity. Positive residuals about0.167..0.466 of
the original hinge remain. These are virtual log inventories, not actual
prime partners or native floor debits. Full phase and allocation enclosures
stay explicit; the fully allocated family is not numerically evaluated.
Do not infer coverage from arbitrary per-candidate beta<=1 or double-spend
global supply. See docs/zeta-riesz-insertion-capacity.md and its JSON audit.

The15 public proofs have focused strict/build/root/lint/standard-axiom checks.
The independent native floor, ceiling and contradiction remain OPEN.
Preserve all prior proofs/no-gos/public files and unrelated staged work;
continue locally without commits, pushes, subagents or wider gates.

### Genuine-prime independent insertion rate audit (local)

`ZetaRieszInsertionRateAudit` keeps the complete signed insertion sum with
ACTUAL weights1/p and logs(log p). The earlier exact Bernoulli identity
retains the empty channel. Using the repository's unconditional reciprocal-
prime Chebyshev bound, ANY prime pool through log X<=2N+2 has empty mass and
relative hinge response at least exp(-16)/(8(N+2))^16. Every fixed u>1/2
therefore gives source regrowth even after ANY fixed polynomial discount;
`not_frequently_response_source_div_pow_le` excludes a bounded cofinal
subsequence of that independent COEFFICIENT model. The exact squarefree
arithmetic bridge retains its old-base/hinge and coprimality hypotheses.

This is a rate no-go for independent product-weight matching, not a native
carrier lower bound or floor impossibility. Do not equate original phase,
owner/allocation masks, actual partner inventory or funding with independent
weights. A replacement needs quantitative cancellation using those retained
correlations. No native population was paid and no floor budget was reduced.

The optional `probe_riesz_prime_insertion_rate.py` uses every actual prime
through each tested endpoint, including78,498 primes through one million.
An integer phi/squarefree sieve enumerates EVERY positive-hinge subset;
all larger products have exactly zero hinge, not an omitted count tail.
Floating logs give empty mass about0.0406382 and complete relative responses
about0.0883..0.2854 on the reported hinges. Five independent signed-subset
unit regressions check the reindex. These are coefficient diagnostics, not
unpaid native-population scans; no native phase/allocation result follows.
Separate source-rate evaluations use the PROVED lower bound, not computed
exponential-length prime pools. See the insertion-rate doc/JSON audit.

The12 public proofs have focused strict/build/root/namespace-lint/standard-
axiom validation. Keep all earlier positive/no-go results and public endpoints
unchanged. Continue locally without commits, pushes, subagents or wider gates;
preserve unrelated staged work and keep this probe outside builds/CI.

### Signed high-dimensional hinge geometry detector (local)

`scripts/probe_riesz_hinge_geometry.py` extends the UNPAID-only detector with
exact signed degree-zero/one/two incidence moments, strict AND inclusive
hinge walls, and independently searched UNSIGNED subset-knot gaps. Every
count/subset parity is retained. The signed second incidence matrix is NOT
a Hessian or positive covariance matrix. Its exact rank/nullspace proposes
correlations; it supplies no native prime-transport or energy saving.

Complete free cubes annihilate low-degree signed incidence polynomials.
`ZetaRieszSignedCubeGeometry` proves this for arbitrary complex coefficients
and gives a direct signed pair floor criterion. Literal membership, phase
and weights must stay INSIDE that pairing; unused unweighted coordinates
do not justify deleting masked/weighted carrier terms. Exact Boolean
complement symmetry resolves nearly full faces. Iterative work stacks
retain growing counts without a call-stack truncation. State/storage
exhaustion exports null coefficients/ranks/directions, not partial claims.

The30-record scan has12 paid skips,15 exact unpaid geometries and3 unresolved
unranked generic300-coordinate profiles. Four exact responses vanish; the
other11 have signed incidence rank one, including three300-coordinate
stress cases. Their49..70 old occupied bins exceed the paid ceiling45.
Fifteen finite-input fixed-total redistribution checks retain the coefficient,
phase/radial factor and support, with allocation enclosures recomputed.
These MODEL directions do not construct primes or opposite-parity partners.
Eight arbitrary nonlattice unpaid profiles in a separate scan remain wholly
unresolved; seven paid profiles are rejected before geometry computation.
Do not assert generic rank-one structure or spend these numbers as credit.

The backend has400 independent exact tensor checks,200 unsigned-boundary
checks,40 two-hinge checks,512-coordinate complement and300-coordinate
hierarchy regressions. The five public Lean proofs have focused strict/
build/root/lint/standard-axiom checks. See docs/zeta-riesz-hinge-geometry.md
and its JSON audit. Native capacity, signed unmatched population, floor and
ceiling remain OPEN. Keep probes outside CI; preserve all old proofs/no-gos,
public files and staged unrelated work. No commits/pushes/subagents/wider
gates are authorized by this local research slice.

### Exact cubic credits and joint signed-cost geometry (local)

`ZetaRieszSignedNullGain` applies the EXISTING cubic divisor-log null to
every squarefree count>=4 label simultaneously, retaining count3 in the
baseline. Its15 public proofs include the exact whole-period saving
`a*sum_{T_b<0}V_b-crossingCost`. Original zero groups and ALL sign crossings
are priced; energy improvement alone does not count as a floor credit.
The arithmetic phase, masks, allocation and all early cutoffs are retained.

`native_floor_with_credit` is a DIRECT inequality for original joinedPhysical
with the SAME analytic error: `Re(P)>=-ComplexNullFloor.nativeCost+
nativeCredit-nativeError`. Credit is max(oldCost-newCost,0), no larger than
the SAME old price. Earlier supply/head/phase credits must not be spent
again. The cofinal credited cost<=399/5000 remains an EXPLICIT OPEN premise;
no native credit magnitude or additional paid population is proved.

The optional signed-block detector searches all supplied directions jointly,
replays costs/crossings with exact rationals, and bounds ALL vectors in the
same box by a rounded dual witness with its residual correlations charged.
An exact zero primal-dual gap certifies only the supplied finite-input box.
Active-kink rank is not covariance/orthogonality. Three-hundred crossing
identity checks and22 LP replays are independent UNIT regressions, not
unpaid population scans. They show a joint direction can improve where
each coordinate alone fails, and also retain positive unmatched costs.
Count3 cubic moments are not fitted away. Paid/incomplete/nonnull records
are rejected before search; declared completeness/native arithmetic origin
are not independently verified by Python. No native block records have
been evaluated. Do not convert sampled cutoffs into a whole-cost estimate.

See docs/zeta-riesz-signed-null-gain.md and its JSON audit. Continue locally
without commits, pushes, subagents or wider gates; keep all prior no-gos,
public endpoints and unrelated staged work. Floor/ceiling/RH remain OPEN.

### Complete crossing-layer variance (local)

`ZetaRieszLayerVariance` proves that complete-layer centering cancels the
first displacement and leaves a nonnegative crossing defect with integral
exactly half the total squared displacement. Its weighted signed floor
retains all central phase values jointly; only weight variation is priced.
Actual squarefree divisor layers and their true Moebius signs are included.
This is a Lebesgue cutoff-average theorem, NOT a prime-measure transport or
native source budget. The signed central aggregate remains unbounded.

The optional crossing-moment probe resolves all crossing layers in488
fixed-cofactor cluster-model cases covering counts3..63 at N3584. Complete
cluster quotas represent every subset; no uncertain crossing is skipped.
Numerical remainder/refinement ratios are relative to MODEL absolute
integrals, not source credit or interval certificates. A90-case mean-phase
scan at fixed internal cluster variance has ZERO sign-changing configurations;
do not claim a generic sign reversal from it. These compact models use the
original count window, not the eventual reduced nativeCost count ceiling.
See `docs/riesz-layer-variance-audit.json` for scope and exact snapshots.

Elliptic/finite-field trace methods are a candidate only after an exact
bridge from the retained signed divisor convolution, with controlled
complexity and all boundary costs. No such bridge is proved. Do not insert
arbitrary trace weights or discard the principal channel. The native floor
is open; keep probes outside CI, public files frozen, and continue locally
without commits, pushes, subagents or wider publication gates.

### Direct elliptic trace-channel audit (local)

`ZetaRieszEllipticChannelAudit` proves the complete Legendre-family cubic
character-sum trace has zero mean over every odd finite field, including its
two degenerate fibers. All translated trace correlations are unchanged by
adding a constant to the residue population. `no_floor_from_twist_norms`
uses a constant negative witness to refute a UNIVERSAL floor from those
twist norms alone. It does NOT refute the native floor, a trace kernel
arising in an exact Cauchy/completion argument, or all elliptic methods.
No Hasse bound, new prime filter or arithmetic trace weight is assumed.

The optional literal-convolution regression retains1,980 selected labels
and114,672 complete cofactor-divisor incidences across108 channel audits,
N256/640/1536, two seeds, heights54/65/100 and six moduli. Exact integer
residues/cutoff membership and original allocation/masks/complex phase
remain; one common amplitude scaling per universe is recorded. The twists
recover the centered residue vector and leave the ENTIRE original signed
total in its principal channel. Tiny diagnostic principal energy is not
a native floor saving. The tests cover finite constructed probable-prime
universes/counts3..9, not count56+, growing many-bin or native populations.

See `docs/riesz-elliptic-channel-audit.json`. Do not try to close the floor
by bounding newly added elliptic twists and discarding their principal
channel. A useful trace route needs an exact ORIGINAL correlation identity,
controlled complexity and independently paid boundaries. The native
signed budget remains open. Preserve all prior sources/public files and
staged unrelated work; continue locally without commits, pushes, subagents
or wider publication gates. Keep this probe outside builds and CI.

### Joined crossing versus common-prefix diagnostic (local)

`scripts/probe_riesz_crossing_coherence.py` tests the proposed population-wide
coherent-channel mechanism BEFORE introducing further floor infrastructure.
It retains the original finite-universe labels, physical/count/radial masks,
allocation and both phases. Every integer divisor prefix is partitioned into
its early value1, reflected late value-mu(n), and exact remaining crossings.
The channels and ALL counts/cutoff periods are recombined BEFORE the actual
one-sided cost; the same single bounded complex-null vector is optimized
globally. Separate channel prices and log-interpolated energies are ONLY
diagnostics, not floor allowances or independently spendable credits.

Fifteen tests at N256/640/1536, two seeds where available and heights54/65/100
put75.44..98.03 percent of the diagnostic component-diagonal post-hinge
energy in intervening crossings. Cross-channel energy reinforces in13/15.
These are constructed probable-prime universes with counts3..9, amplitude
rescaling and unresolved log interpolation, NOT full-native, count56+,
many-bin, cofinal, interval or deficit certificates. The result does not
prove a native energy fraction or disprove the arithmetic floor. It does
not support trying to close the floor merely by canceling common prefixes.
The topology/critical-face description was already recorded in
`docs/zeta-riesz-label-anatomy.md`; naming it again supplies no new saving.

Keep the diagnostic outside builds/CI. See
`docs/riesz-crossing-coherence-audit.json` for the exact scope and outputs.
No new Lean theorem or native numerical budget is asserted by this pass.
Preserve all old mathematical sources/public endpoints and staged unrelated
work. Continue locally on the JOINED signed crossing estimate, without
commits, pushes, subagents or wider publication gates. The floor stays open.

### Whole-carrier imaginary-channel cancellation (local)

`ZetaRieszComplexProjection` retains BOTH phases in the original divisor
prefix, joins all counts/owners and complete cutoff periods, and chooses
ONE real tilt in [-4,4]. Compactness gives its least cost; zero tilt is
included. `native_floor` proves Re(P_j)>=-nativeCost_j-e_j for the ORIGINAL
joinedPhysical, with exact error e_j=4abs(Im P_j)+5norm(Q_j-P_j). Q_j is
the existing count-cropped core. `tendsto_nativeError` proves e_j->0 under
the exposed-zero source for every analytic multiplicity. Never infer an
imaginary null for an adverse/count/period subset from that WHOLE null.

`sourceWeight_re` identifies zero tilt with the SAME source-scaled
primeWeight. `nativeCost_add_credit_le_original` pays the least cost plus
its exact nonnegative nativeCredit with the old adverse Cauchy price.
`native_floor_with_credit` therefore retains the global credit directly
in the original whole floor. Do not add it to a weaker existing energy
floor without also proving that energy upper-bounds the old COST. No
size of the native credit or signed energy budget is currently certified.
When the whole imaginary part is zero, the optimal cost is proved at
least max(-Re(P),0); the selected source cannot be norm-paid away.

The explicit OPEN target is a cofinal nativeCost<=399/5000. Its checked
implication is `false_of_cofinal_nativeCost`, not an independent floor.
The old wideRemainingEnergy target and every earlier no-go remain intact.
The optional constructed-subset probe at N256/640 reduces whole-period
costs in twelve tests by about0.079..36.717 percent; a coarse Cauchy tilt
improves nine, at most43.533 percent. Full positive-semidefinite energy
projection is worse than the old adverse price in all twelve and is set
aside. Subset imaginary corrections are retained and can worsen the
actual subset price. These rescaled/interpolated probable-prime tests
are NOT full-core, interval, growing-count, cofinal or deficit certificates.

See the complex-projection doc/audit for focused Lean/root/lint/axiom
checks of23 public proofs;14 namespace linters pass and all transitive
axioms are standard. A further N1536/one-seed test varies from about
0.009 to27.602 percent saving across three heights, not a uniform rate.
Keep the probe outside builds/CI, preserve all previous modules,
staged unrelated files, README and public explorer endpoints. Continue
locally without commits, pushes, subagents or wider publication gates.
The arithmetic floor, ceiling and restricted exclusion remain OPEN.

### Wider actual shared-factor correlation payment (local)

`ZetaRieszSmallGcdPayment` uses the literal inverse-square common-factor
mass with tail exponent99/100 and convergent M(101/100), replacing the
preceding1/2 tail exponent. The exact squarefree divided-label convolution
pays log(gcd)>N/4096. Source growth is included:2log(2u)+6/262144-
99/409600<=-1/65536 at the unchanged radiusCeiling. For any actual pair
mask, weighted_maskedShared_bound gives norm<=C(B)(N+1)^3exp(-N/65536),
C(B)=16U^2B^2M(1+1/262144)^2M(101/100)exp(6/262144). Its price
sqrt(4C)(N+1)^2exp(-N/131072)->0. Fixed masses and effective starts are
UNEVALUATED; the4.096times smaller log threshold is NOT a fraction of
carrier mass, remaining energy or floor deficit.

The added mask is ORIGINAL retainedPair, so only the actual band
N/4096<log(gcd)<=N/1000 outside old near-label/phase families is paid.
paidPair_band and nonOrbitEnergy_eq certify disjoint placement and the
EXACT ledger. Adverse cutoffs are selected ONCE on the whole native core
at the prior K/864+1 count endpoint; all original phases/allocations,
physical/radial/nondominant/count masks and cutoff Gram remain. The norm
bound is proved for each selected mask itself, not inferred from a norm
of a larger potentially cancelling family. No automatic orthogonality,
zero hypothesis, density theorem or countwise absolute allowance enters.

eventually_joined_floor is a DIRECT comparison for ORIGINAL joinedPhysical
at ORIGINAL K. One original bridge, four old pair prices, the existing
count tail and the new disjoint shared-factor price occur ONCE. No supply
funding/debit or favorable count credit is spent. RemainingEnergy retains
ALL smaller-gcd signed correlations, including coprime pairs. Deleting a
negative family can increase its finite cost; do not claim monotonicity.
Its independent3/(320(N+1)) sufficient budget, numerical-79/1000 floor,
ceiling and zero exclusion remain OPEN. No native reserve lower bound,
finite starting order or percentage of whole-floor progress is certified.

Twelve public proofs have scoped direct/targeted Lean, ordinary-root,
14 namespace-linter and all-public standard-axiom checks; see
docs/zeta-riesz-small-gcd-payment.md and its auditJSON. Preserve all old
mathematical sources/no-gos, staged semiprime files, README and published
endpoints. Continue locally without commits, pushes, subagents or wider
publication gates; attack the remaining combined small-gcd signed estimate.

### Further near-critical global count payment (local)

`ZetaRieszNearCriticalCountPayment` pays EVERY original selected label
with 864*omega(n)>=K on the unchanged native schedule. For j>=1024,
K*logK>=(173/2000)*N yields the count tilt exp(173*N/1728000).
The exact q=499999999/1000000000 and sigma=1000000001/1000000000,
with eventual Euler slack exp(N/100000000), give a rationally checked
source rate <=exp(-N/10000000). The complete selected tail has norm
<=(203/50)*radiusCeiling*(N+1)*exp(-N/10000000), for all heights and
original correlated coefficients under the existing factor-two majorant.
No zero/cancellation or density hypothesis enters. The convergent count
mass and effective eventual start are UNEVALUATED; j>=1024 alone is NOT
a certified start for the final arithmetic payment.

The retained endpoint K/864+1 uses natural division, asymptotically8/9
of the preceding K/768 endpoint, with exact ordering/rounding proofs.
This is about11.1% of count-interval width, NOT a percentage of carrier
mass, remaining energy or floor deficit. The source decay rate is50times
slower in exchange for paying more original labels. The actual complex
core difference is independently paid; do not assert smaller-core energy
<=old energy, since signed cross terms and the adverse cutoff set change.

eventually_joined_floor remains a DIRECT comparison for ORIGINAL
joinedPhysical at ORIGINAL K. It keeps all masks/phases, selects adverse
cutoffs ONCE on the whole new core, and spends one original bridge,
each of four pair prices and the new tail allowance ONCE. No funding
supply/debit or favorable count credit enters. Generic antiphase/aligned
credit identities still apply to this finite support but no native
reserve lower bound is proved. The signed3/(320*(N+1)) budget, numerical
-79/1000 floor, ceiling and new zero exclusion remain OPEN.

Fourteen public proofs have scoped direct/targeted Lean, ordinary-root
import,14 namespace linters and all-public standard-axiom audits; see
docs/zeta-riesz-near-critical-count-payment.md and its auditJSON. Earlier
mathematical sources, staged semiprime files, README and public endpoints
remain unchanged. Continue locally without commits, pushes, subagents
or wider publication gates; attack the remaining signed global estimate.

### Native count/bin partner funding joined before matching (local)

`ZetaRieszOpenCountFloor.eventually_joined_floor_open_counts` proves a
native whole-floor comparison on ONE original support:
R=((coreBand\wholeTail) union radialTail)\sector. Fixed-count, dense,
few-bin and many-bin populations are kept with their actual SIGNED
coefficients; each is below its original positive-part credit. Original
physical/core/count/allocation masks, phase, owner crop and whole-tail
boundary remain. The SAME supply witness and debit
tailCost+epsilon+growingDebit are retained once, with err->0. This is an
alternative joined ledger, not a free use of the old favorable credits.
It may lower the comparison until actual joined cancellation is paid.

The exact original funding is1_R-debit*1_Y, including1-debit on overlap.
Supply labels have count4; all included counts>=5 have coefficient1.
More strongly, every prime in the ACTUAL radial supply has log<=3N/5,
whereas every marked prime on an InnerHinge in the original core has
log>=18N/25 for L>=11N/8. Thus no such label meets the supply, INCLUDING
count4. `joinedFunding_one_innerHinge` proves its native funding equals1;
no partner-equality hypothesis or4+abs(epsilon) bound is needed here.

`floor_after_matching` directly removes any admissible disjoint
fixed-owner opposite-parity matching from this WHOLE floor. Its explicit
matchingBudget uses B=1, decays geometrically, and keeps the ORIGINAL
signed unmatched contribution and supply debit. It removes no actual
gap, coprimality, squarefree, common-hinge or physical support obligation.
Native matching existence and the -79/1000 signed rest bound remain OPEN.

The optional complete-cofactor-cell probe includes ALL squarefree composite
integers/counts in each tested cell, full original allocation and phase.
Its first order96 cell has parity imbalance+204: at height54 all1037
adverse labels pair (583 pairs use count4); at height65 phase reversal
leaves204 adverse labels unmatched. Order128 examples similarly leave
133/101/252 negative labels at reversed phases. This rules out treating
the earlier selected-pool coverage as evidence of automatic complete-cell
coverage. These orders fail the native eventual length lower bound and
are NOT count56+ many-bin/dyadic/funding or cofinal certificates. Keep
the residual parity imbalance SIGNED across radial periods, not as a
separate positive allowance. Eleven public proofs pass focused
Lean/root/lint/standard-axiom checks. See
docs/zeta-riesz-open-count-floor.md and docs/riesz-open-count-floor-audit.json.
Keep all earlier ledgers/no-gos and public endpoints unchanged. Continue
locally without commits, subagents or wider publication checks.

### Many-bin phase and deletion audit (local)

The growing-floor batch was published at
`f7616600703b9a8612fd4bd84a66f5807bd28682`; exact-SHA CI run36923456582
finished successfully. That publication request is complete. The latest
steer tests whether the remaining many-bin condition supplies exponential
joint cancellation. Continue locally without commits, subagents or wider
publication gates. Do not treat bin occupancy as weighted anti-concentration.

`ZetaRieszManyBinPhaseAudit` proves the owner-centre/cofactor compensation:
all occupied bins/counts can have the SAME total-log phase. For ACTUAL
squarefree cofactors, `bin_deletion_energy_exact` retains all four hinges
and arbitrary common original phase/factorial/allocation weights. Averaging
the complete deletion energies first within bins, then across bins, equals
the unchanged original energy EXACTLY. A within-label Cauchy step has no
automatic bin gain. This does NOT exclude cross-label arithmetic cancellation.

The optional joint-period probe retains both hinges, full radial factorial
amplitude, complete periods, moving-length rounding and allocation
enclosures. Six neighbouring growing counts can have joint/diagonal Gram
energy near6 and correlations near1. These are continuous LOG MODELS,
not certified prime populations or spent-set examples; their essential
cofactor mass is unpaid. Odd-grid parity reinforcement is also only a
model identity. The exact tilted complete-period integral is nonzero.

`binary_bin_discount_source_tendsto` proves that a binary discount per
available occupied bin cannot beat the old positive source envelope:
available bin count is logarithmic, so the discount is only polynomial.
This is not a lower bound on the actual signed carrier. The literal signed
peak bounds retain the zero-height signed sum and an explicit quadratic
phase error; that error remains UNPAID. No actual population is newly paid
by this audit, and no floor/ceiling or new zero exclusion follows.

Use the EXISTING `ZetaRieszCofactorPhaseEnergy.phaseEnergy` and literal
`SignedConvolution` if pursuing cross-label correlations. Do not create
another Gram carrier or infer a fixed-height masked power saving from
Ramaré/MR frequency-averaged estimates. No bilinear saving is established
merely by writing its exact factorization. See
docs/zeta-riesz-many-bin-phase-audit.md and its20-public-proof audit.

### Global signed density-prefix cancellation (local)

`ZetaRieszSignedDensityCancellation` proves the elementary weighted
reciprocal Möbius bound one, with real prime weights in[0,1], and applies
it to the EXACT original rough-density coefficients. Every excluded-prime
hit and nonsquarefree zero is retained. Its original signed prefix is
bounded by its own positive rough density, uniformly over ALL cutoffs,
counts and finite prime exclusions. This improves the previous rough
allowance1+log D; the unexcluded allowance improves from2 to the exact
squarefree density. This classical ingredient follows Tao's2009 paper,
Theorem1.1/Remark2.1; do not describe it as newly discovered mathematics.

`literal_whole_carrier_signed_bounds` propagates this to the SAME
masked residual sum on every subset ofcoreBand. The first cofactor moment
U_p stays signed, and the second price retains|sum w| rather than
sum|w|. The translated owner-hinge scalar has allowance rho*(L-log p)_+
after exact owner normalization; its old logarithmic cutoff loss is gone.
The literal comparison variation, both cofactor moments' source costs,
funding debit and final numerical floor remain UNPAID. Do not count
exp(-N/128) alone as an error payment or claim a new source-o(1) population.

The exact actual-integer phase prefix at height19*pi/log2>54 and cutoff2
equals4/3. Thus the real-weight prefix bound cannot be imposed on phase
weights. That example does not refute the core floor or a zeta ordinate.
The optional actual-integer regression is outside ordinary CI. See
docs/zeta-riesz-signed-density-cancellation.md and its12-proof audit.
Continue locally, preserving all earlier negative audits and the strict
distinction between a signed scalar saving and the independent-79/1000
whole-carrier floor. No new zero exclusion or contradiction is proved.

### Owner-hinge cutoff cancellation (local)

`ZetaRieszOwnerHingeCancellation` joins ALL owner-hinge divisor cutoffs
and proves the SAME normalized signed scalar has allowance7*(p+1)/p,
at most21/2 for every actual prime. This strengthens the preceding
rho*(L-log p)_+ price to a height-independent alternative. It reuses
the proved constant-seven density Riesz bound. The exact prime-exclusion
coefficient recurrence, finite integer reindexing and summation by parts
give Lambda_p(c)=densityRiesz(c)+(p+1)^(-1)*Lambda_p(c-log p).
The physical cutoff strictly decreases, so induction proves the bound
without an infinite product, phase completion or arithmetic hypothesis.

`literal_whole_carrier_constant_bounds` applies this to the SAME masked
original carrier on every coreBand subset. Its first moment stays signed
and the price uses|sum w|, preserving the complete cofactor/count/period
sum before its norm. The literal variation error, source costs of both
moments, funding and numerical-79/1000 floor remain UNPAID. No new
source-o(1) population is paid. This is contraction of a complete signed
reference mean, NOT pointwise factorial-kernel contraction; preserve the
old boundary-renewal no-go and every other audit.

The optional actual-integer scalar regression has15 cases through50000
and is outside ordinary CI. It is not a masked-carrier/floor certificate.

The local extension adds eight public proofs: the SAME density Riesz mean
is rho-Lipschitz; its exact owner-conditioned scalar differs by at most7/p.
Thus nearby owners have multiplier difference at most
rho*|log p-log q|+7/p+7/q. `owner_prefix_signed_bound` joins ALL actual
owner sums through G(k)=sum_(p<=k)V_p before any norm, giving cost
7|G(X)|+rho*sum_(k<X)log((k+1)/k)|G(k)|+7*sum_p|V_p|/p.
`literal_whole_carrier_centered_bounds` retains the stronger JOINT signed
main rho*sum U_p-densityRiesz(L-log X)*G(X), charging only the cumulative
variation and7/p correction. It does NOT norm-pay or discard G(X).
`literal_whole_carrier_prefix_bounds` is also available, charging7|G(X)|.
Both propagate to the SAME original masked core and retain its explicit
unpaid comparison variation. This is cross-owner cancellation retention,
not an automatic weighted many-bin gain or source-o(1) payment. G's actual
source cost, first moment, comparison error, funding and final floor remain
OPEN. Five additional optional actual-integer scalar cases prescribe owner
amplitudes; they do NOT measure carrier moments or certify a floor. Keep
the earlier constant bound available: coherent profiles can make the new
prefix cost larger. Do not discard the common resonant moment G(X).

The next eight public proofs clean the RAW comparison extension of the
ENTIRE published unpaid population. Dense/few-bin/high-tail deletions use
squarefreeness in the original paid sets; nonsquarefree labels from those
ranges can therefore remain in the old raw comparison weight. The new
comparisonOwnerBand applies the exact unpaid count/bin/owner tests without
a squarefree indicator. It is a subset of the original remainingOwnerBand
and has EXACTLY the same squarefree subset, including zero-coefficient
rows. Thus the original signed carrier and all its squarefree moments are
unchanged. No nonzero population is newly paid or completed.

comparisonOwnerVariation_eq_active removes ALL error edges whose two
endpoints fail the unpaid geometry. literal_remaining_centered_bounds
keeps the common resonance signed and charges only the cleaned active
edges. eventually_joined_centered_owner_floor spends this on the EXISTING
whole-floor ledger with the SAME vanishing error, funding and debit.
Neither an arithmetic cancellation hypothesis nor an extra funding credit
is introduced. The actual joint main, cumulative owner cost, active-edge
variation and final funding inequality remain UNPAID. Deleting rows does
not make arbitrary total variation monotone: do not claim a uniformly
smaller total price, source-scale decay or a numerical floor from this
support cleanup alone. The former bounds remain available.

The next four public proofs audit the SAME cleaned RAW comparison price.
Canonical ownership forces the raw weight to vanish when any prime q>p
divides its cofactor. Bertrand gives p<q<=2p, and exact telescoping proves
sum a*|w(a)|<=2p*sum a*|w(a)-w(a+1)|. On a literal core column with
log p<=N/2, every active cofactor is at least exp(29N/20), so the CURRENT
exp(-N/128) allowance is at least exp(603N/640)/2 times sum|w|.
comparison_owner_active_allowance_lower proves this also for the cleaned
active-edge sum. This is a MAJORANT audit, not a signed-error/carrier or
population-mass lower bound; do not claim actual divergence, a new paid
population or a floor from it. The owner zeros remain even without a
squarefree mask. Any further comparison must preserve their signed
correlations or adapt the reference measure; no prefactor-only payment.

See docs/zeta-riesz-owner-hinge-cancellation.md and its twenty-four-public-proof
audit. Continue locally without subagents, commits or wider publication
gates, preserving all public frontier endpoints and unpaid terms.
Preserve all previous positive results and no-gos; all five final floor
estimates remain OPEN and the published frontier is unchanged.

### One total-label phase cost for the whole retained floor (local)

`ZetaRieszRejoinedPhaseFloor` applies the EXISTING signed prefix energy on
the original total-integer axis. primeWeight_product proves that the
factorial/allocation/phase weight is independent of its marked incidence
after the product label is fixed. The two owner hinges rejoin to R_L(n).
Every original count/bin/radial/owner/physical/allocation mask remains;
nonsquarefree coefficients are exactly zero. weighted_residual_eq_prefix
permits arbitrary real signed population coefficients inside the prefix.

whole_signed_bounds gives both unconditional directions for any original
count3+ support, with ONE explicit phaseEnergy/profileEnergy cost and no
adjacent variation or arithmetic-mean assumption. phaseEnergy_union and
joined_cost_squared_saving retain the exact cross-population term.
all_populations_cost_le proves that joining a finite disjoint partition
costs no more than separate prices under the SAME endpoint/profile/weight.
This is NOT comparison with different former owner-coordinate costs and
does not assert orthogonality or a source-scale bound.

eventually_joined_funded_phase_floor joins the entire published retained
ledger, INCLUDING its original funding debit. The signed label multiplier
is1_H+a*1_Paid+b*1_tail-debit*1_supply, where a,b recover precisely the old
global positive-part credits. Overlapping supply/paid labels retain BOTH
original coefficients; no extra credit is introduced. Every count, owner,
bin, period and funding cross-correlation is assembled before the square.
The SAME funding witness and vanishing error give
Re(sourceScaled joinedPhysical)>=-negativeCost-err. negativeCutoffs selects
only adverse COMPLETE prefix increments AFTER joining every signed label
and its funding. Favorable complete increments are uncharged. The checked
negative_cost_le_full makes this cost uniformly no larger than the same
full phaseEnergy/profileEnergy price; no upper-bound strength is required
for the floor. The combined cost is UNPAID at source scale. No numerical-79/1000 floor,
fixed exponential saving, new paid population or zero exclusion follows.

Many-bin occupancy is not weighted anti-concentration and does not imply
independent frequencies. Preserve every previous no-go, including the
owner-variation majorant lower bound; the new branch avoids that allowance
but does not prove the original comparison error small. Do not declare
floor estimates1–5 closed by this energy bound.

The optional actual-integer regression samples orders4..6 and all counts
on its finite support at heights0,54,65,100, joining counts before the
square. Its11N/8 length is NOT the rounded moving length; allocation is
exactly zero at these orders. It is NOT the actual unpaid count56+ core,
an interval certificate, source-scale saving or numerical floor credit.
See docs/zeta-riesz-rejoined-phase-floor.md and its eighteen-public-proof
audit. Keep the probe outside ordinary CI. Continue locally without
subagents, commits, pushes or wider publication gates; preserve public
README/default explorer endpoints and all unpaid terms.

### Actual-prefix coherence audit (local)

`ZetaRieszPrefixCoherenceAudit` proves ten public results on the EXISTING
prefix energy and one-sided cost. Every actual label has sharp(1,n)=1;
rough selections retain the same signed common moment through all cutoffs
below their least prime. phaseEnergy_coherent_lower retains that moment,
including phase/allocation/masks/funding, before squaring. With cutoff one
active, any diagonal label-energy bound valid for EVERY weight requires
coefficient at least the label population size. This is an obstruction to
automatic diagonalization, NOT proof that actual carrier weights cohere,
NOT a refutation of a fixed-height arithmetic large-sieve bound and NOT
a floor obstruction. No common roughness threshold is inferred for H.

negativeCost_one_lower is only a necessary condition for the EXISTING
sufficient one-sided cost criterion. constant_projection_pairing proves
that equal profile endpoints allow exact subtraction of a constant prefix
component. The optional actual-integer projection test uses generic orders
4..6, test length11N/8 and heights54,65,100. Full-cost reduction is at most
0.243%; the one-sided price can increase. Do not infer an asymptotic rate
or reject all projected-energy arguments from this finite probe. It is not
the actual unpaid count56+ support or funding witness and runs outside CI.

The fixed-order weighted multiplicative-sum literature checked in this
slice is not directly a moving-order literal-mask estimate. All funding
and the -79/1000 floor remain unpaid at source scale. No new population,
floor/ceiling or zero exclusion is proved. See
docs/zeta-riesz-prefix-coherence-audit.md and its ten-proof audit. Continue
locally without commits, subagents or wider publication gates; keep every
previous positive result and no-go and leave public endpoints unchanged.

The Gamma-joint batch above is now published at
`dd411aa7372438e2e7b7f7e5acf5cb3d6c01c92e`; exact-SHA CI run
`36689789816`, Pages and published desktop/mobile checks passed. That
publication is complete. The user has now explicitly requested committing
and pushing all accumulated joined-physical/cutoff-floor work. That batch
has now been published as `f0151a4fb125bd0db52f0fe1bc6f029c22235d1d`;
exact-SHA CI run `36701400722`, Pages and published checks passed. This
publication request is complete. Continue locally, with focused Lean and
axiom validation; the user deferred wider checks during floor iteration.
No subagents or further commits are authorized by that completed request.

`ZetaRieszJoinedPhysical` gives the exact arbitrary-multiplicity source,
conditional floor/ceiling contradictions, the unsaturated two-hinge full
core and a geometric boundary payment. `ZetaRieszPhysicalCellFloor` only
TRANSFERS an explicit unproved one-sided 1/10000 cell saving; it does not
prove that saving. `ZetaRieszSaturatedCoreFloor` evaluates primary/secondary
saturation and a signed prime prefix. `ZetaRieszJoinedPrefixFloor` spends
these new savings only on the exact unpaid remainder of the strongest
existing radial ledger. Preserve all prior payments, the optimized
seven-prime charge and the unspent **1/64** supply. On its specified
seven-prime short-cutoff geometry at least 75% of that sector's old charge
is removed. This is NOT a global deficit percentage. The cofinal
-79/1000 floor, 3/2 ceiling and any new zero exclusion remain open.
Keep the actual-prime regression optional and outside ordinary CI. See
`docs/zeta-riesz-joined-physical.md`. The preceding explorer default followed the exact source of joinedPhysical;
its compensated-floor endpoint remains available and states the unevaluated
aggregate with the original masks and phase. The new default is specified
in the publication instruction above.

The next local slice, `ZetaRieszPairChamberFloor`, sums the unit, prime and
prime-pair divisor channels together when every prime log lies between
`(log n-L)/3` and `(log n-L)/2`. The affine coefficient is exact for all
counts on that geometry. Its signed charge is intersected with BOTH prior
charges on the same unpaid label. On the seven-prime box
`2 log n/15 <= log p <= 3 log n/20`, `2 log n/3 <= L <= 7 log n/10`,
the old prefix saving is proved ZERO and the new saving returns at least
one quarter of the optimized seven-prime charge for every phase.
`eventually_joined_floor` preserves all older radial payments and the
unspent 1/64 supply. This is a sector saving, not a quarter of the global
deficit or a cofinal floor. The optional actual-label probe stays outside
CI. The remaining signed aggregate, numerical floor, ceiling and RH are
open; keep the published explorer endpoints and top-ten lists unchanged
until the next authorized publication.

During the earlier floor iteration, the user deferred publication and
wider checks. That hold is superseded by the latest publication request above.
`ZetaRieszSignedPeriodFloor` proves an actual signed prime-period floor
throughout the linear radial core. Keep the convex radial drift favorable:
the exact centered cosine integral is minus the second derivative averaged
against `1+cos`, divided by `y^2`. Negative factorial curvature costs only
`(N+1)/T^2`; the actual-prime endpoints have an inverse-square log cost.
The literal allocation and BOTH cofactor cutoffs survive the transfer.
`population_floor` bounds every fixed-count, sign-aligned complete-period
population by `-C_k*v^(-1/2)` times the existing radial unit, and
`eventually_core_aligned_floor` discharges the moving length and physical
owner-prime mask. `owned_subset_core` checks the literal core inclusion.
This is a relative payment, NOT source-scale decay or the whole numerical
floor. Unaligned/clipped periods and integration with the exact unpaid
remainder still need bounds; do not double spend radial supplies or the
older pointwise savings. Keep count-dependent constants explicit, retain
all missed labels, and do not claim a global deficit percentage. Focused
root-import axiom/lint checks suffice during this local iteration.

`ZetaRieszStaggeredFloor` removes the frozen-sign restriction from the
complete-period payment. It splits the actual arithmetic coefficient into
its positive and negative parts, keeping the cosine phase signed. The
positive part uses negative-peak periods and the negative part positive-peak
periods. Positive-part clipping is 1-Lipschitz, so the original response and
allocation variation constants suffice even across coefficient sign changes.
`signedPart_population_floor` keeps the same explicit `C_k/sqrt(v)` radial
debit; `eventually_core_part_floor` retains the original physical primes and
moving length. `eventually_staggered_floor` sums a growing finite collection
of both grids with exact, separate unmatched sign parts. The grids may
overlap in integer labels because `signedPart_add` recovers one original
atom, not two. Within each grid, unique ownership and half-open log periods
prevent reuse. `joined_two_cover_floor` transfers these payments to the
existing `joinedPhysical`, retaining its proved geometric core error.
Through total prime count 55, `missing_population_boundary` isolates the
interior geometric omissions: `log a <= (203/500)*(log(pa)+1/16)` or a
cofactor prime with `log p-log q < 1/8`. This does not pay either boundary,
clipped radial periods, or growing counts. Selecting the original unpaid
set protects earlier credits; do not claim those mask exclusions have been
covered automatically. The accumulated cost still needs comparison with
unused positive supply, so no whole cofinal floor or source-scale decay
follows yet. Continue local floor iteration with focused validation only.

`ZetaRieszOwnerTieFloor` pays one of those explicit boundaries. For a
squarefree label of count 3..55 in `(v-1/16,v+1/16]`, two largest prime
logs less than 1/8 apart lie in one fixed length-1/4 prime-log window
after deleting them. Actual reciprocal prime estimates give two inverse
radial factors. Retaining the least-prime coefficient weight then gives
`close_owner_norm_bound` with `tieConstant k/v` radial debit, and
`bounded_count_norm_bound` assembles the ENTIRE count 3..55 boundary using
one explicit finite `allTieConstant`. `signedParts_abs_eq` proves both
arithmetic-sign omissions cost one atom, not two. The moving-core norm
and signed estimates have arbitrarily small relative radial debit;
`joined_two_cover_floor_with_ties` removes the selected boundary from both
unmatched parts of the existing joined floor. Growing finite boundary
covers are paid by `eventually_core_grouped_tie_floor`; overlaps enlarge
only the boundary allowance. This does not pay the lower cofactor-share
edge, clipped radial periods, prior-credit fibre holes, or growing prime
counts. No source-scale decay or numerical whole floor follows. Keep the
original phase/allocation/masks inside the literal subset being paid,
and continue local floor work without publication gates or subagents.

`ZetaRieszRoughFivePeriodFloor` applies that mechanism to the actual
unpaid five-prime sector. Freeze a squarefree four-prime cofactor and run
its unique largest prime through a complete period. Filtering the cofactor
by `p>B` for every factor preserves the entire owner fibre. If
`B>=max(Q,V)`, the original positive/negative small-prime five-factor heads
cannot clip it; every other spent class has a different prime count.
`roughPeriod_subset_unpaid` proves this exclusion from the ENTIRE prior
credit union. `eventually_unpaid_rough_five_floor` also proves original
dyadic core inclusion, then applies both staggered arithmetic-sign floors
to growing finite grids. It retains both exact unmatched parts, every
old credit, moving length, physical owner mask, allocation and phase.
The debit is arbitrarily small relative to the SUMMED radial units, not
an asserted source-scale error. The next checked estimates now PAY that
debit on complete radial slabs. `period_card_bound` gives a finite
height-dependent packing bound on both grids, and
`eventually_period_debit_paid` compares their summed units with the actual
four-prime supply. `exists_period_debit_supply` proves the needed elementary
phase window exists. `eventually_unpaid_rough_five_supply_floor` removes the
period allowance in each slab; `eventually_radial_rough_five_supply_floor`
aggregates growing disjoint slabs with at most 1/128 of ONE radial supply.
The latter keeps the original supply phase condition explicit.
`eventually_joint_slabs_floor_with_period_budget` reuses the earlier
quantitative supply-selection construction, chosen widths and head/tail
estimates: all six old norm charges plus the new period allowance total
at most 127/128 of that SAME supply, leaving 1/128 unspent. No compatibility
of separate existential supply choices is assumed. The endpoint has not
yet replaced the public joinedPhysical ledger; preserve all older credits
and geometric edge payments when lifting it. Nonrough unspent labels,
the lower cofactor-share edge and clipped endpoint periods remain.
These fractions concern the proved positive supply, NOT the whole source
deficit or a new numerical floor. The owner-weight variation bound of two is a
transfer lemma for an independently proved partial-sum bound; it is not
itself an unconditional carrier floor. No numerical floor, ceiling or
zero exclusion follows. Continue focused local validation only.

`ZetaRieszRoughFiveJoinedFloor` now lifts that checked cost into an actual
whole `joinedPhysical` inequality. `eventually_core_floor_with_scale` and
`eventually_core_full_floor_with_scale` keep the SAME quantitative supply
selection through every old charge and the geometric whole-tail payment.
`period_grids_cost_paid` spends at most 1/128 of that original radial supply
on both growing grids, without a separate supply phase hypothesis.
`eventually_joined_floor_with_rough_periods` replaces only the period-covered
parts of the unpaid five-prime sector by its exact two unmatched sign parts.
All six old favorable credits, the >=7 optimized charge, prefix/pair savings
and geometric core/joined errors remain. Half the former unspent 1/64 is
actually spent on this new cost; 1/128 remains unspent. Cells assign period
CENTERS in half-open slabs: the signed periods may cross slab boundaries,
so this estimate introduces no repeated internal clipping. Their full
literal core support is retained. The parameters and starting order may
depend on the fixed height y>=54. No new numerical floor, source-scale
packet decay, ceiling or zero exclusion follows. Nonrough labels, the
lower cofactor-share transition, close owners and exterior clipped periods
still need their signed coverage/payments. The earlier dominant deletion
already pays cofactor shares <=399/1000; the current complete-period
population starts above 203/500=406/1000, so do not rediscover the already
paid portion when addressing that transition. Keep published endpoints
unchanged and continue focused local validation without commits or subagents.

`ZetaRieszTransitionFiveFloor` extends the literal signed period selector
from cofactor share >203/500 to >199/500 with owner cap 1209/2000, still
inside every original core/physical mask. Every earlier rough period is
included. `transition_mem_roughPeriod` covers the entire rational
399/1000..407/1000 transition without a sign or close-owner assumption;
its whole-floor endpoint uses the SAME count-dependent debit and supply.
`ZetaRieszFiveSignCoverFloor` retains the two original small-prime
thresholds separately: positive parts use Q, negative parts V. Opposite
spent five-prime heads contribute exactly zero to that arithmetic part,
so intersecting a complete period with the unpaid set loses nothing.
`eventually_joined_floor_with_signed_rough_periods` keeps all earlier
credits, higher-count prefix/pair savings, geometric errors and the
remaining 1/128 supply, with no additional period cost. In the retained
radial interior, `unpaid_positive_rough`/`unpaid_negative_rough` give the
appropriate roughness of every nonzero sign part. The exact
`transition_*_zero_or_covered` theorems therefore eliminate the transition
and max(Q,V) omissions together. Do not reintroduce a common threshold
or charge an opposite-sign head twice. Deterministic global cover selection,
exterior clipped periods, close owners outside the transition and the
other signed unpaid sectors remain. The numerical floor, ceiling and
zero exclusion remain OPEN. Continue locally without commits, subagents
or wider gates.

The next checked endpoint, `ZetaRieszFiveSignCoverFloor.eventually_joined_floor_without_fives`,
pays the ENTIRE original unpaid count-five sector in that same whole floor.
`owner_gap_mem_roughPeriod` extends coverage to every cofactor share above
399/1000 with owner-log gap at least 1/8, without an upper-share restriction.
`completeGrid`/`slabGrid` are deterministic half-open phase grids; centres
are assigned once and periods crossing internal slab boundaries are retained.
`interior_parts_covered` proves every nonzero unpaid sign part outside the
already-paid eligible dominant sector is covered unless the owner primes are
close. `exists_unpaid_five_floor` joins the signed period estimates, one
close-owner debit, the existing dominant-allocation decay and the existing
outer radial deviation payment. It has NO unmatched five-prime term.
The same quantitative original supply pays the combined period/tie cost,
not an independently selected supply; all six older favorable credits,
higher-count savings and source-geometric errors survive, and 1/128 remains
unspent. The new remaining W is only E\E5. This is NOT count-five source
norm decay: the debit is paid from the actual positive four-prime supply.
The signed remainder at counts 3,4,6 and >=7, its cofinal -79/1000 floor,
ceiling and zero exclusion remain OPEN. Do not restore common max(Q,V)
roughness, clipped internal slabs, or an already-paid five-prime allowance.
Continue locally with focused Lean/root-import axiom/lint validation only;
no commits, subagents, wider checks or published endpoint changes.

### Rejoined triple and six-prime payment (2026-09-30, local)

`ZetaRieszSixSignCoverFloor.eventually_joined_floor_without_fives_or_sixes`
pays both originally unpaid counts five and six from the SAME original
supply, retaining 1/128. Both signs of an interior unpaid six-prime label
are P-rough, because its old small-prime head is independent of sign.

`ZetaRieszThreeSignCoverFloor.eventually_joined_floor_without_triples_fives_or_sixes`
goes further. Rejoin the old balanced triple band BEFORE the complete-period
estimate. `tripleRestSpent_eq` proves that no other spent class is restored;
`nontriple_rest_filter_eq` retains exactly the original unpaid five/six sets.
The balanced-triple half-supply norm debit is refunded, changing the
available supply from 1/64 to 33/64 before the combined period/tie cost.
The final SAME-supply reserve is 65/128. The old balanced-triple max credit
is consumed by this recombination; all other favorable credits and the
higher-count reflection/prefix/pair savings remain. This is a funded signed
floor improvement, NOT source-norm decay of those separate counts.
`remaining_count_cases` proves the main remainder consists only of count
four or counts at least seven. Source-geometric errors still tend to zero.

`ZetaRieszFourSupplyAudit` checks why count four needs different bookkeeping:
the positive supply itself is rough, count four and negative in arithmetic
coefficient. Some spent supply label has a strictly positive negative sign
part, so the count-five opposite-head zero-intersection argument cannot be
copied unchanged. Joining a remaining four-prime sum to that supply leaves
the exact 63/128 supply debit after spending its retained 65/128 credit.
This audit is not a general no-go for four-prime cancellation. Do not count
the supply twice or claim the four-prime sector is already paid. The direct
numerical floor and ceiling remain OPEN. Keep the public explorer endpoints
unchanged during local iteration; regenerate assets only at publication.

`ZetaRieszHighSignCoverFloor.eventually_joined_floor_without_fixed_counts`
now pays the entire unpaid count band 7..55 jointly with counts 3,5,6.
`exists_unpaid_high_floor` reuses the complete-period and close-owner
machinery at every fixed count; `exists_unpaid_band_floor` joins the 49
inequalities before charging ONE radial budget. Only count seven uses its
original R-rough head. Counts 8..55 retain all cofactors; do not impose R
roughness on them. All four grouped costs share the same 1/128 supply debit,
so 65/128 remains. The positive real part of the entire paid band is also
retained as one joint max credit. `high_rest_filter_eq` checks compatibility
with the triple refund. The main remainder is now count four or count >=56;
the existing reflection, prefix and pair savings remain on that remainder.
Do not keep separate credits for already-paid count 7..55 labels.
The finite-count constants and starting order are unevaluated. There is no
growing-count estimate: the band >=56 remains open below the existing
logarithmic count-tail threshold. This is still a funded signed floor
improvement, NOT the numerical -79/1000 floor or a new zero exclusion.
Keep local, focused validation and the four-supply overlap audit in force.

`ZetaRieszFourPositiveFloor.eventually_joined_floor_with_negative_fours`
also pays the entire positive-arithmetic-coefficient part of the unpaid
four-prime sector. The original supply has strictly negative arithmetic
coefficient, so its positive sign part is exactly zero; its intersection
with a complete positive-sign period may be removed exactly. The original
small-four threshold Q, allocation and phase remain literal. Five grouped
payments share ONE Y/128 debit, retaining the SAME 65/128 credit. The
remaining low-count labels have count four and nonpositive arithmetic
coefficient; other remaining labels have count >=56. Positive arithmetic
coefficient does not imply positive real contribution: the phase is kept.
Focused warnings-as-errors compilation, root-import lint and all public
transitive axiom checks pass. The numerical floor remains OPEN.

`ZetaRieszFourSmallFloor.eventually_joined_floor_with_balanced_fours`
further pays the negative-arithmetic four-prime labels containing a prime
with `log p <= 2N/5`. `supply_prime_log_gt` derives the strict opposite
inequality for EVERY original supply prime directly from its literal
boxes. `smallPrime_mul_iff` and `roughPeriod_eq_filter` keep this condition
on the fixed cofactor throughout the complete largest-prime period, so
there is no clipping or overlap debit. The positive four-prime part and
this negative part share one arbitrary period budget before joining the
other fixed counts. The SAME 65/128 supply and the joint favorable max
credit remain; only the already geometric boundary allowance is added.
`remaining_effective_geometry` proves that nonzero low-count remainder
labels have count four, negative arithmetic coefficient and ALL prime
logs >2N/5. Other nonzero main labels have count >=56, below the original
logarithmic tail payment. No independent numerical bound for either
remaining sector, and no -79/1000 floor, has been proved. Continue locally;
do not replace this supply budget by a percentage of the endgame margin.
Both new four-prime modules pass focused warnings-as-errors compilation,
the rebuilt root import, namespace lint and every public theorem's
transitive axiom audit (standard logical axioms only).

`ZetaRieszLowCountRefund.eventually_joined_floor_with_refunded_heads`
now rejoins ALL former small-prime heads before the signed-period payment.
The existing estimates are uniform in the old head thresholds, so use
Q=P=V=R=0 and eta=0. `smallTriples_zero`, `smallFours_zero`,
`smallPositiveFives_zero`, `radialHeads_zero` and `tailCondition_zero`
check that only the logarithmic count tail remains charged. The carrier,
physical prime support, allocation and phase do not change. The same
original four-prime supply retains 63/64 before the combined period cost,
and **125/128** after it, improving the previous 65/128. Former individual
head max credits are consumed into ONE joint paid-band max credit; do not
add them again. Every geometric boundary error remains in the theorem.
`refunded_four_supply_debit` proves that joining the remaining fours back
to this supply now leaves exactly **3/128** of it unpaid, rather than
63/128. This is not a payment of that debit or a percentage of the numerical
endgame margin. `remaining_effective_geometry` leaves negative-arithmetic
count-four labels with every prime log >2N/5, or counts
56 <= omega(n) < 8*Nat.clog 2 (N+1). No numerical bound for this remainder
has been proved. The cofinal -79/1000 floor, ceiling and zero exclusion stay
OPEN. Focused module/root warnings-as-errors, namespace lint, all thirteen
public theorem axiom checks and whitespace/placeholder checks pass. Keep
this local; publication assets/default endpoints remain unchanged.

`ZetaRieszSharpSupplyFloor.eventually_joined_floor_with_arbitrary_debit`
now keeps the actual charges, rather than rounding them to 3/128 of supply.
The SAME supply width h and lower constant c are chosen before the period
budget epsilon. For every fixed epsilon>0, the whole joined floor retains
`(1 - epsilon - tailCost c N)*Y`, with all earlier joint favorable credits,
reflection/prefix/pair savings and source-o(1) errors. Here
`tailCost c N = 512*exp(4)/(c*(N+1)^4)`.
`ZetaRieszLowCountRefund.radial_tail_sharp_cost` proves this tail payment
for the literal selected labels using the same supply lower bound, and
`tendsto_tailCost` proves its relative decay. The five grouped complete-period
payments cost epsilon*Y jointly. The additive error and starting order may
depend on epsilon; DO NOT substitute an N-dependent epsilon without a new
uniform estimate. `joint_supply_debit` retains the exact unpaid
`(tailCost c N+epsilon)*Y` when four-prime supply labels are rejoined.
`eventually_relative_debit_lt` removes any fixed positive relative-charge
threshold, but neither this nor tailCost->0 implies source-normalized
smallness after multiplying by Y. No independent absolute floor for balanced
negative fours/growing counts, no -79/1000 bound and no zero exclusion is
proved. Do not continue spending slices on successively smaller fixed
budget fractions: that bookkeeping is now exhausted. Further improvement
must control the signed remainder jointly at the required source scale.
Keep local focused validation; public endpoints and publication assets stay
unchanged.
Both affected modules and the rebuilt root import pass warnings-as-errors.
Root-import namespace lint and all 21 public theorem transitive axiom
checks pass (standard logical axioms only); JSON, placeholder and whitespace
checks pass. No commits, subagents or wider publication gates were run.

`ZetaRieszWholeFixedCountFloor.exists_core_band_floor` now applies signed
largest-prime periods to the WHOLE literal core at every count 3..55,
including all original four-prime supply labels. It joins both arithmetic
signs and all 53 count classes before the bound. The full phase, allocation,
physical masks and coprimality are unchanged. For every FIXED epsilon>0,
the cost is `u^(N+1)*epsilon*periodUnits N y`, plus a source-normalized
error tending to zero. Constants and starting orders can depend on epsilon;
this is not an exponential source-scale payment.

`ZetaRieszRejoinedSupplyFloor.eventually_joined_floor_with_growing_counts`
integrates that bound into the same joinedPhysical floor. The entire
four-prime supply is rejoined before estimating and survives only as the
explicit debit `(tailCost c N+epsilon)*Y`; there is NO separate positive
supply credit to reuse. The joint favorable fixed-band max credit,
radial-tail max credit and the higher-count reflection/prefix/pair savings
remain. `remaining_effective_geometry` proves that every nonzero main
remainder is squarefree with
`56 <= omega(n) < 8*Nat.clog 2 (N+1)`. The earlier alternate floor retaining
a positive supply and balanced negative fours remains available; neither
bound is asserted to dominate the other.

Next work must control the growing-count signed contribution TOGETHER
WITH this explicit debit at source scale, or prove an effective signed
period rate that pays the debit absolutely. Removing fixed counts from
the main support does not make their cost free, and polynomial relative
savings do not imply the cofinal -79/1000 floor. That floor and the zero
exclusion remain OPEN. Keep local, without commits, subagents or wider
publication gates. Register the two new modules by family without changing
the published explorer endpoint.
Both new modules, their rebuilt root import and root-import namespace lint
pass warnings-as-errors. All twelve public theorem transitive axiom audits
pass with only the standard logical axioms. Family metadata is registered;
the published endpoint and generated publication assets are unchanged.

`ZetaRieszOwnerCurvatureFloor` now joins the literal selected binomial orders
to the radial factorial amplitude before differentiating. Its exact
`selectedAmplitude_ownerWeight` and `selectedAmplitude_eq_fibre` identify
the complement of unpaidOrders with the original retained largest-prime
allocation. Every selected order, including zero and one, remains.
`selectedAmplitude_curvature_floor` bounds negative joint curvature by
`-(N+1)*amplitude N T/(T*(T-b))`; no separate allocation derivative or
square-root allocation variation is charged. `selected_prime_period_upper`
and `selected_period_floor` are signed inequalities for literal finite
ordinary primes with the explicit inverse-square endpoint/discrepancy
cost retained. They do not yet change the whole joinedPhysical ledger.
Next integrate the bound with the actual two-hinge response, then control
its remaining signed cost across periods and the growing-count band at
source scale. Do not call this local inequality the -79/1000 floor or a zero
exclusion. Continue locally without commits, subagents or wider checks;
register its family without changing published endpoints.
The module and rebuilt root import pass warnings-as-errors. Root-import
namespace lint and all nine public theorem transitive axiom checks pass,
using only the standard logical axioms. Family metadata JSON, the new-module
placeholder/axiom scan and tracked whitespace checks pass. No publication
gates, commits or subagents were run.

`ZetaRieszJointOwnerFibreFloor` applies the joined owner-factorial kernel to
the LITERAL two-hinge coefficient, retaining arithmetic sign parts,
coprimality, unique ownership, ordinary primes, phase and moving length.
`owner_signedPart_fibre_floor` freezes only the cofactor response. Its
variation uses the already-proved quarter slope and actual half-period
pi/y, giving `2^k*pi/(4*y)` rather than the old `2^k` cost. At y>=54 this
is at most 1/64 of that local cutoff charge. The radial budget keeps the
same coarse 200000 curvature/endpoint coefficient, drops the separate
allocation sqrt(N) term entirely, and replaces the cutoff coefficient
400 by 25/4. DO NOT call this a 64-fold reduction of the whole floor deficit.
`literal_signedPart_population_floor` transfers the signed cofactor
population bound to the ORIGINAL allocation using one global geometric
nonowner error. `signedPart_owner_difference_bound` retains the exact
coefficient-sign indicator and works with arbitrary literal label masks;
do not charge a nonowner error per cofactor. `eventually_core_signedPart_floor`
discharges the moving length, owner-prime support and literal radial window.
The remaining explicit population cost is
`200000*responseConstant k*logMassConstant k/v +
(25/4)*2^k*variationConstant k*v^(-1/2)` times the source-scaled radial
unit, plus a geometric error. Count constants and eventual thresholds
are not uniform in a growing k, and the upper cofactor-share cap still
belongs to cofactors k v. This does not close the source-scale period
debit, cover every growing-count geometry, or prove -79/1000.
Continue local signed floor iteration without commits, subagents or wider
checks. Published endpoints stay unchanged.

The module and rebuilt root import pass warnings-as-errors. Root-import
namespace lint and all ten public theorem transitive axiom checks pass
with only `propext`, `Classical.choice` and `Quot.sound`. Family metadata
JSON, the new-module placeholder/axiom scan and whitespace checks pass.

The user now requires every subsequent slice to attack the GLOBAL gap
concretely. A local constant improvement, fixed-count extension or
polynomial relative debit alone does not meet that requirement. The
target is the combined source-normalized growing-count contribution and
period/tail debit in
`ZetaRieszRejoinedSupplyFloor.eventually_joined_floor_with_growing_counts`.
Retain the original signs, allocation, masks and phase while summing
counts and complete periods. A useful next theorem must establish a
global signed saving/payment at source scale, or a quantitative obstruction
to the specific proposed global mechanism. Do not count a representation,
an assumed numerical floor, or another positive polynomial majorant as
closing this gap. The numerical `-79/1000-o(1)` floor remains OPEN.

`ZetaRieszGlobalDebitAudit` now tests that GLOBAL debit directly.
`periodUnits_saddle_lower` proves an actual complete-grid saddle lower
bound. `polynomial_periodDebit_tendsto` rules out source-scale payment
of ANY fixed inverse-polynomial charge of these shared period units.
`combined_supplyDebit_lower` proves that the actual tail-plus-period
debit is at least
`(128*u*exp(1)/(3*(floor(2*y)+1)))*(2*u)^N/(N+1)^5` for every supply
with the already-proved slab capacity, even with a moving nonnegative
extra period allowance. The unknown capacity c cancels EXACTLY.
`actual_combinedDebit_unbounded` discharges that capacity for the literal
arithmetic supplies at the current cofinal orders: the displayed debit
exceeds every fixed source-scale budget. No zero hypothesis is used.
This does NOT show that the signed tail or joinedPhysical diverges, nor
that compensation by the other signed terms is impossible. It closes the
strategy of paying this global debit on its own by smaller constants or
polynomial rates. Do not treat the logarithmic count tail as an independent
source-o(1) payment. The next estimate must join its actual signed
contribution to the growing-count remainder and retained low-count terms.
Do not return to fixed-count extensions or another polynomial relative
cost in place of that global signed estimate. Floor and exclusion remain
OPEN. The user's subsequent publication request authorizes committing
and pushing this entire accumulated local batch, with its required
publication gates and refreshed explorer. It does not authorize subagents.
Further proof iteration remains local until another publication request.

The accumulated thirteen ordinary-root modules pass the warning-as-error
build. The new GlobalDebitAudit root-import namespace lint and all eight
public theorem transitive axiom checks pass with only `propext`,
`Classical.choice` and `Quot.sound`; compiled project-status integrity
also passes. Publication advances the main RH explorer to
`ZetaRieszRejoinedSupplyFloor.eventually_joined_floor_with_growing_counts`,
with its explicit unpaid debit. Keep the GlobalDebitAudit no-go as a
separate supporting endpoint. The new endpoint is not the numerical floor.



The accumulated batch was subsequently published at
`d96fd09849a606c28cb51683d1aa6807b6a75cbd`; exact-SHA CI run
`36671402701` and Pages deployment passed. Its publication request is
complete. The user has now explicitly authorized committing and pushing
the completed selected-resonance slice, which was published at
`1ca9e93abc7b5956cefd705a404c7cb24473694e`. Exact-SHA CI run
`36677567840`, Pages deployment, the published README renderer and all three
published explorers passed. That publication request is complete. Preserve
the default source frontier and both open joint arithmetic bounds. Further
research remains local until another request.

The current continuation joins the Gamma rectangle with the signed rest.
`ZetaRieszGammaCollapse` cancels the marked Gamma normalization exactly,
proves the three-slot factorial sum equals the ORIGINAL finite rectangle
mass, and puts the entire selected response inside one physical integral.
No limiting rectangle or independent Gamma approximation is used.
`ZetaRieszAllCountBoundary.physicalCofactor_eq_eulerBoundary` joins EVERY
nonempty middle-prime subset into a single finite Euler-boundary response
per least prime, including the exact empty-middle subtraction. The
identity commutes with all signed Taylor orders, including zero; no
infinite Euler product, Dirichlet completion or termwise norm is used.
`ZetaRieszGammaComplement.selection_eq_continuous` identifies the CURRENT
literal selection with those same three coordinates throughout fullBand;
`selection_complement_eq` gives its exact factorial complement.
On saturated composite cofactors the unshifted hinge is exactly zero,
so `rest_physical_ledger` uses the same translated cutoff and retains the
old allocation, phase, masks, and exact unmatched boundary. The
`joint_matched_ledger` displays full physical mass plus that boundary and
the selected response minus the MATCHED literal rectangle. The latter
is a signed marked-prime measure discrepancy, NOT a paid error.
It retains any allocation, Euler-power and support differences not
already transferred; do not describe it as a bare prime-density error.

Completing the marked Gamma orders gives mass one MINUS the marked
order-zero boundary. On literal marked shares at least 1/3,
`zeroOrder_literal_bound` pays this boundary by
`(9/10)^N*zetaMoebiusLogMajorantMass(9/8)`, uniformly in height and finite
masks; `tendsto_zeroOrder_literal` proves source-o(1). This does NOT
remove low middle orders or pay a virtual-prime zero-order boundary.
Do not infer virtual/literal transfer from Theta+(1-Theta)=1.
The optional finite mask-model probe keeps its scope explicit: it is
not the complete coreResponse, a zero-phase computation or an asymptotic
certificate. Both joint floor/ceiling remain open. See the appended
Gamma/count/complement audit in `docs/zeta-riesz-selected-gamma.md`.
The user has now authorized committing and pushing this completed
Gamma/count/complement slice. Publish the complete green local batch,
including the following joint recombination theorem and its audits.
No subagents are authorized. Record exact-SHA CI and Pages results.

`ZetaRieszGammaJoint` now pays the UNSATURATED SELECTED boundary by
`2*(19/20)^N*zetaMoebiusLogMajorantMass(257/256)` for `L>=11N/8`,
uniformly in height. Unsaturation forces largest share below 1/3 and
count at least four; the literal factorial rectangle then has an
independent exponential tail. The actual `J+C` is source-equivalent to
full factorial mass on `saturatedBand` plus the unchanged signed rest
outside it (`joinedPhysical`). `tendsto_shifted_joint_sub_joined` keeps
the COMPLETE shifted response under the original exposure hypotheses,
with no simplicity assumption. `selected_discrepancy_eq_joint` shows
that the old selected-to-literal discrepancy plus the remaining shifted
channels is precisely this paid joint error. Do not claim separate decay
of either channel, and do not equate selectedResponse alone to J. The
unselected boundary is NOT paid by the rectangle-tail estimate. The
independent signed floor/ceiling for the full physical sum plus that
boundary remain open; the source frontier is unchanged.

The preceding explicit steer authorized exact Laplace/Fourier inversion of
the selected shifted resonance before seeking a signed inequality.
`ZetaRieszSelectedGamma` proves the positive Gamma probability kernel and
its exact complex transform. `ZetaRieszSelectedPhysical` proves genuine
product-space integrability and the fixed two-prime ordered-quotient atom's
positive Gamma/tent formula, retaining its complex Euler coefficient.
`ZetaRieszSelectedCofactor.selectedResponse_eq_gamma_average` applies the
exact inversion to the whole finite selected rectangle. The finite subset
expansion keeps the Euler denominators, least-prime ordering, all factorial
orders, both frequencies and original prime set. Empty middle subsets
vanish only because the literal complementary order is positive.
`joint_real_eq` keeps arbitrary multiplicity and an unchanged signed
complement. Its prefactor is NEGATIVE: a lower bound for the carrier needs
an upper bound for this physical average relative to the complement.
Gamma positivity is not positivity of the complex arithmetic sum. The
optional probe checks the fixed atom and shows mixed signs across counts
and heights on a small finite prime set; those heights are not asserted
zeros and the probe is not a cofinal estimate. See
`docs/zeta-riesz-selected-gamma.md`. No independent joint floor/ceiling,
source decay, or new zero exclusion follows. Preserve every previous
negative audit and do not norm-pay the selected mode.

The prior cofactor-discrepancy batch was published at
`190a26f44ca4d4d2b8e30168dae763e6c6d42464`; exact-SHA CI run
`36622043917` passed. The later `d96fd09` publication includes the supporting
estimates and negative audits below; it does not discharge the joint signed
target. Both older publication requests are complete. The subsequent
selected-resonance publication is also complete. Do not use subagents.

The latest user instruction requires cancellation among the retained
central/resonant terms and the signed complement `C_j`, with a bound for
their COMBINED real contribution. Further exterior-mode payments or a
polynomial improvement to the positive `(2u)^N` envelope do not satisfy
this slice. Keep the literal `J_j+C_j` target and every original mask.
The exact `core_ledger` joins nonnegative fractions of each SAME atom;
it removes the artificial packet split but does not supply cancellation
within a label. The missing estimate must exploit signed correlations
across labels/cutoffs/counts. Neither the cofinal `-79/1000-o(1)` floor
nor the `3/2+o(1)` ceiling has been proved. Do not report a numerical
prime-density model or an unevaluated signed-energy cost as either bound.

The local `ZetaRieszSmoothOwnerDiscrepancy` supporting module proves an
`exp(-3N/100)` counting-comparison error for the exact smooth owner weight
on full composite cofactor shells, retaining the ordinary-prime subtraction
and full phase. Summing owner-prime columns costs only `sum 1/p`. Its scope
requires `cofactor < owner prime`, short divisor cutoffs and full shells;
the remaining core masks and geometries have NOT been paid by that module.
It estimates `literal shell - signed main`, not the signed main itself.
This does NOT satisfy the latest requested joint floor/ceiling milestone.
Include it in the ordinary root as supporting work, without a new public endpoint. See
`docs/zeta-riesz-smooth-owner-discrepancy.md`.

`ZetaRieszSharpShifted` also enters the ordinary root as supporting work.
Its exact `21N<=40j` rectangle share pays the additional separated shifted
sector at denominator radius `5001/10000`, with rate `999999/1000000`.
The signed resonance and arbitrary unchanged complement remain in its
two-sided comparison. This does not prove either whole-sum bound and does
not replace the current public endpoint.

The optional actual-prime boundary probe now joins `a<p` and `p<=a<2p`
on the actual core radial window, retaining the unsaturated second hinge.
At orders 14, 16 and 18 their real contributions reinforce; the density
and ordinary-prime terms partially cancel but show no proved decaying
rate. This is a limited numerical test, NOT a cofinal obstruction theorem
or the requested joint bound. Nonowner allocation, `a>=2p` and the full
count/mask bridge remain outside it. Do not build another owner-boundary
completion merely from these numbers. See the recorded scope and results
in `docs/riesz-signed-main-boundary-investigation.md`. Public frontiers
and the current theorem-push gate remain unchanged.

The preceding exposed spectral-gap work remains available:
`ZetaExposedMovingModes` bounds the finite competing direct-mode sum by
card(S.erase(-u))*C*(N+1)^d*(u/R)^(N+1), with a polynomial coefficient
budget and 0<u<R. Exposure supplies the strict gap; all multiplicities
remain. The complete prime-filter expansion retains the selected resonance
and the exact old pole/residual/reflected terms. Do not assert an arbitrary
moving filter inherits fixed-filter error estimates without a proof.
The profile factorisation keeps one signed density scalar times the signed
weight sum. Its exp(-N/32) comparison still requires weighted variation,
short cutoffs and exterior endpoint control. The joined ordinary-prime
WHOLE cofactor correction is zero after ONE marked prime; a singleton
middle prime after TWO marks instead has total count three. Do not confuse
these or complete away the marked weight. The masked spectral transfer,
its polynomial coefficient budget and the independent selected-resonance
floor/ceiling remain open. See `docs/zeta-exposed-moving-modes.md`.

`ZetaRieszExposedModeCoupling` now pays a concrete part of the actual
ordered-cofactor symbol: genuine local zeros at distance >=501/1000 on
|xi|<=1/2000. Its source-scaled paired Riesz integral is at most
2*farMass*couplingConstant*(N+2)^3*(9999/10000)^N. The rectangle,
cofactor total order, least-prime Euler product and both Fourier zeros
remain. The exact local principal-part ledger and
`tendsto_retained_sub_current` connect this payment to the unchanged
literal marked packet with all earlier paid errors. The selected mode is
proved outside this paid sector. This is NOT the entire complement:
closer competing modes, exterior frequencies and pole/regular terms stay
signed and unpaid. A tiny exposed gap alone need not beat the current
cofactor norm budget. Do not report this sector bound as either whole-sum
inequality or a zero exclusion. Keep local and without subagents.
See `docs/zeta-riesz-exposed-mode-coupling.md`.
The same batch also pays genuine LOCAL divisor modes with Re(tau)<=999/1000
on the ENTIRE Fourier axis. Horizontal separation survives every shift;
the joint small/large-frequency envelope is integrable. `reducedMain`
subtracts this full-axis component and the disjoint small-band sector for
the remaining zeros. `logMain_reduced_bound` gives
paidConstant(W,y)*(N+2)^3*(9999/10000)^N; the literal packet source ledger
is preserved by `tendsto_reduced_sub_current`. Both the finite integral
exchange and exclusion of the selected mode are proved. No infinite-divisor
payment or bound on the remaining signed main is implied.

`ZetaRieszCompletionPayment` now pays the FULL Gamma completion
contribution with the ordered cofactor and factorial rectangle retained.
The exact digamma recurrence gives height-independent derivative control;
joint small/large-frequency estimates give a genuinely integrable profile
on the entire Fourier axis. For N>=2, 0<=u<=10001/20000, arbitrary moving
height, L>=1 and finite prime sets with p>=16, its source-scaled norm is at
most pi*(couplingConstant+couplingMassConstant)*(N+2)^3*(9999/10000)^N.
No zero premise is needed. The integral subtraction is exact and leaves
the original zeta pole minus full xi derivative; no low cofactor orders
are discarded. `completionReducedMain` combines this with the disjoint
zero-sector payments. `tendsto_completionReduced_sub_current` retains the
unchanged literal packet and all earlier paid errors. The analytic xi
remainder from a local divisor is NOT the Gamma correction and remains
unpaid, together with the zeta pole, right-edge zero modes and their
unpaid frequencies. Do not call this an estimate for the selected
resonance or either whole-sum bound. Keep this work local, without agents.

`ZetaRieszUnshiftedPayment.quotientResponse_single_rate` now pays the
UNSHIFTED half of the existing marked principal part, including the
selected denominator z=-u. The exact finite character reindexing gives
the original composite cofactor hinge, which is zero below L. Its
complementary order is at most 19N/40+1, and the oversized-cofactor bound
is O(N^2*exp(-N/100)) for L>=11N/8 and 0<u<=10001/20000.
The singleton cofactor has exactly zero factorial weight. The actual
character-minus-quotient difference retains a second Fourier zero and
its full-frequency integral is independently bounded by
O(N^3*exp(-N/300)), using the original exponential rough-prime head.
`quotientResponse_eq` justifies this transfer with no unpaid completion
correction. All least-prime order, finite support, full phase and
factorial masks remain. Orders zero are not discarded. The combined
constant is explicit but large; no numerical starting order is claimed.
The physical support and moving Riesz length satisfy the hypotheses
eventually. `tendsto_selected_unshifted` includes every fixed analytic
multiplicity; `selected_principal_split` verifies the genuine zero sign.
`tendsto_selectedReduced_sub_current` preserves the original literal
packet and every earlier paid error. The correlated SHIFTED resonance
is not paid, and no independent whole-sum floor/ceiling or zero exclusion
follows. Keep pole/xi and all other remaining components signed. Continue
locally without commits, pushes or subagents. The proof and audit extend
`docs/zeta-riesz-exposed-mode-coupling.md` and its existing endpoint.

`ZetaRieszUnshiftedLogPayment` extends this payment to the COMPLETE
unshifted logarithmic-derivative contribution under the original exposed
right-half-zero hypothesis. `exists_normalized_mark_bound` discharges its
coefficient budget using the existing complete-moment theorem. The exact
finite-character saturation and full-frequency Euler correction then give
`exists_exposed_unshifted_bound`: C_rho*(N+2)^3*exp(-N/300) eventually on
the literal rough support and moving length. Every zero multiplicity, the
pole and regular channels remain included in this joint payment. No
simplicity, rightmost zero, infinite-divisor inversion or masked leg-limit
transfer is used. `logResponse_eq` proves the genuinely integrable split;
`tendsto_shifted_sub_current` leaves the negative SHIFTED full log moment
coupled to its original ordered cofactor, rectangle and Fourier phases.
It retains the original literal packet and all prior transfer errors.
Previous zero-sector and Gamma bounds remain available. The source-carrying
shifted expression is still unpaid: no whole-sum floor/ceiling, percentage
of source cancellation, or zero exclusion follows. C_rho and the eventual
starting order are unevaluated. Keep local, no commits, pushes or subagents.

`ZetaRieszGlobalHorizontal` extends the horizontal payment to EVERY
actual zero with Re(tau)<=999/1000, all analytic multiplicities and the
entire Fourier axis. Its mode bound retains 1/|tau-(3/2+i*y)|^2;
`globalResponse_bound` sums this with the existing global inverse-square
budget to obtain responseConstant*zeroMass(y)*(N+2)^3*(9999/10000)^N.
The height is fixed; no uniform bound on zeroMass(y) is asserted.
`globalPair_L1`, genuine integrability and `hasSum_globalResponse` justify
the integral exchange. `hasSum_xiDifference` and `logSymbol_split` identify
the negative principal parts through the convergent global xi DERIVATIVE
series. This is not the forbidden infinite-product inverse and uses no
reflected modes. The rectangle already forces marked order >=2; cofactor
orders zero and one are retained. No exposure or simplicity is needed.
`logMain_poleEdge_bound` combines the disjoint global-zero and Gamma
payments. `tendsto_poleEdge_sub_current` preserves the unchanged literal
packet and every old error. The remaining expression is the signed zeta
pole minus genuine zeros with Re(tau)>999/1000; the selected source lies
there. The older finite horizontal payment is INCLUDED in the global
sector and must not be added again. The earlier complete-unshifted exposed
payment remains valid as a separate reduction. No whole floor, ceiling,
zero exclusion or numerical fraction of source removed follows. Keep all
remaining phases and cofactors joint. The endpoint/audit stay in the
existing exposed-mode-coupling documents. Work locally without subagents,
commits or pushes.

`ZetaRieszShiftedExterior` now pays the actual shifted pole and entire
right-edge zero exterior. Its exact mask is |xi|>=1/2000 AND
|xi-Im(z)|>=1/40, tested at each original signed frequency. Genuine modes
and the pole have Re(z)<=-1/2; this vertical gap gives radius>=1001/2000.
The old coupled-order rate retains the full cofactor/rectangle and an
inverse-square mode-distance weight. `edgeExteriorResponse_bound` sums
all right-edge multiplicities; summable L1 norms justify both exchange
and genuine integrability. `poleEdgeSymbol_split` checks the exact signs.
`logMain_resonant_bound` combines the disjoint horizontal/Gamma and new
shifted-exterior payments with a C_y*(N+2)^3*(9999/10000)^N bound.
`tendsto_resonant_sub_current` retains the literal packet and all old
errors. Only the retained SHIFTED parts are confined to |xi|<1/2000 OR
|xi-Im(z)|<1/40; unshifted pole/right-edge terms still appear algebraically.
The earlier complete-unshifted payment under exposure remains available
as a separate exact reduction. Do not claim the whole integrand is
supported in these bands, pay any central/resonant term by norm, double
count earlier components, or infer an independent floor/ceiling from
source equivalence. The numerical log-rate diagnostic is motivation,
not a certificate. Both whole-sum bounds and the selected shifted
resonance remain open. Continue locally without commits or subagents;
keep the existing supporting endpoint and audit rather than proliferating
new documentation.

`ZetaRieszSignedDensityMain` bounds the SIGNED
comparison main itself. Exact squarefree density factors and a positive
Dirichlet convolution with density-normalized mass exactly one give
|c_D|<=2 and |eta(t)|<=7. The full hinge coefficient costs <=14 after summing
its signs. For the original
core weights, `core_signed_main_bound` gives
28*exp(2)*(N+1)/L_N*(2u)^(N+1), without an unknown population/mean constant.
This supersedes the earlier statement that no signed-main bound exists,
but NOT the open sufficient-bound milestone: its source factor still grows
for u>1/2. It bounds the canonical comparison main, NOT coreResponse.
Literal mask variation and long-cutoff comparison errors remain unpaid.
The uniform hinge bound requires all its support; do not apply the short
cutoff error theorem to that support without discharging its premises.
Preserve the phase-retaining column bound for the next genuine phase saving.
Both cofinal thresholds and RH remain open. No publication or subagents
are authorized for this local slice. See `docs/zeta-riesz-signed-density-main.md`.

`ZetaRieszLiteralVariationAudit` now proves that the canonical squarefree
zero extension cannot be charged as a smooth weight in the existing Abel
allowance. Its weight is zero on every multiple of four, hence
sum n*abs(w(n)-w(n+1)) >= (1/3)*sum n*abs(w(n)), including the final jump.
On support n>=exp(N/2), the exp(-N/32) variation allowance is at least
exp(15N/32)/3 times the absolute column mass. This is a lower bound on
the MAJORANT, not on the actual signed error and not a proof of its
divergence. The threshold premise remains explicit. Do not claim that
the prefactor pays literal mask variation or that a different extension
is free. The main bound remains valid; a sufficient joint main/error
phase estimate and both cofinal thresholds remain open. This negative
audit closes that smooth-zero-extension shortcut; it is not a new floor,
ceiling, or saving for the actual carrier. Keep local, no subagents.

`ZetaRieszCofactorDiscrepancy` proves the signed squarefree prefix error
C X^(3/4) D^(3/8), hence C X^(15/16) for D^2<=X. Its exact composite model
keeps c_D sum w - w(1) - sum_(D<p<=X) w(p) SIGNED. On dyadic cofactors above
exp(N/2), short cutoffs and w=a(n)cos(y(c+log n))/n, the error is at most
C exp(-N/32)*((3+abs(y))*A+TV(a)); both exterior jumps are paid. The profile
is recombined before taking the error norm. The scalar source-rate margin
is exp(-3N/100), but arbitrary literal mask/allocation variation, long
cutoffs and the signed main expression are NOT paid. C is unevaluated.
The user's latest steering requires the NEXT slice to bound the SIGNED MAIN
expression itself, not another error-only estimate or carrier reformulation.
Optional order-16 tests use actual primes and squarefree integers in three
nonempty physical-annulus columns, with owner allocation only; earlier
nested masks are not all verified. Tiny counting errors and signed main
values are individual-column diagnostics, not whole-core/asymptotic bounds.
Both cofinal thresholds remain open. Keep local, no subagents/publication.
See `docs/zeta-riesz-cofactor-discrepancy.md`.

The subsequent optional signed-main boundary diagnostic is recorded in
`docs/riesz-signed-main-boundary-investigation.md`. It proves NO new main
bound. In the order-14/16/18 probe, radial endpoints dominate the density
part; after separating them, sector-boundary plus exact prime subtraction
changes sign and does not decrease in magnitude. The boundary n=p-1 belongs
to the EXTRA p>whole-cofactor diagnostic sector, not the full carrier's
largest-prime ownership mask. Do not promote it to a whole-core obstruction
or omit the neighboring sectors. The literature check supplies no missing
signed Type-II estimate. This numerical investigation does not meet the
user's requested next milestone; the signed-main target remains OPEN.
No Lean frontier change, new publication authorization, or CI-heavy probe.

`ZetaRieszCofactorDiscrepancy.literal_compositeModel` now audits the
canonical literal rows: the unit and prime-cofactor weights are ZERO, so
their main has no virtual prime subtraction. A smooth extension must first
agree on every eligible composite and pay its own variation/error. The
exact `comparison_error_prime_extension` theorem says changing one excluded
prime weight by a changes the model by (c_D-1)*a and its comparison error
by the opposite amount. Apparent cancellation created by extending weights
is not free. This is a soundness/interface audit, NOT the requested signed
main bound or a saving toward either endgame threshold. Keep that target
open and do not launch another error-only or representation slice.

`ZetaRieszCofactorPhaseEnergy` now preserves the cofactor phase through the
sharp Mobius prefix BEFORE its square. Both whole-core bounds have explicit
cost sum_a sqrt(Q_a V_a), with no unknown mean multiplier. All original
masks, counts, orders and allocation remain. The centered new cost is no
larger than the old joint cost for ONE common universal E, proved by finite
duality. Both whole-core bounds intersect this cost with the prior radial
bound; its outer error is paid only on that radial branch. Optional y=54
probes, joining all cofactor shells BEFORE squaring, give 0.000189,0.0000483,
0.0000298 at N=6,8,10, versus the previous 0.00425,0.00308,0.00340 BEFORE
sqrt(E). The separate-shell N=10 cost is 0.000347: joining retains further
phase cancellation. These floating tests omit earlier nested deletions.
Cancellation on an enlarged test population does NOT bound its masked
subsets. More specifically, the entire N=6,8,10 test windows lie ABOVE the
literal physical annulus: 2L_N/N is about 1.59860,1.70060,1.81732, below
1.971. Their costs give NO numerical margin on a nonempty literal core.
No numerical certificate or asymptotic rate is claimed from the
finite decreasing joined costs. The NEXT target is a sufficient
large-order estimate of these literal signed cutoff correlations, with
no new carrier, generic PNT transport or discarded phase. Neither whole
threshold is closed. Continue locally without subagents or publication.
See `docs/zeta-riesz-cofactor-phase-energy.md`.

`ZetaRieszCentralRadialCost` now improves the SAME combined central cost
to (12*sqrt(2E)/log(2))*(4*exp(1/2)*log(4))*sqrt(16N+8)*(2u)^N.
The exact factorial radial mass pays all dyadic shells before separate
peak bounds; literal Chebyshev counts pay sum sqrt(log p)/p without the
previous log-log loss. Every central label/count, original mask, allocation
and factorial order remains. Both whole-core bounds inherit the minimum
of the new and old majorants, with the outer error charged ONCE. E and
the starting order remain UNEVALUATED. This saves polynomial order but
does NOT remove the exponential or prove phase cancellation. The user
explicitly directs the NEXT slice to attack the necessary PHASE saving
to close the endgame, not another polynomial refinement. Preserve all
no-gos; work locally, without subagents or unrequested publication. See
`docs/zeta-riesz-central-radial-cost.md`.

`ZetaRieszCentralCostGrowth` now bounds the COMBINED central cost by
C_E*N*(1+log(16*N+8))*(2*u)^N, summing all actual cofactor shells and
prime counts and retaining every original mask/allocation/phase in the
exact cost. Its outer error is paid once on both sides of the whole core.
The global scalar majorant uses absolute weight bounds; it does NOT prove
additional prime-phase cancellation. E and the starting order remain
UNEVALUATED. The majorant is o(N^2*(2u)^N) but provably diverges when u>1/2;
this does NOT prove actual-carrier or optimized-cost divergence. At the
upper radius the remaining exponent lies between 99/1000000 and 1/10000.
The user explicitly prioritizes a bound for the combined cost as N grows;
do not count further fixed-sector percentage gains as closing that target.
Both final thresholds remain OPEN. The second-prime extension also proves
energy <=4 log r when p>=r*s and a squared-cap factor 2/s with the SAME E;
keep it as a valid supporting improvement, not a global asymptotic claim.
See `docs/zeta-riesz-central-cost-growth.md`. Keep local; no subagents,
commits or pushes until renewed authorization.

`ZetaRieszCentralPrimeDifference` targets the CENTRAL signed carrier itself.
Extract the actual least cofactor prime before the arithmetic mean. Its Mobius
sign produces an exact two-hinge difference; raw energy is <=2 log r and
cofactor-count times energy is <=2 log(cofactor). Every count >=3, all
orders, original masks, allocation, physical cutoffs and full phase remain.
`exists_whole_difference_bounds` allows ONE common coordinate system across
counts and small primes. `exists_central_joint_bounds` intersects this new
central bound with the quadratic/cubic enclosures and adds the paid outer
error ONCE. Both whole bounds can only improve. Constants and total central
cost remain UNEVALUATED; neither eventual threshold is closed. The optional
N=10 least-prime 2,3,5 probes give about 56%,60%,65% reductions against the
RAW UNPROJECTED hinge budgets on IDENTICAL test labels. They are NOT cost
certificates or comparisons with the CUBIC whole cost; sqrt(E), other sectors
and earlier nested core deletions are not paid numerically. Do not claim a
central source-scale bound or new zero exclusion. See
`docs/zeta-riesz-central-prime-difference.md`. Keep local; no subagents.

`ZetaRieszLargeOrderCore` now pays BOTH outer strips of the original core
at the explicit rate exp(-N/1000000), with one finite C for every order,
height, count cutoff and 0<=u<=10001/20000. The remaining support is the
literal intersection 1.971N<log n<=2.029N. All coefficient, allocation,
physical and earlier masks remain; the signed error tends to zero even
for moving heights and radii. `exists_contracted_core_bounds` applies the
quadratic/cubic enclosures to that smaller support and pays the geometric
error on both sides of the ORIGINAL core. E and C are UNEVALUATED. This
is an outer-strip payment, NOT a bound for the central large-order cost.
Both whole thresholds remain OPEN. See `docs/zeta-riesz-large-order-core.md`.
Keep local without subagents or unrequested publication.

`ZetaRieszCubicPrimeEnergy` removes the third logarithmic divisor direction
only with its exact signed correction retained. Cubic residual energy is
quadratic energy minus squared correlation over the cubic-direction energy;
the width is no larger with the SAME E and coordinates. All cofactor counts
at least four annihilate both corrections, independently of shares or phase.
The remaining center lives on original triple/quadruple labels and is NOT
free credit. Both whole-core enclosures retain it. The optional enlarged
N=10 test gives about .002603 before sqrt(E), versus the earlier .003818,
and a new center about +.000113017. These are floating diagnostics, NOT
certificates. No eventual central bound follows, and E stays UNEVALUATED.
Preserve the conditioned bound too; cubic width is compared with QUADRATIC,
not automatically with the further conditioned width. See
`docs/zeta-riesz-cubic-prime-energy.md`. No subagents or new carrier.

`ZetaRieszCoordinateGain` targets the enlarged order-ten cost WITHOUT
changing the carrier. The exact signed center is invariant under admissible
common coordinates. A gain max(0,C-D) in the existing cost raises the floor
and lowers the ceiling by the same amount; disjoint populations ADD their
actual gains with the SAME E. Exact plane rotations and finite rational
recipes, including identity starts, preserve every coordinate. No labels,
counts, orders, masks or exterior profile terms are dropped. The optional
32,709,252-label N=10 probe, cofactor cap 6,484,203, reduces the quadratic
cost from about .003818 to .003406 before sqrt(E). This is floating numerical
exploration, NOT a certified bound; E remains UNEVALUATED. The recipe's
exact admissibility does not certify its numerical cost. Prior nested core
deletions are omitted by the test population; no eventual rate follows.
Both whole thresholds remain OPEN. Preserve the earlier arithmetic and
conditioned savings, default endpoints and top-ten lists. See
`docs/zeta-riesz-coordinate-gain.md`. Keep local; no subagents.

`ZetaRieszConditionedPrimeEnergy` further improves BOTH whole-core bounds
with the SAME signed center H. In every common coordinate, the known
moment M=sum w(n)*secondMoment(n) reduces the squared residual allowance
from A*Q2 to (A-M^2/V)*Q2, where A=E*X*sum w^2 and V is the centered
log-squared energy. Nonnegativity and all degenerate energy cases are
proved from the existing mean theorem. The exact saving M^2*Q2/V is
strict when the correlation is nonzero and both energies are positive.
The entire literal core inherits the smaller cost with the SAME E,
coordinates, masks, counts, allocation, physical cutoffs and full phase;
no extra companion credit or count split enters. E stays UNEVALUATED.
The optional --conditioned-constant 1 diagnostic is only a nominal model;
E=1 is NOT certified, and the cost depends NONLINEARLY on E. Do not
multiply that displayed cost by sqrt(E) to claim a general bound. Finite
gains are modest; both eventual whole thresholds remain OPEN. See
`docs/zeta-riesz-conditioned-prime-energy.md`. Keep local; no subagents.

`ZetaRieszQuadraticPrimeEnergy` sharpens BOTH whole-core bounds by the
exact quadratic logarithmic divisor moment. Every squarefree cofactor
with at least three primes annihilates this profile; the two-prime
response is exactly 2*log(q)*log(r). Keep its signed correction H, supported
only on triple-prime labels, while ALL counts stay coupled in the residual
cost K. Lean proves K<=B0 for the SAME E, coordinates and weights, and the
entire original core has max(-B0,H-K)<=J<=min(B0,H+K). Neither bound can
worsen. Higher-count populations get the narrower bound automatically
with H=0, without a new count ceiling. All original masks, orders zero/one,
full phase, both cutoffs and unique ownership remain. E is UNEVALUATED.
The optional finite probe shows smaller widths but the center changes
sign; no free positive credit or eventual decay follows. Do not split
counts to claim this improvement or replace H by a favorable sign.
Both whole source-scaled thresholds remain OPEN. See
`docs/zeta-riesz-quadratic-prime-energy.md`. Keep local; no subagents.

`ZetaRieszJointPrimeEnergy` now proves BOTH signed bounds for the ENTIRE
literal coreResponse. Sum the complete factorial allocation and full product
phase FIRST. A common exact orthogonal coordinate change retains cross terms
in BOTH cofactor weights and centered prime profiles. Identity coordinates
always satisfy the finite algebraic premise. Arbitrary prime-row HOLES are
retained without binary maximal loss. Canonical largest-prime ownership
exhausts all original squarefree labels exactly; nonsquarefree coefficients
vanish. Thus no unproved interval-cover premise remains for THIS cost.
All original masks, both cutoffs and all factorial orders including zero/one
remain; the theorem adds no count ceiling, prime-density assumption or zero
hypothesis. Disjoint partitions sum their costs with the same UNEVALUATED E.
The finite N=10 diagnostic lowers cost from about 0.1406 to 0.00238 on the
same truncated 30.5-million-label population, before sqrt(E). ALL numerical
coordinate directions are retained. This is NOT a uniform cost-comparison
theorem, an eventual estimate, or a whole-carrier numerical certificate.
Expanding the N=10 cofactor cap to 6,484,203 gives about 0.00407 on
32.7 million labels, slightly above the expanded N=8 cost 0.00390. The
expanded tests still omit prior nested core deletions; do not infer decay.
The TOTAL source-normalized cost and both whole thresholds remain OPEN.
Preserve all prior growth audits; never spend companion credit twice.
See `docs/zeta-riesz-joint-prime-energy.md`. Keep local; no subagents.

`ZetaRieszCenteredPrimeEnergy` now improves BOTH original-carrier bounds
by exact composite moment cancellation. Constant and logarithmic divisor
profiles vanish on every selected squarefree composite; subtract their
optimally chosen component BEFORE the signed block energy. The exact
saving is correlation-squared/logarithmic-energy, and the same E gives a
PROVED NO LARGER total cost at every physical cutoff. The population
endpoint is paid exactly by zero divisor mass. Both Riesz cutoffs, all
factorial orders ZERO AND ONE included, exact B(n,j), full phase, moving
intervals, unique ownership and finite families remain. No count ceiling,
PNT replacement, zero hypothesis or new companion credit enters. E is
UNEVALUATED. Optional N=6,8,10 probes save about 30-40%, but the N=10
cost grows again: neither eventual decay nor an asymptotic no-go follows.
A disjoint WHOLE-CORE COVER and TOTAL source-normalized bound remain open.
Do not treat a norm budget uniform over arbitrary endpoint choices as a
proved small budget for the actual whole radial carrier. Retain the known
central-sector growth audits and both open thresholds. See
`docs/zeta-riesz-centered-prime-energy.md`. Complete the authorized
publication gates; no subagents.

`ZetaRieszMovingPrimeIntervals` now pays COFACTOR-DEPENDENT prime
interval endpoints via a binary maximal bound, at squared-mean cost
4*(b+1). BOTH cutoffs, full phase, all orders ZERO AND ONE included,
and the EXACT retained B(n,j) energy remain. Signed primes are summed
INSIDE every block's quadratic energy. One UNEVALUATED E works for all
finite cutoffs and heights, without an eventual prime threshold or count
ceiling. Only selected primes must be eligible/coprime. Disjoint cells and
unique largest-prime ownership yield an actual duplicate-free label set;
finite radial/count families have the sum of their exact costs. This
removes the need to pay full cofactor variation for interval masks.
Internal holes still need explicit runs. A disjoint WHOLE-CORE COVER and
the TOTAL source-normalized cost remain OPEN. Small-order optional probes
show much lower costs, but do not evaluate E or prove eventual smallness.
Never complete a row, reuse companion credit or infer a global floor from
a finite-block theorem. Both whole thresholds remain open. See
`docs/zeta-riesz-moving-prime-intervals.md`. Keep local; no subagents.

`ZetaRieszSmoothPrimeTail` now PAYS the signed smooth response on COMMON
joined eligible/coprime prime intervals, including exterior clipping and
arbitrarily many periods. The factorial prime density has one turning point;
integration by parts gives amplitude 2W/(a*abs(y)), without a period-count
factor. BOTH cutoffs, ALL orders including zero/one, the exact original
allocation and cofactor phase remain. Adding the ACTUAL discrepancy gives
joinedCost=smoothCost+factorialError. The original carrier and finite
radial/count families have BOTH signed bounds with one proved UNEVALUATED
E,T and K=sqrt(E)*sum retainedJoinedCost. The previous signed H comparison
remains available; no sign information is deleted from its theorem.
This budget is NOT uniformly better than the older joined-period estimate:
the optional diagnostic improves long blocks and loses on some short ones.
TOTAL source-scaled cost still grows in the positive binomial-cap probe;
that is NOT a carrier lower bound or a proved asymptotic no-go. Actual prime
holes and unique ownership remain unpaid, and a family theorem does not
license double-counting labels or old credits. Both whole thresholds remain
OPEN. The numerical experiments are optional, never CI certificates. See
`docs/zeta-riesz-smooth-prime-tail.md`. Keep local; no subagents.

`ZetaRieszRetainedDiscrepancy` now attaches the original retained allocation,
ALL factorial orders including 0/1, full cofactor phase and BOTH Riesz
hinges to the joint arithmetic discrepancy. The exact B(n,j) expansion
and cosine/sine rotation give H-K<=J<=H+K for the ORIGINAL residual
coefficient/kernel carrier. K=sqrt(E)*retainedErrorCost, with the explicit
sum of binomial caps times the cubic-log factorial errors and sqrt(b).
One UNEVALUATED E,T works for arbitrary finite radial/count families;
the smooth H_i remain SIGNED across the whole family. Complete/exterior-
clipped intervals must be COMMON, eligible and coprime to all cofactors.
There is no count ceiling or maximum-order/family-cardinality price.
THE JOINT SIGNED SMOOTH CARRIER, actual prime holes, unique incidence
accounting and TOTAL source-normalized cost remain OPEN. Do not append
credits already in complete intervals or treat labels counted twice as
new credit. The optional finite actual-prime regression is below the
established eventual threshold, uses floating quadrature and is NEVER CI.
Its large-order binomial-cap budget still grows; no carrier lower bound,
asymptotic no-go or source-smallness conclusion follows. Both whole
thresholds remain open. See `docs/zeta-riesz-retained-discrepancy.md`.
Keep these changes local, without subagents.

`ZetaRieszDiscrepancyEnergy` now carries that actual arithmetic error through
BOTH Riesz cutoffs and the squarefree cofactor mean. For a COMMON complete
or exterior-clipped interval and smooth signed profile F with |F|<=W,
|F'|<=V, epsilon=5*(2W+(V+2W)*(b-a))/a^3 and the coupled energy is at
most b*epsilon^2. Every divisor sign and endpoint remains. The actual
primeResponse-minus-smoothResponse mean is <=E*X*b*epsilon^2, with both
signed weighted bounds and no count ceiling or Riesz-length price. E and
the starting T>=5000 are UNEVALUATED; do not advertise validity at 5000.
The SIGNED SMOOTH RESPONSE IS NOT PAID. The original varying retained
factorial/order coefficients and cofactor phase rotations still need to
be assembled with these estimates, actual prime holes and ownership, and
the total source-normalized cost. Do not call this a whole residual-carrier
bound or source-smallness theorem. No low orders or previous negative
audits may be dropped. The finite diagnostic is optional, below the
established threshold and NEVER a CI certificate. Both whole thresholds
remain open. See `docs/zeta-riesz-discrepancy-energy.md`. Keep local.

`ZetaRieszJointPrimeError` now sharpens the ACTUAL prime discrepancy.
The existing complete smoothed prime estimate gives exp(t)/t^6 eventually;
monotone desmoothing and every prime-power allowance give
abs(theta(exp t)-exp t)<=5exp(t)/t^2. The start is proved but UNEVALUATED:
do NOT advertise 5000 as the start of the sharper theorem. The joined
finite-prime comparison pays 5(2W+D(b-a))/a^3, with the signed smooth
integral and exact reciprocal logarithm retained. Only exterior endpoints
are priced. The global factorial peak improves interval amplitudes.
`eventually_retained_interval_error` uses the exact original 1-boundedShare,
full factorial amplitude, all orders including 0/1, full phase and arbitrary
signed cofactor weights. Common complete/externally clipped eligible coprime
intervals are required; all squarefree cofactor counts >=2 are allowed.
This is a PRIME-MOMENT discrepancy bound, NOT a bound on the entire Riesz
carrier. The prime-dependent cutoff response, coupled signed smooth term,
prime holes, unique ownership and total source cost remain OPEN. Do not
substitute density at source scale or append already-spent credits. The
optional all-order probe gives a substantially smaller error expression,
but source-normalized positive budgets still grow; it proves no carrier
lower bound or asymptotic no-go. Both whole thresholds remain open. See
`docs/zeta-riesz-joint-prime-error.md`. Keep these changes local, without
subagents, and preserve every previous negative audit.

`ZetaRieszJointPeriodEnergy` now combines separated COMPLETE prime
periods before the quadratic mean. At most one interval can be partially
active at any cutoff, so the joint energy pays a single maximum partial
tail plus the retained full moments. All quantitative prime/amplitude
inputs are discharged for factorial legs. `exists_literal_joint_period_bounds`
keeps the original residualCoefficient/kernel, allocation, every order,
both Riesz hinges and the full cofactor phase. Its ONE COMMON cofactor
population is squarefree with >=2 factors; there is no upper count ceiling.
One proved UNEVALUATED E controls the explicit sum_j binomial_cap*sqrt(Q_j),
where Q_j is the combined period energy. There is no sum of period norms.
Common complete/eligible/coprime periods are required. Arbitrary moving
prime holes are NOT covered. The budget improves the tested central blocks,
not every possible configuration; no source-smallness theorem is asserted.
Next control combined full moments and the total source-normalized cost,
retaining actual mask boundaries and disjoint paid credits. All prior no-gos,
the -79/1000 floor and 3/2 ceiling remain open. See
`docs/zeta-riesz-joint-period-energy.md`. The probe is optional, never CI.
No subagents. Keep the work local and separate from published b44806e.

`ZetaRieszRetainedFactorial` and `ZetaRieszWeightedPrimeTail` now pay
ORIGINAL factorial/allocation amplitudes on COMPLETE prime periods. The
exact unused-majority multinomial has nonnegative marked-order coefficients
bounded by the binomial cap, with every order including zero and one retained.
The signed varying prime tail pays both Riesz hinges before squaring.
Binomial variance sums all factorial orders into explicit `summedPeriodCost`;
`exists_literal_family_bounds` gives BOTH signed bounds sqrt(E)*sum cost,
with one proved but UNEVALUATED E. All squarefree cofactor counts >=2 are
allowed, with no upper count cutoff. Periods must be common, complete,
eligible and coprime to every selected cofactor. Arbitrary cofactor subsets
are allowed; cofactor-dependent prime holes are NOT filled. The original
phase, residualCoefficient and boundedShare remain literal. There is no
maximum-order/count/family-cardinality multiplier. The optional diagnostic
shows improved order costs but growing source-normalized central-saddle
budgets; this is neither a carrier lower bound nor an asymptotic no-go.
Next pay the actual holes and the TOTAL source-normalized cost, preserving
disjoint paid sectors. Do not turn polynomial gains into source-o(1), append
spent credits, or discard low orders. Both whole thresholds, RH and any new
zero exclusion remain OPEN. See `docs/zeta-riesz-retained-factorial.md`.
The previous `PrimeTailEnergy` module remains the constant-amplitude
special case; its earlier amplitude limitation is discharged only on the
complete-period support specified here. No subagents.

`ZetaRieszPrimeTailEnergy` now pays the combined moment/crossing energy
of ACTUAL FULL prime periods. For a>=5000 and |y|>=54, the numerical cost
Q=16/a^3+(2*pi/|y|)*(2/(|y|*a)+4/a^2)^2 has sqrt(Q)<=1/(16*a).
The entire signed cutoff tail is squared only AFTER its prime sum; all
hinge crossings and the full moment are included, with no Riesz-length or
count multiplier. Squarefree means allow arbitrary cofactor phase, including
log(n), and reciprocal cofactor weights pay their entire energy. Finite
radial families have BOTH signed bounds sqrt(E)/16*sum W_i/a_i; E is proved
but UNEVALUATED. Prime period and L are common across labels within each
family member. Original factorial/allocation amplitudes varying with the
prime, cofactor-dependent prime holes, and their TOTAL source-normalized
cost are NOT paid by this theorem. Do not replace the literal masked prime
set with a full period or append spent sector credit. The optional actual-
prime probe tests the identities below a=5000, not the numerical theorem
or an eventual rate. No zero/simplicity hypothesis or source-o(1) claim.
Both whole thresholds and any further zero exclusion remain OPEN. See
`docs/zeta-riesz-prime-tail-energy.md`. Keep these changes local and separate
from the verified published b44806e snapshot.

`ZetaRieszSignedCutoffEnergy` now controls arbitrary SIGNED cutoff
profiles by E*X*sum_k k*b_k^2 with one proved UNEVALUATED E>0. Every
counting error is paid; there is no cutoff/count ceiling. Finite Abel
summation keeps the actual prime sums inside this quadratic energy. The
terminal `exists_literal_joint_bounds` applies to the ORIGINAL finite
residualCoefficient/kernel sum, retaining allocation, factorial weights,
phase, both reflected cutoffs, squarefreeness, coprimality and all selected
masks. Constant moment, first moment and signed crossings stay TOGETHER.
The remaining explicit cost is sqrt(E)*sum_q q*sqrt(sum_i i*Delta_q b^2),
where b is the cutoff difference of the combined signed prime profile.
This pays finite boundaries as an inequality; their SOURCE-SCALE ENERGY
remains OPEN. The optional exact-prime/floating-log probe gives a signed
profile-energy ratio about 0.01188 at N=8, but the cofactor-variation bound
is about 71.13 after source normalization even BEFORE sqrt(E). Do NOT call
this a small carrier bound or an asymptotic no-go: these are early finite
diagnostics. Avoid another absolute-variation closure attempt; target the
actual boundary correlations using the signed energy. Do not spend already
paid sectors twice. Both whole thresholds, restricted exclusion and RH
remain OPEN. See `docs/zeta-riesz-signed-cutoff-energy.md`. The slice is
local; published b44806e remains a separate verified snapshot.

`ZetaRieszLinearCutoffMean` improves the exact squarefree cutoff-difference
mean to E*X*min((B-A)^2,B-A), for EVERY cutoff pair A<=B and squarefree
selection S subset (1,X]. E is proved but UNEVALUATED. Exact finite Abel
weights have 0<=b_k<=1/k, and retaining all signed Gram terms pays only
their total mass via a logarithmic row cost at most four. Direct and exact
complementary (n-1)/k Gram bounds pay every counting error. Both signed
inequalities retain arbitrary correlated weights; the literal original
prime fibre now costs E*X*min((log p)^2,log p) times its actual weight
energy. No prime count ceiling, density substitution or zero hypothesis
is used. The energy, prime/radial aggregation, signed crossings and holes
from already-paid sectors remain UNPAID. Do not turn this polynomial
improvement into source-o(1), count a paid sector twice, or claim either
whole threshold. See `docs/zeta-riesz-linear-cutoff-mean.md`. Keep the
optional floating diagnostic outside CI and preserve every prior no-go.

The user has now authorized committing and pushing all accumulated local
work after this slice passes the full gates. Include the earlier joint
mean/owner/count estimates and their audits, not just the latest prime-period
module. Verify the complete staged tree and push the passing commit; track
CI on its exact SHA while continuing useful independent work. No subagents
are authorized. This instruction supersedes the earlier local-only holds.

`ZetaRieszQuantitativePrimePeriod` proves actual ordinary-prime period
costs 4/a^2 and first-moment costs 1/a^2 at cosine extrema, for prime-log
lower endpoint a>=5000 and |y|>=54. The proved explicit Chebyshev error
pays every arithmetic premise. The signed-profile theorem retains its
common smooth integral, numerical discrepancy and exact clipped endpoints.
Squarefree ownership and the all-count second moment give the numerical
joint bound 8*W*(H_(2M)^2+H_(2M))/log(M)^2; arbitrary finite radial families
replace W by sum_j W_j. No maximum prime count or E_h enters this bound.
The terminal cofactor weights remain CONSTANT WITHIN EACH PRIME PERIOD.
Original factorial/allocation variation, Riesz cutoff corrections and
cofactor-dependent paid-sector holes still need their combined budget.
Do not reuse a full-period estimate after deleting favorable sectors or
append their credit twice. This is not generic source-scale PNT transport;
both whole -79/1000 floor and 3/2 ceiling remain OPEN. Preserve all prior
no-gos, masks and multiplicities. See
`docs/zeta-riesz-quantitative-prime-period.md`. The optional finite-prime
probe is below the theorem's logarithmic cutoff, is not a certificate and
stays outside CI. Complete the authorized publication gates without subagents.

`ZetaRieszOwnerCountEnergy` now pays the cofactor part of the owner-log
energy for EVERY prime count together. Literal prime incidence counting
gives sum_{n<=X} omega(n)^2 <= X*(H_X^2+H_X). Squarefree ownership gives
log(n)/omega(n) <= the marked prime log, and the dyadic shell energy for
|w(n)|<=W/n is at most 2*W^2*(H_(2M)^2+H_(2M))/(M*log(M)^2).
The existing Chebyshev counts bound H_X by an explicit O(log log X)
expression. Both real and COMPLEX owner-slope sums therefore have
K^2=144*(b+1)^2*E_h*W^2*(B_M^2+B_M)*sum|a_i|^2/log(M)^2,
where B_M is explicit and E_h is proved but UNEVALUATED. Complex phases
remain coupled before taking the real part; their fixed factor two is
absorbed into E_h. The original owner, strict slope, reciprocal log and
cofactor-dependent interval endpoints remain. There is NO remaining
cofactor-energy SUM or exponential prime-count price in this theorem.
Base a_i and cutoffs stay FIXED across labels. The irregular signed
prime moments, remaining coefficient energy, radial aggregation and
matching signed cutoff correction are STILL OPEN at source scale.
Noncontiguous cofactor-dependent period holes are not paid. Preserve all
earlier no-gos and disjoint paid sectors. Neither whole floor/ceiling,
RH nor a new zero exclusion is proved. See
`docs/zeta-riesz-owner-count-energy.md`; the optional integer diagnostic
stays outside CI. Continue locally, without subagents or commits.

`ZetaRieszSquarefreeSeparatedMean` now pays the counting errors for an
ENTIRE signed log-separated cutoff family: sum_S (sum_i a_i M_Ri(n))^2
<= E_h*X*sum_i a_i^2, with NO period-count multiplier and NO remaining
floor term. S is squarefree, nonunit, in (1,X]; the budget uses X, NOT
card(S) or X-Y. Exact complementary quotient rounding loses at most one
in logarithmic separation. Both small direct and large reflected finite
Gram kernels have inverse-square separation decay INCLUDING their
integer rounding errors. This closes the binary-block counting budget
for the squarefree family covered by the new theorem.
`ZetaRieszOwnerUniformMean` combines it with the existing literal owner
and moving-interval maximal estimate: the mean is bounded by
36*(b+1)^2*E_h*X*sum_i a_i^2 for 2^b periods. Both signed sides and the
strict cutoffSlope bridge retain cofactor-dependent owner shares, radial
lengths T(n,i) and interval endpoints. Base a_i and R_i remain FIXED across
labels; arbitrary a_i(n) and cofactor-dependent noncontiguous holes are
NOT covered. Common real weights have EXPLICIT unpaid energy. E_h is
proved but UNEVALUATED. The remaining prime-moment dependence, matching
signed cutoff correction and TOTAL source-normalized cost are still OPEN.
Do not claim a whole floor/ceiling, RH or a new zero exclusion. No zero or
simplicity hypothesis enters these estimates; preserve disjoint paid
sectors and every previous negative audit. See
`docs/zeta-riesz-uniform-period-budget.md`. The floating Gram probe is
only a finite diagnostic, stays outside ordinary CI, and does not bound
the prime phase or certify E_h. Continue locally, no subagents or commits.

`ZetaRieszOwnerDensity` additionally retains any nonnegative decreasing
cofactor-dependent factor v(n,i)<=D at only D^2 times this SAME mean
budget, with no additional period or maximal-depth price. Its literal
reciprocal-log slope theorem keeps 1/(T(n,i)-log n) and separate positive
lower bounds delta(n), with explicit energy sum (w(n)/delta(n))^2.
This pays the monotone coefficient dependence covered by the theorem,
NOT the irregular signed prime-count discrepancy. Do not substitute a
smooth prime density for actual prime moments. The energy, remaining
signed cutoff correction and whole source-normalized cost are still open.

`ZetaRieszSquarefreeUniformMean` now CLOSES the intermediate-cutoff gap
left by the earlier cubic reflected budget below. Sum all complementary
divisor pairs BEFORE rounding: each pair is one exact interval count with
error at most 1, so the reflected error is floor(X/R)^2, not its cube.
The moving main term is a sum of sharp lcm quadratics, each bounded by the
existing proved E. Combining direct and reflected squares gives a UNIFORM
LINEAR mean E*X for EVERY positive cutoff and every squarefree nonunit
selection S in (1,X]. The Riesz difference inherits (B-A)^2*E*X, and both
signed weighted bounds follow with explicit weight energy. General A,B
remain fixed across labels; exact response reflection fixes L-log(p),L
for each marked prime in `exists_literal_prime_fibre_bounds`. This bounds
the ORIGINAL residualCoefficient/kernel with all cofactor counts, masks,
phase, factorial and allocation retained, without a raw-prime-bound premise.
The counting penalty is now linear everywhere, but E is UNEVALUATED and
the weight energy and combined prime-period cost remain UNPAID AT SOURCE
SCALE. Do not infer a whole floor/ceiling or a zero exclusion. Both whole
thresholds remain OPEN. No zero/simplicity hypothesis enters this estimate.
Preserve all previous no-gos and disjoint paid-sector masks. See
`docs/zeta-riesz-squarefree-dual-mean.md`. Continue locally, no subagents
or unrequested commits; the integer diagnostic stays outside ordinary CI.

`ZetaRieszSquarefreeDualMean` improves the actual squarefree counting
budget by exact strict divisor reflection: M_R(n)=-mu(n)*M_((n-1)/R)(n).
Do not replace the integer endpoint by n/R. For every squarefree nonunit
selection S in (1,X], the mean is bounded by E*X+min(R^2,floor(X/R)^3),
with one proved UNEVALUATED E. It is linear in the two regimes R^2<=X
or X^2<=R^3, NOT throughout the intervening range. X<=Q^5 gives the
all-cutoff budget E*X+Q^6. The improved two-hinge and literal strict-slope
bounds keep arbitrary correlated real weights, with EXPLICIT unpaid
weight energy. Common hinge endpoints are FIXED across labels. Exact
response reflection also yields `exists_literal_prime_fibre_bounds` for
the original residualCoefficient/kernel with fixed marked prime p: the
reflected endpoints L-log(p),L are common across cofactors. All cofactor
counts, phase, factorial and allocation weights remain. This needs no
raw prime-bound premise, but does NOT pay the weight energy or combined
marked-prime/period cost at source scale. Do not turn this finite counting
improvement into a whole floor/ceiling claim. Both whole thresholds remain
OPEN. No zero hypothesis, no newly excluded zeros. Retain all prior no-gos
and disjoint paid-sector masks. See `docs/zeta-riesz-squarefree-dual-mean.md`.
The exact integer diagnostic stays outside ordinary CI. Continue locally,
without subagents or unrequested commits.

`ZetaRieszOwnerMaximal` now proves that the EXACT original owner allocation
has total variation at most 2 along decreasing cofactor shares, for N>=32.
The unpaid orders are exactly Icc(N/5+2,13N/32). Raw signed complex partial
sums transfer through the owner factor at cost 3; moving interval endpoints
cost 6. A binary-block maximal argument gives the all-count literal cutoff
mean at cost 36*(b+1), with main energy E_h*(X-Y)*(b+1)*sum a_i^2 and the
explicit signed dyadic block-floor error. The coarse total price is only
36*(b+1)^2 for 2^b periods. `exists_owner_slope_bounds` gives BOTH signed
sides with cofactor-dependent owner shares, radial lengths and interval
endpoints, arbitrary population masks and common real weights. Base a_i
and cutoff R_i remain FIXED across labels. Arbitrary a_i(n), holes in the
period selection and the matching Riesz cutoff correction are not paid.
`literal_owner_prime_partial_bound` preserves the exact coefficient/kernel,
but its raw prime partial-sum bound is an EXPLICIT OPEN PREMISE, not an
independent small bound. E_h is unevaluated. Neither the binary-block floor
budget nor the remaining prime-period weight energy is source-small yet.
Do not apply a logarithmic saving to the exponential absolute envelope
and call it decay. Both whole thresholds remain OPEN; no zero hypothesis
or new zero exclusion. Preserve previous no-gos and paid-sector overlaps.
See `docs/zeta-riesz-owner-maximal.md`. Continue locally, without subagents
or unrequested commits. The optional allocation probe is not a prime-sum
certificate and stays outside ordinary CI.

`ZetaRieszCrossCutoff` now proves inverse-square decay of the ACTUAL
sharp cross quadratic: `abs(Q(R,S)) <= C/(4+abs(log R-log S))^2` for
positive cutoffs, with one unevaluated C. The repo's finite Suzuki Schur
estimate then bounds any signed family with log spacing at least
`h*abs(i-j)`, h>0, by `E_h*sum a_i^2`, with no period-count factor.
The literal integer interval second moment is at most
`E_h*(X-Y)*sum a_i^2 + (sum abs(a_i)*R_i)^2`. Both signed sides hold
with arbitrary population masks and a common real weight. The exact
`cutoffSlope` bridge preserves the strict rounding `R_i<exp(D_i)<=R_i+1`.
The stronger cancellation endpoints replace the finite-error square by
`(sum_d abs(mu(d)*sum_{i:d<=R_i} a_i))^2`: signs are retained until AFTER
cutoffs have been combined at each divisor. This error remains explicit
and is not proved source-small. The optional 128-cutoff alternating probe
reduces its normalized allowance from about 32719.54 to 10.22374; this is
not a certificate for the original carrier or its changing masks.
The family coefficients a_i are FIXED across the selected population;
arbitrary a_i(n) are NOT covered. The retained prime-period coefficients
do depend on the cofactor, so their variation and matching cutoff
correction still need joint control. Do not erase the combined finite
floor error or infer a source-small bound from the numerical alternating
Gram probe. Both whole thresholds remain OPEN. Preserve all previous
no-gos, original masks and paid-sector overlaps. See
`docs/zeta-riesz-cross-cutoff.md`. Continue locally, no subagents or
unrequested commits.

`ZetaRieszSharpSieve` and `ZetaRieszCutoffMean` now prove a stronger
all-count cutoff-change budget. One PROVED but UNEVALUATED constant E>0
bounds the sharp Mobius lcm quadratic at every cutoff. For every integer
interval `(Y,X]`, the actual sharp response has second moment at most
`E*(X-Y)+R^2`. For A<=B and exp(B)<R+1, the actual Riesz difference has
second moment at most `(B-A)^2*(E*(X-Y)+R^2)`. Finite positive mixing of
sharp prefixes proves this; no count split or external sieve premise is
used. `exists_masked_difference_bounds` preserves arbitrary real weights
and finite selections and gives BOTH signed sides. The endpoints A,B
are fixed on each selected population; label-dependent moving cutoffs
are not automatically covered. Do not identify E with the floating 0.44
probe, erase the R^2 error, or claim the stronger classical uniform O(X)
mean for all X,R. The actual weight energy, moving endpoints and total
source-normalized period cost remain unpaid. Both whole endgame thresholds
remain OPEN, with no zero exclusion. Keep the absolute-crossing no-go and
all paid-sector overlaps. See `docs/zeta-riesz-cutoff-mean.md`. Continue
locally without subagents or unrequested commits.

`ZetaRieszSieveQuadratic` and `ZetaRieszSieveMean` now prove an independent
all-count bound for the literal Riesz response. For `R<=x<R+1`, `x>0`,
the signed logarithmic lcm quadratic form is at most `196*(1+log R)` and
`sum_(n<=X) R_(log x)(n)^2 <=196*X*(1+log R)+16*x^2`.
Exact prime exclusions cost their Euler factors; their total is bounded
before any prime-count split. `literal_residual_bounds` applies to the
original allocated residual on arbitrary finite squarefree-composite
selections, preserving its actual factorial and phase weights. The weight
energy and the `x^2` floor error remain explicit. This is NOT a source-small
cost, a payment of every prime period, or either final whole threshold.
Do not multiply this bound by the absolute carrier and claim cancellation.
The square-root-cutoff specialization needs the literal `x^2<=X` premise;
it does not automatically hold on every reflected cofactor geometry.
The stronger uniform O(X) sharp Mobius mean remains a literature lead.
The later SharpSieve slice proves a constant quadratic but still pays R^2.
The Dress--Iwaniec--Tenenbaum/de la Breteche--Dress--Tenenbaum uniform mean
and 2026 explicit constants are NOT imported Lean theorems.
Keep clipped boundaries, moving cutoffs and previously paid overlaps in
any transfer to the signed prime periods. Both whole bounds remain open.
See `docs/zeta-riesz-sieve-mean.md`. Continue locally without subagents or
unrequested commits; preserve every earlier negative audit.

`ZetaRieszSignedCrossing` now improves BOTH literal affine comparisons:
the convex hinge error is nonnegative, so only `min(g*mu(d),0)` is charged
in the floor and only `max(g*mu(d),0)` in the ceiling. These inequalities
cover all cofactor counts, arbitrary radial selections and clipped prime
sets, keeping the original allocation, factorial weight, phase and both
cutoffs. A favorable crossing is not a separate extra reserve.
`ZetaRieszCrossingGrowth` proves a decisive limitation of the preceding
absolute-cost plan: the actual full-period crossing cost, restricted to
the original core with unique largest-prime ownership, is at least
`c_(u,y)*(2u)^N/(N+1)^4` at every negative saddle peak, eventually on the
dyadic schedule for `1/2<u<=10001/20000`, `abs(y)>=54`. Ordinary-prime
population bounds, the literal floor-defined length and all core masks
are proved. Hence `not_eventually_period_cost_bounded` rules out even a
constant separate absolute crossing budget. This is NOT divergence of
the whole signed sum. Do not optimize that impossible separate payment:
bound the retained prime moments PLUS their signed cutoff correction
together. Keep the already-paid sectors and their overlaps explicit;
the box may not be appended as a second credit. The earlier global
nonowner source-o(1) payment remains valid. Both whole numerical thresholds
remain open. See `docs/zeta-riesz-signed-crossing.md`; the numerical probe
is optional and is not a certificate. Continue locally without subagents
or unrequested commits.

`ZetaRieszNonownerAllocation` now pays ALL non-largest-prime allocation
incidences together at source scale. Each such prime has log share <=1/2;
the literal unpaid-order mass is <=exp(-N/64). The complete masked sum has
bound `(4(N+1)/3)*nonownerRate^N*(1509/1000)*M(2049/2048)`, with
`nonownerRate<124/125`. The bound permits label-dependent prime selections,
arbitrary complex masks of norm <=1, all counts and all periods in the
literal window, uniformly in changing heights. Exact residual subtraction
and `signed_owner_bounds` pay BOTH sides once; `tendsto_joint_sub_owner`
connects this to the unchanged whole floor/ceiling target. The original
source is retained, not cancelled. `ZetaRieszOwnerVariation` bounds the
remaining exact owner allocation derivative by `6*sqrt(N+1)/T` on EVERY
cofactor share in (0,1), and literal fibre variation by
`12*sqrt(N+1)/v`, with no count factor or upper cofactor-share cap. The
physical prime selection and unique ownership remain explicit. This does
NOT bound the retained owner sum or the combined signed prime moments.
Next combine this global allocation payment with the cutoff-crossing bound
below to attack those moments and their total source-scale cost, retaining
clipped/exterior boundaries and every signed overlap. Both whole constants
remain open. See `docs/zeta-riesz-global-owner-allocation.md`. Keep earlier
no-gos and defaults; continue locally without subagents or unrequested
commits. Do not replace signed correlations by an unpaid absolute envelope.

The new `ZetaRieszGlobalCurvature` and `ZetaRieszGlobalPrimePeriod` replace
count-by-count cutoff-variation charges by ONE bound over every integer
cofactor: `(1+log X)*h*(exp(2h)-1+exp(h-D))`, and at most
`(23/7)*(1+log X)*h^2` under the stated small-width/interior assumptions.
`owned_population_affine_bounds` applies directly to the existing allocated
residual coefficient, retaining both cutoffs, parity, full factorial weight,
phase and any actual masks, with unique largest-prime ownership. It improves
BOTH signed sides around the same retained constant and first prime moments.
`radial_affine_error_le` aggregates arbitrary finite radial collections using
only the sum of their literal weight budgets. It does NOT prove those budgets
or the two moments bounded at source scale. Counts are unrestricted above
three total primes; clipped periods retain their real moments. No separate
favorable-phase credit may be added without signed overlap accounting.
Next attack those two joint weighted moments, the combined crossing cost and
exterior boundaries. Do not report this component bound as the whole floor
or ceiling; both numerical endgame constants remain open. See
`docs/zeta-riesz-global-crossing.md`. Continue locally, without subagents or
unrequested commits. Preserve every older negative audit.


The latest local fixed-count estimate removes both the artificial cofactor
ceiling and the fixed relative ownership gap. It uses `log(a)<=197v/200`
and `log(q)<=v-1/16-log(a)`. For k<=54, ownership alone implies
`log(a)<=54v/55`, making the cap redundant. The fixed 1/16 covers a whole
prime half-period for |y|>=54; its relative width vanishes. The earlier
70-percent and relative 1/200 sectors are retained. The allocation variation
is `20(k+1)*sqrt(N+1)/v`, with denominator `100/v`; BOTH cached whole
applications retain `<1/90000` local debit, every observation, growing margin,
prior costs and one owner payment. Actual seven-prime labels now reach
0.8544v<log(a)<=0.85476v and violate the old relative gap at every cofactor
prime. No source-o(1), effective threshold or growing-count uniformity claim.
The final -79/1000 floor and 3/2 ceiling remain open. The user's latest steer
is to find a SINGLE mechanism controlling all remaining share geometries,
counts and radial periods at a globally summable cost. Do not substitute
more isolated sector widening for this goal. Keep overlaps with previously
credited phase selections signed: a full-period completion cannot add their
credit again. Test the aggregate Riesz hinge/curvature and allocation costs
before developing new representations. See `docs/zeta-riesz-owner-geometry.md`.
Continue locally without subagents or unrequested commits. The preceding
slice `e9ebbfb353aaff22c529e9c3056751a7ebeee484` passed exact-SHA Lean Action
CI run `36485037998`, including Pages deployment. That success does not
cover this newer local extension.

The fixed-count signed payment now crosses saturation: its cofactor band
extends to 7v/10 instead of 133v/200. `ZetaRieszFixedCountPeriod.response`
retains BOTH R_(log(pa)-L)(a) and -R_(log(a)-L)(a). The second is constant
on a prime fibre, so it adds no cutoff variation; twice the previous fixed
amplitude constant suffices. Never discard this unsaturated correction.
`eventually_unsaturated_extra` proves actual added seven-prime labels have
0.6948v<log(a)<=0.6984v and a strictly positive second response on the
literal 0.693..0.6932 cutoff-ratio band. All three fixed-count optional
applications use this wider population in BOTH whole estimates, retaining
the same <1/90000 local debit and >=(N/16)*sourceCredit margin. Preserve
all masks, favorable observations and the single owner payment. The final
floor and ceiling remain open; no source-o(1), growing-count or zero-free
claim. See `docs/zeta-riesz-unsaturated-periods.md`. Continue locally,
without subagents or unrequested commits.

`ZetaRieszCofactorMass`, `ZetaRieszFixedCountPeriod` and
`ZetaRieszFixedCountBand` now give ONE signed full-prime-period estimate
at every fixed cofactor count. Actual least-prime mass is <=C_k*v,
reciprocal mass <=C'_k*sqrt(v), and the literal factorial allocation
variation is <=4(k+1)*sqrt(N+1)/v times the radial displacement. All
small primes and coefficient sign changes remain. Counts and constants
are fixed; do not claim a rate uniform in growing count or source-o(1).
The concrete new family includes total counts 7–55 in the cofactor band
203v/500<log(a)<=7v/10 with log(q)<=199v/200-log(a), together with the
old six-prime payment exactly once. Each new count costs <=1/100000000
of the local radial unit; the combined debit is <1/90000. Actual added
seven-prime labels exist eventually. `CheckRieszFixedCountLocal`,
`CheckRieszFixedCountJoint` and `CheckRieszFixedCountWhole` preserve BOTH
whole inequalities and the previous >=(N/16)*sourceCredit margin, all
favorable observations, the single global owner payment and all six-prime
signed costs on the smaller exact unpaid rest. Reuse cached covers.
The default whole endpoint and both numerical endgame bounds remain
unchanged/open. Next work must improve BOTH whole estimates and their
remaining geometry/radial coverage, not merely produce another count
reformulation. See `docs/zeta-riesz-fixed-count-periods.md`. Continue
locally without unrequested commits or subagents.

`ZetaRieszSixSmallHinges` and `ZetaRieszSixSmallPrimes` now pay the previously
untreated no-reflected-large six-prime sector in BOTH growing-band whole
comparisons. For all six prime logs <=D and 3D<=log n, the complete signed
Riesz response is <=log(minFac n). The original coefficient interval improves
from [-3,4] to [-1,4] in actual `(log n/L)*log(minFac n)` units. Keep pair and
triple hinges together: individual signed divisor windows can still reach
three, so do not infer this bound pointwise inside the old integral.
`CheckRieszSixSmallWhole` uses the new directed costs only on exact unpaid
rest `S\(union_i E_i union D)`, retaining every earlier period observation,
the growing >=`(N/16)*sourceCredit` margin, owner payment and allocation error.
All reflected-large six-prime estimates are unchanged. The floor saves two
least-prime units times positive cosine; the ceiling saves two times negative
cosine. These are alternatives, not two supplies to add. All original masks,
small primes, factorial orders, phases and other counts remain literal.
Both numerical whole endgame bounds remain OPEN. This is an independent
coefficient/subset estimate and its compiled whole-sum use, not a zero-free
result. See `docs/zeta-riesz-six-small-primes.md`. Reuse cached optional covers;
continue locally without unrequested commits or subagents.

`ZetaRieszSaddleBand` and `ZetaRieszSaddlePacking` now extend BOTH whole
signed comparisons to a GROWING square-root radial band. For fixed |y|>=54,
M_N=1+floor(|y|*sqrt(N)/(4*pi)), with centers v+2*pi*i/|y| and
2N<=v<=2N+1/2, stays inside [2N,2N+sqrt(N)]. Uniform moving-cutoff,
radial and literal signed six-prime estimates retain the same constants.
`CheckRieszSaddleBandLocal` isolates each paid population's signed inequality;
`CheckRieszSaddleBandJoint` sums DISJOINT populations, not repeated whole-sum
inequalities. Keep every favorable period observation separately. The net
margin `(M_N*sqrt(N+1)/16-1/8)*sourceCredit` is proved >=`(N/16)*sourceCredit`.
Pay the owner population and global companion error ONCE. All M_N separate
Q allocation errors fit `(N+1)*allocationBound -> 0`. `CheckRieszSaddleBandWhole`
applies previous reflection costs only to exact rest `S\(union_i E_i union D)`.
All original masks, small primes and factorial orders remain. The older fixed
period centers are included and replaced, never paid twice. Cached covers
are unchanged. This is eventual at fixed height/parameters, with no certified
starting order; the floating geometry probe is not an arithmetic certificate.
It covers a growing part of the right saddle, not the entire core. Both final
whole numerical thresholds remain OPEN. See `docs/zeta-riesz-saddle-band.md`.
Continue locally without commits or subagents. Every next slice must improve
both whole estimates, rather than stop at a new representation.

`ZetaRieszMultiPeriodSix` now REPLACES the previous single-period six-prime
payment in BOTH whole comparisons. It pays `1+floor(abs(y)/(4*pi))` disjoint
full periods, at least five, with centers spanning at most half a unit.
All original transition cofactors, small primes, factorial orders, literal
allocation and physical/core masks remain. Fix precision epsilon/M before N;
the sum of absolute real PERIOD sums has the same relative radial debit.
Do not take absolute values of individual prime atoms. Keep the floor's
SUM of positive period parts and the ceiling's SUM of negative period parts;
do not replace these by the positive/negative part of their combined sum.
The previous period is included and replaced; extra actual labels exist
eventually. `CheckRieszMultiPeriodSixJoint` and `CheckRieszMultiPeriodSixWhole`
retain the same `(sqrt(N+1)/16-1/8)*sourceCredit` margin and only Q's separate
allocation error against exact rest `S\(P union I union H union Q union multiZ
union D)`. The owner band is paid once. Earlier reflection costs apply only
to that smaller rest. This is relative local o(radial), NOT source-o(1),
for fixed height with existential starting order. The full radial saddle,
remaining labels and both final whole thresholds are still open. Reuse
cached covers unchanged. See `docs/zeta-riesz-multiple-periods.md`.
The baseline commit `36042c008d85d3575f1625a51163d64f3db73799` passed
Lean Action CI run `36461429079`; that CI result does not cover these newer
local multiple-period theorems. Continue locally without commits or subagents
until requested otherwise.

`ZetaRieszTransitionSixPeriod` now REPLACES the preceding six-cofactor
payment in BOTH whole comparisons. Its lower cofactor cut `203v/500`
crosses the former owner-share allocation transition `19/32` while retaining
all previous extra cofactors. `ZetaRieszAllocationVariation` proves exact
binomial variance and literal share variation `<=24*sqrt(N+1)/v*abs(T-U)`.
Keep the allocated fraction INSIDE the signed prime sum; it need not vanish.
Every moving owner is proved in `intermediatePrimes`; the other prime masks
remain fixed. All small primes, orders, phases and literal masks remain.
The actual new labels are proved to cross `19/32` eventually. The new
share cap `1189/2000` stays below the separately paid owner band `119/200`.
The full residual cost is relative local o(radial), NOT source-o(1), with
budget `1000*eta*C1+720*C1*sqrt(N+1)/v+100*C2/sqrt(v)`. No extra allocation
error is needed for this population. `CheckRieszTransitionSixJoint` and
`CheckRieszTransitionSixWhole` keep the same margin and favorable observations
on exactly `S\(P union I union H union Q union transitionZ union D)`; earlier
reflection costs apply only to that rest. Replace prior payments, never
spend them twice. Both final numerical whole bounds remain open. Reuse
cached covers unchanged. See `docs/zeta-riesz-allocation-transition.md`.
The user authorized committing and pushing all accumulated green work on
2026-09-28. Apply the publication gates, record the exact SHA and CI result,
and continue concrete joint WHOLE estimates without subagents.

`ZetaRieszSixCofactorPeriod` now REPLACES the wide six-prime payment
in BOTH whole comparisons. It adds the actual five-prime cofactor band
`3v/5<log(a)<=133v/200`, with every cofactor prime log `<=33v/100`, to
all earlier wide cofactors. The full largest-prime phase period, every
small prime, signs, original masks and allocation remain. Unique ownership
is proved. `eventually_added_population_nonempty` proves this is a STRICT
actual population enlargement eventually, not only a formal inclusion.
Actual cofactor mass constants are at most four times the original broad
constants; denominator cost is 5/v and allocated norm mass is
`<=240*C1*m*V*h`. The full residual sum still has arbitrarily small relative
radial cost. `CheckRieszSixCofactorJoint` and `CheckRieszSixCofactorWhole`
keep `(sqrt(N+1)/16-1/8)*sourceCredit`, all prior favorable observations,
and only Q's separate allocation error, on exactly
`S\(P union I union H union Q union enlargedZ union D)`. Earlier reflection
costs apply only to this rest. Do not count any previous six-prime payment
twice. Relative local o(radial) is NOT source-o(1), thresholds are
existential, and both final whole thresholds remain open. Reuse cached
covers unchanged. The ~96.3% angular probe is not an arithmetic certificate.
See `docs/zeta-riesz-six-cofactor-period.md`. Hold commits and subagents.
Continue concrete joint WHOLE estimates for the remaining labels and periods.

`ZetaRieszWideSixPeriod` now REPLACES the preceding broad six-prime
population in BOTH whole comparisons. The exact cofactor set is
`(B(v) union B(4v/5))` filtered by `log(a)>41v/100`, with the original full
largest-prime phase period. Every small prime, coefficient sign, core mask
and allocation is retained. The new `591/1000` prime-share cap has proved
allocated fraction `<=6*exp(-N/100000)`. This rate DOES NOT beat the crude
source envelope: it is paid only against actual local population mass.
`eventually_residual_population_small` bounds the FULL residual sum at
arbitrarily small relative radial cost. No separate allocationBound is
needed for Z. `CheckRieszWideSixJoint` and `CheckRieszWideSixWhole` retain
the same `(sqrt(N+1)/16-1/8)*sourceCredit` margin and favorable observations,
with only Q's separate allocation error, on exactly
`S\(P union I union H union Q union wideZ union D)`. Prior reflection costs
apply only to that rest. The previous broad population is included and
replaced, NEVER paid twice. This is relative local o(radial), NOT
source-o(1); the final independent whole floor and ceiling remain open.
Cached covers stay unchanged. The optional ~92.5% angular coverage probe
is not a certificate. See `docs/zeta-riesz-wide-six-period.md`. Hold commits
and subagents; continue concrete joint WHOLE estimates, including their
literal masks and remaining signed sum.

`ZetaRieszBroadSixPeriod` now REPLACES the small six-prime plateau in
both whole comparisons. The five-prime cofactor log is in
`(56v/125,3v/5]`, every cofactor prime log is at most `39v/100`, and the
unique largest prime runs over the full phase period at `2N<=v<=2N+1`.
Every small prime and both coefficient signs remain. The exact varying
Riesz coefficient, slope-eight cutoff bound, O(v) logarithmic cofactor
mass and O(sqrt v) unweighted mass give arbitrarily small relative raw
cost. `ZetaRieszSaddlePeriod` supplies arbitrarily precise actual signed
prime-period bounds. No zero or simplicity premise is used. The broader
population provably contains the old plateau, so NEVER pay both.
`CheckRieszBroadSixJoint` and `CheckRieszBroadSixWhole` retain the same
`(sqrt(N+1)/16-1/8)*sourceCredit` margin, all prior observations and two
allocation errors against precisely the new smaller rest
`S\(P union I union H union Q union broadZ union D)`. The second-reflection
costs apply only to that rest. Cached numerical covers are reused unchanged.
The raw estimate is relative local o(radial), NOT source-o(1); both final
whole thresholds remain open. The optional angular probe suggests broad
coverage but is not an arithmetic certificate. See
`docs/zeta-riesz-broad-six-period.md`. Hold commits and subagents. Each next
slice must improve joint WHOLE estimates, including their actual masks and
signed rest; prioritize the remaining populations and phase periods.

`ZetaRieszSixPrimePeriod` now pays a genuine signed six-prime population.
Four middle primes have logs in `(14v/125,27v/200]`; EVERY least prime with
log at most `v/200` is retained, including fixed small primes. Across the
complete last-prime period the literal coefficient is exactly
`-3*(log(n)/L)*log(minFac(n))`. Actual weighted cofactor counts and the
signed factorial prime-period estimate give raw cost `m*V*h/100000`.
All original core masks, unique ownership and allocation are checked;
the allocated correction is the existing geometric error. The population
is proved nonempty eventually. `CheckRieszSixPeriodJoint.lean` spends it in
BOTH certified whole comparisons, without overlap with P,I,H,Q,D. The new
rest is `S\(P union I union H union Q union Z union D)` and the margin is
`(sqrt(N+1)/16-1/8)*sourceCredit`, with two allocation errors. All numerical
cover premises are discharged using the cached assemblies. The final
`CheckRieszSixPeriodWhole.lean` also retains the previous second-reflection
costs on precisely this smaller rest. Do not combine this smaller rest
with an older larger margin. This is a relative local signed payment,
not source-o(1) or either final whole threshold. See
`docs/zeta-riesz-six-prime-period.md`. Hold commits and subagents. Continue
with signed population estimates for the unpaid sectors and remaining
periods; do not revert to pointwise-only progress.

`ZetaRieszSixPrimeSecondReflection` now reduces the unpaid one-large
six-prime charge by reflecting its five-prime active cofactor again. If
one, two or three additional genuine cofactor primes are inactive, the
original coefficient intervals are [-2,1], [-1,1] or [0,1] in least-prime
units; the four-factor outer thirds improve the first lower endpoint to
-1. Unsupported counts keep their previous cost. The original least prime,
integer, phase and allocation are preserved, and each signed allowance is
clipped against the existing midpoint estimate. `costs_le_centered` proves
both costs never increase. `scripts/CheckRieszSixSecondWhole.lean` applies
them to BOTH concrete whole comparisons, only on exactly
`S\(P union I union H union Q union D)`, without changing their certified
populations, favorable observations, vanishing error or
`(2/25*sqrt(N+1)-1/8)*sourceCredit` margin. All numerical cover premises are
discharged. The angular probe suggests lower coefficient envelopes, but
is not a certified population payment; neither final whole threshold is
closed. See `docs/zeta-riesz-six-second-reflection.md`. Hold commits and
subagents; reuse the optional checked covers unchanged. The next estimate
must control a signed population, not infer a whole constant from this
pointwise gain or the floating diagnostic.

`ZetaRieszPrimePeriodCancellation` and `ZetaRieszTriplePeriod` now prove
signed cancellation across a complete phase period of literal unbalanced
triples. The cofactor windows are `(9v/25,2v/5]` and `(2v/25,v/10]` in
prime logarithms. The exact coefficient, cofactor-dependent final-prime
interval, factorial kernel, phase, core masks and original allocation are
retained. The raw weighted prime-period cost is `1/500`; actual cofactor
counting gives `m*V*h/6250`, with V bounded ABOVE and below by the original
radial kernel. The terminal `eventually_whole_saddle_bound` chooses a
nonempty population at `2N<=v<=2N+1/2` and bounds BOTH sides of the SAME
whole J+C against its exact signed complement with explicit debit
`pi/(25000*abs(y))*u^(N+1)*exp(-v/2)*v^N/N!+o(1)`.
No zero or simplicity premise is used. This is a relative local payment,
not source-o(1); the numerical whole floor and ceiling remain OPEN.
The payment is now combined with the expanded P,I,D,H ledger in
`ZetaRieszJointTriplePayment` and the optional
`scripts/CheckRieszCertifiedTriplePeriod.lean`. All disjointness is proved;
Q is removed exactly once, and its geometric allocation error is included.
The new margin is `(2/25*sqrt(N+1)-1/8)*sourceCredit` against exactly
`S\(P union I union H union Q union D)`. Both comparisons retain the favorable
coupled Q observation, all earlier observations and original masks. The
six-prime variants use their existing centered charge only on this smaller
unpaid rest. Do not pair an older larger margin with this new remainder.
See `docs/zeta-riesz-combined-triple-payment.md`. Keep this supporting
explorer endpoint distinct from the main RH endpoint. Hold commits and
subagents.

The full positive-five interior now has a kernel-checked 100001-leaf cover:
all 1051 chunks, their repaired assembly and the concrete optional whole
applications passed. The assembly repair only replaces generated rational
third-coordinate simplification with `decide +kernel`; unchanged chunk
hashes and results were revalidated. The exact total is
`664412815772131473729/167772160000000000000000 < 3961/1000000`.
With the proved `1003/1000` counting overhead and `1/100000` slack it pays
the full interior at `1/250`. Its population I REPLACES the old fixed B;
never charge both. Before the new Q payment, the expanded comparison has
margin `(2/5*sqrt(N+1)-1/8)*sourceCredit` and exact rest
`S\(P union I union H union D)`. After Q use only the new margin above.
The coverage theorem removes all nonzero positive five-prime coefficients
in the selected period. Other counts, negative signs and periods remain.
Both numerical whole endgame bounds remain OPEN; sourceCredit grows for
u>1/2. See `docs/zeta-riesz-full-positive-five-payment.md`. Keep exhaustive
covers optional and reuse checked artifacts only with matching hashes.

`ZetaRieszSixPrimeReflection` independently proves the literal six-prime
two-reflected-large coefficient interval `[-1,1]`, replacing `[-3,4]` in
least-prime logarithm units. Its core-subset inequality retains the exact
phase, allocation, favorable observations and every other count. The
one-reflected-large interval is also reduced to `[-3,3]`; the terminal
core-subset comparison uses charges 3, 1 and 0 for one, two and three
reflected-large primes respectively. Three-large cancellation is exact.
The optional full-five application's additional floor/ceiling use this only
on their unpaid rest, with no extra credit. The concrete
applications pass with the positive-five cover now checked. No population
density, final whole constant bound or zero exclusion follows from the
pointwise savings alone.

`ZetaRieszSixPrimeCentered` clips the one-large charge further by the
exact five-active-prime midpoint cancellation. With T=log n, D=T-L and
a=activePart(D,n), its original coefficient costs at most
`(T/L)*min(3*log(minFac n),4*abs(2*D-log a))`. The corresponding charge is
proved no larger than the earlier reflected charge. The same optional
whole floor and ceiling apply it only to their unpaid remainder, retaining
all prior credits, favorable observations and masks. Its numerical density
diagnostic is not a population certificate; both final whole thresholds
remain open. Preserve the cached cover's checked inputs.
The independently checked `scripts/CheckRieszSixCenteredJoint.lean` applies
this refinement to BOTH earlier certified whole comparisons using only
the cached four/negative-five covers. It retains P,B,D,H and their old
margin; no new positive-five certificate is assumed. Never mix that
comparison's larger margin with the expanded comparison's smaller rest.

`ZetaRieszPositiveFiveBoundary` now pays the SAME positive-five small-prime
boundary with local constant `3/40000` and period constant `g/1600`, each
25 percent below its preceding debit. The existing whole saddle floor and
ceiling spend this sharper bound, retaining all P,B,D,H populations and the
identical signed rest, with margin `(25/2*sqrt(N+1)-1/8)*sourceCredit`.
The exact gain over the preceding endpoints is `sqrt(N+1)*sourceCredit/2`;
neither final numerical whole bound is closed. `ZetaRieszPositiveFiveInterior`
checks the ACTUAL near-saddle bin `693/1000..1733/2500`, the exact translated
cofactor cap in the original five-prime coefficient, and harmonic cap
subtraction with full integrability. Two accepted cap certificates bound
the entire translated fibre, including the zero endpoint. These are the
correct inputs for the positive-five interior debit. The complete 3D
cover and literal ordered-prime transfer were open at that earlier stage;
the checked full-interior payment above now discharges them. Spend only
its proved rational debit, not the floating probe. Do not count the fixed positive-five sector a
second time when paying its full interior union. Starting thresholds stay
unevaluated; `N>=20000` alone does not discharge the eventual length bound.
See `docs/zeta-riesz-positive-five-interior.md`. Keep all previous no-gos,
all multiplicities and the exact signed rest. Continue locally without
commits, subagents or exhaustive cover reruns.

`ZetaRieszSaddleCredit` restores the factorial square-root factor in the
SAME whole comparisons. Stirling monotonicity gives `N!<=3*sqrt(N)*(N/e)^N`
for every N>=1, hence radial bound `exp(-1)*2^N/(3*sqrt(N))` on the actual
saddle window and `2*sqrt(N+1)*sourceCredit` per old normalized credit.
The cached `eventually_joint_saddle_boundary_floor` and `..._ceiling`
retain exactly P,B,D,H, every favorable observation and the same signed
rest, with margin `(12*sqrt(N+1)-1/8)*sourceCredit` replacing `47/8` times
that credit. This is a concrete strengthening of both WHOLE bounds, not
a new positive-five counting or cancellation theorem. Both final numerical
thresholds remain OPEN. See `docs/zeta-riesz-saddle-joint-credit.md`.
The new optional three-variable fibre probe preserves the second-largest
cofactor denominator and suggests an interior cost near 0.004 on a tighter
saddle bin. Its floating output, the refined moving-length bin and the
literal transfer are NOT certified; do not spend those values. Keep all
previous payments and no-gos, use cached covers, and continue locally
without commits or subagents.

`ZetaRieszPositiveFiveBoundary` pays an additional literal boundary in both
WHOLE J+C comparisons: positive squarefree five-prime labels in the original
central phase period, largest share below `119/200`, and a prime share at
most `1/100000000`. Exact coefficient geometry forces the other three
cofactor logs above `9t/100`; the marked logarithmic weight, three finite
reciprocal sums and exact last-prime interval give local cost `V*h/10000`
and period cost `g*V0*h/1200`. The cached `eventually_joint_boundary_floor`
and `..._ceiling` retain the SAME old P,B,D payments, selecting H only from
their signed complement, and preserve all `47*sourceCredit/8`. The raw
margin after B and H is `37*g*V0*h/6000`, still paying six credits before
the owner debit. The favorable H observation remains explicit. This
removes the small-prime boundary from the positive-five interior in that
period; it does not pay all positive-five labels, other periods or the
whole signed rest. Both numerical bounds remain OPEN. Starting orders are
unevaluated. See `docs/zeta-riesz-positive-five-boundary.md`. Continue
locally without commits, subagents or exhaustive cover reruns.

`ZetaRieszCentralSharpBudget` strengthens the SAME joint payment: the full
triangular cosine minorant gives mass at least `2g` on each alternative
favorable half-period, and the actual short-cell radial factors are
`99999/100000` and `50001/50000`. Here `g` is the phase mesh count, NOT zero
multiplicity. The central margin improves from `g*V0*h/500` to
`g*V0*h/125`. The cached optional `eventually_joint_sharp_owner_floor` and
`..._ceiling` retain the old positive-five and all-count owner payments,
both favorable observations and the SAME signed rest, with reserve
`47*sourceCredit/8` replacing `3*sourceCredit/8`. These are alternative
bounds, not two additive supplies. The gain is exactly `11*sourceCredit/2`
in each comparison; it is not a source-normalized constant floor/ceiling.
Both whole numerical thresholds remain OPEN. Do not widen the paid
positive-five population without a new literal estimate. Continue locally
without commits, subagents or exhaustive cover reruns. See
`docs/zeta-riesz-sharp-joint-budget.md` and the refreshed optional audit.

`ZetaRieszJointOwnerPayment` pays the all-count owner interval
`119/200 <= log(p)/log(n) <= 13/20` from the EXISTING joint reserve.
The original missing allocation is at most `3*exp(-N/400000)`; summing
actual atom norms with the fixed divisor majorant gives
`3*M_sigma*2^N*exp(-N/500000)`, `sigma=1+1/100000000`.
This is small RELATIVE to sourceCredit, not independently source-o(1).
The optional cached transfer's `eventually_joint_owner_floor` and
`..._ceiling` retain the earlier positive-five payment, both favorable
observations, and `3*sourceCredit/8`, paying only the previous signed rest.
`remaining_prime_log_lt` discharges the actual core masks and shows every
nonzero label in the new rest has all prime shares below `119/200`.
Both whole-sum numerical thresholds remain OPEN. Never add alternative
lower/upper credits or reuse the earlier paid populations. Keep all work
local and use cached covers; no subagents or exhaustive reruns.
See `docs/zeta-riesz-joint-owner-payment.md`.

`ZetaRieszPositiveFiveBudget` now gives a literal local debit at most
`(1/10000)*exp(-t/2)*(t+h)^N/N!*h` for positive-coefficient squarefree
five-prime labels whose four nonlargest log shares lie in `1/10..9/80`.
Its last-prime interval keeps the exact cofactor endpoint. All original
masks/allocation/phase remain; the moment threshold is existential.
`ZetaRieszJointPositiveFiveBounds` pays the COMPLETE original phase period
from half the existing central `m*V0*h/500` reserve. The optional cached
`CheckRieszCentralCapacityTransfer` now checks
`eventually_joint_positive_five_floor` and `..._ceiling` for the actual
WHOLE J+C, retaining `sourceCredit/2`, favorable new observations, a proved
vanishing boundary error and one signed rest. Only labels in the OLD rest
are newly charged; do not spend old angular or radial supplies twice.
These are alternative lower/upper comparisons, not simultaneous additive
credits. The SevenCountTail/reflection comparisons remain separate.
This removes one fixed positive-five sector over a central period, not
all five-prime labels or the whole radial band. Both numerical endgame
thresholds remain OPEN for all multiplicities. The ordinary library proves
the literal cost/spending lemmas; the cached optional application discharges
its central-cover inputs. Do not rerun exhaustive covers in ordinary CI.
See `docs/zeta-riesz-positive-five-payment.md` and the updated central audit.
The probe is optional and uncertified; no theorem uses its sampled values.
Keep default frontiers/top-ten lists unchanged; continue locally without
commits, pushes or subagents until further user instruction.

The user's latest steering (2026-09-28) makes concrete improvement of the
WHOLE joint floor/ceiling estimates the acceptance criterion for each slice.
Do not stop at an isolated coefficient bound, representation or transport
lemma. Apply any component saving to the existing unpaid joint remainder,
preserve all paid populations and their spending ledger, and exhibit the
resulting improvement in the actual `J+C` estimate. Distinguish such an
improved finite comparison from reaching the required numerical constants.

The user's latest instruction authorizes committing and pushing the complete
accumulated local work after the reflected-prime slice passes all gates.
This supersedes the older local-only instructions for this publication.
Keep working without subagents. Include the multiplicity audit and all
compatible local arithmetic improvements, with refreshed campaign metadata
and the unchanged open whole-sum obstruction.

The user's latest minimal-endgame instruction (2026-09-26) takes precedence
over component-decay plans: directly target a cofinal floor for the JOINT
sum and its signed complement. Separate smallness of either is unnecessary.
`ZetaRieszJointFloor` now connects the existing expression
`lowerThresholdPacket - shortOverflowPacket + ZetaRieszLeastBoundary.rest`
to the retained source using only the already paid errors. No new carrier
is defined. For `1/2<u<=10001/20000`, `retainedCost_lt_restricted` proves
`retainedCost u<921/1000`. `false_of_joint_cofinal_floor` therefore needs
only, for a SIMPLE exposed zero, a cofinal source-normalized real floor `-79/1000-err_j`, where
`err_j->0`, for the WHOLE displayed expression. Neither individual limit,
individual norm estimate, nor separate rest allowance is a prerequisite.
This is a checked sufficient criterion with an OPEN arithmetic premise,
not an independent joint floor or new zero exclusion. See
`docs/zeta-riesz-joint-floor.md`. Numerical packet-only values do not test
this joint criterion unless the same signed complement is included.
The 2026-09-27 multiplicity audit is a separate endgame obligation.
Exposure selects a location and never implies analytic multiplicity one.
`retainedCost_gt_nine_tenths` and `multiple_source_gt_three_halves` prove
that the SAME source `-m+m^2*c_ret(u)` exceeds `3/2` for every `m>=2`.
The negative floor alone therefore cannot exclude multiple zeros.
`false_of_joint_cofinal_bounds` checks an all-multiplicity repair using
that floor and an additional independent cofinal ceiling `3/2+o(1)` on
the SAME literal sum. Both whole-sum inequalities remain OPEN. Do not
advertise the new conditional criterion as an arithmetic upper bound or
as a restricted zero exclusion. The proved simplicity boundary layer is
height dependent and does not cover the entire fixed candidate strip.

The local complete-period slice is documented in
`docs/zeta-riesz-capacity-phase-payment.md`. `ZetaRieszJointCapacityFloor`
combines the complete four/five-prime angular inequalities with one
disjoint spending ledger. `ZetaRieszCapacityPhaseBudget` pays the full
period's distinct radial/phase envelopes, including cosine-zero
neighborhoods, and constructs an actual period in the first certified
ratio bin on the original dyadic schedule. The optional
`scripts/CheckRieszJointCapacityTransfer.lean` imports only the cached
assemblies and proves `eventually_exists_first_bin_payment`: its literal
population union has strictly positive real response. This does not give
a uniform positive source-normalized surplus. Other bins and the signed
complement remain unpaid. Do not add overlapping older five-prime supply.

`ZetaRieszOppositePhase.eventually_five_cell_core_ceiling` now gives an
explicit negative five-prime credit on a positive-cosine window.
`eventually_four_core_ceiling` bounds the entire clipped positive-coefficient
four-prime population with all log(p)>delta*N at the original height, with exact relative
calibration cost <=1001/1000. Calibration at pi/t changes only the proof's
observation, not any coefficient, allocation or support mask;
`mem_calibrated_population_iff` proves no eligible label is dropped.
Both preserve the complete signed complement and are component estimates,
not the independent whole-joint-sum ceiling. Continue locally without
subagents or new carrier representations. Keep the heavy angular covers
outside ordinary CI; cached transfer checks do not rerun their verification.

`ZetaRieszJointCapacityCeiling.eventually_five_core_ceiling` calibrates the
complete existing angular population at once. The optional
`eventually_first_bin_joint_ceiling` discharges its credit as 6823/50000
and combines it with debit 133555/1000000 in one disjoint upper ledger.
`eventually_exists_first_bin_upper_payment` proves a genuine negative
component on every sufficiently large dyadic order, with an actual positive
cosine peak inside the first certified bin. The quantitative credit is
h*exp(-t/2)*t^N/(1000*N!). This is not the whole-carrier 3/2 ceiling;
retain the complete signed complement and all multiplicities. The upper
and lower payments are alternative inequalities, not additional independent
supplies that may be summed without a new disjoint ledger.
`eventually_exists_first_bin_upper_period` now extends that upper payment
to a COMPLETE original phase period. `original_finite_upper_period_budget`
pays radial variation and phase uncertainty in every cell, including the
cosine boundaries, with margin m*V0*h/2000. The actual four-prime population
is complete throughout the period (`mem_full_period_calibrated_iff`);
only favorable five-prime credit is spent, and every unspent five-prime term
stays in the single signed complement. No zero or simplicity is assumed.
This remains a component inequality, not the whole-joint-sum ceiling.
The central saddle bin has proved moving-length geometry in
`eventually_central_bin_ratio` and `eventually_exists_central_bin_period`.
The optional bin-2 FOUR-prime cover in `.lake/riesz-four-capacity-bin2`
has passed all 85 chunks and assembly. `CheckRieszCentralCapacityTransfer`
then proves `eventually_central_window_four_ceiling`, with calibrated
constant 121003/1000000 throughout actual windows in 1.999N..2.001N,
retaining the signed complement. The FIVE-prime cover in
`.lake/riesz-five-capacity-bin2` has now passed all 447 chunks and assembly.
The cached `CheckRieszCentralCapacityTransfer` passes warnings-as-errors,
its namespace lint and terminal axiom audit. The owner-enhanced central
credit is 1309/10000 after upper calibration; the common broad-triple/four
debit is 1261/10000. `eventually_exists_central_bin_three_four_five_period`
and its `..._upper_period` counterpart prove actual complete-period
payments, with quantitative margin g*V0*h/500 in the preceding payment
theorems. Here g is the mesh count, not zero multiplicity. Preserve one
signed complement, all masks and the existing small-prime threshold on the
four-prime population. These are independent component comparisons, not
whole-sum bounds. Their later source-scale refinement is recorded below.
The checked sources
and reproducible commands are recorded in
`docs/riesz-central-capacity-audit.json` and the phase-payment note.
Do not rerun cached exhaustive covers during ordinary CI or local builds.
`ZetaRieszBalancedTripleBudget` now pays the literal squarefree triple
population with EVERY prime share in `997/3000..1003/3000`. Its reciprocal
mass is eventually <=h/(8000*t); the coefficient/allocation/kernel transfer
costs <=1/10000 of the original radial and separate one-sided phase
envelope. The optional first-bin transfer spends the SAME five-prime
credit against both this triple band and the four-prime debit. The
three counts are disjoint; no older four-prime compensation is added.
`eventually_exists_first_bin_three_four_five_period` and its
`..._upper_period` counterpart prove complete-period payments at every
sufficiently large original dyadic order, each with margin g*V0*h/2000.
Here g is the phase mesh count, NOT the analytic zero multiplicity.
`mem_full_period_iff` proves the triple selection covers the entire
half-open period, including phase boundaries. Keep the single exact
signed complement in each inequality. These are alternative lower/upper
ledgers, not independent supplies to add. Other triple shapes, count/sign
sectors and cutoff bins are unpaid; no fixed source-normalized surplus,
whole-sum bound or zero exclusion is claimed. See the same phase-payment
note. Work locally without subagents; optional transfers use cached covers.
`ZetaRieszBroadTripleBudget` now preserves SIX distinct ordered prime
representations for every squarefree triple in the share band
31/100..7/20. The sixfold fibre inequality bounds its actual reciprocal
mass by (19/2000)*h/t, and its coefficient/allocation/kernel debit by
(1/200)*Vplus*h, with separate original positive/negative phase factors.
No prime-density transport or zero hypothesis is used. Its optional
central-bin three/four-prime transfer has lower debit 125882/1000000 and
upper debit 126003/1000000 on literal windows in 1.999N..2.001N; the moving
length premises are discharged and the signed complement is retained.
The broader band CONTAINS the narrow band; never add those charges or
spend overlapping older compensation again. Its central five-prime payment
is now checked as described above. The numerical probe and its older
proposed credit remain diagnostic; the actual payment uses the checked
1309/10000 credit. No whole-sum bound or zero exclusion is claimed.
Preserve the generated certificate input hashes and cached results.
`ZetaRieszFivePositiveHead` now proves the positive five-prime coefficient
costs ONE marked-prime logarithm, improving the earlier factor three.
Two small cofactor primes kill its positive part, not its negative part.
Literal counting bounds the surviving positive head by
`113246208*(log 4)^5*exp 4*(1+log Q)*exp(2M)/(M+1)*radialEnvelope`.
The `Q=N^2` head costs an arbitrarily small fraction of the existing
signed supply's radial scale; a fixed positive exponential head width
also has a relative-cost theorem. `eventually_core_joint_floor` pays the
new polynomial head along with the old narrow triple band and count-3/4
heads from ONE supply, leaving one eighth and the exact signed rest.
This replaces the older one-quarter leftover. Do not add the overlapping
ledgers or infer separate source-normalized head decay. Other signs,
sizes, counts and the whole signed complement remain unpaid; both
whole-joint-sum multiplicity bounds stay open. See
`docs/zeta-riesz-five-positive-head.md`. Work locally without commits,
pushes or subagents; the checked central comparison remains independent.
The same module's `eventually_core_full_exponential_floor` now pays the
whole common exponential head (`p<=floor(exp(delta*N))`) of counts 3/4
and the POSITIVE five-prime class, together with the original balanced
triple band. Radial and dominant-prime failures have the existing
`r^N*C+2*majorantMass*exp(-N/1000000)` source-normalized allowance, which
vanishes. One eighth of ONE supply and the exact signed rest remain.
The common delta is chosen afresh; do not identify it with an older
separately chosen width or add the earlier ledger. Every prime in a
surviving positive five-prime label exceeds the new exponential threshold.
The optional `probe_riesz_signed_counts.py` is an uncertified continuous
sign audit with no allocation/phase/radial transport or higher-count tail
bound. Its substantial broad triple and higher-count masses are a warning
against assuming that the current five-prime credit pays the whole rest,
not a formal no-go theorem. No whole-sum floor or ceiling is claimed.
`ZetaRieszHeadCeiling` now supplies the UPPER counterpart for the same
literal core. Positive-cosine windows give an actual negative four-prime
supply at the original height; no simplicity or zero hypothesis is used.
`eventually_core_full_exponential_ceiling` pays the common exponential
heads of counts 3/4 and the positive five-prime class plus the balanced
triple band, retaining every negative selected observation, one eighth
of the negative supply, the signed rest, and the already paid vanishing
radial/dominant allowance. It is an upper COMPARISON, not the whole-carrier
3/2 ceiling. Lower and upper widths/windows may differ; do not add their
credits or claim their rests cancel. See `docs/zeta-riesz-head-ceiling.md`.
The goal and both whole-joint-sum arithmetic inequalities remain open.
Work locally without commits, pushes or subagents.
`ZetaRieszFiveOwnerBoxes` now strengthens the SAME `interiorFamily`
comparison by an additional `1/800` angular credit throughout cutoff bins
inside `69/100..7/10`. All 246 rational cube scores, their uniqueness and
their total `1397410/1000000000` are checked by the Lean kernel.
`owner_integral_lower` gives `1/750`; `ownerRegion_subset_cells` places
every cube inside the original fine grid. Their owner shares exceed 1/2,
so `ordered_plus_extra_le_cells` adds their integral to the old credited
region without duplicating the already larger literal population.
`eventually_owner_core_floor` and `eventually_owner_core_ceiling` retain
the full signed complement and original phase/allocation/physical masks.
The upper credit has its explicit relative calibration factor. The 1/800
is an angular coefficient; a source-scaled period bound is proved by the
subsequent refinement below. Neither is a whole-sum multiplicity bound.
Do not add a second overlapping prime supply or count the numerical probe
as an arithmetic theorem. The generator proposes only a small exact table;
the optional continuum probe and long central cover stay outside ordinary
CI. See `docs/zeta-riesz-five-owner-credit.md`. Preserve frozen cover inputs,
all previous no-gos and the open whole-floor/ceiling obligations. Continue
locally without commits, pushes or subagents.
`ZetaRieszCentralReserve` now retains the central radial scale instead of
only its positivity. `eventually_exists_central_bin_period_at_saddle`
keeps `2N<=v<=2N+1/2`; the two `...period_budget_with_radial` theorems
keep `exp(-v/2)*v^N/N! <= (501/500)*V0`. The optional literal transfer's
`eventually_exists_central_bin_lower_source_credit` and upper counterpart
therefore retain credit `G_N=pi*u*exp(-1)/(24000*abs(y))*(2u)^N/(N+1)`
with the exact existing signed complements. `sourceCredit_tendsto_atTop`
proves growth for every fixed nonzero height and u>1/2. The conditional
finite-source audits force the lower rest to minus infinity and the upper
rest to plus infinity. They do not show the WHOLE carrier diverges or
prove either arithmetic endgame. Keep the actual unused selected surplus
and opposing complement coupled; never replace either rest by a small
error or add the alternative credits. No stronger divergent whole-sum
target replaces the minimal cofinal floor/ceiling. See
`docs/zeta-riesz-central-reserve.md`. All starting indices remain
existential; the optional scalar probe evaluates a rate, not a finite
prime sum or certified starting order. Reuse cached covers, retain every
old statement, and continue locally without commits, pushes or subagents.
`ZetaRieszPhaseDensityAudit` now checks the proposed opposite-phase
counting shortcut. The REAL model error
`a*exp(-(u-1/2)*T)*cos(y*T)` is smaller than every fixed inverse power
of T, and `1+error` is eventually positive, but its exact source-normalized
factorial observation tends to `a/2`, also on `39N/20<T<=203N/100`.
Both exterior boundaries have the explicit vanishing gamma bound
`abs(a)*10000*(N+2)/(u^2*N^2)`. At a half-period shift the observed error
reinforces rather than cancels. Amplitudes -1/5 and 4 cross the two proposed
endgame thresholds in this MODEL. Do not report these as values or bounds
for primes or `coreResponse`: sieve, allocation and prime-factor masks
are not modeled. The result forbids neglecting a phase-correlated error
merely because local density estimates are accurate; it does not forbid
arithmetic cancellation. The new probe is optional and uncertified. See
`docs/zeta-riesz-phase-density-audit.md`, including the primary-literature
applicability audit. Keep both whole-joint-sum targets open and unchanged;
do not retry generic PNT transport or add another carrier representation.
Continue locally without commits, pushes or subagents.
`ZetaRieszSignedSperner` now preserves Mobius subset parity in the LYM
bound for the ORIGINAL divisor window. For k prime factors, let E and O
be the largest even/odd binomial layers on k-2 coordinates. The actual
coefficient lies in `[-(T/L)*log(minFac n)*E,(T/L)*log(minFac n)*O]`
at every positive cutoff. In particular, six-prime coefficients have
capacities [-6,4], improving the previous symmetric [-6,6]; eight-prime
capacities are [-15,20] instead of [-20,20]. The exact phase-specific
six-prime allowance is two thirds of the old allowance on negative
cosines for the floor, and on positive cosines for the ceiling.
`core_subset_bounds` keeps every favorable selected observation and the
complete signed complement, with all original factorial/allocation masks.
These are independent component estimates, not either whole-joint-sum
cofinal bound. Existing stronger four/five-prime bounds are not replaced.
`ZetaRieszSixPrimeGeometry` now proves the six-prime lower capacity THREE
whenever `2*log n<=3L`, so the signed interval is [-3,4] there. In the
reflected window, a pair and its complementary pair would force the total
logarithm below three times the cutoff, contradicting the actual geometry.
At most three positive pair terms remain; the unit and full-cofactor
boundaries are explicitly handled. `eventually_core_subset_six_bounds`
discharges the moving-cutoff premise for EVERY subset of the original core,
all heights and count ceilings, on the restricted radius range. Its two
charges are one-half/two-thirds of the original mean-prime allowance on
the respective cosine signs, retaining favorable observations and all
other counts exactly. No new prime supply is spent. The rational share
witnesses attain capacities -3 and 4, but are not asserted prime labels.
See `docs/zeta-riesz-signed-sperner.md`; no new zero exclusion or novelty
claim is made. Preserve both multiplicity targets and all prior audits.
Continue locally without commits, pushes or subagents.
`ZetaRieszSixPrimeHead` now pays EVERY six-prime core label containing
a prime `p<=N^2`, with both coefficient signs. The exact `[-3,4]` bound
leaves one marked logarithm; one large prime is counted at its actual
product endpoint and four unrestricted reciprocal prime masses cost
`O((log M)^4)`. The polynomial head has relative cost
`O((log M)^5/M)`, not separate source-normalized decay.
`eventually_core_full_floor` and `eventually_core_full_ceiling` use ONE
of the existing four-prime supplies, together with the old exponential
count-3/4/positive-5 heads and narrow balanced triple band. The fractions
now total 15/16, replacing the older 7/8 spending ledger. The original
interfaces remain, and their `..._with_scale` variants expose the actual
radial calibration. All radial/dominant boundary failures have the same
proved vanishing allowance; every favorable selected observation and one
exact signed rest remain. `remaining_six_prime_gt` excludes every prime
at most `N^2` from the unpaid six-prime population. The common exponential
width is chosen jointly and does not extend to count six. The starting
order is existential. Do not add overlapping credits or infer either
whole-sum multiplicity target. See `docs/zeta-riesz-six-prime-head.md`.
Preserve optional cached covers, unchanged public endpoints/top-ten lists
and all prior no-gos. Continue locally without commits, pushes or subagents.
`ZetaRieszPrimeFractionalBudget` now preserves the least-prime cost as
`min(r,a,b,c,d)<=sqrt(r)*a^(1/8)*b^(1/8)*c^(1/8)*d^(1/8)` in positive
logarithms. Literal dyadic prime shells prove
`sum (log p)^alpha/p <= [6*log4/(1-2^(-alpha))]*X^alpha` for alpha>0.
`ZetaRieszSixPrimeHead.small_six_fractional_norm_upper` therefore bounds
both signs of the entire six-prime head by an explicit constant times
`sqrt(log Q)*sqrt(2M+2)` times the same radial scale. Its relative cost
is at most `4*B*sqrt(epsilon)` for logQ<=epsilon*N.
`ZetaRieszSixPrimeExponentialHead.eventually_core_full_floor` and its
ceiling counterpart now pay the WHOLE fixed exponential six-prime head,
including original boundary masks. They keep the calibrated old widths
and choose epsilon separately, retain 1/16 of ONE supply and every
favorable selected observation, and leave one exact signed rest.
Every prime of an unpaid six-prime label has logp>epsilon*N; the earlier
N^2 head is eventually included. This strengthens, and does not add to,
the preceding polynomial ledger. The old statement that its elementary
logarithmic estimate alone cannot pay an exponential head remains valid;
the fractional minimum-prime estimate supplies the missing gain.
All widths/starting orders remain existential at the signed-supply level.
No PNT/Abel phase approximation, new zero exclusion or whole-sum floor/
ceiling is asserted. See `docs/zeta-riesz-six-prime-head.md`. Preserve
all prior audits and continue locally without commits, pushes or subagents.
`ZetaRieszFiveFractionalHead` now proves both five-prime coefficient
signs cost `B5*sqrt(log Q)*sqrt(2M+2)` times the original radial scale,
where `B5=192*log4*exp4*C_(1/2)*C_(1/6)^3` and
`C_a=6*log4/(1-2^(-a))`. It keeps the minimum across four cofactor
logarithms before counting the largest prime at its actual product
endpoint. `ZetaRieszFiveNegativeHead.eventually_core_full_floor` and
its ceiling counterpart now pay the negative five-prime exponential
head as well, with a separately chosen width zeta. One original supply
pays the old 7/8 charges, six-prime 1/16 and negative-five 1/32;
one thirty-second remains. The new six/negative-five group retains its
favorable observation, every old selected group remains, and one exact
signed rest plus the old vanishing boundary allowance are kept.
The old separate six-prime statements are preserved, not additive credits.
`remaining_five_log_gt` forces every factor of an unpaid nonzero five-prime
label above `exp(min(delta,zeta)*N)`; `remaining_six_log_gt` keeps the
old separate six-prime restriction. Both coefficient signs are now paid
at a positive exponential threshold. Constants are coarse and the signed
widths/starting orders are existential; no whole-sum bound or numerical
starting order is certified. Neither simple-zero floor nor higher-zero
ceiling is closed. See `docs/zeta-riesz-five-negative-head.md`.
Retain all prior no-gos, cached covers and public endpoints; continue
locally without commits, pushes or subagents.
`ZetaRieszComplementWindow` now uses the reflected one-third window
jointly across higher even counts. A middle-rank divisor subset with at
least two primes cannot coexist with its complement: their upper windows
would imply v<a+b<=2b, but the subset weight is at least 2b. At most
half a central binomial layer survives. Combining that count with LYM
bounds its parity by `(C+B)/2`, where B is the largest off-middle layer
of the same parity. Checked coefficient intervals in `(T/L)*log(minFac)`
units are [-15,13] for eight primes, [-49,56] for ten and [-210,186]
for twelve. `eventually_core_subset_higher_even_bounds` applies to EVERY
subset of the original core and every higher even count at once, with
both original phase signs, exact weights, all favorable observations and
all other counts unchanged. It spends no supply; do not add it as a credit.
The sharper six-prime [-3,4] bound remains separate, and neither whole-sum
multiplicity target is proved. The optional exact-rational probe models
logarithms, NOT prime labels; it reaches the unchanged eight-prime lower
endpoint -15 and does not prove a uniform stronger bound or density
transport. See `docs/zeta-riesz-complement-window.md`. Preserve all cached
covers and no-gos; continue locally without commits, pushes or subagents.
`ZetaRieszLogCountBudget` and `ZetaRieszLogCountTail` now pay ALL counts
`omega(n)>=8*Nat.clog 2 (N+1)` at once. Squarefreeness gives tau=2^omega;
the existing complete divisor-square mean supplies
`sum 2^omega <= 2^(-K)*X*(1+log X)^3`. Keeping the original coefficient,
allocation and factorial kernel gives the explicit relative cost
`512*exp(4)/(N+1)^4` on N<=2M and M<=2N. The same actual signed supply
pays the tail for 1/64 eventually, preserving the old radial charges and
leaving 1/64. Both full-core directions pay the omitted high-count radial
edges by r^N*C and retain all favorable observations and the signed rest.
Every remaining squarefree label has count below this logarithmic threshold.
The older full low-count boundary payments are preserved; the new terminal
statements explicitly retain the old RADIAL payments. Do not say the tail
itself is source-scale o(1), that the remaining count ceiling is fixed,
or that either whole-sum multiplicity bound follows. Starting orders still
depend on an existential supply constant. Polymath's smooth-weight almost
primality estimate has not been applied to the nonsmooth hinge. See
`docs/zeta-riesz-log-count-tail.md`. Keep all prior no-gos and cached covers;
continue locally without commits, pushes or subagents.
`ZetaRieszIntersectingWindow` now sharpens every higher ODD count on every
literal core subset. Two surviving subsets cannot cover the residual prime
universe if one has at least two elements; their complements are intersecting.
Mathlib's checked Erdős--Ko--Rado quota Q combined with the exact LYM budget
gives B+(1-B/C)*Q for the upper central parity. At residual count five,
t surviving singletons exclude their coordinates from every surviving
triple; t+min(4,choose(5-t,3))<=5. Thus the seven-prime interval improves
from [-10,10] to [-5,10]. The nine/eleven intervals are [-35,27] and
[-308/3,126], in (log n/L)*log(minFac n) units. The terminal
`eventually_core_subset_higher_odd_bounds` retains the original phase,
factorial/allocation weights, favorable observations and all other counts.
It applies to the signed rest without spending supply; neither whole-sum
multiplicity target is proved. The optional rational-weight probe is not
actual prime data or a source-bound certificate. See
`docs/zeta-riesz-intersecting-window.md`. Preserve prior bounds, frozen
covers and no-gos; continue locally without commits, pushes or subagents.
`ZetaRieszSevenPrimeHead` and `ZetaRieszSevenCountTail` now pay the entire
seven-prime exponential head with any log(p)<=theta*N, theta>0, while
preserving all earlier radial head widths and the one-sixty-fourth reserve.
One counted macroscopic prime and fractional exponents 1/2,1/10,...,1/10
give the explicit constant B7=640*log(4)*exp(4)*C(1/2)*C(1/10)^5,
where C(a)=6*log(4)/(1-(1/2)^a). The original coefficient and every
allocation/factorial/phase weight are retained. The old 1/64 count-tail
spending splits into 1/128 for all high counts and 1/128 for the seven-prime
head. Both terminal full-core comparisons pay all enlarged-tail radial
edges by r^N*C, retain the earlier low-count favorable observations,
the combined enlarged-tail observation and the signed complement.
`remaining_seven_log_gt` puts every unpaid seven-prime factor above theta*N;
`remaining_count_lt` preserves the logarithmic count ceiling. Older complete
low-count boundary payments and the separate high-count comparison remain
available. B7 is roughly 4.07e16: the optional scalar probe illustrates a
very small width and is not a certified supply constant or starting order.
Do not call the head itself source-scale o(1), claim that the halved negative
coefficient halves the whole head, or infer either whole-sum multiplicity
bound. See `docs/zeta-riesz-seven-prime-head.md`. Keep all frozen covers,
prior no-gos and public endpoints; continue locally without commits,
pushes or subagents.
`ZetaRieszReflectedPrimeBounds` now applies the existing exact inactive-prime
deletion at D=log(n)-L before bounding the signed divisor response. The
active cofactor retains the original least prime, while the coefficient
retains the ORIGINAL total-count parity. For k>=5 the literal core gives
D>log(n)/4, hence at most three reflected large primes and at least two
active primes. Three reflected large primes force saturated-composite
coefficient zero exactly. `core_sum_eq_outer_filter` deletes this zero
sector on every selected core subset, retaining phase and every mask.
The smaller active count improves seven-prime [-5,10] to [-4,6] with one
reflected large prime and [-3,3] with two; analogous checked rows for
counts 8,9,10 are in `docs/zeta-riesz-reflected-prime-bounds.md`.
`eventually_core_subset_bounds` applies both phase-sensitive inequalities
to every higher-count subset, intersecting with all earlier even/odd
costs so neither charge increases. Lower counts stay unchanged and every
favorable observation remains. No supply is spent, no new carrier is
introduced and no whole-sum floor/ceiling or zero exclusion follows.
The optional rational-weight probe is not actual prime data, an extremal
certificate or a density transfer. Keep all earlier payments and audits.
`ZetaRieszSevenPrimeReflection` sharpens the seven-prime/two-reflected-large
interval again, from [-3,3] to [-1,3] in the same least-prime units.
The actual core gap D/T>289/1000>2/7 puts the five-prime active cofactor
beyond its two-thirds cutoff. A second exact reflection and the proved
five-prime lower-third bound give the improvement without changing any
integer, total parity, phase, allocation or mask. `seven_cost_savings`
quantifies the two alternative phase charges; `eventually_core_subset_bounds`
transfers both to any selected literal core subset. Every earlier allowance
is intersected, no supply is spent and both whole-sum multiplicity bounds
remain OPEN. The endpoint examples in the optional rational probe concern
model logarithms only, not actual prime populations or source mass.
`ZetaRieszJointReflectionBounds.eventually_joint_floor` and
`eventually_joint_ceiling` now apply that saving to the actual WHOLE `J+C`.
They retain the full `SevenCountTail` payment ledger, its positive/negative
one-sixty-fourth reserve and every favorable observation. Only the unpaid
rest receives the improved cost. `sum_observation_savings` gives exactly
two least-prime units times the original factorial/allocation weight and
the appropriate cosine orientation on seven-prime/two-outer labels.
The boundary and radial errors are proved to vanish independently. These
are improved joint comparisons, not the final numerical -79/1000 floor or
3/2 ceiling. Neither a positive lower bound for the total saving nor the
remaining numerical gap is certified. Keep both all-multiplicity targets
open and attack these joint comparisons directly in subsequent slices.
The prior accumulated slice is published at c6e081e with exact-SHA CI and
Pages success. Subsequent reflection work is local pending a new publication
instruction; continue without subagents.
The packet selection cancels exactly against its complementary fraction
in `fullPacket+rest=coreResponse`. Do not require solving those artificial
rectangle/share projections as a prerequisite for a direct core floor.
The original core masks and `1-boundedShare` remain, and the full joint sum
is NOT restricted to the packet's count ceiling 55.

`ZetaRieszJointAllocationFloor.re_core_ge_joint_unallocated` now gives a
direct one-sided comparison for the WHOLE core, retaining its complement
inside the same real observation. On any selected core subband where every
eligible prime has log share at most `9/16`, it pays removal of the old
allocated coefficient by
`4*U*(N+1)*allocationBoxRate^N*majorantMass(1+1/262144)`.
The existing rate is strictly below one (approximately `0.9991080225`).
The whole original logarithmic window supplies the bound `omega(n)<=4N`;
there is no fixed count ceiling, least-share mask or rectangle restriction.
The bound is uniform in all real heights and has no zero hypothesis.
`tendsto_allowance` proves this explicit error vanishes. The surviving raw
Riesz sum and the unchanged complementary core still need a JOINT signed
floor. Do not interpret the comparison inequality as that floor, delete its
complement, or reopen an absolute rest allowance. See
`docs/zeta-riesz-joint-allocation-floor.md`.

`ZetaRieszJointDominantFloor` now lowers the independently paid dominant-prime
threshold from `13/20` to `121/200` on the restricted radius interval.
`norm_scaled_sum_le` bounds the actual normalized residual sum on ANY
eligible finite subband above that share by
`2*majorantMass(1+1/262144)*exp(-N/8000)` for N>=320, uniformly in real
height and all prime counts. The rational tilt `21/20` pays the upper
missing allocation tail; the lower tail retains the physical prime cutoff
and its already proved `exp(-N/2000)` bound. `re_core_ge_without_large`
is a direct lower comparison for the WHOLE core, retaining its entire
signed complement inside one observation. `remaining_prime_log_lt` proves
on the original cofinal schedule that every prime in a nonzero remaining
atom has log share strictly below `121/200`; its eligibility is discharged
from the actual masks. The error tends to zero, but its finite majorant
constant is unevaluated. The raw signed Riesz sum below `9/16` and the
allocation transition `9/16..121/200` remain unbounded. The joint cofinal
floor and zero exclusion remain OPEN. See
`docs/zeta-riesz-joint-dominant-floor.md`. Continue locally without commits
or subagents; do not replace this complement by the divergent allowance.

The concrete refined tilts in `ZetaRieszJointAllocationFloor.Refined` and
`ZetaRieszJointDominantFloor.Refined` now improve both allocation endpoints.
Removal of the assigned part is paid up to prime share `293/500 = 0.586`
by `4*U*(N+1)*r^N*majorantMass`, with
`r=U*(262144/131071)*exp(-1/8200)<=exp(-1/100000)`.
The actual residual sum above `601/1000 = 0.601` is independently bounded
by `2*majorantMass*exp(-N/1000000)`. The old faster estimates at their old
endpoints remain intact. All original phases, physical masks and arbitrary
counts are retained. `Refined.remaining_prime_log_lt` proves the new
endpoint for every prime in a nonzero remaining atom on the original schedule.
`Refined.re_core_ge_joint_reduced` combines both comparisons into ONE signed
core inequality, with both allowances tending to zero. The allocation
transition is now `0.586..0.601`; the raw Riesz sum below it and the signed
transition itself remain unbounded. This is not a tail-wide or zero-free bound.
`fifty_nine_percent_all_tilts_grow` and `sixty_percent_all_tilts_grow` prove
at the upper radius that EVERY positive scalar tilt has positive normalized
log rate at 59% and 60% shares. Do not keep searching for another tilt to
cover that gap using the same envelope. This does not obstruct a joint
signed estimate or establish growth of the actual tails.
The optional `scripts/probe_riesz_joint_tilts.py` and
`docs/riesz-joint-tilt-probe.json` contain uncertified scalar diagnostics;
the Lean rational endpoints and all-tilt inequalities are the proofs.
The whole joint cofinal floor remains open, with no new carrier definition,
zero exclusion, publication or subagent work in this local slice.

`ZetaRieszJointPhaseCredit` audits the positive observations of the SAME
core. `eventually_positive_credit_growth` proves their normalized sum is
at least `k*(2u)^N/(N+1)^4` eventually, k>0, at EVERY fixed real height,
using actual balanced prime boxes and all original support/allocation masks.
`positive_credit_tendsto_atTop` and `clipping_loss_tendsto_atTop` prove
divergence of this specific information loss. This is not the old absolute
antichain allowance, and it is NOT a free positive reserve: the signed
complement remains. `SignedCompensationBounds.re_sum_ge_compensation_keep_positive`
now improves the earlier all-phase clipped bound to
`sum (log n/L)*((g-S)*x-e*max(x,0))`, with
`e=max(0,log(r)-max(0,L-log(P)))`. The unit tent equals g-e exactly; the
new inequality retains positive unit credit, with no absolute cosine.
Pair separation is still required, and its complement remains unpaid.
`least_log_reflected_margin` and `rising_edge_zero_of_seven` show e=0 for
counts >=7 after log(P)<=121log(n)/200, log(n)<=203N/100 and L>=137N/100;
the last length bound is available eventually at the restricted radius.
Only this unit-edge defect is confined to counts 3..6, not the entire
signed obstruction. Net compensation, pair-separation failures and the
joint cofinal floor remain OPEN. See `docs/zeta-riesz-joint-phase-credit.md`.
`ZetaRieszJointEdgeLoss` now turns the scalar slopes
`(log r,log a,log P)=(0.42,0.46,1.12)*N` into an actual-prime audit.
`eventually_edge_loss_growth` proves the source-normalized THREE-PRIME
rising-edge clipping loss is at least `k*(2u)^N/(N+1)^4` eventually, k>0, for every
fixed NONZERO height and the restricted radius interval. The proof uses
three disjoint fixed-width prime intervals and a bounded phase translation;
it retains the exact original core, physical, count and allocation masks.
The edge is at least N/10, all shares are below 9/16, and at least half the
unassigned fraction survives eventually. `edge_loss_tendsto_atTop` rules
out a bounded or cofinally bounded allowance for this specific deletion.
`SignedCompensationBounds.re_atom_sub_compensation_keep_positive` identifies
the exact loss as `(log n/L)*e*max(-x,0)` on the stated compensation support.
`edge_charged_core_tendsto_atBot` then shows that the normalized core minus
just this three-prime loss tends to minus infinity under the existing
exposed-zero source hypotheses. Even a cofinal constant floor for that
comparison is therefore impossible; the unchanged actual core retains its
original finite source. No simple-zero or new arithmetic-floor premise
is inserted into this audit.
This is a negative result about the comparison, NOT a signed-carrier floor
or a proof that joint cancellation is impossible. Keep the rising edge's
signed contribution, including counts 3..6. Do not try to pay this deletion
by norm or a fixed allowance. The joint cofinal floor remains open; see
`docs/zeta-riesz-joint-edge-loss.md`. No new carrier, commit or subagent.

`ZetaRieszJointRadialFloor` now combines radial position and allocation
before using the summable envelope. On `0<=u<=10001/20000`, it proves the
actual residual sum above 60% eligible prime share is bounded by
`2*majorantMass*exp(-N/400000)` for `N>=320`, provided
`log n<=248N/125` or `252N/125<=log n`. The physical prime cutoff pays
the lower missing allocation tail. The actual assigned part below 59%
eligible prime share is bounded by
`4*U*(N+1)*majorantMass*exp(-N/400000)`, provided
`log n<=987N/500` or `507N/250<=log n`.
This assigned-part estimate does NOT bound the surviving raw signed sum.
`remaining_prime_log_lt_radial` discharges eligibility on the original
cofinal schedule: every prime in a nonzero remaining outer-radial atom
has share below 60%. `norm_residual_union_le`, `norm_assigned_union_le`
and `re_core_ge_joint_reduced` retain the old 60.1% / 58.6% regions and
combine both new paid regions into ONE signed inequality for the whole core.
`tendsto_joint_allowance` proves its explicit total error vanishes.
All counts, phases and original masks remain; no carrier is introduced.
The earlier all-tilt obstructions at 59% / 60% still apply to the share-only
envelope at the central saddle. They do not forbid these additional
radial savings. Do not claim the central signed transition, raw balanced
triples or joint cofinal floor is bounded. The finite majorant constant
is unevaluated and no numerical order threshold is claimed. See
`docs/zeta-riesz-joint-radial-floor.md`; the optional
`scripts/probe_riesz_joint_radial.py` output is uncertified scalar
exploration, not a prime-sum certificate. No new zero exclusion, publication,
commit or subagent work is authorized by this local slice.

`ZetaRieszJointTailAudit` strengthens the central scalar no-go without
introducing another carrier. For `N=32m`, `m>=10`, at `U=10001/20000`,
the actual assigned binomial mass at cofactor share `41/100`, multiplied
by `(2U)^(N+1)`, is at least `(1001/1000)^m/(3(N+1))`. The actual missing
mass at cofactor share `2/5` is at least `(2001/2000)^m/(3(N+1))` under
the same scaling. Both diverge on the original dyadic moment schedule;
both literal unpaid-order endpoints are retained. The proof uses a modal
atom lower bound and exact rational likelihood ratios, not a Chernoff
upper envelope or floating evidence. Thus changing the scalar tilt or
waiting for a favorable subsequence cannot make these particular central
tails small at the upper radius. This is NOT a lower bound or divergence
theorem for an actual prime population or signed carrier, and it does not
negate the already paid outer radial regions. Keep the central weights
coupled in the direct signed floor. No new independent floor, zero
exclusion or publication follows. See `docs/zeta-riesz-joint-tail-audit.md`;
`scripts/probe_riesz_joint_tails.py` is optional and its generated JSON is
an uncertified scalar diagnostic. No commits or subagents in this slice.

`ZetaRieszJointCountFloor` independently pays a larger part of the actual
integer response: replace the count endpoint `K_j=dyadicPrimeCount j` by
`K'_j=dyadicPrimeCount (j-9)=K_j/512` on the SAME moment schedule. Eventually,
every selected original-band residual sum with `omega(n)>=K'_j` has
source-normalized norm at most `32*U*log(2)*N_j*(49999/50000)^N_j`, uniformly
over all real heights and `0<=u<=U=10001/20000`. The Euler mass is paid,
not assumed. Its starting order remains unevaluated; `j>=64` is only the
count-power certificate threshold. The exact `coreBand_count_filter`
and `coreResponse_sub_count` retain all original masks and allocation.
`eventually_re_core_ge_smaller_count` gives a direct signed lower comparison,
and `tendsto_joint_sub_smaller_count` transfers the original joint target
through independently vanishing errors. No component floor is required.
The retained small-prime divisors (all primes <=N_j^2) now have
`log(a)<=N_j/2048`; this support restriction does not delete their phase.
The count endpoint still grows, so every fixed class remains eventually:
do not treat this as a fixed 39/55-count cap or a balanced-triple deletion.
The existing radial/allocation comparisons still apply at the new endpoint.
The raw low-count signed sum, central transition and joint cofinal floor
remain OPEN. See `docs/zeta-riesz-joint-count-floor.md`; the optional
`scripts/probe_riesz_joint_counts.py` records scalar diagnostics only.
No new carrier, zero exclusion, commit or subagent work in this slice.

`ZetaRieszJointSmoothFloor` uses that tighter count budget to prove exact
cancellation on every remaining label `n=p*q*a` with p,q prime and a
composite N_j^2-smooth factor. Below the paid 60.1% prime-share endpoint,
the N_j/2048 bound forces `log(pa),log(qa)<=L<=log(pq)` throughout the
core once the existing `L>=5N_j/4` bound holds. In the four-term prime
insertion identity, three small-factor cutoffs are saturated and the
fourth is nonpositive. All vanish, so the actual coefficient and its
allocated/residual multiples vanish. `sum_without_two_primes_composite` deletes
this exact zero class with arbitrary complex observations and inherited
masks retained. `eventually_re_core_ge_without_large_and_composites`
gives a direct signed lower comparison for the WHOLE original core, with
only the already paid count and 60.1% deletion allowances; their sum
tends to zero. The cancellation adds no error. It remains valid on
further selections, including the radial reductions. The composite
condition is essential: prime a leaves a nonzero logarithmic moment.
Balanced triples, three-or-more-large-prime labels and the central signed
transition remain unbounded. The independent JOINT floor stays OPEN.
See `docs/zeta-riesz-joint-smooth-floor.md`. No new carrier, zero exclusion,
commit or subagent work in this local slice.

`ZetaRieszJointQuintupleFloor` now gives an actual signed coefficient
bound for retained labels `n=p*q*r*a*b` with all five factors prime and
`a,b<=N_j^2`. From the same count/window/share masks and the proved
eventual `L>=137N_j/100`, only three pair-boundary responses survive.
They are nonnegative two-prime tents, and the literal radial gap excludes
three simultaneously active tents. `five_residual_bounds_core` proves
`-(log(n)/L)*(1-boundedShare)*2*min(log(a),log(b)) <= residual.re <= 0`.
No largest-prime ordering, sqrt(n) owner condition or unpaid pair-separation
test is required. `re_five_residual_nonneg_core` proves a nonnegative
observed atom when its FULL observation has nonpositive real part;
the opposite phase sector and signed complement remain unpaid. This
opposing arithmetic sign is NOT a population comparison, free reserve,
source-scale decay or independent whole-core floor. Do not discard either
phase sector. The exact rational-log probe and `three_pair_tents_sharp`
check that the two-tent scalar cost is attainable in the real-logarithm
model; they do not assert rational shares are actual prime logarithms.
See `docs/zeta-riesz-joint-quintuple-floor.md`. The shared
`JointSmoothFloor.reduced_core_geometry` only exposes the already proved
support tests and is used by both literal inequalities. No new carrier,
zero exclusion, commit or subagent work in this local slice.

`ZetaRieszSmallDescendants` quantitatively audits appending small factors
to the surviving balanced triples. With large logs <=27N/40, total log
>=2N, L in [137N/100,7N/5] and log(a)<=N/2048, all three pair cutoffs
saturate. For squarefree p*q*r*a and a>1 the actual Riesz response
reduces to log(a) if a is prime and zero otherwise. Thus all composite
small-factor descendants, including the previous five-prime candidates,
vanish on this interior chamber. The previous five-prime bound still
applies near its pair boundaries. Exact kernel transport and the harmonic
sum bound give a total descendant norm <=4log(N)(1+2log(N))*||K_N(pqr)||,
with arbitrary selections and literal residual allocation retained.
The base atom has norm >=N/4*||K_N(pqr)|| once half its allocation survives;
that premise is supplied eventually by the existing balanced-allocation
bound, and the existing actual prime boxes eventually lie in the chamber.
The relative budget 16log(N)(1+2log(N))/N tends to zero and is <1/1000 on
the original dyadic schedule for j>=32. This is NOT an absolute
source-scale allowance. `re_balanced_descendants_upper` retains an arbitrary
signed complement and proves that these descendants cannot cancel a
fixed negative phase fraction of their own base atom, even with optimal
descendant phases. It does not control cancellation across different
large-prime configurations or prove divergence of the whole core. Do not
continue appending small factors as the sole compensation strategy for
these balanced triples. The independent JOINT floor remains OPEN.
See `docs/zeta-riesz-small-descendants.md`; the optional floating prime
insertion probe uses model base logarithms and is not a certification.
No new carrier, source completion, commit or subagent work in this slice.

`ZetaMultiplicativePhase.uniform_re_floor_iff_norm_bound` audits a possible
accidental strengthening of the minimal endgame: a signed floor uniform
over all complex coefficient families with fixed magnitude budgets is
equivalent to a norm bound. A unit rotation of one family proves necessity
without changing the correlated arithmetic matrix. The existing phase
transport makes this equivalent to a zero-height norm bound, also at
cofinally many orders (`cofinal_uniform_floor_iff_zero_height_bound`).
The cofinal quantifier is outside the coefficient quantifiers on both
sides. This does NOT apply to the one fixed arithmetic family: do not
rotate the actual Möbius coefficients, discard their signs or strengthen
the joint target to a coefficient-uniform assertion. No new carrier,
component bound or independent joint floor is supplied by this audit.
See `docs/zeta-riesz-joint-floor.md`. Keep public frontiers unchanged.

`ZetaRieszCoreExtensions` strengthens the small-descendant audit to EVERY
squarefree extension remaining in the core, with no `N^2` ceiling on the
inserted prime. For base triple logs <=67N/100, total >=2N and
137N/100<=L<=7N/5, the core upper endpoint forces log(a)<=3N/100.
All pair cutoffs saturate, so composite extensions vanish exactly.
Actual Chebyshev summation gives sum(log(p)/p)<=log(4)(1+x) up to log(p)<=x.
Exact factorial curvature gives exp(-delta^2*N/24)/a on the larger head.
With half the base allocation surviving, `relative_extensions_split`
bounds the whole extension norm by
12*(1/N+delta+(1/N+3/100)*exp(-delta^2*N/24))*||base||.
`eventually_extensions_relative_small` proves this relative mass tends
to zero uniformly in heights, selections and allocation sets.
The scalar budget for delta=1/50000 is <1/1000 when N>=10^12, hence at
dyadic index j>=32; geometric and allocation hypotheses are STILL required.
The actual phase-audit prime boxes eventually lie in the sharper chamber.
`joint_signed_bounds` and `joint_negative_block` preserve the entire signed
complement. This is NOT source-normalized decay or a whole-core floor:
different large-prime configurations can still interact. Do not continue
appending arbitrary in-core factors to these fixed balanced triples as
their sole compensation mechanism. See `docs/zeta-riesz-core-extensions.md`.
The optional density probe is only motivation, not an arithmetic transport.
Continue locally without commits or subagents; public frontiers unchanged.

`ZetaRieszQuadrupleCompensation` proves actual cross-count signed
compensation, following the core-extension obstruction. For every fixed
nonzero height, one fixed-width balanced triple box near total log 2N has
norm at most B/(N+1) times the positive real contribution of an explicitly
selected four-prime population. Its two log-translation coordinates are
balanced in the fourth leg. Unique factorization makes all grid labels
distinct; actual fixed-width PNT lower counts and Chebyshev upper counts
give the extra power of N. The four-prime coefficient is <=-N/20 and its
selected cosine <=-1/2. Original allocation and every core mask remain;
there is no zero hypothesis or signed prime-density transport.
`eventually_core_spending` is the primary terminal theorem: with X the
triple sum, Y the positive supply and W the untouched signed complement,
theta=max(-Re X,0)/Re Y satisfies 0<=theta<=B/(N+1)<=1 eventually and the
source-normalized core equals u^(N+1)*(Re W+max(Re X,0)+(1-theta)*Re Y).
Keep ALL unused positive credit. The weaker pair-deletion theorem is not
a floor for its complement and can discard an unbounded surplus. The
relative spending cap tends to zero, NOT the source-normalized amount
spent. Never spend the same supply twice. The theorem pays one box with
fixed log width and bounded translation, NOT a whole N-wide share region.
It provides no effective starting index. The whole joint cofinal floor
remains OPEN; do not add a zero-free claim or update public frontiers.
See `docs/zeta-riesz-quadruple-compensation.md`. Work locally without
unrequested commits or subagents.

`ZetaRieszFourPrimeFloor` gives an independent signed inequality for the
WHOLE four-prime class, not just the compensating grid or reflected-linear
class. For T=log n, P=largestPrime n and g=log P+T-2L, with 0<L<=T and
2T<=3L, `actual_four_signed_gap` bounds Re(c_L(n)) between
-(T/L)*max(0,-g) and (T/L)*max(0,g). Nonsquarefree coefficients remain zero.
`coefficient_four_sign` is a WEAK sign theorem, not strict away from the
transition; `coefficient_four_eq_zero_at_gap` proves exact vanishing at g=0.
Reflection reduces a large P to a three-prime midpoint bound; otherwise
only singleton divisors survive and the four-prime response is affine.
The actual core eventually discharges the length hypotheses. Its moving
threshold obeys (71/203)*T<=2L-T<=(17/39)*T; do not freeze T at 2N.
`eventually_re_core_ge_four_credit` keeps the entire signed non-four-prime
complement AND all actual positive four-prime credit, charging only
weight*(T/L)*max(0,-g*cos(y*T)). It is uniform in height/count endpoint,
without zero hypotheses. This debit is still UNPAID at source scale;
the whole joint floor remains open. No new carrier is defined.
The optional rough-sector density capacity probe suggests four-prime
favorable mass alone is insufficient for the whole triple class and that
five-prime contributions are substantial. It is not an arithmetic no-go:
it omits small prime factors, counts above nine and phase/radial transport.
See `docs/zeta-riesz-four-prime-floor.md`. Preserve every existing positive
credit and do not spend the same supply twice. Public frontiers unchanged;
continue locally without unrequested commits or subagents.

`ZetaRieszFivePrimeFloor` proves the candidate five-prime inequality for
ALL actual labels with five distinct prime factors, including small primes
and nonsquarefree labels (whose coefficient is zero). For T=log n,
P=largestPrime n, Q=largestPrime(n/P), 0<L and 2T/3<=L<=3T/4, the upper
coefficient bound is (T/L)*max(0,min(2logP+T-3L,logP-logQ+T-2L)). Its
stronger `actual_five_upper_clipped` caps that allowance by 3log(minFac n),
reusing the existing two-smallest-prime antichain bound. The actual core
eventually satisfies every length hypothesis. `positive_five_core_geometry`
proves positive coefficients require logP>(104/203)T AND
logP-logQ>(71/203)T. These are NECESSARY conditions, not converse signs.
Balanced five-prime labels are favorable on negative-cosine observations;
no sufficient cross-count population mass is inferred from that fact.
`eventually_re_core_ge_four_five_credit` places the four-prime gap and the
clipped five-prime upper bound into the SAME original core sum, uniformly
in height/count endpoint. It keeps all actual positive observations in
those classes and leaves positive-cosine five-prime terms and every other
count SIGNED. It does not complete any cofactor or spend compensation.
The combined debit is still UNPAID at source scale. The sufficient target
remains a cofinal joint -79/1000-o(1) floor; no new zero exclusion follows.
The optional density probe compares the gap and least-prime costs, but
does not control prime-density transport, missing small primes, higher
counts or radial/phase errors. See `docs/zeta-riesz-five-prime-floor.md`.
Keep the public frontiers unchanged; work locally without unrequested
commits or subagents.

`ZetaRieszBandCompensation` widens the paid balanced triple population:
for each fixed nonzero height there is a fixed eta>0 such that ALL original
core triples with 2N<=log n<=2N+1 and |log p-2N/3|<=eta*N for every prime
factor have norm at most HALF a positive four-prime supply, eventually.
Its three disjoint prime-log grid coordinates retain total log 2N+v+O(h).
Actual unsigned prime lower counts give supply >=c*exp(2N)/(N+1);
Chebyshev upper counts give a quadratic eta^2 cost for the entire triple
band, at the same rate. No zero premise or signed density transport is used.
The original coefficient, allocation, phase and every core mask remain.
`eventually_core_tripleBand_nonempty` proves this actual selection nonempty.
`eventually_core_band_spending` retains theta<=1/2, all positive triple
credit, (1-theta)Re Y and the complete SIGNED complement W exactly.
`eventually_core_band_floor` directly bounds the normalized core below by
u^(N+1)*(Re W+max(Re X,0)+Re Y/2). This is NOT a numerical whole-core floor.
The proof selects SOME conservative eta, not every eta<=1/1000; its
total-log interval has width ONE, not the whole radial core. No effective
starting order or source-normalized decay of the spent mass is proved.
The new supply OVERLAPS the old two-dimensional supply; do not spend both
as independent budgets. Keep the untouched signed remainder and unused
positive credit together. The optional density probe and floating witness
evaluation are not certificates. See `docs/zeta-riesz-band-compensation.md`.
The cofinal JOINT -79/1000-o(1) floor remains OPEN. Keep public frontiers
unchanged; continue locally without unrequested commits or subagents.

`ZetaRieszRadialCompensation` pays a fixed positive balanced triple share
band throughout the ORIGINAL radial core. For each fixed |y|>=16, one
eta>0 is chosen; the band is |log p-log n/3|<=eta*N/4 for every factor.
`eventually_core_balanced_nonempty` proves the actual band nonempty.
The radial index M varies, but the factorial moment remains N. Actual
triple slabs 2M<=log n<2M+2 are compared with negative-coefficient,
negative-cosine four-prime supplies in (2M,2M+1]. Their radial index set
keeps each supply inside the original core. `supply_disjoint` and
`union_spending` prevent any repeated capacity. The fixed width pays at
most half the union's actual positive contribution. All original masks,
allocation, phase and moving length remain; there is no zero assumption,
signed density transport or source completion. The height condition is
available for hypothetical right-half zeros from the existing >54 theorem.
`balanced_mem_radialTriples` covers ALL such balanced labels between
1.952N and 2.029N. `exists_missed_bound` independently bounds the remaining
balanced edge labels by C*r^N, r<1, at source scale, uniformly in height
and selection. `tendsto_edge_allowance` proves decay on the actual schedule.
`eventually_core_balanced_floor` retains the SIGNED complementary sum W,
positive triple credit and at least HALF the positive supply in one
core lower bound, minus only that geometric error. The width is SOME
conservative fixed eta, not every eta<=1/1000. No finite threshold is
certified. This does not cover all balanced configurations or all counts.
The old/new supplies OVERLAP; never add their credits independently.
The full cofinal JOINT -79/1000-o(1) floor is still OPEN. Numerical density
ratios do not certify arithmetic transport or widths. See
`docs/zeta-riesz-radial-compensation.md`. Keep public frontiers unchanged;
continue locally without unrequested commits or subagents.

`ZetaRieszFourPrimeReserve` now evaluates the negative coefficient of the
ENTIRE four-prime class exactly. For squarefree n, T=log n, D=T-L,
F=3L-2T-sum_p max(0,log p-D), 0<L<=T and 2T<=3L,
`negativeAllowance_eq` proves max(0,-Re c_L(n))=(T/L)*max(0,F).
Nonsquarefree allowances and coefficients are zero. The clipped-log
identity keeps all subset cancellations and all prime-log excesses;
do not estimate its pair hinges separately. `negativeAllowance_le_gap`
and `fourDebit_le_gap` prove improvement over the previous largest-prime
bound pointwise, with the original moving length and phase.
`re_four_atom_eq_keep_positive` is exact on nonnegative cosines.
`eventually_re_core_ge_four_five_credit` keeps the sharper debit, the
existing clipped five-prime bound and the full signed complement together.
`eventually_compensated_core_floor` applies that comparison ONLY outside
the radial triple band and its positive supply. It keeps positive triple
credit and HALF the supply, with only the existing geometric edge error;
never spend or debit that supply again. Its full complementary signed
expression still needs a numerical floor. No whole joint floor or zero
exclusion is proved. The optional density probe shows a smaller modeled
negative allowance but supplies no prime/radial/phase transport or bound
for omitted counts. See `docs/zeta-riesz-four-prime-reserve.md`. Preserve
public frontiers; continue locally without unrequested commits or subagents.

`ZetaRieszFivePrimeReserve` evaluates the POSITIVE five-prime coefficient
exactly. For squarefree n with five factors, T=log n, P=largestPrime n,
d=L-log P, and 2T/3<=L<=3T/4, `positiveAllowance_eq` proves
max(0,Re c_L(n))=(T/L)*max(0,2logP+T-3L-sum_(q != P) max(0,log q-d)).
Nonsquarefree coefficients and allowances are zero. Reflection and actual
largest-prime deletion reduce the live chamber to the four-prime clipped
theorem; saturated and zero chambers are handled exactly without completion.
`positiveAllowance_le_clipped` and `five_floor_improves_clipped` prove
pointwise improvement over the old two-gap/least-prime allowance.
`re_five_atom_eq_keep_positive` reconstructs the original negative-cosine
five-prime atom exactly from its full positive credit and this debit.
`eventually_compensated_core_floor` keeps the paid balanced triple band,
half its four-prime supply and the comparison on the UNTOUCHED complement.
Never spend the supply twice. Four-prime positive-cosine and five-prime
negative-cosine debits are exact; this is not a weighted population estimate
or numerical whole-core floor. Other sectors and counts remain signed.
The optional probe records a smaller modeled debit, without prime/radial/
phase transport. A preliminary pair-hinge lower bound gave no observed
improvement over the old joint comparison and was discarded before
formalization. Do not revive it without a concrete stronger inequality.
See `docs/zeta-riesz-five-prime-reserve.md`. The full joint -79/1000-o(1)
target stays OPEN. Preserve public frontiers and work locally without
unrequested commits or subagents.

The user's latest restriction (2026-09-26) is binding: do not introduce
another representation unless it immediately targets a provable signed
inequality. Keep the existing carrier and correlated weights fixed. A
model-only reformulation or inversion is not arithmetic progress. The
unfinished synthetic Fourier-inversion exploration was moved outside the
repository and is not an imported or proved module.

`ZetaRieszSignedCompensationBounds` follows that restriction with inequalities
for the existing coefficient and observations; it defines no new carrier.
See `docs/zeta-riesz-signed-compensation-bounds.md`.
`five_coefficient_bounds_core` proves the actual five-prime coefficient lies
between `-(log n/L)*2*log r` and
`(log n/L)*min(log r,max(0,log(P*r*a)-L))`, using the original core geometry.
`coefficient_le_gap_sub_prime_tents` keeps every opposing prime tent on the
right of a signed upper bound for arbitrary counts satisfying the explicit
pair-separation test. `re_sum_ge_signed_compensation` gives a literal finite
observed-sum lower bound in the negative-real phase sector. The stronger
`re_sum_ge_compensation_all_phases` retains ALL observations: writing S for
the opposing prime tents, g for the unit gap and x=Re(z), its lower bound is
the sum of `(log n/L)*(g*min(x,0)-S*x)`. The term `-S*x` remains signed;
no absolute cosine or separate norms replace it. Pair-separation failures
and the source-normalized net signed compensation remain UNPAID. There is
no whole-packet bound or new source-scale component decay.
Do not treat this finite signed inequality as the missing cofinal floor or
resume the divergent absolute rest allowance. Continue locally without
subagents or unrequested commits; preserve the running probe's frozen inputs.

### Literal joint prime transfer (2026-09-25)

The subsequent ordered-completion slice is recorded in
`docs/zeta-riesz-ordered-euler-completion.md`. `ZetaRieszMarkedEuler`
combines the existing Riesz Fourier factor with the exact finite factorial
rectangle, retaining orders zero/one and both marked coordinates.
`ZetaRieszOrderedEulerCompletion.completePacket_eq_completion` identifies
the all-count physical squarefree sum with an ordered least-prime Euler
product; its middle subset sum is performed before coefficient extraction
and norms. The empty-middle term vanishes exactly. All actual prime
incidences, coprimality and both Fourier frequencies remain explicit.
`ZetaRieszMarkedCompletion.exteriorPacket_bound` pays unrestricted-count
share exteriors by C*(N+1)*r^N, r<1: incidence count costs only log(n),
absorbed by one factorial shift. Radial tails are paid and every original
whole-label mask follows on the retained core/share interior. The terminal
`tendsto_completion_sub_current` proves source equivalence to the unchanged
lowerThresholdPacket (3..55) minus shortOverflowPacket (3..13), on the
original dyadic schedule for 1/2<u<=10001/20000 and arbitrary fixed height.
No zero hypothesis or signed-bound premise is used. This completion is
therefore paid, but its coupled main Euler response is NOT yet bounded.
Do not report source equivalence as a floor, decay theorem or zero exclusion.
At this intermediate step the physical prime endpoints remain; the follow-on
below pays them. No generic PNT transfer, separate-leg phase replacement,
dropped low orders or previous no-go is reversed. The complementary carrier
still needs its independent floor. Work without subagents.

The follow-on `ZetaRieszPhysicalCompletion` now removes BOTH physical
prime endpoints with a proved source-scale error. `interior_physical`
derives N^2<p<(linearDampedCutoff u N+2)^2 from the core/share interior:
log(minFac n)>39N/4000 eventually exceeds 2log N, while
log(maxPrime n)<609N/500<5N/4<=L_N. Outside that interior, the existing
radial bound and the unrestricted-count share bound apply to every finite
partial sum. `exists_eventual_physical_bound` passes this uniform bound
to the absolutely convergent missing-label series, giving
C*r_rad^N+shareBudget N, with r_rad<1 and
shareBudget=C_share*(N+1)*r_share^N, r_share about .99948275824<1.
`tendsto_packet_sub_current` identifies the same current signed packet
with the unrestricted marked arithmetic series at source scale.
`tendsto_prefixEuler` identifies that series, for each fixed N>=21, as the
limit of genuine finite ordered Euler integrals over primesLE X. This is
ordinary absolute convergence at Re s=3/2, NOT an infinite zero-divisor
inversion or a continuation through the source circle. All low factorial
orders, least-prime ordering, the rectangle and signed Riesz weights remain.
Neither the common signed series nor the complementary carrier is bounded.

The user explicitly requested committing and pushing this accumulated slice
on 2026-09-26 before continuing. Publish the checked completion theorems,
their supporting explorer endpoint and the optional numerical audit together.
Keep the running coupled numerical job's inputs frozen; partial rows are not
a completed integration result. The whole-carrier default, zero-free region,
certificate and top-ten lists do not change.

The local continuation `ZetaRieszMarkedPrimeHead` pays every actual label
containing a prime p<=exp(N/110), uniformly in height and for
0<=u<=10001/20000. `exists_head_bound` gives the same radial geometric
allowance plus `shareBudget`; `tendsto_head` proves its source-scale decay.
The original marked factorial rectangle, signed coefficient and all orders
remain. This extends the removable polynomial head to an exponential one.
`ZetaRieszMarkedEulerError` now bounds the FULL character-minus-quotient,
including its leading quotient multiplier, by C*exp(-N/220) on a safe
half-plane. `rectangle_split` is an exact finite factorial identity.
`integral_norm_rectanglePairError_div_le` retains both marked prime slots
and every order, and proves genuine paired-frequency integrability.
`ZetaRieszOrderedEulerBound` sums all ordered prime pairs before proving
the source-scale allowance C*(N+2)^3*r^N, with checked r<249/250
(diagnostically r is about .9955720). Its `tendsto_errorResponse` has no
zero hypothesis and allows arbitrary moving heights and prime cutoffs.
`ZetaRieszRoughEulerTransfer.tendsto_main_sub_current` connects the actual
remaining leading quotient to the UNCHANGED dyadic counts 3..55 minus
short overflow 3..13. The exponential prime head and full nonlinear
correction are both independently paid. The correlated signed MAIN
quotient is still unbounded; the complementary floor and zero exclusion
remain open. The earlier sharper `quadratic_rate_lt` scalar test alone
does not replace the proved full-operator allowance. Keep the exact
rectangle, least-prime ordering, original length and both Fourier signs.
See `docs/zeta-riesz-ordered-euler-bound.md`. Continue locally without
subagents or unrequested commits, and do not edit the running numerical
probe's frozen inputs or report its partial rows as a completed result.

`ZetaRieszMainFrequency` pays the actual main quotient's two Fourier
exteriors, retaining the exact ordered primes and factorial rectangle.
The marked phases give a quadratic zero at frequency zero and a bounded
numerator at infinity. `norm_scaled_exterior_le` controls frequencies
below exp(-N/220) and above exp(N/220) by C*(N+2)^3*sourceRate^N, with the
same proved sourceRate<249/250. `response_split_frequency` is exact, and
`tendsto_central_sub_current` connects `centralMain` to the unchanged
signed counts 3..55 minus short overflow 3..13. No zero hypothesis enters.
The central interval grows with N and its coupled signed integral remains
unbounded. This is a paid exterior estimate, not a floor or packet-decay
theorem. Continue at that central arithmetic estimate; do not discard its
least-prime ordering or factorial correlations. The complementary carrier
still needs its independent signed floor.

`ZetaRieszMarkedSeparation` now pays the high marked prime's incidence
restrictions in the actual main quotient. Unequal radii 3R/2 and R/2,
together with p<=r, cost no extra prime weight; the exact rectangle gives
(2/3)^j*2^h<=exp(-N/10). Restoring p in the cofactor tail costs an extra
actual prime factor and is bounded by exp(-N/220) after the common Cauchy
estimate. `norm_scaled_response_difference_le` pays BOTH full integrated
errors by C*(N+2)^3*sourceRate^N, sourceRate<249/250. The exact
`separatedSymbol_factor` isolates the finite difference
sum_p(K_j(s,p)-K_j(s+i*xi,p)) from the ordered tail over q>r, retaining
rectangleOrders and total order N+1. `tendsto_separated_sub_current`
connects this to the unchanged signed counts 3..55 minus short overflow
3..13. No prime-phase approximation, zero hypothesis, composite-cofactor
completion or dropped low order enters. See
`docs/zeta-riesz-marked-separation.md`. The next open estimate is the joint
Fourier pairing of this finite high-prime difference with the ordered
cofactor response; neither its signed bound nor the complementary floor
is proved. Keep the two frequencies and all factorial correlations.

`ZetaRieszMarkedPrimeCompletion` now pays completion of ONLY the independent
high marked prime to the full ordinary-prime difference P_j(s)-P_j(s+i*xi).
`eventually_rough_support` proves every omitted prime lies below exp(N/110)
or above exp(11N/8), including the polynomial head and actual physical
upper cutoff. The exact rectangle and radii 2R / 5R/6 give
`omitted_kernel_bound` with exp(-N/160), R=1/2-1/262144. Both marked
Fourier zeros are retained; `completionPair_profile` and
`norm_integral_completionPair_le` pay the ENTIRE frequency integral.
`norm_scaled_errorResponse_le` bounds this error by C*(N+2)^3*sourceRate^N,
sourceRate<249/250, uniformly in moving height. The exact
`completedResponse_split` and terminal `tendsto_completed_sub_current`
connect it to the UNCHANGED signed dyadic target. See
`docs/zeta-riesz-marked-prime-completion.md`. The cofactor still retains
q>r, its finite physical prime set, every middle order and the exact
rectangle. No zero hypothesis, separate-leg phase transfer or composite
completion enters. The joint signed completed-prime / ordered-cofactor
integral and the complementary floor remain open. Do not drop the shifted
frequency, mistake a completion-error bound for packet decay, or change
the public frontier. Continue locally without subagents or unrequested
commits; keep the running numerical refinement's inputs frozen.

The user explicitly authorized committing and pushing this accumulated
local batch on 2026-09-26. Publish all seven new arithmetic modules,
their supporting `marked-prime-completion` explorer, Latest Update 81,
and the completed-model diagnostic audit after the normal gates. Keep
the whole-carrier default and zero-free/certificate claims unchanged.
This authorization does not require restarting or waiting for the
optional numerical refinement.

The next local continuation is `ZetaRieszMarkedLogDerivative` and
`ZetaRieszOrderedWard`; see `docs/zeta-riesz-marked-logarithm.md`.
`tendsto_log_sub_current` pays replacement of the completed ordinary-prime
mark by its exact full zeta logarithmic moment divided by the marked order.
The ENTIRE proper-prime-power error, still coupled to the ordered cofactor,
both Fourier signs and the exact rectangle, has bound C*(N+2)^3*r_pp^N,
with `properRate_bounds` proving r_pp<91/100. Its origin zero and all
frequency integrability are proved; the estimate is uniform in moving
heights and contains no zero hypothesis. This is not a bound on `logMain`.
`marked_ordered_ledger` proves the exact joint logarithmic-derivative
identity with BOTH unpaid terms explicit: the omitted factorial orders and
the complete-prime versus ordered-tail slope mismatch. The original mark
also retains its reciprocal order factor 1/j. Do not silently drop that
factor, remove the order window, or replace the ordered cofactor by a
complete quotient. The signed main estimate and complementary floor remain
open. Continue locally without subagents or unrequested commits. Snapshot
34ee00fd155545435ffbd5c2543cc10d1a9e2590 passed exact-SHA CI 36258001944,
Pages deployment and the published README/RH-explorer browser checks;
that remote success does not validate subsequent local changes.

`ZetaRieszMatchedSlope` subsequently pays the prime-range mismatch.
`mismatchAtom_split` keeps exactly the finite extra-prime-power mark and
the forbidden p<=r ordering. The local extra-power factor is
q^2*(1-z)*(1+z-q*z)/((1-q)*(1-q*z)); its Fourier zero is retained and its
Cauchy radius is 3/4. The old unequal-radius theorem pays the second error.
`norm_scaled_mismatchResponse_le` and `tendsto_mismatchResponse` bound the
ENTIRE coupled paired integral by C*(N+2)^3*r_pp^N, r_pp<91/100, uniformly
in moving heights, with no zero hypothesis. `tendsto_matched_sub_current`
connects the unchanged dyadic packet to a mark that is the logarithmic
derivative of its OWN finite tail quotient q>r. `tendsto_log_sub_matched`
pays the preceding complete-prime/ordered-tail mismatch; its combined rate
also includes the older prime-completion bridge, so do not ascribe r_pp to
that whole comparison. `symbol_difference_eq_rangeMismatch` retains the
literal rectangle in the exact signed identity. Do not keep listing this
prime-range mismatch as unpaid. The remaining main problem is the signed
restricted-order convolution with its reciprocal 1/j, not a separate-leg
phase limit or a full unmasked derivative. Its complementary order sum and
the final carrier floor are still unbounded. No cofactor completion, mask
removal, new zero region or RH contradiction is proved. Keep working locally
without subagents or unrequested commits; the live probe's inputs stay frozen.

`ZetaRieszMarkedSaturation` now pays the entire unshifted cofactor branch
of the same literal marked packet. See `docs/zeta-riesz-marked-saturation.md`.
`atom_split` and `completePacket_split` keep exactly
`-R_L(n)=-R_L(n/p)+R_(L-log p)(n/p)`, with the full `markedWeight`, least-prime
slot, total kernel order N+1, phase and prefactor. On squarefree labels with
at least three factors, `cofactor_data` and `riesz_cofactor_eq_zero` prove
the first cofactor response zero when log(n/p)<=L. On the other side,
`markedWeight_tilt` sums the exact multinomial allocation before estimating;
the rational 5/4 tilt and eventual L>=11N/8 give `saturation_tilt` with
exp(-N/100). `norm_scaled_unshiftedPacket_le` pays ALL incidences on ANY
finite label mask by C*(N+1)*saturationRate^N, and `saturationRate_bounds`
proves 0<=r<991/1000. The bound is independent of zeros and uniform in
moving heights and finite masks; the factor count is paid by a summable
logarithmic majorant, without a fixed count ceiling.
`tendsto_reflected_sub_current` keeps the UNCHANGED signed dyadic target;
`tendsto_matched_sub_reflected` connects it to the previous matched Euler
slope. The actual remaining input is R_(L-log p)(n/p), still signed across
incidences/counts with the original correlated factorial rectangle. This
does not pay the reflected profile, justify an unmasked Ward identity, or
prove the final complementary floor. Do not describe another cutoff branch
as an independent packet bound or a zero exclusion. Continue locally without
subagents, commits or changes to the optional running probe's frozen inputs.

`ZetaRieszWardWindowAudit` tests ONLY the generic matched-slope shortcut.
See `docs/zeta-riesz-ward-window-audit.md`. It keeps `rectangleOrders`, the
reciprocal 1/j, and every correlated cofactor order. `zeroMode_rectangle`
proves exact annihilation for the synthetic simple-zero cofactor 1+s and
ANY low-leg sequence. `pole_rectangle` instead computes the synthetic pole
1/(1+s), matched to its own logarithmic slope. The reciprocal low leg leaves
mass at least 1/20 at every N=400*t, t>=1; `not_tendsto_pole_rectangle_norm`
proves nondecay. The optional stdlib probe confirms the model behavior.
This is a PRE-FOURIER analytic-model audit, not a counterexample for the
actual ordered Euler quotient, its paired Fourier integral, or the literal
prime packet. It pays no new arithmetic component. Use the actual two-frequency
and ordered-product correlations in the next signed estimate; do not infer
decay just from matching the prime ranges or the unmasked Ward identity.
All previous paid components, masks and no-gos remain unchanged. The signed
reflected main and complementary floor remain open. Work locally without
subagents or commits, and leave the long coupled probe's inputs frozen.

The same audit now also proves a POSITIVE scalar-model estimate.
`poissonPrefix_rectangle_bound` uses 200*(j+h)<=123*N, x=L/2>=11N/16,
and rational tilt 9/10 to get exp(-N/300). `joinedPoleTail_bound` retains
Q_(j+h-1)-Q_(j-1)-Q_(h-1). `source_joinedRectangleTail_bound` sums the
original rectangle with reciprocal 1/(j*h), giving
3*(N+2)^2*exp(-N/400) after (2*radiusCeiling)^N growth. These are scalar
gamma-model estimates only. Their Fourier identification is NOT formalized;
the synthetic global pole model has a 1/xi tail needing improper/Abel
regularization, whereas the actual finite Euler integral is absolutely
integrable. Do not treat the model bound as an estimate of that actual
integral. The optional probe keeps the exact integer-floor length and shows
decreasing joined-model values, but transfers no actual prime measure.
The joint-frequency mechanism and its ordered/exterior comparison remain
the next research target. No new arithmetic component has been paid here.

The optional coupled `N=262144`, `48/160/256` model run completed with
joined finite-quadrature value about +0.0001080270744329. All 15,360 rows
and frozen sources were checked, and the full rule reassembled from its
row archive. See `docs/riesz-owner-coupled-probe.json` and
`docs/zeta-riesz-owner-integration-audit.md`. Its tiny internal evaluation
enclosure is NOT an outer quadrature bound, prime-sum bound or asymptotic.
The low-degree subset reweighting is an inconclusive sensitivity test,
not a convergence certificate. The `64/160/256` radial refinement is now
TERMINAL: all 20,480 rows completed, but its final `1e-18` radius gate
failed and no success `.json` result was written. Its log is
`/tmp/riesz-owner-coupled-262144-64-160-256.log`. Do not report the job as
running or restart it from scratch. `audit_riesz_coupled_checkpoint.py`
verified the complete `.rows.jsonl` checkpoint and nine frozen source
hashes, rebuilt the original weights, and recovered the finite-grid ball
`[0.000108027 +/- 1.92e-10]`, overlapping the earlier 48-node result.
See `docs/riesz-owner-radial-refinement-audit.json`. The original precision
gate remains FAILED; outer quadrature, prime transfer, and the joint floor
remain unpaid. Preserve both checkpoints and their source provenance.
Do not spend another full run solely tightening internal point precision
without a concrete use in the current JOINT signed inequality.
The completed `48/160/256` rows are
durable evidence and must not be overwritten or reinterpreted as a prime
calculation. These optional calculations stay out of ordinary CI.

`docs/zeta-riesz-joint-prime-transfer.md` records independent arithmetic
progress beyond the modal seam model. `ZetaRieszJointBoundary` joins the
old packet with explicitly debited neighbors in its old rest. Keeping the
exact original rectangle, its literal exterior at largest share <=1/2 or
>=3/5 has source-normalized bound 2 U C_sigma r^N, where
r=U*(262144/131071)*exp(-1/1600)<1. No exterior modal gap is assumed.
`ZetaRieszJointPrimeTransfer` gives the exact prime-kernel expansion with
scalar (N+1)/log(n), preserving every correlated allocation and low order.

`ZetaRieszJointOwnerTransfer` pays removal of canonical-largest ownership:
each wrong owner has share <=1/2; the widened box has count ceiling 83
(NOT 39), and the complete wrong-incidence sum costs 166 U C_sigma r^N.
For N>=21, the marked incidence weights still sum to at most one, by
strict factorial majority. `markedPacket_riesz_expansion` is the exact
remaining signed sum, retaining least-prime, physical, count, core and
nondominant masks and the Riesz hinge. `ZetaRieszJointAllocationError` now
pays the old allocation overlap on this enlarged carrier as well:
`boundedShare * weight <= 83 exp(-N/3200)`, and the marked error costs
`249 U C_sigma r_a^N`, with r_a=U*(262144/131071)*exp(-1/3200)<1.
Its exact raw packet removes only that allocation factor. The combined
source-normalized comparison with old packet plus neighbors is bounded by
U C_sigma (249 r_a^N + 166 r^N). No completed prime
phase or zero hypothesis is used for either error estimate.

Do not report this as decay of the joint/marked packet, a signed floor or
a new zero exclusion. In particular the remaining least-prime/Riesz masks
still prevent separate complete-leg phase replacement. The optional probe
`scripts/probe_riesz_joint_boundary.py` contains finite actual-prime label
regressions and a distinct unmasked beta-integral modal diagnostic; neither
is an exhaustive carrier estimate. Keep all probes outside ordinary CI.
The truncated Sobol masked probe is inconclusive: high-count sampling error
exceeds the target and its omitted count tail is unpaid. The all-count
renewal probe instead computes A(X)B(XY) with A=exp(-sum a_i X^i) and
B=exp(sum a_i X^i), retaining the ramp difference, finite rectangle,
moving cutoff and full complex modes. It is an uncertified continuum
diagnostic, not a transfer to distinct arithmetic primes or a decay proof.
The old fixed-cutoff, masked-mode and diverging-rest-allowance no-gos remain.
`ZetaRieszLeastBoundary` subsequently joins both least-share directions,
with an exact debit to the prior rest. Its full packet has no hard log-share
cut. The original rectangle mass outside least share 1/200..3/50 is
<=3 exp(-N/1600); combined largest/least exterior error is 3 U C_sigma r^N.
On the surviving interior the newly proved count ceiling is 200. Ownership
plus old-allocation cleanup costs 600 U C_sigma r_a^N. The exact ledger is
coreResponse = rawInteriorPacket + rest - cleanupError + exteriorPacket;
both named errors are independently o(1) at source scale. This is still
not a bound for rawInteriorPacket or rest. The canonical least prime,
Riesz hinge, physical/core/count support and factorial correlations remain
inside the explicit actual-prime sum. Do not transfer separate complete-leg
limits through them. The widened all-count numerical probe is synthetic,
has no certified continuum error and does not contain the complete actual
zeta pole/analytic-remainder transfer.
The same module now pays the two final radial localizations of the actual
marked sum: `exists_raw_radial_error` gives C*r_rad^N, r_rad<1, uniformly
in height, count and 0<=u<=10001/20000 for N>=21. `rawRadialBand` still has
the original nondominant, physical, count and share restrictions; it is
not an unrestricted completion. `tendsto_rawRadial_sub_full` proves the
wider signed sum and the joined packet have the same source asymptotics.
Its own cancellation estimate remains open. The synthetic analytic-mode
probe needs separate oscillatory quadrature refinement: coarse apparent
growth changed substantially on refinement. The wider radial diagnostic
has joined norms about 2.21e-8 at N=2048 and 5.77e-9 at N=4096, but these
have no certified continuum error and do not rule out delayed growth.
The canonical least-prime ordering is still inside the literal sum; the
unmarked finite-mode support theorem does not automatically handle it.
`highCountPacket_bound` independently pays omega>=64 on the retained
interior. Such labels have least share<=1/126; the exact factorial tilt
gives mass<=2 exp(-N/5000) per marked incidence. The source-normalized
tail costs 400 U C_sigma r_count^N, where
r_count=U*(262144/131071)*exp(-1/5000)<1. The exact count ledger leaves
counts 3..63 signed and coupled in `lowCountPacket`; their bound is open.
The later joint owner/least tilt improves this cutoff to 56: squarefreeness
gives x_p+55*x_min<=1, and the exact tilts 341/340 and 79/68 give
`markedWeight_joint_count_tail <= 2 exp(-N/9700)`. With the finer majorant
sigma=1+1/1048576, `jointHighCountPacket_bound` pays all omega>=56 by
400 U C_sigma r_56^N, r_56=U*(1048576/524287)*exp(-1/9700)<1.
The rate is close to one (about .999998809568); do not claim a small explicit
finite-order bound from the asymptotic saving. `joint_count_ledger` keeps
counts 3..55 together in `jointLowCountPacket`. The explicit
`fullPacket_sub_jointLow_bound` and `tendsto_rawRadial_sub_jointLow` pay the
whole comparison to the existing joined/radial packet. Their signed low-count
target is still unbounded. The complementary carrier also still needs its
independent floor. Preserve the earlier 64-factor result and its faster rate.
The further least-share quadrature refinement changes the N=4096
synthetic norm from 5.77e-9 to 8.52e-9. Do not certify either number or
infer asymptotic decay from these finite diagnostics.
On 2026-09-25 the user authorized committing and pushing the accumulated
work after this slice passes its gates. Continue without subagents. The
signed low-count target remains open; publishing this arithmetic tail bound
does not mark the retained signed-sum objective complete.
The close-mode stress family uses synthetic shifts 0 and 1/40000 +/- .006i,
with selected multiplicity one. Competing multiplicities three give a
refined response about -0.00559 at N=65536; the N=262144 value remains
resolution-sensitive. These are not actual zeta zeros, prime-sum estimates,
eventual growth theorems or numerical certificates. The independent
65-digit recurrence audit is a rounding check, not a quadrature enclosure.
Preserve these negative controls when exploring new cancellation identities.

`ZetaRieszLeastVariation` now instantiates least-slot telescoping with the
literal rectangle. The unit endpoint vanishes for N>=101; its coincident
marked/least slot has an independent source-scale bound 2 U C_sigma r^N.
The signed variation itself is not estimated. `ZetaRieszLeastOrderOverflow`
keeps the full multinomial allocation and pays the upper least-order overflow
on counts 14..55: x_p+13*x_min<=1 gives tilts 126/125 and 138/125, with
overflow mass<=2 exp(-N/6000) per incidence. Its literal arithmetic packet
costs 110 U C_sigma r_up^N, r_up=U*(262144/131071)*exp(-1/6000)<1
(about .9999409595). The exact retained target is lowerThresholdPacket
(counts 3..55) MINUS shortOverflowPacket (counts 3..13). Do not bound these
two terms separately or claim that all contributions with >=14 factors
are paid. `fullPacket_sub_joint_boundary_bound` pays the comparison to the
original joined carrier. That signed difference and the complementary rest
remain open. The optional sparse actual-prime probe is only an identity
regression; see `docs/zeta-riesz-least-order-boundary.md`. Preserve every
earlier no-go and the public whole-carrier frontier. Keep this continuation
local until the next user-authorized publication.

The continuous renewal audit in `scripts/probe_riesz_joint_continuous.py`
checks the old lattice diagnostic by a method-of-steps solver and separate
convolution quadrature. It retains the empty-factor atom and both exact
factorial beta faces. At N=262144, grid/endpoint interpolation errors account
for much of the old apparent growth; refined synthetic responses are about
1e-4, still uncertified. Higher-order runs are strongly cancellation-sensitive.
See `docs/riesz-joint-continuous-probe.json` and the least-order boundary note.
No actual prime-sum bound was obtained. Do not infer decay, an eventual floor,
or a generic counterexample from these finite runs. The synthetic exterior
endpoint terms and arithmetic transport are not paid by this diagnostic.
Keep it optional, preserve the prior theorems and keep the same signed target.

The label-anatomy audit is `docs/zeta-riesz-label-anatomy.md`, with the optional
`probe_riesz_label_anatomy.py`. Do not confuse dyadic moment indices with the
enormous squarefree integers in their logarithmic windows. The sparse Mersenne
regression has only five labels sharing five large factors and nearly lies on
the log(2) lattice; it is not a phase-distribution sample. The new certified
Proth examples hold largest/least factors and total log almost fixed while
middle factorization changes the Riesz sign. They are also chosen examples,
not density evidence, and no prime-count-parity sign rule or bound follows.
The anatomy probe also records the signed middle-divisor staircase after
largest/least deletion. Its integrated even-minus-odd count reproduces the
literal Riesz coefficient. The quota-complex/Euler-characteristic connection
in that note is classical, and least-vertex pairing is already represented by
our recurrence. Do not count this interpretation, or deliberately constructed
near-equal subproducts, as a new cancellation bound or as population evidence.
`ZetaRieszCutoffProfile.four_coefficient_nonneg_lowSupport` now resolves the
arithmetic coefficient sign for every four-prime label on the unchanged
retained support (u>=1/2, N>=2). This is not a sign for its full complex atom.
The weighted-cutoff probe retains all marked incidences and the exact
lower-threshold-minus-short-overflow factorial weight. Its ordinary-density
model currently sums only counts 3..14: no prime-density transport or bound
for counts 15..55 follows. Randomized certified Proth products remain chosen
regressions, not population evidence. See `docs/zeta-riesz-signed-cutoff-profile.md`.
Keep the whole-carrier frontier, signed target, and prior no-gos unchanged.
The same cutoff-profile module proves a nonpositive five-prime coefficient
under its explicit core geometry when the largest prime times the two
smallest primes lies below X_N. This follows from the exact decreasing
middle-three-prime profile; no phase or density claim is part of the theorem.
Its observed 98% coverage of negative five-prime mass is only a continuum
model diagnostic. Do not revive the failed isolated triple/quintuple
short-cell transport or replace the full signed count sum by these classes.

`ZetaRieszPrimeCompensation` retains two small primes in a squarefree label
`n=P*r*a*b`. If every distinct prime pair in `b` has log sum at least
`D=L-log P`, its response is exactly the unit pair tent minus the sum of
prime tents. If `log r+log a<=D`, the unit tent vanishes. Each prime in
`D-log a<=log p<=D-log r` supplies a full `log r` of opposing response,
and its magnitude costs at most `card(b.primeFactors)*log r`. The original
coefficient normalization is retained; the lowSupport theorem discharges
saturation for its canonical largest/least factors. These are quantitative
coefficient bounds, not phased carrier floors or population estimates.
The optional compensation probe analytically integrates the radial phase
before share quadrature. Its ordinary-density results still do not evaluate
the prime sum, pay counts 15..55, or justify generic PNT transport. Keep the
exact joined boundary target, all masks and previous no-go results.

`ZetaRieszCompensationSupply.eventually_retained_positive_supply` now proves
actual opposing supply, beyond coefficient signs: five disjoint prime-log
boxes have slopes 1/25, 1/10, 11/50, 27/50, 11/10. Fixed positive widths and
a bounded largest-prime translation give genuine prime populations by the
proved PNT and favorable full product phase at each fixed nonzero height.
The exact coefficient is -log(n)*log(minFac n)/L. The original correlated
rectangle has weight at least 1/2 eventually; every current lowSupport mask
is discharged on the unchanged dyadic schedule for 1/2<u<=10001/20000.
The real source-normalized subfamily is >=c(u,y)*(2u)^N/(N+1)^6 eventually,
with c>0 and an unevaluated starting index. This does NOT bound the complete
five-prime class, the joined counts 3..55, or the complementary carrier.
Do not count this supply twice, drop the remaining negative phases, infer
matching from population alone, or revive short-cell/PNT absolute-error
transport. The exact joint signed target is unchanged. The optional
`probe_riesz_compensation_supply.py` verifies chosen Proth prime certificates
and finite numerical identities; it is neither a population sample nor CI
certification. Keep work local until new publication authorization.

The minimum-coordinate audit in `docs/zeta-riesz-minimum-collision-audit.md`
is a diagnostic, not a bound or counterexample for that entire target.
`ZetaRieszMinimumCollisionAudit` evaluates both ordered Laplace chambers:
the factorial minimum moment is `1/(a*b*(a+b)^h)`. The concrete conjugate
nodes separately lie outside the source disk, yet their normalized minimum
moment grows. It also certifies positive candidate radial-minus-entropy
budgets at total counts 13 and 49 and nonzero equal-share Riesz kernels.
At count 45, owner share 14/25 and 44 shares of 1/100 have exactly zero
multinomial entropy cost; every positive horizontal gain therefore gives
a positive candidate radial budget, even on a narrower radius interval.
These budgets omit the integrated residue and cross-count cancellation;
do not claim that a collision source survives the complete retained sum.
The optional probe includes the literal factorial beta faces and moving
length, but is neither actual prime data nor an interval certificate.
The next modal test must compute the joint collision coefficient with both
least-order faces and all count/Riesz signs retained. No new packet, floor,
zero exclusion, rightmost-zero assumption or public frontier is introduced.

The same module now proves `collisionChambers_eq`: summing all factored
orthant chambers gives `(sum a_i)/(prod a_i)`. For balanced conjugate nodes,
`diagonalCone_eq` includes the fixed-total determinant and gives the positive
factor `a/(a^2+eta^2)^m`. The derivative of the correlated factorial profile
gives normal slopes 1/1045 and 1/4465 at the 12- and 48-cofactor candidates.
`paired_face_cones_window_neg` proves that their Riesz cone factors reinforce
after the original boundary subtraction, uniformly for 693/1000<=lambda<=694/1000.
This interval contains the canonical limiting source ratio. These are finite
model integrals and signs, not a proved local asymptotic of the entire
carrier or an assumed nonzero arithmetic residue. The remaining corners,
all other counts/modes, the actual radial/factorial asymptotic and prime
transport still need estimates. Do not report this as a full modal no-go,
signed prime-sum bound or zero exclusion. See the audit's summed-cones section.

`ZetaRieszCardinalityChamber` evaluates the full signed kernel whenever
subset cardinality determines the hinge side. Its exact affine formula
applies to unequal prime logs and gives explicit opposite coefficient
bounds in the stated 13- and 49-prime chambers. These are not phased-sum
bounds or population comparisons. The interior 45-prime kernel changes
sign at lambda=149/215: its earlier positive 693/1000 regression is negative
at every canonical source ratio in the restricted radius range. Do not
infer an integrated sign from the old rational regression. The accompanying
coherent-count probe sums every geometrically possible count at matched
point profiles; it leaves a nonzero response even for multiplicity one.
`coherent_normSq_gap` compares coupled modal denominators, not complete-leg
limits or full masked integrals. All owner/radial/factorial integrations and
the literal prime-sum transfer remain unestimated by these diagnostics.
See `docs/zeta-riesz-cardinality-chamber.md`; retain the exact target and
all prior no-gos. Probes remain outside ordinary CI; work remains local.

`ZetaRieszRenewalCurvature` now audits a specific joined count coefficient.
Its finite Euler recurrence retains both empty atoms and all orders. The
signed coefficients are nonpositive after the empty atom, and the second
cutoff difference is nonnegative on the strict core and strictly positive
in the stated interior chamber. `upper_face_lattice_strict` is a rational
lattice regression, not a theorem about the actual prime measure. The
optional `probe_riesz_renewal_curvature.py` independently checks the full
count convolution with exact rational arithmetic and the continuum
Dickman/Buchstab formula by refinement. The sampled upper-face pair
coefficient is about 8.8e-6 versus about 2.6e-48 at the lower face. Higher even differences can reverse sign (the
ten-marked-leg rational model gives -96/5); they must still be summed. These
are fixed-slice selected-background coefficients: they do not include every
modal assignment, the integrated finite beta faces or a proved collision
asymptotic. Do not infer failure or success of the literal signed bound.
Keep counts 3..55/3..13 and all original masks unchanged. A fixed positive
least cutoff is essential to this model; this is not a scalar-renewal
rescue or a transfer of continuum density to primes. See
`docs/zeta-riesz-renewal-curvature.md` for the exact scope and next test.

### Joint shifted configurations and share-seam cancellation (2026-09-25)

`docs/zeta-riesz-duality-transfer-audit.md` audits the Alladi--Johnson,
Tenenbaum and Wang least-prime identities and the displayed sharp-cutoff
hybrid Euler--Hadamard estimate. `ZetaRieszDualityRateAudit` proves that
the explicit duality allowance grows at source scale on the core for
every adaptive auxiliary cutoff, even with zero prime-density error.
The displayed hybrid envelope grows at fixed height for every choice of
order. These are theorems about upper-bound allowances, not lower bounds
for actual errors, a no-go for exact signed identities, or prime-sum
divergence. The weighted divisor differences, product phase and original
count masks are not covered by those published summands. Do not import
them as a signed floor or replace the retained target. The optional rate
probe is not prime data; no public frontier or accomplishment changes.

`ZetaRieszJoinedHeadCancellation` proves both endpoint zeros of the exact
rectangle and cancellation of any cutoff-independent complex head against
its signed derivative. On literal squarefree two-prime labels,
`markedWeight=0` and `lowerWeight=overflowWeight`; extending the joined
boundary difference by such labels adds zero with its full carrier phase.
This does not estimate counts 3..55. `coefficient_saturated_prime` still
requires a composite cofactor. Do not silently apply it to the one-cofactor
head of an exponential model. See `docs/zeta-riesz-joined-head-audit.md`.
The optional direct precision probe retains 100 decimal digits through its
Euler recurrence and convolution, but proves no grid or quadrature error.
The large million-order integrated output remains inconclusive: unresolved
oscillations and the FFT route's long-double conversion cannot certify
growth, decay, or a retained prime-sum bound. Keep numerical probes outside
CI, every old no-go, all literal masks, and the same signed arithmetic target.
The subsequent `docs/zeta-riesz-joined-ball-audit.md` identifies a concrete
phase-quadrature failure: at N=1048576, a 12-node beta rule gives a value of
norm about .909 for a sixth-harmonic moment with independently enclosed norm
below 3e-43. Node refinement can alias non-monotonically. The optional ball
reference includes its exterior beta mass and verifies branch analyticity;
it encloses only those individual numerical moments, not the full model or
an actual prime sum. The coupled ball probe encloses finite arithmetic only;
grid, interpolation, quadrature and arithmetic transport remain open. Its
head/marginal calibration pays no other error. Do not report an unresolved
large-order coupled output as growth, decay, a floor or a zero exclusion.

The next `docs/zeta-riesz-phase-refinement.md` also audits N=65536: the
old eight-node beta rule has enclosed phase error about .96277 at harmonic
ten. Even a 64-node rule aliases harmonic 24 badly. Do not treat the old
-.00557 coupled result as a resolved continuum value. The optional
positive-term binomial helper includes its explicit geometric remainder,
is checked against exact rational and separate incomplete-beta values,
and reproduces the prior finite coupled expression. Its refinement wrapper
freezes and rechecks input hashes. Both higher-resolution runs finished:
at N=65536 and 128 beta nodes, grids 128/256 give about -.005589023 and
-.005575740. The grid change is about 22 times the 8-to-128-node beta
change. These differences are not error bounds or asymptotic conclusions;
cutoff discretization and the full varying-amplitude quadrature remain
uncontrolled. `docs/riesz-joined-refinement-probe.json` preserves their
finite output balls and frozen sources. There are no pending runs from this
pass. Retain both factorial faces, the literal count caps and every no-go.
The optional `probe_riesz_phase_budget.py` evaluates the classical Gauss
remainder for single beta Fourier moments. It checks normalization by exact
rational arithmetic and against both earlier independent reference reports.
At N=65536, using the full radial upper endpoint, the conservative 1e-30
budget needs 291 nodes at lower-face harmonic 54 and 85 at upper-face
harmonic 12. These are sufficient single-mode counts, not a certified node
prescription for the full varying-amplitude coupled expression. Its Riesz
hinges, interpolation cells and accumulated mode weights still need control.
This optional external numerical audit adds no Lean theorem or arithmetic
estimate and must stay outside ordinary CI and certificate verification.

The next `docs/zeta-riesz-continuous-renewal-audit.md` evaluates the same
synthetic continuous all-count response at fixed geometry by a cellwise
delay equation with explicit polynomial, propagation and roundoff budgets.
It retains both empty atoms and includes independent one-/two-count checks
and step/degree refinements. It is external numerics, not a Lean certificate.
At N=1048576, p=11/20, r=1/99, the continuous response is about 5.95e-19,
whereas splitting the one-cofactor head before grid-128 interpolation gives
about 8.48e5. The exact difference is H-I(H). Even grid 2048 leaves about
4.73e-9 of this artificial head term. Preserve the count cancellation during
evaluation; do not use those split-head outputs as modal growth evidence.
This is a fixed-point artifact, not a bound on its integrated contribution.
The outer weighted quadrature, prime transfer and complementary floor
remain open. No previous Lean no-go, literal mask or signed target changes.

The subsequent `docs/zeta-riesz-coupled-continuous-audit.md` retains the
continuous count response through both factorial faces. Its optional
interval projection pays numerical polynomial compression and skipped
summands explicitly; neither operation deletes factorial orders. A separate
finite incomplete-gamma sum audits the radial quadrature: at N=65536, a
12-node rule has error about .164 on a moment of norm .00889. The optional
gamma-weighted rule retains both core endpoints and checks centered moments.
These single-moment checks do not bound the full varying-amplitude integral.
All four coupled N=65536 runs are complete. The 24-node ordinary and
gamma-weighted values differ by about 4.73e-8; refining the ordinary run's
beta/owner counts from 32/128 to 96/192 changes it by about 2.96e-11.
These are finite quadrature diagnostics, not error bars or asymptotic rates.
At N=1048576 the continuous upper-boundary fixed-point response is about
1.292e9, despite the tiny lower-boundary point. Do not claim joined growth
or decay from either point. Outer quadrature, literal prime transfer and
the complementary floor remain open. Keep probes outside ordinary CI.

The optional `docs/zeta-riesz-owner-integration-audit.md` now encloses the
complete signed owner integral at fixed radial/least-share points on both
faces.
It convolves the renewal polynomials before taking norms and integrates
against exact conditional-binomial moments, with density, Taylor and
roundoff budgets. The physical owner interval remains explicit. At
N=262144 its refined fixed-point integral is about -12783.43; this is NOT
the radial/beta integral or evidence of its asymptotic growth. The enclosed
lower-face owner integral at that order's mean geometry is about 2.53e-24,
with explicit density/Taylor budget below 5.8e-69; this is not a uniform
bound on the lower face. Pure-phase
quadrature budgets do not control this varying amplitude. The joined
cutoff-independent head is separately enclosed by 6.55e-43 at 48/160/256
nodes, retaining the common beta/binomial marginal without calibration.
The larger coupled response still needs outer-error control; no arithmetic
prime transfer or signed floor follows. Preserve both faces, all count
signs and every previous no-go. Numerical input hashes are frozen during
long runs: inspect their checkpoints and live handles before changing any
dependency or restarting a job. No new Lean or public frontier is claimed.

The tilted-selection audit is `docs/zeta-tilted-zero-selection.md`.
`ZetaTiltedZeroSelection.exists_unique_upper_max` constructs a genuine upper
zero uniquely maximizing Re(rho)-a*Im(rho) for a sufficiently small generic
positive slope. Moving the evaluation height by -a*u gives an exact signed
projection identity and coupled convex separation for all upper modes,
without a globally rightmost-zero assumption. It does not prove simplicity,
transfer the source ledger to the shifted height, remove the pole, or control
lower modes. `remote_pair_denominators` and `remote_minimum_tendsto` show
that a symmetric synthetic family of distant competitors can lose that
upper score yet have an exponentially growing minimum-coordinate moment.
This is not growth of the full Riesz/count sum or an actual zero assertion.
The optional exact-geometry/ball probe is outside CI. Keep the same signed
prime target, every prior no-go and the public frontier unchanged; upper
selection and local analyticity alone do not pay the masked remainder.

The current local continuation is recorded in
`docs/zeta-riesz-joint-cancellation.md`. `ZetaRieszJointShift` retains
every nonempty shifted subset and every factorial order. The complete
signed correction cancels the shifted count factor exactly and returns
the original response WITH its positive pole. The exact two-variable
pole quotient is C(a+z)/(Ca+z), not one: shifting factorial moments does
not rescale the literal Riesz cutoff. Do not silently use a common-clock
model as the literal filtered count transform. Previous negative audits
remain valid within their stated model hypotheses.

`ZetaRieszJointShiftError` pays a literal arithmetic error on the existing
FIXED `FullParityBox`: every prime log is at least 117N/5000, every order
at most N+2, and the product-multiplier error is at most
2^39 exp(-N/50). `correctionPacket_bound` and
`tendsto_shiftedPacket_sub_original` give an independent source-normalized
geometric bound, keeping all original masks and orders zero/one.
This is not a shrinking-share bound, a completed-mode transfer, or decay
of the shifted/original packet itself. Keep those distinctions explicit.

The optional synthetic finite-mode probe `scripts/probe_riesz_joint_share.py`
finds opposite growing terms on adjacent share intervals, with a small
signed union. It retains the radial window and moving length, but uses dp
and does not identify the literal prime/least-share/factorial masks.
`ZetaRieszJointShare.jointModal_bound` proves geometric decay of the
coupled integral from its NONRESONANT EXTERIOR endpoints; the shared
internal endpoint may be resonant. `model_joint_tendsto` instantiates
the dominant seam regression, not the entire eight-zero numerical model.
The retuned `-19/21` height-ratio control restores growth at the NEW outer
edge. `retuned_edge_resonance` verifies this geometry at any nonzero edge.
Do not infer universal endpoint separation from enlarging a share box.
This is a new joint mechanism, not a reversal of the radial counterexample
for an isolated hard-share packet. The adjacent arithmetic slice is part
of the unpaid rest. Preserve its signed correlation and do not give it
a separate positive allowance. The remaining task is a literal weighted
joint transfer and then a signed bound on the remaining carrier. No RH,
zero-free, or certificate frontier changes. Continue locally without
subagents, unrequested commits, or exhaustive certificate verification.

### Causal pole-surface regression bypass (2026-09-25)

After the request to keep iterating, `ZetaRieszCausalSurface` proves a
different mechanism for the latest toy analytic-factor counterexample.
See `docs/zeta-riesz-causal-surface.md`. The cutoff-only factor 1/(1-z)
matches the entire selected pole surface. Its positive-cutoff-ray inverse
preserves the triangular cone. The exact response splits into that
supported component and 1/[z(w+1)(z-1)], whose ordinary inverse is proved.
Below the diagonal, the complete toy inverse is bounded by exp(-(s-d)).

`sourceFactor_path` checks the original normalized counterexample exactly
at the physical center w=1/2,z=-ut, including displacement delta=1/2-u.
`sourceKernel_transform` proves its double inverse by genuine changes of
variables. `sourceMaskedToy_radial_decay` retains the moving length,
core window, largest-share mask, one-sided boundary and full phase; its
normalized bound is (4/5)^(N+1), with <1/1000 for N>=32. Integrability is
proved. The older (2/3)^(N+1) bound is for the unscaled comparison only.
These are regression results, not literal finite-prime packet decay or an
independent arithmetic floor. Keep public frontiers unchanged.

`displacedKernel_core_bound` proves the joint model envelope
2 exp(-7T/25000) when the analytic mode has Re b>=1/1000.
`directional_radial_bound` turns any proved M exp(-7T/25000) joint envelope
into M(9999/10000)^(N+1). The actual remainder has not been shown to meet
this condition. The complex-mode probe retains the one-sided term and
shows delayed radial growth with Re b<0 despite a pole radius >4/3.
This numerical audit prevents treating the original real-mode regression
or the local Cauchy radius as a universal remainder theorem.

The actual shifted conjugate channel is now checked in Lean:
`shiftedMode_conjugate_re_gt` gives physical Re xi>99/100, while
`shiftedPole_conjugate_outside` places its Taylor pole outside radius two.
`shiftedPole_original_re_gt` puts the original center there in Re>199/100.
`shifted_conjugate_displacement_neg` rules out the proposed positive
horizontal displacement for this actual channel. The finite four-mode
probe retains both originals and both shifted copies and grows strongly.
It uses synthetic coordinates; do not claim a full-divisor or arithmetic
packet growth theorem. Any further transfer must retain joint cancellation
of this channel; a favorable real-mode toy or separate Cauchy envelope
cannot replace that estimate.

A real-contraction follow-up was tested numerically before construction.
C=1/2 removes the positive conjugate displacement, but two farther
rightward pairs at height ratios 10 and 119/40 produce delayed growth,
including their full functional-equation/conjugation quartets. The probe
retains the selected largest-prime source. `contraction_model_phase_exact`,
`contraction_model_rate` and `contraction_model_exponent_pos` check the
resonant term's exact zero radial frequency, rate and exponent >1/40000.
These are model facts, not literal-packet growth. Do not promote the
selected-pair success or a minimum-height hypothesis into an all-mode
bound. Keep `probe_riesz_contracted_modes.py` optional and its stated
moving-length and numerical truncation errors visible.

`surface_subtraction_removable` gives the parameterized normal-pole
subtraction H(w,z)-H(-z,z). The next actual obligations are causality and
growth control of the real zeta count trace, and a strict-core bound for
its remaining joint response. Generic local analyticity does not supply
those facts. Preserve all previous support, artificial-mode, radial and
Gamma-growth no-gos; this toy model is distinct from the old divergent
constant-filter masked-mode model. Keep the optional exact-floor radial
probe outside CI. Continue locally without subagents or unrequested commits.

### Finite artificial-mode renormalization (2026-09-25)

The test is recorded in `docs/zeta-riesz-artificial-mode-audit.md`.
`ZetaRieszArtificialModeAudit` proves arbitrary-small-parameter interpolation
of any nonzero H(1), both normalized endpoint values, single-slice removable
singularity and geometric Cauchy bounds. The support theorem already allows
arbitrary fixed complex mode locations; `augmented_support` retains every
boundary channel for the selected mode plus artificial modes. The supplied
m=8 coefficient regression is reproduced.

The exact two-variable gate fails for the existing toy remainder.
`repeated_factor_path` identifies the correct fixed-mode lift. On the
selected surface w+z=0 its trace is a polynomial in w, whereas the toy
factor has trace 1/(w+1). `not_eventually_surface_match` rules out equality
on any neighborhood of w=1 for every finite fixed complex family.
`residual_normal_residue` and `frequently_residual_pole` prove genuine
uncancelled poles arbitrarily near the interpolated slice. Matching the
single value H(1) does not give joint pole removal. A w-dependent location
does not satisfy the fixed-mode diagonal-convolution support theorem.

Preserve the valid one-variable interpolation result and every earlier
audit. This is not a no-go for every coupled estimate or a theorem about
the actual zeta remainder's value. Stop before physical-cutoff or packet
work; keep the optional numerical probe outside CI. No new independent
floor or public mathematical frontier is claimed. Continue locally without
subagents or unrequested commits.

### Finite local divisor and analytic-factor audit (2026-09-25)

The local continuation is recorded in `docs/zeta-riesz-local-analytic-audit.md`.
`ZetaRieszLocalXiDivisor` uses only the adaptive radius: the finite divisor
consists of genuine zeta zeros, retains actual analytic multiplicities and
the selected zero, and has no reflected modes. `normalized_radius_bounds`
proves 4/3<R/u<2. Removable singularities give one analytic H in the disk;
`fullGenerating_local` splits the shifted-center full generator into the
finite negative principal parts and one analytic A. Cauchy bounds A's
coefficients by M(3/4)^n. `local_singular_core` retains every low-order
boundary channel and vanishes on the strict core tests.

The generic analytic-perturbation test fails. The count exponent is a
logarithmic primitive of the leg generator, not its exponential directly.
`ZetaRieszAnalyticFactorAudit` takes A(t)=1/(2-t), analytic on radius two,
whose normalized count factor is 1-t/2. Multiplication by 1/(1-t) leaves
the exact principal part 1/(2(t-1)); every positive-order coefficient is
-1/2. `analytic_factor_principal` exposes the general residue
-Q(1)(exp(B(1))-1), with B the integrated count exponent.

Coefficient persistence alone does not prove support failure. The exact
full response is 1/(z(w+z)(w+1)); `leakageKernel_transform` identifies its
ordinary one-sided inverse. `leakageKernel_below_pos` proves it positive
on 0<d<s, including gap 3/10>7/25 and largest share 11/20. All count and
empty-cofactor terms are retained. This is a toy analytic-factor
counterexample, not a theorem that the actual zeta remainder leaks.
Its local analytic coefficient hypotheses alone cannot close the route.

Stop before physical-cutoff or broad-packet work. Further progress needs
special information about the actual joint analytic count factor, not
another Cauchy envelope. Preserve both the finite support theorem and the
global Gamma-growth no-go. No new arithmetic floor or public frontier is
proved. Keep `scripts/probe_riesz_analytic_factor.py` optional; numerical
truncations are not certificates. Continue locally without subagents or
unrequested commits.

### Finite negative-mode support and infinite-divisor audit (2026-09-25)

The local continuation from `cb88975` is recorded in
`docs/zeta-riesz-negative-mode-support.md`. Preserve all previous results
and no-gos. `ZetaRieszNegativeModeSupport.inversePrimitive_laplace`
identifies an explicit weak inverse with response/z^r. Its signed normal
derivatives retain the empty-subset, diagonal delta and higher derivative
channels. `inversePrimitive_support` proves vanishing on tests with
closed support in d<s, including r=0. `inversePrimitive_core_patch`
connects it to the literal core gap. No factorial orders are deleted.

`ZetaRieszInfiniteModeAudit` retains actual analytic multiplicities in
finite canonical windows. Their restricted core-test limits are zero;
this alone does not identify the complete inverse. The exact xi count
factor xi(s)/xi(s+z) solves the global-divisor ODE with its constant
boundary channel retained. `xi_response_normal_growth` proves that,
at z_n=v+2n+1 for every v>1, the norm of
(1-xi(v-z_n)/xi(v))/z_n^(r+2) tends to infinity for every fixed r.
Reflection and the actual factorial Gamma lower bound prove this without
any off-line-zero hypothesis. Inverse-square leg summability is preserved.

`no_dominated_cone_primitive` and
`no_dominated_shifted_cone_primitive` rule out an ordinary inverse
primitive with fixed exponential weights in both cone coordinates and
agreement with the xi response on that eventual normal ray. This is a
precise obstruction to the proposed fixed-primitive dominated passage,
not a theorem excluding every generalized inverse or disproving packet
decay. No below-diagonal actual-zero contribution has been identified.
Do not call a restricted zero limit a complete-divisor inverse theorem.

Stop this pass at the infinite-divisor gate. The supported insertion
exp(-N/100) estimate is still not a literal cutoff estimate. No broad
packet, multiplier-subset error bound, new rest ledger or independent
floor is proved. A joint treatment of the regular completion term would
need a new bound before it can repair this count-transform growth.
The optional actual-xi probe is `scripts/probe_riesz_xi_support.py`; keep
it out of routine CI. Continue locally without subagents or unrequested
commits. The public RH, zero-free and certificate frontiers are unchanged.

### Per-leg shifted-center test (2026-09-25)

The local pass from `316a00c` is recorded in
`docs/zeta-riesz-shifted-center-audit.md`. Preserve every earlier no-go.
`ZetaRieszShiftedCenter` proves the exact multiplier `1-C^k/p`, actual
height >54, norm(C)<1001/1000, full generating series, exact pole
cancellation, global xi decomposition and analytic radius-two correction.
`ZetaRieszShiftedZeroModes` justifies infinite coefficient extraction by
locally uniform convergence and the genuine inverse-square divisor sum.
`ZetaRieszShiftedPrimePowers.completeLeg_global_error_bound` proves every
complete ordinary-prime leg of order k>=2 equals the all-negative actual
zero-power sum with error bounded by M*(3/4)^(k-1). Both proper-prime-power
terms are paid. No exposure, simplicity or rightmost hypothesis is used.
Do not transfer that complete-leg theorem through a hard share mask.

`ZetaRieszShiftedAllocation` proves exact arithmetic product factorization
and uniform relative multiplier closeness; this is not source-normalized
packet closeness. `ZetaRieszNegativeModeCascade` proves finite count/product
algebra including two/three modes and the adjoining-mode recurrence. The
subsequent finite weak inverse/support theorem and complete-divisor
domination obstruction are recorded above; do not drop diagonal
delta/derivative channels. The moving supported
insertion process has a checked exp(-N/100) bound for N>=100000 in rescaled
coordinates. This is not an identification with the literal multimode
positive-cutoff packet; auxiliary cutoff, boundary and infinite-mode
passages remain separate.

`ZetaRieszAdaptiveRateAudit.zero_order_full_marginal` sums every allocation
of the other legs, giving (1-x)^N exactly. The generic
`shrinking_share_source_mass_tendsto` proves (2u)^N*(1-x_N)^N -> infinity
for any x_N -> 0 and fixed u>1/2. This blocks discarding the adaptive bad
mass by a generic source-envelope norm bound, not cancellation in the
actual arithmetic packet. Keep low-order allocations in a coupled signed
estimate, or prove a stronger actual weighted error bound. Do not count
individual order-zero atoms as fatal, but do not call polynomial total
exceptional-mass decay source-scale decay either. The relative multiplier
error has the same unpaid rate issue. No broad packet, new floor, zero
exclusion or public-frontier advance is claimed. The optional probe is
`scripts/probe_riesz_shifted_center.py`; never add it to routine CI.
Continue locally without subagents or unrequested commits.

### Pole-jet half-plane and rightward-mode audit (2026-09-24)

The local continuation is recorded in
`docs/zeta-riesz-pole-jet-half-plane-audit.md`. Preserve the prior radial
no-go and every literal unfiltered mask, error estimate and ledger.

`ZetaRieszHalfPlaneModes` proves actual direct/reflected zero half-plane
geometry under an explicit temporary Rightmost hypothesis, arbitrary
finite convex stability, and the exact hard-share two-node bound
2u/(norm(z1-z2)*(N+1)), with distinct and confluent decay statements.
Do not infer existence of a rightmost zero from RH failure.

The decisive bridge audit is in `ZetaRieszFilteredMaskAudit`: the actual
polynomial Riesz kernel filters total moments with all masks frozen at N.
It does not filter each prime leg independently. A mixed denominator w
gets P(1/w), not a product of individual evaluations. The actual pole-jet
filter is nonzero for real 1/2<w<u under Rightmost, and for every exposed
inner denominator with Re(w)>1/2. Hence the zero-isolating polynomial also
does not automatically annihilate masked mixed modes.

The actual pole is 1/2+i*Im(rho). The real pole/zero mixture 0.500023125
requires an explicit compensating ordinate on a same-real-part zero.
The actual-zero non-annihilation theorem retains existence and that
ordinate relation as hypotheses; do not claim such a zero exists.

`ZetaRieszRightwardModeAudit` proves the one-successor displacement bound,
but also an exact synthetic two-rightward-mode family that defeats every
uniform squared-displacement/gain bound while retaining exposure and a
local radius. Three/four-mode numerical checks corroborate this geometry;
they are not actual zero data. Resonance depth still forces a horizontal
gain, but supplies no usable ordinate control for the existing chain.
Stop that chain extension without new actual correlations.

No conditional literal filtered-packet bound is proved or refuted here.
Its joint residual estimate, pole-containing mixed assignments, and the
old one-sided positive-cutoff inverse boundary remain unpaid. Do not
advance the rest ledger or claim a floor, contradiction or zero exclusion.
No higher-dimensional divided-difference framework was built after the
filter bridge failed. Continue locally without subagents.

### Coupled radial masked-mode audit (2026-09-24)

The continuation from `6214417` is recorded in
`docs/zeta-riesz-radial-mode-audit.md`. The old analytic `band` already
contains a complete Gamma radial integral; do not insert its denominator
power into a second factorial radial integral. The corrected model uses
the mode density exp((1/2-pole(q))*T) against exp(-T/2).

`ZetaRieszParityMaskedPhaseAudit.radial_saddle_in_core`,
`radial_growth_bounds`, `radial_window_rate_margin`, and
`no_uniform_negative_radial_exponent` check that the resonant saddle is
inside the literal window and its exponential rate is positive, while
the Gamma tail rates are larger. These certify rate geometry, not a new
integral theorem or an arithmetic packet bound.

The optional radial all-count ordered-sector model retains the exact
moving length and shows delayed growth beyond N=700000. It assigns the
left mode to the largest prime and the right mode to every cofactor.
It is not the full sum over all mode assignments, actual primes, or the
literal finite masked packet. Other assignments have a proved modal-share
separation, but that alone does not prove their integrals cannot cancel.
The full-mixture FFT residuals are below their numerical diagnostics and
do not settle growth or decay. Do not promote them to a no-go theorem for
FullParityPacket. The positive-cutoff boundary identification remains open.

Stop the proposed generic radial rescue of separate complete-leg phase
limits; any reopened packet argument needs genuinely joint arithmetic
control of the endpoint modes. Preserve every paid error and the exact
packet/rest ledger. No rest limit, independent floor, zero exclusion,
public frontier change, or completed masked transfer is claimed. Continue
locally without subagents; do not resume the divergent rest allowance.

### Signed support tail and joint masked phase audit (2026-09-24)

The local continuation from `6e42991` is recorded in
`docs/zeta-riesz-parity-tail-transfer-audit.md`. The requested full packet
estimate has NOT passed. Preserve every mask, the paid factorial errors,
the exact packet/rest ledger, and the existing public frontiers.

`ZetaRieszParityInsertionPoisson` resums the actual signed insertion series
at positive auxiliary cutoff as an exponentially compensated positive
jump-count sum. `ZetaRieszParityInsertionIdentity` identifies that series
with iterated two-coordinate differences of the supported inverse.
`ZetaRieszParityInsertionTail.nested_tail_core_bound` (in the
`ZetaRieszParityInsertionPoisson` namespace) bounds all supported orders
12 and above together by 1/1000000, uniformly for 0<a<=7/250 and on the
literal core. Signs and infinitely many orders are retained. This is not
yet the whole positive-cutoff inverse: the one-sided support boundary,
empty-cofactor source and passage a->0 remain explicit obligations.

`ZetaRieszParityMaskedPhaseAudit` proves an analytic-mode counterexample
to inferring a hard share-mask bound from uniform complete-leg limits.
Both individual modes decay uniformly for k>=N/200, yet their correlated
integral over [43/80,9/16] has no fixed eventual norm bound. Multiplication
by any fixed nonzero defect does not fix it. This is NOT actual prime data,
zeta zeros, or a no-go theorem for FullParityPacket: the full Riesz/count
structure may remove the modes. Do not apply the existing product-phase
theorem through the remaining coupled masks without a new joint estimate.
The optional numerical probes are diagnostic, not certificates. Their
fixed total-log slices do not include the radial factorial cancellation.

No conditional whole-packet bound, revised rest source, independent rest
floor or zero exclusion is proved. The existing rest allowance still
diverges. The strict mathematical task remains incomplete; do not call
this slice a completed masked transfer. Work without subagents.

### Simple-zero parity and independently paid factorial errors (2026-09-24)

The continuation from `6a30bfb` is recorded in
`docs/zeta-riesz-zero-parity-audit.md`. Preserve the literal packet/rest
ledger, every finite mask, the count ceiling 39, and all previous paid
errors. The user forbids generic PNT/Abel transport, thin cells, ownership
completion and subagents. Numerical investigation should guide actual
analytic estimates; do not promote probe output to a certificate.

`ZetaRieszZeroParityCascade` proves the signed transform
`(1-exp(-J_r))/z^2`, with zero-cutoff value `1/(z*(w+z))`, and directly
verifies the inverse representative `1_(d>=s)`. It vanishes on the literal
core. Do not claim general inverse uniqueness or an unevaluated pointwise
count-sum interchange. The cutoff renewal keeps its empty-cofactor term.
The sharpened core gap exceeds `289/1000`; ten omitted shares <=7/250
cannot reach support. `ZetaRieszParityFirstInsertion` identifies the first
possible insertion with a positive simplex indicator and bounds its
reciprocal-density integral, including 1/11!, below 1/1000000. This pays
only order eleven, not the entire cutoff defect or its boundary term.

The pointwise order-zero obstruction remains true, but the user explicitly
reopened it by asking to sum factorial weights first. It is now paid:
`fullParityBox_bad_mass <= 39 exp(-N/400)` for allocations with any base
order below N/200. The actual `badPacket` has an independent geometric
source-scale bound, uniform in moving heights/counts. The exact rectangle
splits into good plus bad; no order-zero atom is silently removed.
`ZetaRieszParityOrderPhase` extends finite-prime completion to
N/200<=k<=27N/40. Under the original simple exposed-zero hypotheses,
`eventually_good_product_phase` supplies a uniform parity limit on every
good prime-product array, using the finite count ceiling.

Two further original factorial masks are now independently paid throughout
the whole FullParityBox, for every prime count:
- `rectangleOmittedMass <= 6 exp(-N/6000)`;
- `boundedShare <= 39 exp(-N/1000)`.
Their literal arithmetic errors have strict geometric source-normalized
rates for 0<=u<=10001/20000. `tendsto_coefficientBox_sub_fullParity` keeps
exactly the original finite support and phase and pays these two errors.
The remaining Riesz and prime-log masks are coupled; the coefficient box
is not a product of complete prime sums. Do not apply the product-phase
array theorem to that box without proving the masked transfer.

The optional `scripts/probe_riesz_zero_parity.py` evaluates a candidate
Dickman/Buchstab inverse and checks finite-count quadratures and grid
refinements. Its tiny continuum values are exploratory. The inverse's
identification and the literal conditional packet bound remain open.
The subsequent support-tail theorem above does not pay the full one-sided
cutoff defect. Keep the probe out of ordinary builds and CI.

`ZetaRieszParityRestAudit` proves that balanced triple boxes survive
untouched in fullParityRest, even inside the narrower core. The existing
independent phase-cost allowance for that rest still grows at least as
c(2u)^N/(N+1)^4 at each fixed height, and tends to positive infinity.
This does not prove divergence of the signed rest or exclude joint
cancellation. No rest source has been recomputed by assuming the packet
small. Keep LocalizedTypeIIBound and public frontiers unchanged; no whole
packet floor, zero exclusion or RH contradiction is established here.

### All-count continuum and global Abel audit (2026-09-24)

The latest steer from `a8fd375` is recorded in
`docs/zeta-riesz-continuum-cascade-audit.md`. Preserve the earlier direct
packet, paid core window, five-prime allocation and phase audit. Do not
resume exponentially thin cells, cofactor completion or the scalar
Buchstab contraction route. Work without subagents.

`ZetaRieszContinuumCascade` proves the exact prime-product Riesz kernel
and its arithmetic coefficient orientation, the all-count iterated
Laplace transform `1/(w*z)` at zero cutoff, and positive-cutoff renewal
with its empty-cofactor boundary source. Inner and outer integrability
and absolute summability of the evaluated count transforms are checked.
Do not assert a pointwise inverse-Laplace or cutoff-sensitivity bound
from this transform theorem alone. The full cutoff contrast retains a
nonzero first variation under a shared prime-density perturbation.
The explicit interior `interior_variation_fibre` has normalized kernel
response one; its remaining cofactor share fits exactly one prime above
the lower cutoff, so higher counts cannot cancel that same fibre. This
is a support identity, not a bound on its actual prime discrepancy.

`ZetaRieszFullParityPacket` selects the interior largest/least-prime box
directly in `coreResponse`, retaining the original residual coefficient,
all masks and phase, and exact finite `rectangleMass` across every count.
The packet/rest ledger is a suballocation, not a floor. At most 39 prime
factors can occur; counts 12 through 39 are not discarded or estimated.
No quintuple-only allocation estimate has been extended to all counts.

`ZetaRieszCascadeAbelAudit.normalized_coreAbelAllowance_tendsto` proves
that the standard one-prime absolute-variation allowance obtained from
the current inverse-log Chebyshev envelope diverges at source scale
for every fixed u>1/2 and nonzero fixed height, inside the retained core
window. This is an obstruction to that error estimate, not a lower bound
for the true discrepancy or the complete packet's multivariable variation.
The full signed arithmetic error could still cancel. Do not claim a
general impossibility theorem for global Abel or parity methods.

The strict packet-norm/floor test has NOT passed. The fully coupled
multivariable variation has not been evaluated, so do not report the
one-prime allowance audit as a completed go/no-go test for the whole route.
The next arithmetic task is a signed weighted prime-discrepancy estimate
or an identity that cancels its first variation with paid higher errors.
A tiny fixed continuum residual,
O(1/N) relative prime error, or numerical count subtotal is not source-scale
o(1). Keep the public RH frontier, zero-free/certificate results and
`LocalizedTypeIIBound` unchanged; expose these results only as a supporting
continuum/transport audit. Do not add stronger short-interval machinery.

### Direct triple/quintuple cell audit (2026-09-24)

`docs/zeta-riesz-parity-cell-audit.md` records the continuation from
`3f19e314`. Preserve the literal rectangle reserve and its matching owned
copy. `ZetaRieszQuintupleHinge` evaluates the proposed five-prime hinges
on the actual moving cutoff; the third region has zero response at its
closed upper boundary. `ZetaRieszParityPacket` selects a genuine
suballocation of the direct finite carrier with all original masks,
factorial rectangle, allocation weights and full phase. Its quintuple
packet belongs to H. No cofactor is completed and no hypothetical-zero
phase is used for the cancellation test.

`ZetaRieszParityCells.tendsto_packet_sub_frozen` independently pays the
source-scale phase error for deterministic half-width exp(-N/4000), on
0<=u<=10001/20000. The signed cell main term remains the difference of
literal triple/quintuple densities times the common cosine. The current
Rosser endpoint count bounds overlap strictly on those thin cells;
`actual_prime_count_thin_cell` and
`eventually_packet_cells_below_count_resolution` prove the limitation of
endpoint subtraction. Polynomial-width failure is an audit of the
available error envelope, not a lower bound for the actual error.

The strict arithmetic test has NOT passed: no -1/1000 or -1/500 floor for
the paired packet is proved. Do not claim that a quintuple density
surplus is automatically favorable at every phase, discard unmatched
mass after capped transport, or call this a general parity impossibility
theorem. Literature short-interval counts can reach this raw resolution
but are not formalized here; the masked weighted signed comparison is
also open. The user subsequently instructed continued work toward the
floor and requested numerical probing; pursue concrete counting, mask
savings or signed estimates and record exploratory models separately
from actual prime counts and Lean proofs. Keep the main RH endpoint, LocalizedTypeIIBound, public
zero-free/certificate frontiers and top-ten lists unchanged. Expose this
only as a supporting arithmetic audit. Work without subagents.

The numerical probe now has two concrete consequences. `ZetaRieszParityWindow`
pays the full original narrow-carrier tail above 2.03N by a geometric
source-scale bound. `ZetaRieszParityAllocation` proves
`boundedShare<=5*exp(-N/2200)` on the literal five-prime packet and proves
its summed allocation error tends to zero. Both estimates are independent
of zeros and uniform in arbitrary heights. The actual packet main term
is still open; never report those error estimates as its floor.
Optional scripts `probe_riesz_parity_packet.py` and
`probe_riesz_parity_cascade.py` use continuous prime density, not actual
prime enumeration. Their recorded results distinguish selected packets,
full log-share boxes and finite-order masks. Seed spread is not certified
error, and an odd-class subtotal must not silently discard even classes.
Keep these probes out of ordinary builds and CI.

On 2026-09-05 the user explicitly changed the objective to an overnight Lean
theorem push using phase colour, Gaussian heat, the literal eta support, and
finite/continuous representations. This supersedes the former requirement
that every commit improve a literal zero-proportion certificate above `17/25`.
On 2026-09-06 the user authorized the next full theorem package: actual
overlap averaging, complex weighted endpoint corrections, signed Gaussian
reflection, mixed matrices, and an exact completed-current audit. The active
mathematical targets and implementation ledger were recorded in
`docs/eta-signed-endpoint-theorem-plan.md`; that package is complete at its
stated scope. The user then authorized the full objective: reconstruct the
original leading current and prove the uniform weighted arithmetic estimate.
The active ledger is `docs/eta-current-reconstruction-plan.md`. The completed
first program remains recorded in `docs/rh-overnight-theorem-plan.md`.

A qualifying slice must prove a concrete target from that program, with all
analytic hypotheses discharged for the actual carrier. Retain exact phase,
tail, and mixed-kernel identities alongside their estimates. Generic models,
unproved premises, numerical experiments, and merely renamed obstructions
do not establish these targets. Document the compiled terminal theorem and
the precise remaining obligation before staging.

Commit and push each coherent passing theorem slice with its necessary
documentation and generated inventory. Auxiliary heat or matrix estimates
must not be reported as proving RH, an RH-equivalent open direction, or an
improved zero-count certificate. The soundness and exact-commit CI gates
below continue to apply.

### Actual small-prime triple compensation (2026-09-27)

`ZetaRieszSmallPrimeCompensation.eventually_compensated_core_floor` now pays
both the fixed positive balanced-triple band and the ENTIRE original
three-prime head containing a prime <=N^2, using one actual four-prime
supply at every radial slab. The marked-log coefficient and Chebyshev prime
budget give O(log N/N) cost relative to that supply. Half plus one quarter
is spent; both positive triple credits and a quarter of the same supply
remain. Exclude overlapping triple selections and used supply labels before
applying the exact four-/five-prime debit inequalities to the signed rest.
Only the already proved radial-edge geometric allowance is added. Constants,
balanced width and eventual thresholds are existential and height-dependent.
This is relative signed compensation, not separate head decay or a numerical
whole-carrier floor. See `docs/zeta-riesz-small-prime-compensation.md`.
The cofinal joint -79/1000-o(1) target, restricted exclusion and RH remain open.
Preserve all old no-go audits and paid error bounds. Do not resurrect the
old divergent allowance or add overlapping positive supplies. The user has
authorized committing and pushing the accumulated work after this slice
passes the full gates. No subagents are authorized.

### Exact four-prime debit and small-head payment (2026-09-27)

`ZetaRieszFourPrimeExact.positiveAllowance_eq` proves the ENTIRE positive
four-prime coefficient is `(T/L)*max(0,logP+T-2L-sum_(q!=P)
max(0,logq-(L-logP)))` on `0<L<=T`, `2T<=3L`. Combined with the already
exact negative allowance, its `exactDebit` has no coefficient slack on
either cosine sign. `re_four_atom_nonneg_of_second_large` proves all
four-prime atoms with a second reflected-large prime nonnegative on the
negative-cosine side. `norm_coefficient_le_marked_log` bounds the coefficient
by `(T/L)*log r` for ANY marked prime. The compensated core theorem keeps
the existing triple credits, quarter-supply and entire signed rest.

`ZetaRieszFourPrimeHead.small_four_norm_upper` now bounds an ENTIRE selected
four-factor population in each original radial slab, not a fixed cofactor.
Two small factors cancel exactly; every surviving label with a prime<=Q has
three cofactor prime logs>M/16. Actual Chebyshev counts preserve log(r)/r
and give `B4*(1+log Q)*exp(2M)/(M+1)*radialEnvelope N M`, with
`B4=1179648*(log 4)^4*exp 4`, M>=100, log Q<=M/32,
all prime logs<=5M/4, and 271M/200<=L<=143M/100. The original moment N,
allocation, complex phase and arbitrary finite selection are retained.
For Q=N^2 this costs O(log N/N) RELATIVE to the actual positive supply,
not a separate source-normalized decay bound.
`eventually_core_joint_floor` simultaneously pays the radial balanced
triple union, remaining small-prime triples and `radialFours` with ONE
supply. Half+eighth+eighth is spent; all three positive credits and a quarter
of that supply remain. Supplies and selected populations are proved disjoint.
`mem_radialFours_of_geometry` covers the small-four-prime inner radial core
below the already paid 60.1% dominant endpoint. The new floor keeps its
outer-edge/large-prime omissions SIGNED; older independently paid errors
remain available and may not be silently discarded. Existing full triple
head and edge theorems remain intact. Do not add old/new supplies as
independent budgets. The full numerical -79/1000 joint floor remains OPEN.
The density probe is an uncertified single-slice diagnostic outside CI;
no actual signed prime transport or remaining-count bound follows from it.
See `docs/zeta-riesz-four-prime-exact.md`. Keep public endpoints unchanged
and continue locally without subagents or unrequested commits.

The continuation in the same module now pays an EXPONENTIAL prime head.
`exists_log_head_budget` chooses a fixed delta>0, delta<=1/128, using
min(1/128,b/(8*(B3+B4))) for the desired supply fraction b. The width
depends on the positive-supply constant; neither an effective numerical
width nor starting index is claimed. `eventually_joint_slabs_spending_log_head`
handles EVERY log Q<=delta*N. `eventually_core_exponential_floor` uses
Q=floor(exp(delta*N)), with the same half+eighth+eighth spending and the
same quarter of ONE supply retained. This replaces the two head selections;
never add their old budgets as independent credit.
`exists_exponential_head_missed_bound` pays all omissions in the FULL
three-/four-prime exponential head and balanced triple band by the existing
radial and dominant errors: C*r^N+2*majorantMass*exp(-N/1000000), r<1.
`eventually_core_full_exponential_floor` incorporates these payments into
the original whole-core inequality; `tendsto_exponential_head_allowance`
proves the error vanishes. `remaining_full_head_prime_log_gt` proves every
prime of a surviving squarefree count-three/count-four label has log>delta*N
throughout the core. `eventually_polynomial_le_exponential` proves the new
threshold eventually exceeds every fixed polynomial. The actual signed
complement, all three positive credits and quarter-supply remain together.
No separate source-normalized head decay, control of counts>=5, numerical
whole-core floor or zero exclusion follows. Continue locally without
unrequested commits or subagents; keep public theorem endpoints unchanged.

### Sharp cross-count population test (2026-09-27)

`ZetaRieszSharpPrimeWindows` proves arbitrary relative log-mass, cardinality
and harmonic-mass bounds for actual primes in fixed log widths h, uniformly
for a>=alpha*N. Its ordered-product and signed-box theorems keep the original
moment, allocation, coefficient and cosine. These are relative population
budgets, not source-scale signed PNT/Abel transport; do not claim a rate or
effective starting order. Pointwise signed box-score premises remain explicit.

`ZetaRieszFivePrimePairSupply.neg_coefficient_eq_pair_balance_add_triples`
evaluates the squarefree five-prime coefficient whenever 0<L<=T=log n and
every prime log<=L. With D=T-L, its negative is (T/L)*(B+Q), where
B=3T-4L+sum_p(log p-D)_+-sum_pair(D-log(pair))_+ and
Q=sum_triple(D-log(triple))_+>=0. `re_atom_ge_pair_credit` gives actual
positive credit weight*(T/L)*max(0,B)*(-cos(yT)) on the negative-cosine
side for largest share<=1/2. `re_sum_ge_pair_credit` retains the entire
signed complement. `eventually_re_atom_ge_raw_pair_credit` pays old
allocation by any fixed relative loss on this favorable population;
never reinterpret that as a separately decaying absolute carrier error.

`eventually_core_cutoff_ratio` proves the ACTUAL moving core ratio lies
eventually in [693/1015,139/195]. The optional four/five density probe uses
interval coefficient envelopes across this whole range, four-largest
share<=601/1000, five-least share>=1/100 and five-largest share<=1/2.
Its sampled minimum ratios ~1.2988 (full credit) and ~1.1343 (pair minorant)
are NOT certified integrals or actual population payments. Do not mark the
whole adverse four-prime sector as paid: a certified angular cover, common
phase-arc comparison, radial and mask control and disjoint spending remain.
No new supply is added to the already-spent four-prime supply. Positive-cosine
terms and all other counts stay signed. No change to the joint -79/1000-o(1)
target, endpoints, zero-free claims or RH status. See
`docs/zeta-riesz-four-five-capacity.md`. Continue locally without commits or
subagents unless the user requests them.

`ZetaRieszOrderedCapacity` now evaluates the ordered positive four-prime
coefficient as a capped least-prime logarithm, proves its strict supporting
geometry, and gives a direct debit bound for the literal negative-cosine
atom. Its five-prime three-tent equality and interval-cap lower bound keep
all original weights and both moving-cutoff edges. The cap and symmetric
pair integrals are evaluated exactly, including the cap's zero lower endpoint
when its height is positive. Rational log bounds include the sharp odd-denominator tail.
`radial_kernel_le_phase_arc` bounds variation of the ORIGINAL radial
factorial kernel by 501/500 on a total-log interval of width<=1/8 inside
the core. This is a relative supply cost, not a source-scale absolute error.
`moving_cutoff_stays_in_padded_bin` proves that 1/100000 padding keeps the
ACTUAL moving length in one cutoff bin throughout the same phase arc for
N>=5000. Do not drop arcs crossing unpadded cutoff-bin boundaries; that
would leave an unestimated source-scale term. The numerical probe includes
the proved padding.

The optional ordered-capacity probe uses these scalar formulas and a
two-dimensional symmetric five-prime integral. It suggests a minimum model
surplus around 3.39% throughout the proved cutoff range. Floating-point
enclosures and the angular symmetry/cover are NOT a Lean certificate or an
actual prime-population payment. Common phase-arc
transport, masks and disjoint spending remain open. Do not mark the adverse
four-prime population paid, discard positive-cosine terms, or change public
frontiers. See `docs/zeta-riesz-ordered-capacity.md`. Continue locally without
unrequested commits or subagents.

`ZetaRieszOrderedCapacity.cap_integral_zero_eq` now closes the cap integral's
zero endpoint, retaining its harmonic cancellation. Parameter-monotone cap
integrals, `five_fibre_lower`, the full debit root-box restriction and the
coarse-cell density bound are proved. `ZetaRieszCapacityCheck` connects checked
dyadic cap evaluations to actual real integrals, including whole parameter
cells. `first_bin_fibre_credit` verifies one explicit interior fibre uniformly
over its outer rectangle. This is NOT a certificate of the full 3.39% angular
surplus, an actual prime-population payment, or a joint floor. The full angular
cover/symmetry, phase-arc transfer, masks and disjoint spending remain open.
The optional numerical probe still reports unverified floating-point totals;
its metadata now includes the cap-checker source. Do not promote a checked
individual cell into a checked whole-region claim. Keep the same joint target
and public endpoints. A second unverified probe with four/six log-series terms
retains a minimum model ratio around 1.03035, suggesting a cheaper finite
certificate. Both diagnostic reports remain outside proof dependencies and
ordinary CI. Continue locally without unrequested commits.

The complete-cover continuation adds `ZetaRieszCapacityIncidence`:
`re_sum_ge_ordered_pair_credit` proves the exact factor one half on the
literal five-prime atom and retains every unselected label signed.
`ZetaRieszCapacityCover` uses half-open cells and checks every split;
`integral_bounds_of_check` sums the entire root, including zero-credit
children, and `integrableOn_of_check` discharges integrability from checked
bounded leaves and measurability. `ZetaRieszFourCapacityCover.check_sound`
handles the full debit density, including empty fibres and coarse cells
crossing the apparent singularity. `ZetaRieszFiveCapacityCover` proves the
actual supply density measurable, nonnegative and integrable, its pair
ordering/saturation geometry, and the exact cancellation of the half-incidence
factor with the symmetric pair integral. `fibreExpression_le` and
`expression_le_density` retain the moving boundary and sum all eight adjacent
common fibres before the outer integration. Its `check_sound` and
`integral_ge_of_checked_cover` connect accepted whole-cell computations to
the actual selected supply integral. The deliberately large coarse upper
bound in this lower checker is ONLY an integrability witness, never an
arithmetic debit allowance.

The optional capacity generators propose rational complete trees using
floating point; generation is untrusted. Chunk the subsequent `decide +kernel`
checks and assemble them with proved child-box equalities and exact totals.
Keep these expensive computations outside default builds/CI. A successful
checker theorem or a coarse smoke cover is not a certificate of the proposed
3% surplus. Report a tight whole-region budget only after EVERY chunk and
its assembly pass, and distinguish it from the still-open actual prime-window
transport, common-cosine comparison, original mask control and disjoint
spending. In particular no adverse four-prime population or full joint floor
is paid by these checker soundness theorems alone. The same joint
`-79/1000-o(1)` target and public endpoints remain unchanged.

`ZetaRieszPhaseBudget` now proves the whole-period signed transfer budget:
a 103/100 angular supply/debit ratio tolerates one-percent aggregate
population/allocation loss, radial factor 501/500 and phase uncertainty
1/10000, keeping cosine-zero neighborhoods. `original_radial_phase_budget`
uses the ORIGINAL factorial kernel at fixed |y|>=54; its angular surplus
premise is explicit. `tuple_negative_phase_enclosure` keeps the literal
product phase in fixed log windows. `eventually_phase_window_mass` gives
relative harmonic prime bounds 9999/10000..10001/10000, and
`eventually_phase_tuple_mass` combines up to five legs with bounds
999/1000..1001/1000. These are relative population budgets, never generic
source-scale Abel errors. Angular-cell transfer, masks and disjoint
spending are still open; do not treat the one-percent allowance as paid.
The first-bin FOUR debit cover passed locally with exact upper bound
133011/1000000, all 274 chunks plus assembly and standard-axiom audit.
Its optional generated proof is outside the ordinary root; the tight FIVE
supply cover and other bins remain unfinished. See the ordered-capacity
note. Keep the joint floor and all public zero/RH endpoints unchanged.


`ZetaRieszCoupledWindow.eventually_owned_five_core_lower` now gives an
explicit retained signed lower bound for any finite family of ordered
five-prime cofactor windows. The last-prime window follows the EXACT
cofactor, so every product stays in (t,t+h] in total logarithm. Three common
hinge caps, original allocation, full phase, all core masks and unique
largest-prime ownership are proved, with the entire complement signed.
`ZetaRieszMacroPrimeWindows` gives relative Darboux harmonic bounds
4999/5000..5001/5000 for macroscopic outer windows and 999/1000..1001/1000
for up to four outer legs. These are relative population costs, not generic
source-scale Abel errors. `ZetaRieszFivePrimeCells.eventually_five_cell_core_floor`
then retains 997/1000 of an EXPLICIT conservative cell credit inside the
actual core. Its premises are log-cell geometry and the negative phase
margin, not an assumed arithmetic signed score or prime-count bound. It
keeps original N, L, allocation and masks. The 0.3% factor pays allocation
and counting ONLY; angular grid/edge approximation, the matching four-prime
upper transfer, the complete numerical surplus and aggregate disjoint
spending remain open. Do not claim the whole angular integral or adverse
four-prime population is paid. Other phases/counts and the full
-79/1000-o(1) joint floor remain open. Starting indices are unevaluated.
Keep public RH/zero-free endpoints unchanged and continue locally without
unrequested commits or subagents; frozen optional five-cover inputs stay
unchanged until verification finishes.


`ZetaRieszFourPrimeCells.eventually_four_cell_core_floor` now supplies the
matching literal debit at factor 501/500, retaining all three coefficient
caps, actual negative cosine, positive coefficient and original core masks.
`ZetaRieszJointPrimeCells.eventually_joint_cell_family_floor` combines finite
families in the unchanged core. Five-prime credit cells are disjoint by
ordered coordinate separation; four-prime adverse cells may overlap because
duplicates only overcharge. The count classes are disjoint. Phase windows
with no certified favorable margin supply zero credit, while every adverse
label and the entire signed complement remain.

`ZetaRieszCellCompensation.eventually_fixed_height_payment` discharges one
CONCRETE interior comparison without an assumed numerical surplus. At every
fixed y!=0 and 1/2<u<=10001/20000, eventually each original dyadic order has
a bounded radial translation t=2*N+v and fixed positive width h. The four
cofactor log/t intervals are (0.060,0.061], (0.230,0.231], (0.240,0.241];
the five intervals are (0.060,0.064], (0.070,0.074], (0.220,0.224],
(0.245,0.249]. The largest prime enforces t<log(n)<=t+h exactly. The proved
moving chamber 17*t/25<=L<=18*t/25 supplies an angular credit >=1/6000000
and debit <=1/16000000, including counting/allocation. After conservative
phase/radial comparison, the core floor retains the entire signed complement
plus strictly positive h*exp(-(t+h)/2)*t^N/(100000000*N!). This is one
interior population payment, not the whole angular region or numerical
joint -79/1000-o(1) floor. Starting indices are unevaluated. Do not add it to
old spent supplies without a combined disjoint ledger. Recovering the full
angular integrals from cells, grid/edge costs and the optional complete
numerical surplus remain open; positive-cosine terms and other counts stay
signed. Keep all public RH/zero-free endpoints unchanged. Continue locally
without unrequested commits or subagents; preserve frozen optional cover
inputs while their kernel verification is running.

`ZetaRieszFourPrimeCells.eventually_boundary_cell_floor` extends the same
501/500 debit to overlapping cofactor-prime intervals, retaining literal
ordering, positive coefficient, negative cosine and original support.
`positive_four_top_gap` proves log(p)-log(q)>7*log(n)/145 for a positive
four-prime coefficient in the actual cutoff chamber. The complementary
top-gap region is pointwise nonnegative on the negative-cosine side.
Both middle ordering boundaries remain inside the adverse cover.
`ZetaRieszFourBoundaryCover.eventually_exponential_threshold_floor` covers
EVERY adverse four-prime label above log p>delta*N in each core total-log
interval, for fixed 0<delta<=1/128. Its fixed grid has M=ceil(3000/delta),
a=delta*N and b=delta*N/1000, with ordered index tuples and all half-open
endpoints retained. The exact positive coefficient forces sufficient final-
prime length; no ordering-boundary mass is omitted. The signed floor charges
the explicit sum of cellDebit and keeps the entire complement signed.
`ZetaRieszJointPrimeCells.eventually_joint_boundary_family_floor` connects
these cells to disjoint literal five-prime credits. This is NOT a small
source-normalized allowance or a completed whole-region compensation.
The Darboux totals must still match the checked angular domains: the optional
four-prime certificate uses largest share<=601/1000, whose restriction and
paid exterior cannot be dropped when applying that integral budget to a
more general grid. Favorable boundary/approximation costs, complete numerical
surplus and combined disjoint spending remain open. Never spend the previous
head/interior credits twice. No new whole joint floor, zero exclusion or RH
claim follows; all other phases/counts stay signed. Keep public endpoints
unchanged and continue locally without unrequested commits or subagents.

`ZetaRieszFourOrderingBudget.eventually_core_interior_floor` now bounds the
ENTIRE clipped adverse four-prime population above log p>delta*N by its
strictly ordered interior-grid debit plus a proved 1/1250 boundary allowance.
The factor multiplying this allowance is the ORIGINAL
exp(-t/2)*(t+h)^N/N!*(max(0,-cos(y*t))+abs(y)*h)*h. Do not describe 1/1250
as a source-normalized constant or claim separate boundary decay.
The largest-share cutoff 601/1000 remains literal, with its exterior signed.
Exact coefficient geometry cancels the least-prime denominator; cell density
is at most 800. Only two repeated-index families can cross an ordering face,
with at most 2*ceil(t/(3*b))^2 nonempty cells; b=delta*N/1000. All other
nonempty cells have separated cofactor intervals. `eventually_edge_population_floor`
is an actual signed-prime-sum bound, not only a continuum volume estimate.
`original_two_percent_budget` reduces the required angular surplus from 3%
to 2% after the same one-percent aggregate loss, radial factor 501/500 and
phase error 1/10000. The exact rational first-bin candidate fits both 1/1250
ordering cost and another 1/2000 approximation cost. That scalar inequality
DOES NOT certify the proposed five-prime supply or its arithmetic transport.
Keep the optional full-cover verification separate, with frozen inputs.
Interior/angular matching, favorable edge losses, complete covers and combined
disjoint spending remain open, as do other phases/counts and the full joint
-79/1000-o(1) floor. Preserve every signed complement and do not spend existing
credits twice. No public zero-free/RH endpoint changes; continue locally without
unrequested commits or subagents.

`ZetaRieszFourInteriorBudget.eventually_core_integral_floor` now gives an
independent floor for the ENTIRE clipped adverse four-prime population above
log p>delta*N on the unchanged dyadic core. Its debit is at most
the following quantity; "adverse" here means coefficient>0 and cosine<=0,
not the other sign/phase sector:
`(1003/1000*integral_Omega density+1/100000)*E`, where
`E=exp(-t/2)*(t+h)^N/N!*(max(0,-cos(y*t))+abs(y)*h)*h` is original.
The cofactor density retains the exact three-cap coefficient. Disjoint
half-open cells share ONE 1/100000 volume allowance; it is not charged per
cell. The refined mesh is delta*N/1000000000 with fixed
M=ceil(3000000000/delta). Actual nonempty-cell geometry discharges the
denominator conditions, and all ordering faces are covered. Empty cells
spend nothing. The largest-share 601/1000 mask, allocation, phase, original
moment/length/support and whole signed complement stay literal.
This does NOT yet bound integral_Omega by the optional two-dimensional
133011/1000000 certificate: the ordering and largest-share excess of the
covering cells must be paid before that substitution. The 0.3% factor
includes upper counting, and the 1/100000 is an angular cost, not a
source-normalized constant. It spends part of the ONE aggregate 1/2000
approximation allowance from the preceding budget; favorable boundary
costs and other grid errors cannot each spend that budget again.
The exact coordinate formula `density_eq_ordered` identifies the existing
cap integrand; the domain/integral comparison and favorable five-prime
transport remain open. Keep optional cover inputs frozen while checking.
No complete joint -79/1000-o(1) floor, new zero exclusion or RH follows.
Continue locally, preserving public endpoints and without unrequested
commits or subagents.

`ZetaRieszFourAngularDomain.eventually_core_capacity_floor` now pays the
complete adverse four-prime angular-domain comparison. For the same original
core, threshold log p>delta*N and literal largest share<=601/1000, the debit
is `(1003/1000*(D+1/1000000000+1/78000000)+1/100000)*E`, where D is the complete
ordered two-dimensional density on `outerBox lo` and E is the unchanged
radial/phase factor above. Exact affine coordinates have unit absolute
Jacobian; genuine integrability and Fubini identify the three-share density.
`fine_face_budget` bounds both repeated-index ordering families together by
1/1000000000 on the refined mesh; the largest-share cover excess
has width at most four normalized cell widths, density<=800 and cost at most
1/78000000. Actual nonempty cells discharge every geometric premise.
The full signed complement and original allocation/physical/count/phase masks
remain. The optional first-bin upper certificate can now be substituted ONLY
inside its exact padded L/t range. `scripts/CheckRieszFourCapacityTransfer.lean`
is an optional checked application, outside ordinary CI; its cached angular
assembly must first be verified. Do not infer all-bin numerical coverage.
The 1/100000 mesh and tiny largest-share cost spend part of the ONE aggregate
1/2000 approximation allowance; favorable boundary errors must share the
remaining budget. Favorable whole-domain arithmetic transport, disjoint joint
spending, other signs/phases/counts and the full joint floor remain open.
No separate source-scale decay, zero exclusion or RH follows. Continue locally
without unrequested commits or subagents, preserving frozen cover inputs.

The optional first-bin five-prime cover has now passed all 713 chunks and
its assembly (10,131 leaves); `whole_supply_lower` proves 34261/250000.
`CheckRieszCapacitySurplus.lean` combines the independently checked four/five
assemblies into a two-percent ANGULAR surplus after one 1/1250 ordering cost
and ONE 1/2000 approximation allowance. `CheckRieszFourCapacityTransfer.lean`
proves the actual first-bin adverse-prime debit <=133421/1000000 times E,
with the entire signed core complement retained. Both optional scripts print
terminal axioms; keep exhaustive covers outside ordinary builds and CI.
Only the first padded cutoff bin is checked. The favorable full-domain
arithmetic transfer, remaining seven bins and whole signed floor are open.
Do not reuse its unused favorable credit in more than one joint ledger.

`ZetaRieszFiveAngularBoundary.eventually_ordered_region_core_floor` now
pays the whole ordered favorable five-prime region on the original dyadic
core and 1/2<u<=10001/20000. For the padded bin lo<=L/t<=hi, its actual
signed credit is `(996/1000*D5-1/50000)*F`, where D5 is the exact
four-cofactor three-cap integral over `orderedRegion lo hi` and
`F=exp(-(t+h)/2)*t^N/N!*max(0,-cos(y*t)-abs(y)*h)*h`.
The region has shares at least 1/100, largest share at most 1/2 and both
saturation constraints. `ZetaRieszFiveInteriorBudget` pays all disjoint
cells with ONE 1/100000 mesh allowance. Every uncovered point lies in one
of six ordering/saturation strips, together of volume at most 60*b; the
density bound 10^12 and b<=10^(-20) pay ONE more 1/100000 angular allowance.
The fixed finite grid needs M*b>=1; its starting moment is unevaluated.
All actual prime, moment, length, allocation, physical and phase conditions
are retained, as is the entire signed core complement. No zero premise.
D5 has NOT yet been compared with the optional certificate's two-dimensional
pair integral. Do not substitute 34261/250000 until that incidence/Fubini
comparison is proved. These costs multiply F; they are not source-normalized
small constants. Do not add this supply to the already spent interior-five
credit. Common phase-period aggregation, other seven bins, combined disjoint
spending, other sign/count sectors and the full joint floor remain open.
Default public source/zero-free endpoints and both top-ten lists stay fixed.

The previous eleven-module slice was committed and published as ad19357.
The user has now authorized committing and pushing the current slice after
its checks, before continuing. Include both five-prime region modules,
documentation, status and explorers. Preserve the optional cover cache;
do not rerun exhaustive verification or add it to ordinary CI. Do not use
subagents.

`ZetaRieszFiveAngularIncidence.eventually_pair_integral_core_floor` now
transfers the exact one-half pair-density integral over any measurable
subset of the unordered padded chamber into the same literal five-prime
floor, retaining 996/1000 and the existing total 1/50000 angular cost.
The six large-share relabellings have unit absolute Jacobian, preserve the
five-share denominator, and count each of the three hinge caps twice.
`half_integral_pairDensity_le` proves the comparison with the ordered
three-cap density; sorting covers ties and does not assume disjoint
preimages. Every integrability condition is discharged. No new angular
loss or discarded boundary enters. The literal corollary has explicit
17/25<=lo, lo<=L/t<=hi and all preceding mesh/core premises, with unchanged
arithmetic masks, full phase and signed complement. This is not another
supply to spend alongside the already credited five-prime population.
The remaining certificate comparison is the exact Fubini/domain identity
with its two-dimensional least-share/pair integral. Do NOT substitute
34261/250000 until that identity is proved. No full joint floor, new
zero exclusion or RH result follows. Keep optional cover inputs frozen,
public endpoints and both top-ten lists unchanged. The user authorized
committing and pushing this completed checked slice before further work;
no subagents are authorized.

`ZetaRieszFiveAngularDomain.eventually_core_capacity_floor` now completes
the certificate comparison. Its unit-Jacobian map and both justified Fubini
exchanges identify the two-dimensional certificate integral with the exact
one-half pair budget, retaining both half-open scalar fibres and every
admissibility guard. `supply_integral_le_ordered` adds no error to the
existing 996/1000 credit and total 1/50000 angular cost. The optional
`scripts/CheckRieszFiveCapacityTransfer.lean` imports the already checked
first-bin assembly and proves an actual credit of 8529739/62500000 times F.
Its terminal axiom audit uses only the three permitted standard axioms.
This constant exceeds 102/100 times the actual first-bin four-prime debit
constant 133421/1000000 by 96601/250000000. F and the adverse factor E are
still distinct: this scalar comparison is not a joint arithmetic payment.
All original masks, full phase and signed complement remain. No new
source-normalized constant, zero exclusion or RH follows. This supersedes
the earlier notes that the incidence/Fubini certificate transfer is open.
Keep both exhaustive covers optional and cached; do not rerun their
verification or import either assembly into ordinary builds/CI. The next
target is one disjoint spending ledger and common phase-period comparison,
with the other seven bins and all unselected signs/counts still open.
Do not double-spend the previous interior-five supply. The user authorized
committing and pushing this completed slice before further proof work.
No subagents are authorized; public endpoints and both top-ten lists stay
unchanged.

## Soundness invariant

The repository must remain a continuous, bottom-up Lean proof chain after
every commit.

- Do not use `sorry`, `admit`, introduce custom axioms, use compiler-trusting
  proof shortcuts, or add declarations whose purpose is to assume the missing
  mathematics.
- Do not weaken `RiemannHypothesis`, redefine a frontier quantity to make it
  trivial, hide the frontier in a typeclass or hypothesis, or report a
  conditional reduction as a proof of its premise.
- Lean's standard logical axioms `propext`, `Classical.choice`, and
  `Quot.sound` are permitted. Any other transitive axiom dependency is a
  failed gate unless the user has explicitly approved and documented it.
- Every mathematical progress claim must name a compiled theorem. Comments,
  Markdown, Python output, numerical evidence, and successful examples are
  not proof.
- A zero-proportion threshold counts as achieved only when a compiled theorem
  is stated for the literal zeta counting functions and every arithmetic or
  analytic antecedent is discharged. Generic moment models, toy measures,
  conditional implications, equivalent criteria, and method ceilings are not
  certificates and must not appear as achieved dashboard milestones.
- Decimal labels are descriptive unless Lean proves exact enclosing
  inequalities. State the exact checked constant in theorem claims.
- External research notes are leads, not trusted inputs. A pinned external
  Lean proof may be used only with attribution, license provenance, a strict
  build, and a complete transitive axiom audit; it must be labeled an external
  baseline rather than original project progress.
- Numerical and symbolic computation may explore conjectures, find constants,
  or produce exact certificates. The final theorem must check in Lean without
  trusting Python or floating-point output.
- Preserve genuine definitions and all analytic side conditions, including
  convergence, integrability, zero avoidance, multiplicity, domains, and
  limit hypotheses. Never silently totalize a singular expression and then
  reason as though the original identity held there.

The compiled project must contain no project-defined axioms. The status
generator rejects any such axiom, even when it is disconnected from a
displayed frontier theorem.

## Information-flow invariant

Treat every theorem interface as a transport decision. Before applying a
lossy operation such as a norm, absolute value, trace, determinant, scalar
integration, asymptotic limit, or channel sum, identify which phase, sign,
orientation, multiplicity, scale, correlation, and cutoff data it forgets.

- Fork, do not discard: retain the richer source object and prove the lossy
  summary as a named downstream theorem.
- Keep sign-bearing odd and even channels, completion phases, reflected-zero
  colours, and the full heat-time family available until a proved estimate
  uses their cancellation or ordering leverage.
- Prefer commuting-diagram theorems that connect the rich carrier to each
  compressed view, so later work can move back upstream without rebuilding it.
- Before investing in a compressed statistic, test whether distinct
  on-line/off-line or positive/negative configurations can share that
  statistic. If so, add a companion channel or stronger carrier first.
- Collapse information at the latest theorem where it produces a concrete
  estimate. Never replace an exact signed identity by only its triangle bound.

For the current ordinary-prime tail, the compiled all-filter obstruction in
`docs/zeta-prime-window-obstruction.md` rules out source-scale norm bounds on
every raw interval for any fixed normalized polynomial, including the actual
pole-jet filter. Its windows lie beyond both current arithmetic cutoffs.
Retain cancellation between windows or identify a centered error before
invoking interval estimates. The complementary-tail relative limit uses the
hypothetical zero's source theorem and is not an independent arithmetic bound.

The adaptive Gaussian region in `docs/zeta-gaussian-all-height.md` now has
an explicit starting height and no upper height ceiling. Its arithmetic
transport supplies a radius greater than one at every eligible center,
but its response constant may depend on that center. Do not extend the
older compact-band uniform constant to the unbounded center domain without
a new proof. The exact literature comparisons retain their plateau scope.

The refinement in `docs/zeta-gaussian-multiplicity-depth.md` keeps the
actual multiplicity in the Gaussian source. Its larger layer excludes
multiple zeros and discharges simplicity and the full eta head-current
identity there. It does not exclude simple zeros in that added layer,
enlarge the universal zero-free curve, or give separation throughout that
whole simplicity layer.
The comparison with the older simplicity width requires enlarged
logarithmic height at least 100. Keep these distinctions in status and
explorer descriptions.

The finite-group refinement in `docs/zeta-gaussian-zero-separation.md`
counts at most one zero with multiplicity in each boundary rectangle of
horizontal depth `2*d(t)` and vertical radius `d(t)/2`, at central heights
at least one million. It also isolates zeros within `(3/2)*d(t)` of either
edge from every other zero by distance greater than `d(t)/2`. Keep these
horizontal scopes separate from the larger simplicity-only layer.
The inverse-distance estimate alone controls individual factors. The
subsequent `docs/zeta-zero-filter-cost.md` controls the whole original
pole-jet filter in the right isolation layer: exact Mahler identities remove
the inverse-coordinate denominators, and a global Poisson count pays for
every factor. Its height-dependent weighted coefficient bound also controls
the exact density primitive and the finite-band reduction error. This is
not a bound for arbitrary order-dependent augmented filters or the signed
bulk. A rectangle may contain one simple zero; the same centered source
tends to minus one under that hypothesis. The independent signed prime
floor and an enlarged universal zero-free curve remain open.

The source-level audit in
`docs/signed-prime-carrier-information-audit-2026-09-12.md` records the
current carrier's correlations and exact loss points. Distinguish its
compiled identities from diagnostic mode calculations and proposed
interfaces. Keep the three Gaussian prime responses on their common
prime measure; separate finite block floors may not be added when they
each bound the same full sum. Test any growing-block improvement at the
actual dilation and source scale before treating strict positivity as
a quantitative advance.

`docs/zeta-gaussian-prime-blocks.md` now proves the complete common prime
measure, disjoint triangular-block floors and a ceiling for that whole
minorant class. It includes the stronger weighted recurrence, arbitrary
distinct prime sets and lengths, and moving coefficient families. Their
guaranteed reserve divided by unbounded dilation tends to zero. This is
not an upper bound on actual mixed prime work or a classification of every
possible recurrence. Do not extend the same triangular-minorant route in
the hope of a leading-scale gain; retain cross-prime and signed-boundary
correlations or establish a new arithmetic property instead.

`docs/zeta-gaussian-prime-correlation.md` gives the anchored Schur test on
the complete Gaussian prime measure. Retain both logarithmic ratios and
products: their average is the exact cosine energy, while the excess in
the ratio-only test is a nonnegative sine energy. The actual finite-zero
constraint retains the full squared source surplus and removes the
constant phase from the energy exactly. It is proved, but the independent
energy gap in the arithmetic floor criterion remains a premise. Do not
describe this classical matrix
transport as a proved cancellation estimate, a new region or historical
novelty. Test its complete real pair energy with all product phases and
the signed boundary mean before claiming a gain at the source scale.

`docs/zeta-gaussian-prime-reduction.md` now proves the complete remainder
reduction at the current fixed-strip dilation. Proper prime powers and
both auxiliary responses share one fixed summable majorant; an explicit
Young allowance pays every mixed term in the real energy. At reciprocal
dilation tuning, that allowance divided by the squared dilation tends to
zero for moving families of bounded nonconstant mass. The actual squared
source constraint now targets ordinary Gaussian-prime energy. Preserve
its product and ratio phases, diagonal and signed boundary mean. Do not
claim that decay of the remainder proves the ordinary-prime bound or a
new exclusion; the actual source surplus must still be positive and beat
the complete remaining energy cost.

`docs/zeta-gaussian-prime-energy-bound.md` supplies the first independent
complete-energy bound and the exact complete-prime-prefix source transport.
Its sufficient decay condition `log(abs(t)+26)/q -> 0` was not supplied
by the current dilation. The stronger argument in
`docs/zeta-gaussian-prime-energy-decay.md` now proves actual decay at that
dilation: signed Poisson differences use the already proved log-log gap
to give every positive logarithmic coefficient for the real pole-removed
Euler response, uniformly on `1 <= sigma <= 3`. The full Gaussian
response inherits the small coefficient uniformly in all `q >= 1`.
For moving nonnegative summable families of bounded mass and first
logarithmic frequency cost, normalized ordinary-prime energy tends to
zero when absolute height diverges and `log(abs(t)+26)/q` is bounded.
The current schedule has ratio at most `320000+log(13)`, so it qualifies.
The complete auxiliary cost and actual positive squared source surplus
over the original signed budget have the same normalized zero limit.
Do not continue describing that energy decay as open. The signed
boundary budget and a source-beating inequality remain open; this is
not an RH proof or a larger zero-free region. Keep the `+26` and `+2`
height smoothings distinct, the unevaluated coefficient-dependent
thresholds explicit, and the arbitrary moving finite-zero windows,
multiplicities and clipping depths in the source theorem. The complete
prime-sum bounds do not apply to sign-selected prime subsets or supply
the independent floor for the separate centered prime carrier.

`docs/zeta-gaussian-signed-budget-reduction.md` now isolates the original
signed clipped left mean. The actual right-response multiplier is bounded
by `1/(50000*q^2)`, rather than only the earlier uniform cap. The complete
budget difference has absolute value at most
`109*m+3*(m*log(abs(t)+26)+F)/(50000*q^2)` for `q>=1`, `abs(t)>=10^6`.
It vanishes after division by the current dilation, and the actual
positive squared source surplus over the left mean has a vanishing
normalized limit. Do not keep listing the non-left terms as an unresolved
source-scale cost in this regime. The original left mean, all finite
negative-depth clipping and all coefficient/frequency dependence remain.
No unclipped integral limit, source-beating left-mean bound, new region
or RH proof follows yet. The right response contains the logarithmic
completion; it must not be treated as a bounded Euler prime sum before
its inverse-square multiplier is applied.

`docs/zeta-gaussian-source-support.md` audits the source side before further
normalization. The exact nearby condition is
`(t-gamma)^2 < (beta-line(k))*(2*(1+x)-beta-line(k))` for positive shift.
The order-nine source is identically zero for `beta<=2035/2046`, at every
dilation and frequency. All currently admissible orders `k>=2` leave
`beta<=5/7` outside this source. Those are visibility cutoffs, not zero-free
boundaries. The original complex contribution is retained in the far term;
its norm estimate is the later information loss. Every fixed finite zero
window also has exactly zero source once diverging detector height leaves
its bounded ordinate range, even with arbitrary scalar reweighting. Do not
present the source-surplus limit for such a window as a contradiction: it
then controls only the negative part of the left mean. Before another decay
push, exhibit a nonzero source for the fixed hypothetical zero at the chosen
scale, or state precisely the new region being targeted. The centered
prime carrier retains such a source; its independent cofinal floor is open.
The same source-support module now supplies a constructive alternative in
the existing general strip identity. For a hypothetical zero with
`h=beta-1/2>0`, choose `sigma=1+h/4` and `eta=1/2-h/4`; the right edge is
exactly `3/2`, the left edge is `1/2+h/2`, and the zero lies strictly inside
the source ball at its own ordinate. The aligned compensated source is
strictly positive for every `B>0`. The original full signed strip inequality
is instantiated with all geometric premises discharged and every finite
`M>=0` retained. This repairs coverage, not the independent arithmetic
estimate. Do not claim the fixed-order-nine height-decay theorems apply to
this adaptive geometry without a new proof. A larger growth domain is not
needed for this construction.

The general envelope audit in `docs/zeta-prime-envelope-rate.md` also rules
out direct absolute integration of subexponential full-density errors for
every fixed normalized filter, even with the entire complex derivative
kept together. Do not report such an allowance as tending to zero at the
selected source scale. This does not bound the actual signed error or rule
out order-dependent filters with separately proved source/error control.

`docs/zeta-prime-discrepancy-work.md` now supplies exact integer Chebyshev
drift/jump and complex-weighted square identities, with all preceding prime
pairs, block boundaries and test increments. For the full factorial kernel
divided by its positive integer coordinate, the complete local forcing
diagonal is bounded by `C(p)*(4/5)^N`, uniformly over all finite index sets
and heights. Thus normalized `2*work+flux` tends to zero for every fixed
filter and `0<=u<=1`, even on moving blocks. This is a quadratic correlation
tool, not a bound for the original linear carrier. The signed squared-error
flux and its connection to a source-beating linear estimate remain open.
Do not discard its boundary or weight-variation terms, apply the monotone
real-weight bound to an oscillatory test without its hypotheses, or use the
zero-source theorem as an independent estimate. No new zero-free region or
historical novelty is claimed by this slice.

`docs/zeta-prime-lattice-carrier.md` now transports the original linear
carrier to the complete finite sum of `(lambda(n)-1)*K(s,n)`, where lambda
is the ordinary-prime logarithm. Exact first error increments connect it
to the actual integer Chebyshev recurrence without inserting an extra
discrepancy. The signed sawtooth identity keeps both unrounded endpoints;
its full sampling error is at most `C(p,y)*(4/5)^N` at positive orders.
The comparison with the original carrier adds only the old geometric
boundary cost and requires no pole-cancellation condition on the fixed
polynomial. The actual right-half-zero source remains `-m_rho`. The
independent cofinal floor for this full signed lattice sum remains open;
this does not make the separate quadratic work a bound for it. The
sampling constant may depend on the fixed ordinate and coefficient budget.

## Proof-slice workflow

`docs/zeta-vaughan-log-average.md` now evaluates the genuine logarithmic
Vaughan floor-cutoff integral, with its measurable finite cell partition,
unit probability mass and full von Mangoldt endpoint. The same convolution
identity holds for every arithmetic profile. At
`L_N=log((floor(u^(-N)/(N+1))+2)^2)`, every actual cell has square-root
product budget at most `2*(D_N+2)`, and the complete normalized average
budget independently tends to zero. The exact composite squarefree Riesz
band retains the original conditional source `-m_rho`. Completing its
prime deletion restores `log(p)*min(L,log(p))/L`; keep this correction.

For nonunit squarefree composites the full Riesz profile obeys
`R_(log(n)-L)(n)=mu(n)*R_L(n)`. Odd parity gives exact midpoint cancellation
and opposite endpoint values. This is a structural sign identity, not an
independent bound for the full signed band. The reflected cutoff depends
on `n`; replacing the common length by `log(n)/2` inside the source sum
requires a new source-error estimate. The current mixture theorem keeps
its weights independent of the tested integer. The cofinal signed floor,
RH and any further zero-free improvement remain open. No historical
novelty claim is made for these convolution identities.

`docs/zeta-squarefree-vaughan-budget.md` now keeps the physical and divisor
logarithms together before estimating the projected head. Their leading
local derivatives cancel exactly; the remaining prime incidence contains
two local Euler atoms and has a summable prime cost after averaging.
For every bounded complex divisor-weight family, the complete filtered
head has bound `C_y*sqrt(U)*sum norm(p_k)`, with no moment-order or cutoff
logarithm factor. The entire projected small part has the original
`C_y*sqrt(U+1)*sqrt(V+1)*sum norm(p_k)` budget for every cutoff pair.
Independent nonsquarefree deletion now holds for all schedules whose
normalized product budget vanishes. Every moving finite probability
mixture in `(U+1)*(V+1)<=(D_N+1)^2`, with
`D_N=floor(u^(-N)/(N+1))`, preserves the original conditional source in
the full squarefree finite band. Keep the exact weights, product phases,
unit total mass, squarefree support and budget. This does not cover
arbitrary signed mixtures, moving filters without a coefficient budget,
height-uniform constants, or the simultaneous undamped symmetric cutoff.
The exact logarithmic hyperbola average is now compiled in the subsequent
modules above; its independent signed floor remains open.
No larger zero-free region or historical novelty is claimed.

`docs/zeta-squarefree-vaughan-projection.md` now removes the entire
nonsquarefree part of the original finite Vaughan band at
`D_N=floor(u^(-N)/(N+1))`, for every fixed polynomial, `0<u<1` and
`abs(y)>1`, without a zero hypothesis. The literal squarefree projection
retains the conditional source `-m_rho`. The proof averages the full
reciprocal Euler correction at `Re(s)>=1/2` against the summable
`sum tau(d)^2*d^(-3/2)`, pays the exact coprime Mobius--prime cross term,
and separately pays the logged and finite-prime prefixes. This is decay
of the complete signed nonsquarefree sum, not its total variation. Keep
the remaining squarefree support, factor coprimality, Mobius signs and
product phases. The cofinal signed lower bound and RH remain open.
The logged projected prefix alone permits the undamped inverse-source
ceiling; do not extend that statement to the full cross term or entire
Vaughan band. No larger zero-free region or historical novelty is claimed.

`docs/zeta-vaughan-cutoff-budget.md` improves the complete classical
Vaughan reduction from a cutoff-product cost to
`C_y*sqrt(U+1)*sqrt(V+1)*sum_k norm(p_k)`. Actual Chebyshev prime-power
density pays for the entire von Mangoldt prefix without a cutoff logarithm.
For every fixed polynomial, `0<u<1` and `abs(y)>1`, both cutoffs may reach
`floor(u^(-N)/(N+1))` with normalized allowance
`C(p,y)*(u/(N+1)+u^(N+1))`, which tends to zero independently.
Every positive denominator tending to infinity is also allowed, with its
explicit reciprocal cost. General asymmetric cutoff pairs retain the
complete product budget; do not assign both factors the full asymmetric
budget separately. The new concrete cutoff eventually exceeds every
geometric cutoff with base `r>=1` and `u*r<1`, including the preceding
`floor(u^(-N/4))` cutoff. This is not an optimal-cutoff theorem and does
not justify the undamped ceiling `floor(u^(-N))`. The cofactor
`kappa_V(n)=sum_(d|n,d>V) Lambda(d)` is nonnegative, at most `log n`, and
additive on coprime products. The literal bilinear coefficient has the
original divisor-log majorant, so the existing finite-band error applies
uniformly in both cutoffs. At every hypothetical right-half zero, the
complete finite two-large-factor sum retains source `-m_rho`.
The independent cofinal signed lower bound is still open. Do not treat
the conditional negative limit as an independent estimate, call these
factors comparable in size, infer arbitrary-coefficient Type II estimates,
or discard their product phases and shared-prime terms. This is an
application of a classical identity, not a claimed novel identity or a
larger zero-free region. Constants may depend on the fixed filter and
ordinate; no moving-filter or height-uniform estimate is supplied.

The current explicit endpoint is `ZetaUnifiedZeroFree.exact_strip`, described
in `docs/zeta-unified-zero-free.md`. It retains the maximum of the earlier
signed-pole/reserve width and the two Gaussian widths at every ordinate.
The Gaussian analytic estimates still start at absolute height 1000000;
below that height their physical cap is proved strictly smaller than the
older reserve, so the combined elementary maximum needs no height premise.
Preserve both containment theorems when changing the displayed region. A
better large-height coefficient must never silently remove older coverage
at modest heights. Literal nonvanishing includes the closed right edge and
explicitly excludes the pole at one.

With L=log(abs(t)+2), the four elementary widths are
792/(7625*L-2000), min(4/39,4752/(45750*max(13/10,L)-35725)),
min(1/450000,221/(250*(L+2052*log(L)+30240))), and
min(1/40500,1547/(1800*(L+1995*log(L)+29400))). The two Gaussian
branches pay their full q>=1 and q>=9/100 costs, respectively.
`SquarefreeUnifiedRegion` transports the combined width through the full
doubled window and gives the original response radius for abs(y)>=3,
preserving every Gaussian radius and the complete signed prime envelope.
Constants may depend on the center. Keep older multiplicity, separation,
filter-cost and energy theorems at their stated widths; a new radius cannot
be silently substituted into them. The eventual log-log component retains
its original unevaluated threshold.

The active benchmark target is pointwise coverage of every applicable
region in the audited literature table, with height ranges and edge
conventions preserved. This has not been achieved: lower-height
classical/Littlewood and eventual VK gaps remain. Do not describe the
restored endpoint as unbeaten at every height, or the external proofs as
imported. `ZetaGaussianExpandedComparison.nonvanishing_and_comparison`
now extends the strict headline comparison to `(L_*,480000]`, where
`L=log(abs(t))` and `L_*` is the earlier exact crossover. The new interval
is certified, not asserted maximal. The proof pays the plus-two scale
correction and bounds the actual complete width below by `18/(25*L)`
on `[300000,480000]`. It covers the generic classical, Littlewood and VK
denominators and the full intermediate/Ford expressions there; the older
proof covers the remaining overlap down to `L_*`. The earlier exact
constant-plateau ceiling remains a separate historical theorem. The graph
must use the new checked endpoint while showing all remaining global gaps;
its default theorem stays the complete all-height proved region.

`docs/vinogradov-korobov-framework.md` records the proved signed finite
logarithmic expansion, its transport to the full weighted product sum,
actual product-shift averaging and damping transport, and the exact
all-order torus-moment/equal-frequency tuple-count identity. The
monomial instance is the literal unit-cube Vinogradov integral, and its
first moment is exactly N. Preserve the full weighted complex Gram form.
The exact remainder identity holds for every nonnegative ratio. The unit
base phase, parity sign, both factor monomials and all complex weights
survive before the perturbation estimate. `VinogradovKorobovBlock` keeps
the signed boundary and the outer base phases in the complex approximation.
Its boundary majorant uses the actual mean shifts; do not silently replace
this by the largest product or round integer endpoints. The error bound
controls the difference between actual complex prefixes and their
approximation, which transports through Abel summation.
`VinogradovKorobovDamping.feature_approximation_error_le` pays the actual
damping mass for the original `zetaPrimeFeature` at positive integer starts
and nonnegative real parts. `VinogradovShiftedMoment` now bounds every
shifted frequency-difference count by its homogeneous count and proves the
even-moment majorant for bounded complex weights. `VinogradovMomentReduction`
proves the two-Hölder reduction with exact frequency multiplicity mass and
energy. `VinogradovKorobovMoment` applies it to the actual product polynomial
at its exact real sampling coordinates. Keep the joint attainable tuple-
frequency support and the explicitly defined phase-dependent alignment
weights in `two_holder_bound` until an explicit estimate uses them; a rectangular support enlargement is a separate loss.
`VinogradovGaussianKernel` now proves genuine lattice summability,
multivariate Gaussian Poisson summation and the complete signed Gram
identity. Its dual-moment majorant pays the exact maximum exponent cost on
the attainable joint support. Gaussian majorization adds frequencies
outside that support, so retain the exact restricted `dualMoment` upstream;
the maximum cost alone does not preserve its holes or multiplicities.
`VinogradovKorobovMoment.interval_gaussian_bound` applies it to the actual
interval sum with the canonical alignment weights. A positive spatial
kernel does not make the individual complex cross terms positive. Keep
all integer translates, coordinate differences and tuple-weight products
until an explicit estimate uses them. A quantitative saving for this Gaussian
Gram form and the homogeneous mean value remains open.
`VinogradovGaussianResonance` now groups the exact signed Gram form by the
full integer power-sum difference vector. Its bounded-weight majorant uses
the homogeneous moment on each complete fibre and retains the entire joint
resonance support and every Gaussian translate. The actual interval product
sum reaches both homogeneous moments and this resonance sum in
`VinogradovKorobovMoment.interval_resonance_bound`. Keep the signed fibre
identity upstream of the norm bound; removing its weights is a documented
loss, not a proof that the actual phase correlations are irrelevant.
`VinogradovGaussianBounds` pays every translated Gaussian tail with a
uniform fractional-phase envelope and an explicit geometric denominator.
Its distance estimate works for moving phases; do not substitute a
fixed-phase asymptotic. `VinogradovGaussianCentering` preserves the complete
complex sample under an integer frequency translation by retaining the
exact unit phase twists of every original weight. The canonical interval
midpoint pays all rounding and gives at most one quarter of the origin's
Gaussian exponent cost, proved in `interval_centered_cost_le_quarter` for
positive tuple order and a nonempty interval. The actual product sum uses
this in `interval_quarter_envelope_bound`. This is a quartering of the
exponent cost, not of the whole product bound or a new zero-free width.
`VinogradovPowerSumRigidity` now evaluates Newton identities for arbitrary
integer tuples and retains repeated entries in the resulting multiset
equality. For every finite set of distinct integers, collisions at `r<=k`
are exactly permutations, giving `J_(r,k)<=r!*N^r`. At every order the
elementary bound is `min(r,k)!*N^(2*r-min(r,k))`. Both moment factors are
paid explicitly in `interval_explicit_moment_bound`, with the same quartered
Gaussian cost and complete joint resonance envelope. These are classical
base estimates, not historical novelty or the full VK saving. Do not keep
listing every homogeneous moment estimate as unproved. Keep the exact
signed centred Gram identity upstream.
`VinogradovPrimePowerRigidity` now proves the full power-sum Jacobian,
its nonsingularity for distinct residues modulo p>k, exact nonlinear
prime-power lifting, permutation rigidity and the at-most-k! complete
nonsingular fibre bound. Newton identities share one general domain proof
with the existing integer theorem. Arbitrary correlated target families
retain their actual cardinality before taking coordinate products.
`VinogradovAnisotropicCongruence` pays separate precisions e_i<=n with
p^(sum(n-e_i))*k!, and instantiates the actual degree moduli p^b,...,p^(kb)
with p^(b*k*(k-1)/2)*k!. The unsigned count is for canonical residue tuples with
distinct residues modulo p. `VinogradovSignedRigidity` now reconstructs
any complete signed moment fibre over a domain as exactly the permutations
within its two sign classes, with cardinality r+!*r-! for distinct reference
entries. `VinogradovWeightedLifting` pays all nonlinear remainders with
arbitrary integer weights nonzero modulo p. `VinogradovSignedCongruence`
retains the signs and any common integer translation at all precisions,
with correlated-target cost T.card*r+!*r-! and degree-modulus cost
p^(b*k*(k-1)/2)*r+!*r-!. `VinogradovConditionedMoment` retains the complete
binomial translation and derives the actual degree congruences when both
tail tuples lie in eta modulo p^b. Its `conditioned_block_card_le` bounds
the nonsingular residue-block projection of those original moment equations.
It does not count tail completions or the whole moment. Keep the exact
sign partition and correlated targets upstream of their product bounds.
`VinogradovCoarseCongruence` now pays the full coarse precision cost.
For 1<=k<p, a<=b, a common residue xi modulo p^a, and distinct normalized
next digits, `conditioned_residue_card_le` bounds the original canonical
tuples by p^((a+b)*k*(k-1)/2)*r+!*r-!. Full weighted translation retains
all lower degrees; integer quotient reconstruction and its injectivity
connect the normalized count back to the actual tuples. Quotient division
must occur in Nat before casting to ZMod; field division by p is not this
condition. Correlated complete targets remain upstream. The proved
colour-factorial comparison supplies the classical k! allowance, and
`conditioned_moment_card_le` gives the corresponding actual moment-block
projection. This is the coarse-conditioned congruence counting ingredient,
including a>0; do not continue listing that whole count as open. The
canonical representatives are 0,...,p^(k*b)-1 and a=b is also permitted.
These are classical ingredients, not a historical novelty claim.
`VinogradovAffineMoment` now proves exact affine invariance of complete
integer moments and the full complex homogeneous Gram coefficient.
`VinogradovResidueMoment` reconstructs the actual positive residue window,
retaining its exact quotient support before the explicit enlargement to
floor(X/q)+1. Every fixed tail target is bounded by the literal normalized
mean value J_(r,k)(floor(X/q)+1); `tail_completions_le_meanValue` applies
this to actual completions of each fixed pair of integer-weighted blocks.
`VinogradovSignedTailMoment` crosses the two variables at negative positions,
preserving the entire frequency target. `signed_weightedShift_eq_crossed`
retains every original complex pair weight through explicit conjugation.
Every fixed tail sign pattern has the same normalized completion bound.
The crossing acts on complete tuple products; additional joint constraints
within a tuple, including nonsingularity, require separate transport proofs.
Do not list all tail bounds as open. `VinogradovConditionedCompletion`
now combines the coarse count with every signed finite tail completion for
each fixed opposite block. It retains arbitrary integer coefficients on
both blocks and tails through translation, and an exact supported row sum
before its product bound. `conditioned_complete_count_le` counts canonical
block representatives in Fin(p^(k*b)), not arbitrary block integers <=X.
`VinogradovCongruenceEnergy` now retains the full complex fibre Gram form
and pays the pointwise Cauchy estimate with the actual signed fibre count.
`coarse_product_energy_le` applies it to products of actual positive
residue-window Fourier sums for every finite endpoint X. Each reversed
power-vector phase is exactly conjugated before its norm is simplified.
This is the pointwise ingredient in Wooley equation (6.5).
`VinogradovMomentPartition` now partitions the full original complex Gram
form and actual torus energy by all translated degree targets. Actual
positive tail windows discharge the complete collision condition, and
arbitrary integer coefficients and complex configuration weights survive.
`VinogradovPartitionEnergy` retains the exact coarse/fine polynomial
refinement and proves its full integral estimate with all integrability
and finite sum exchanges paid. `VinogradovResidueEnergy` then discharges
both arithmetic conditions for the original block entries: reduction modulo
p^(k*b) preserves their coarse class, normalized next digits and every signed
degree target. For 1<=k<p and a<b, `conditioned_whole_integral_le` pays the
whole original energy by the sum of its finer block-residue energies, with
cost p^((a+b)*k*(k-1)/2)*r+!*r-!. `window_whole_integral_le` applies it to all
admissible positive blocks and literal tail windows up to X, retaining
arbitrary complex weights and their correlations. Unlike the earlier
canonical block count, this whole-moment theorem includes original entries
up to X. Do not keep listing the exact target partition or this whole-moment
transfer as open. These are the ingredients underlying Wooley (6.4)--(6.6);
`VinogradovProductEnergy` now proves the actual product factorization.
Its finer-fibre bijection retains every original block entry, and
`window_fine_polynomial_eq_product` keeps arbitrary complex tail weights,
including correlations and joint restrictions between tail entries.
`conditioned_product_norm_energy_le` applies the whole-moment theorem to
those literal product factors, after the exact complex identities.
The actual finer-residue cardinality and weighted finite mean inequality
then give `conditioned_product_max_le`: the original energy is at most
r+!*r-!*p^((a+b)*k*(k-1)/2)*(p^(k*b-a))^k times the actual maximum over
canonical finer residues of integral(|f_(p^(kb))|^(2k)*|Tail|^2). No unproved
moment-budget premise remains. The full correlated tail polynomial survives,
and the exact fibre energies remain upstream of the maximum. Do not keep
listing this factorization or first finite Holder bound as open. The analytic
interpolation and higher homogeneous comparison are now proved as described
below; complete conditioning of arbitrary tuples and stronger high-moment iteration
remain open.
`VinogradovFourierEvaluation` now keeps complete complex frequency fibres
and proves point evaluation is at most attained-frequency count times the
actual energy. `ZetaRieszConditionedEnergy` applies signed congruencing
directly to the original Riesz carrier. Its full Fourier lift at zero and
exact residue partition retain the entire band, coefficient, logarithmic
phase, damping and filter. `actual_band_le_mixed_moments` bounds that literal
carrier by actual finer mixed moments with all sampling, congruence and
residue-summation costs explicit. The normalized theorem uses coarse class
zero; p^(a+1)<=2^(32*N) supplies an explicit nonsingular block and proves
the literal block count positive. The multiplied bound also covers empty
windows. Keep `amplified_moment_eq_gram` and the exact residue Gram identity
upstream of all majorants. `tendsto_actual_residue_source` retains the
original negative-multiplicity source and common length. Do not replace
the common length by log(n)/2, silently delete prime corrections, identify
the logarithmic phase with a polynomial, or treat torus energy as a free
pointwise estimate. The actual weighted mixed-moment saving after all costs
remains open. No new zero-free width follows from this bridge.
`VinogradovBlockMass` now injects every next-digit embedding and complete
higher quotient choice into the actual original block family. It gives
C>=p.descFactorial(k)*floor(X/p^(a+1))^k and the explicit real lower bound
p.descFactorial(k)*(X/(2*p^(a+1)))^k when a complete window fits.
`ZetaRieszBlockMass.actual_band_le_explicit_block_mass` uses this proved
positive mass in the original carrier bound. `VinogradovInterpolation`
proves the actual continuous Holder step (Wooley6.8), including u=1,
zero values and all Lp conditions. `ZetaRieszInterpolation` applies it to
the original weighted Riesz tail: M_eta<=H_eta^(1-1/r)*V_eta^(1/r), where
H_eta is the actual (2r+2)-moment and V_eta is the actual maximum of
integral |R_eta|^2*|f_fine|^(2kr). `actual_band_le_interpolated_moments`
retains all source weights/cutoffs and the explicit block denominator.
Do not keep listing this analytic interpolation or the block normalization
as open. The critical high-order exponent plus positive epsilon is proved below; the quantitative combined weighted-moment saving remains open. The reverse mixed moment has a squared
Riesz factor; it is not assumed controlled. No new universal zero-free width
is claimed.

`VinogradovConditionedHigherMoment` now injects the original conditioned
blocks into full signed residue tuples, preserving every power coordinate.
The count comparison precedes sign crossing; no within-block nonsingularity
invariance under crossing is assumed. Every shifted count and bounded joint
complex weight receives J_(u*k,k)(floor(X/p^b)+1), and so does the actual
higher conditioned moment. `VinogradovCongruencingStep` retains all original
block restrictions in an exact image tail weight. Its
`conditioned_congruencing_step` transfers the actual energy K_(a,b) to
J_((u+1)*k,k)(floor(X/p^b)+1)^(1-1/u) times the actual reverse mixed maximum
I_(b,k*b)^(1/u), paying the explicit signed congruence and residue-count cost.
The statement keeps independent block colours, every finite endpoint and all
rounding. This is the finite inequality underlying Wooley (2012), Lemma 6.1;
it assumes no moment budget. Do not list the higher homogeneous comparison
or this finite transfer as open. The critical high-order exponent plus positive epsilon is proved below; quantitative saving remains open
for the original weighted Riesz moments after all sampling costs. No new
zero-free width follows from this finite step.

`VinogradovConditioningSupport` now uses the joint class support of both
sides of each original collision. It selects an actual nonsingular block,
retaining its induced signs and exact complement, or covers the singular
support by literal sets of k-1 classes. Their count is choose(p,k-1).
`VinogradovResidueDigits` gives exact finer-window equivalences and full
complex polynomial refinement at p^(b+1), with the original cutoff retained.
`VinogradovSingularConditioning` identifies the actual mixed moment with its
complete original collision count and splits it exactly into singular and
nonsingular contributions. The terminal `singular_count_le_next_mixed_max`
bounds the singular contribution by choose(p,k-1)*(k-1)^(2s) times the actual
next-level mixed maximum. All finite Holder and integral hypotheses are paid;
no supplied moment budget is assumed. This closes the singular contribution
underlying Wooley (2012), equation (5.2). Do not list that contribution or its
class refinement as open. The nonsingular estimate and one-step conditioning recurrence are now
proved by the following modules; the uniform iteration and critical high-order exponent plus positive epsilon are now proved below. Neither the
original weighted Riesz saving nor any larger zero-free width follows yet.

`VinogradovSignedComplement` retains every selected position, induced sign
and exact complementary frequency; its full complex factorization precedes
the norm bound. `VinogradovNonsingularSelection` injects each qualifying
original pair into both original blocks, the actual selected block and its
full complement, and covers T2 by the actual selected-position families.
`VinogradovConditioningHolder` proves continuous Holder with zeros included
and explicit AM-GM absorption. `VinogradovNonsingularConditioning` proves
T2<=D*K_*^(1/(2u))*I^(1-1/(2u)), s=k*u, D=(2s).descFactorial(k), retaining
the sum of induced-sign moments before the maximum. Its `conditioning_step`
proves I<=2u*A*I_+ + D^(2u)*K_*, A=choose(p,k-1)*(k-1)^(2s), for nonzero
p,1<=k<=p,u>=1,eta<p^b and the original finite X. All moments and maxima
are actual; no budget is assumed. These explicit constants are not optimized.
This closes the finite step underlying Wooley (2012), Lemma 5.1. Do not list
either collision bound, this Holder step or this one-step recurrence as
open. The uniform iteration now proves the critical high-order exponent plus positive epsilon below.
The weighted Riesz moments are not identified with these unweighted moments;
their required saving and every new VK zero-free width remain unproved.

`VinogradovConditioningRemainder` now iterates the actual level maxima:
L_b<=S^H*L_(b+H)+E*sum_(h<H)S^h*Q_(b+h), preserving every finite cost.
Its remaining factor receives the two literal higher moments at
floor(X/p^a)+1 and floor(X/p^(b+H))+1. `VinogradovRemainderScaling`
retains the exact scale identity and proves the exponent inequality for
all lambda>=2k(u+1)-k(k+1)/2. `VinogradovConditioningPowerSaving` pays
the actual rounding with C=2^(k(2u+1))*k! and the iterated constant
D=2u*(k-1)^(2ku). For k>=2,u>=k,a<=b,H>=1,b-a<=2H,p^(b+H)<=X,
and (C*D)^2<=p, the actual remainder S^H*L_(b+H) is at most
(X/p^a)^k*(X/p^b)^(2ku)*p^(-H/2). The same threshold proves k<p.
`finite_conditioning_power_saving` inserts that bound into the actual
finite recurrence without any supplied moment-budget premise. Do not
list this elementary remainder saving, its constant absorption, or its
finite iteration as open. Keep the finite cutoff condition; this is not
a decay limit in H at fixed X. The general exponent transfer explicitly
requires its two homogeneous-moment bounds, which are discharged by the
final theorem only at the elementary exponent. The uniform finite profile iteration and critical high-order exponent plus positive epsilon are proved below; evaluated parameter costs remain open. No original
Riesz weighted saving, VK zeta growth or new zero-free width is claimed.

`VinogradovIteratedCongruencing` now identifies the reverse maximum with
its actual next-level conditioning maximum and feeds the full finite
remainder back into signed congruencing. `VinogradovCongruencingScaling`
retains N_(a,b)(lambda)=(X/p^a)^(lambda-2ku)*(X/p^b)^(2ku) and proves the
exact scale factor p^(-delta*(b-a)), delta=lambda-2k(u+1)+k(k+1)/2.
The original integer cost pays triangular division and truncated subtraction.
`VinogradovNormalizedIteration.allowance_scale_identity` retains the exact
finite allowance p^(-H/2)+E*sum S^h*p^(-2kuh)*Qhat_(a,b+h), with each
Qhat an actual conditioned maximum divided by its positive source scale.
The general recurrence keeps its two required actual homogeneous estimates.
`normalized_finite_iteration` supplies both at lambda0=k(2u+1), so its
actual signed K_(a,b) is at most c_colour*C^(1-1/u)*N_(a,b)(lambda0)*
p^(-k(k-1)(b-a)/2)*A_(b,kb,H)(lambda0)^(1/u). This specialized endpoint
assumes no moment budget: k>=2,u>=k,a<b,H>=1,k*b-b<=2H,p^(k*b+H)<=X,
prime p,canonical eta<p^b and (C*D)^2<=p are its explicit conditions.
The full intermediate sum remains before `conditioned_le_geometric_iteration`,
which bounds each S^h*p^(-2kuh) by D^h*p^(-(2ku-k+1)h), including D.
Do not list this finite normalization or coupling as open. The initial global
mean-value conditioning is proved below. The uniform finite profile iteration is proved below. The critical
high-moment exponent remains open; the defect factor alone does not bound
the next energies.
No original weighted Riesz saving or larger zero-free region follows yet.

`VinogradovCrossMoment` preserves complete complex correlations and proves
weighted even-moment invariance under nonzero integer frequency dilation.
`VinogradovRepeatedMoment`, `VinogradovRepeatedSolutions` and
`VinogradovInitialExceptional` absorb the actual repeated-coordinate count
using J_r>=X^r: for X>=4*k^4, the retained distinct-block count D satisfies
J_r<=2D. `VinogradovPrimePacket` supplies one common packet of R primes in
(M,2^R*M] when X^(k*(k-1))<M^R. `VinogradovInitialPrimeTransfer`,
`VinogradovInitialEnergy` and `VinogradovInitialFactor` retain the original
solutions and full complex polynomial identities before Cauchy and Holder.
`VinogradovInitialConditioning.exists_initial_conditioning` proves, for
k>=2,s>0,M>0,R>0 and those explicit size conditions, one actual prime and
residue with J_(k+s,k)(X)<=(2R)^2*p^(2s)*I_(0,1)(X;0,eta).
`VinogradovInitialIteration.exists_initial_finite_iteration` cancels the
initial residue factor exactly and gives J_((u+1)k,k)(X)<=
(2R)^2*X^(k(2u+1))*A_(0,1,H)(lambda0), retaining the full actual allowance.
Its additional conditions are u>=k,H>=1,(2^R*M)^(1+H)<=X and (C*D)^2<=M.
The packet conditions are also discharged on explicit growing power cutoffs;
no upper moment budget is assumed. Do not list the initial global entry or
its connection to the finite recurrence as open. The first independent bound on its remaining
energies is proved below. This is an unweighted mean-value result,
not a new zero-free width or a saving for the original weighted Riesz carrier.
The RH explorer includes this as a separate auxiliary endpoint while its
default frontier remains the actual carrier bound.

`VinogradovInitialSaving` now bounds the actual initial conditioned level
by the net exponent k(k-1)(u-1)/(2(u+1))>=1/3 for k,u>=2, after paying the
actual elementary quotient cost. The full depth-one allowance has an
independent p^(-1/3) saving, and global conditioning transfers it to J.
`VinogradovFirstExponent` converts that saving exactly on power cutoffs,
proves collision-preserving monotonicity, and covers every sufficiently
large endpoint by a nearby cutoff. `exists_global_first_exponent` proves,
for every k>=2,u>=k, positive C and finite X0 with
J_((u+1)k,k)(X)<=C*X^(k(2u+1)-1/(3k)) for every X>=X0. The packet/base
parameters are constructed; no homogeneous-moment estimate is assumed.
Do not list the first global exponent improvement as open. The critical
exponent, full VK growth/detector chain, quantitative original weighted
Riesz saving and additional zero-free benchmark coverage remain open.
The terminal threshold is existential; no evaluated threshold or historical
novelty is claimed. The auxiliary view retains the unweighted exponent;
the default view now applies it to the actual original carrier below.

`VinogradovImprovedNormalization` now pays all eligible padded quotient
moments at lambda1=k(2u+1)-1/(3k), with a common C>=1 and threshold N0.
Both homogeneous premises in the full mixed and signed normalized
recurrences are discharged. `ZetaRieszImprovedMoment` gives the original
Riesz band both the explicit improved two-scale bound and the complete
finite conditioning bound. Its `exists_original_band_improved_iteration`
remains the general finite-scale explorer view. Preserve all actual fibre correlations,
sampling costs, positive lower block mass and finite-depth/quotient conditions.
The exact `allowance_exponent_shift_identity` proves that after restoring
the source scale, only the deep remainder changes by (X/p^a)^(-epsilon);
every original intermediate energy is identical. The companion comparison
proves the full scaled allowance cannot increase for X>=p^a,epsilon>=0.
Do not assign that normalization factor to the intermediate sum. Its new
independent negative-profile saving comes from the finite induction below. The common constants and thresholds are unevaluated. Combined
weighted saving, evaluated parameter costs, VK growth/detector chain and
additional zero-free coverage remain open. Keep the exact comparison in
the explorer's information-audit view and document these limitations.

`VinogradovConditionedUpper` retains the exact two-scale upper bound for
both actual signed blocks. `VinogradovProfileIteration` factors the whole
intermediate sum before bounding its ratio by 1/2 with the original prime
budget; the finite sum costs at most two, with no depth-count loss.
`uniform_profile_iteration` proves q_ab<=B_n*p^(delta*a+beta_n*b) for
all original residues and both colours, with beta_0=ku and
beta_(n+1)=(k/u)*beta_n-(1-1/u)*delta. One constructed T_n pays every
actual descendant cutoff and padded quotient. No later-energy premise
remains. `VinogradovNegativeProfile` supplies the independently proved
lambda1 budget and obtains a negative profile after finitely many steps.
`VinogradovProfileSaving` caps beta at -1/2, controls the complete initial
H=1 allowance including its remainder, and cancels the initial normalization
at every real exponent. `VinogradovExponentBootstrap` pays every prime,
packet and actual quotient condition on growing cutoffs and extends to all
large original endpoints. Every proved eventual exponent lambda>critical
admits critical<mu<lambda; `exists_beyond_first_exponent` is unconditional.
Separate strict improvements do not prove the critical theorem; the uniform improvement and infimum argument below now close that gap for positive epsilon.

`ZetaRieszNegativeProfile.exists_original_band_negative_profile` retains
the initial negative profile at the first improved homogeneous exponent. At a=0,b=1 it replaces the complete
initial energy allowance by B*p^beta, -1/2<=beta<0, with every homogeneous
and descendant-energy premise discharged. Its actual conditions retain
prime p, p^S<=X, the deepest padded quotient >=N0 and the prime budget.
The original signed complex fibre correlations, sampling costs, source
normalization and positive block mass remain. Their combined source-scale
saving is still open. Constants, depth, negative exponent and terminal
thresholds are unevaluated; no historical novelty, critical mean-value
estimate, VK growth, wider zero-free region or RH proof is claimed.
Keep the general recurrence as its own explorer view and preserve the exact
exponent audit: normalization alone still changes only the deep remainder.
Continue local theorem work during exact-SHA CI and report both statuses
separately; keep published source checks pinned to the committed snapshot.

`VinogradovUniformProfile` now chooses the same finite depth before the
actual source exponent, homogeneous constant or quotient threshold, for
every fixed lower defect. `VinogradovUniformSaving` pays the full initial
allowance and original prime packet uniformly. `VinogradovUniformExponent`
proves one epsilon>0 improves EVERY proved exponent above a fixed positive
defect. `VinogradovCriticalExponent.exists_global_critical_exponent` closes
the infimum argument and proves, for every k>=2,u>=k,eps>0, actual
J_((u+1)k,k)(X)<=C*X^(2k(u+1)-k(k+1)/2+eps) for all X>=X0, with
positive C and finite X0. No analytic moment budget remains as a premise.
Do not list this critical high-order exponent with positive epsilon or its
uniform iteration/infimum argument as open. It does not assert eps=0 or
all smaller moment orders. Degree/order/epsilon dependence of constants
and thresholds is unevaluated and still needs quantitative control.

`VinogradovCriticalNormalization` supplies all eligible actual padded
quotients. `ZetaRieszCriticalProfile.exists_original_band_critical_profile`
is now the default RH explorer endpoint: the original a=0,b=1 carrier
uses critical+eps and its independently bounded negative initial profile,
retaining every original complex correlation, sampling and mass cost.
`VinogradovCriticalKorobov.exists_critical_product_bound` inserts both
critical moments into the actual Korobov product sum. Its frequency
embedding preserves original collisions; a finite positive subset B uses
its CONTAINING INTERVAL length Y, never an assumed cardinality-only critical
bound. Preserve original B, exact coefficients, attainable support,
quartered Gaussian cost and whole joint resonance envelope. The fixed-degree joint resonance and Dirichlet saving described below are
proved. Uniform quantitative moment costs, all-scale zeta growth, new
zero-free coverage and the combined signed Riesz saving remain open. No historical novelty is
claimed for this formalization. Keep these scope limits in the explorer.

The ten Accomplishments consolidate the reproduced Anthropic baseline with
its improved 67.31% entry, making room for the broadly applicable critical
high-moment theorem. Preserve the baseline attribution and verification
links; keep both Accomplishments and Notable Formalisations at ten entries.

`VinogradovFibreCorrelation` now retains the exact complex average of the
original configuration weights on each full frequency fibre. Its exact
polynomial and energy identities precede the bound E_w<=chi^2*E_1 on the
identical configuration family; chi is the actual largest fibre-average
norm, not a supplied budget. It is at most any coefficient envelope, but
keep the complex averages upstream to preserve cancellation. Empty fibres
and empty families are covered. `ZetaRieszConditioningTransfer` identifies
E_1 with the literal signed-block/full-residue mixed moment, then applies
the proved finite conditioning bound to the original Riesz band. Its
`actual_band_le_conditioned_iteration` pays the actual attained-frequency
cost, residue Holder factor and positive floor block mass, retaining
p^(-H/2) and the full sum of normalized conditioned levels at lambda0.
The geometric endpoint retains every intermediate level and its per-step
constant. Both require k>=2,u>=k,a<=b,H>=1,b-a<=2H,p^(b+H)<=2^(32*N),
nonzero p and (C*D)^2<=p; the same budget proves k<p and block positivity.
No missing weighted-moment estimate is assumed. Do not list this direct
finite Riesz-to-conditioning transfer as open. A net saving in its actual
correlations and conditioned levels after all costs remains unproved,
as do quantitative parameter bounds, VK growth and a larger region.
Do not infer a pointwise comparison of oscillating polynomials from the
integrated fibre comparison, or send H to infinity at a fixed cutoff.

Moment bounds at smaller orders, evaluated degree-dependent moment costs,
uniform all-scale zeta growth and the VK zero-free region remain unproved
here. The fixed-degree exponential-sum saving and Gaussian constants are
proved below; do not list those as open. Do not add a VK curve to the proved union or promote a
conditional transfer as that analytic proof. The independent cofinal signed
arithmetic floor and RH remain open. Numerical verification stays in its
optional target; do not edit its fingerprinted inputs during a live run.

The Gaussian resonance continuation is now proved through the full degree
window and original Dirichlet blocks. `VinogradovDegreeWindow` and
`VinogradovFullResonance` give the exact full-window gain m*(m-1),
m=k-floor(2k/3). `VinogradovFullPowerSaving` gives the literal product sum
saving 1/(64*k^2) for k>=12 at t=M^(2k),z=M^4. The original k>=4 theorem
with saving 1/(2r^2), r=k(k+1), remains available.
`VinogradovPhaseRectangle`, `VinogradovRectangleResonance` and
`VinogradovRectanglePowerSaving` extend the actual product saving to
1/(128*k^2), uniformly for M^(2k-2)<=t<=M^(2k),M^4<=z<=4*M^4,
all B subset[1,M] and every sufficiently large M at each fixed k>=12.
The exact rectangle degree gain is (m-1)*(m-2). Both critical+1/2 moments,
full Gaussian tails, smoothing and the entire Taylor error are paid.
`VinogradovDirichletSaving.exists_partial_dirichlet_saving` gives the
literal original Dirichlet block, for L<=2*M^4 and M^4<=z<=2*M^4, the
bound C*L*M^(-1/(128*k^2))+2*M^2 throughout that same height interval.
Its `exists_dirichlet_block_saving` gives C*M^(4-1/(128*k^2)) at L=M^4.
The signed averaging identity survives upstream; the endpoint norm bound
is an explicitly named downstream relaxation, with its full mass paid.
`VinogradovDampedSaving` now transports the partial-block saving through
all nonnegative decreasing weights. The linear term pays the actual total
weight and the constant endpoint term only the initial weight. Its
`exists_feature_block_saving` applies to the literal zeta coefficients at
every nonnegative real part, integer start M^4<=a<=2*M^4, and N+1<=2*M^4.
The original complex Abel identity remains upstream. Do not infer a bound
for additional prime/sieve or oscillating weights from this damping theorem.
`VinogradovRectangleResonance.actual_resonance_le_explicit` exposes the
previously constructed constant; retain its existing existential wrapper.
`VinogradovGaussianCost` bounds the full actual joint resonance plus
support exponential by 2^(9*k^2)*M^(dimension-S'). Its actual moment-root
constant is at most two uniformly for k>=12. These are genuine all-tail
bounds; homogeneous moment constants and thresholds remain separate.
Constants and starting thresholds are unevaluated for each fixed degree.
Do not promote these fixed-degree bounds to uniform all-scale zeta growth
or a VK zero-free region. Quantitative degree costs and the all-scale
analytic transport remain open. No new zero-free region or combined
Riesz signed saving follows yet. Keep the Riesz critical profile as the
RH explorer default; show the actual damped-zeta-block theorem and uniform Gaussian costs in its
critical-moments view and Latest Update. See
`docs/vinogradov-gaussian-power-saving.md`. Enrich the existing Vinogradov
entries in both ten-entry README lists; do not add entries or trigger
exhaustive certificate verification.

`VinogradovDefectRemainder.deep_remainder_preserving_defect` retains the
actual exponent-defect contribution -delta*u/(u+1)*(b-a+H) alongside
-H/2 and the original constant C, under D^2<=p. The named coarse theorem
in `VinogradovConstantPreservation` is now a downstream relaxation of this
stronger result. Its complete actual allowance and Holder identities keep
C linear; no C-dependent prime threshold is needed in the new chain.
`VinogradovLinearProfile` proves the actual profile multiplier is at most
(k!)^2*(1+2*selectionCost)^(2/u) <= (2ku)^(7k), independently of the
finite iteration count. Descendant depth T remains unevaluated.
`VinogradovLinearSaving` transports C linearly through the actual initial
allowance and prime packet. `VinogradovLinearExponent` chooses one positive
decrement and multiplier before the source exponent and C, covering every
positive integer endpoint. `VinogradovFiniteCritical.exists_finite_critical_iteration`
starts from the proved elementary bound and reaches critical+defect for
every positive defect, with exact accumulated cost A^n*k! and no analytic
moment premise. Do not list this finite, all-endpoint descent as open.
The numerical degree dependence of the global A, decrement and stopping
count remains open. The stronger defect saving is retained upstream, but
the present profile/global allowance still uses its named half-depth
relaxation and clips the initial exponent at -1/2. Do not claim those
losses have been removed downstream. Quantify cutoff/prime-packet costs
before inferring uniform zeta growth, a VK region or a new universal width.
The Riesz critical profile remains the default RH explorer endpoint; expose
the finite descent and explicit profile costs in its critical-moments view
and Latest Update. See `docs/vinogradov-linear-constants.md`.

The local quantitative continuation now exposes actual descendant depth.
`VinogradovLinearProfile.bounded_depth_profile_iteration` gives `(k+d)^n`
when `d>=k` and every earlier profile satisfies `-d/2<=defect+k*beta_j`.
`VinogradovQuantitativeProfile` specializes to u=k,k>=4,defect=1/2:
`n=2*k*(k+1)+4`, `T=(3*k)^n`, profile multiplier at most `(2*k*k)^(7*k)`.
The complete initial allowance is at most
`C*(1+selectionCost*(2*k*k)^(7*k))*p^(-1/2)`; its
`half_defect_global_bound` transfers this through the original prime packet.
The actual quotient moment budgets, packet inequality, size/depth and prime
thresholds remain explicit hypotheses. Do not claim a new unconditional
quantitative critical moment, degree-uniform zeta estimate or zero-free
region. The old unconditional finite descent remains available but its
all-endpoint constant is unevaluated. This explicit depth is an admissible
proof cost, not an optimality or impossibility theorem. The relative-defect
continuation below uses the quadratic resonance margin and pays its global
costs. Work locally without commits or pushes until the user changes that
instruction; the previously published harmonic Type-II no-go remains intact.

The relative-defect continuation is now unconditional at its terminal bounds.
`VinogradovRelativeProfile` uses defect k^2/q and 2*q steps with polynomial
depth `(k+2*k^3)^(2*q)` for fixed q. `VinogradovQuantitativeDescent` specifies
the packet, rounding, small-endpoint and accumulated iteration costs.
Its `relative_moment_bound` proves the actual J_{k(k+1),k} bound at every
X>=1 for k>=4 and 1<=q<=k^2, with the defined `momentMultiplier` and no
supplied moment estimate. `VinogradovRelativeResonance` pays both q=128
allowances and retains inverse-square saving 1/(256*k^2).
`VinogradovQuantitativeDirichlet.feature_block_bound` reaches the literal
damped zeta coefficients; all coefficients are defined, and M>=k*(k+1)
is the starting scale. Do not keep listing these particular coefficients or
cutoffs as existential. The stronger 1/(128*k^2) chain remains separately
available with existential costs.
The compiled `packet_square_power_le_momentMultiplier` audits our chosen
allowance as at least 2^(packetDepth^2). This is not a lower bound on J or an
impossibility theorem for sharper proofs. These oversized costs do not close
uniform VK growth, all-scale analytic transport or a new zero-free region.
The next literature target is the actual polynomial-system conditioning and
differencing inequalities behind the s->s+k step in Bellotti Section 2 /
Ford Section 3, including endpoint costs; a scalar recurrence alone is not
that proof. See `docs/vinogradov-quantitative-descent.md`. Keep the default RH
carrier, proved union and both ten-entry README lists unchanged. Continue
local validation and amortize publication gates; no commits or pushes.

The polynomial-system continuation is now in `VinogradovPolynomialRigidity`
and `VinogradovPolynomialSystems`. Weighted triangular equations preserve
all power-sum collisions, even over prime-power residue rings when the
leading coefficients are regular. `HasType` indexes only the active m=k-d
polynomials; retain the first d monomial-tail constraints in any future
mixed-count definition. Literal finite differences give type (d+1,hT),
and the first linear difference is proved constant. For p>max(k,2), p not
dividing T, `type_integer_congruence_card_le` proves the actual distinct-
residue polynomial count at degree moduli with factor
m!*p^((r-d)*(r-d-1)/2), using natural truncated subtraction. All leading-unit
and missing-precision costs are proved. This is the modular ingredient
inside K-to-L conditioning; the next paragraph records the integral
differencing step now proved separately.
The polynomial-row transformation differs from common input translation;
its checked transport is recorded below. See `docs/vinogradov-polynomial-systems.md`.

The quantitative L-to-next-K integral step is now proved in
`VinogradovMixedMoments`, `VinogradovDifferenceEnergy`,
`VinogradovMixedDifferencing` and `VinogradovPolynomialDifferencing`.
The complete mixed moment is its full-frequency tuple count; bounded
boundary masks are paid at the even moment before interpolation. The
literal residue energy is P plus twice the signed positive-shift overlaps.
For M>=2 and q<=P, `exists_difference_bound` selects one fixed h in
1..floor(P/q) and proves L<=max((2*M*P)^M*J,
2*(2*floor(P/q))^M*K_h^(M/(2*(M-1)))*J^((M-2)/(2*(M-1)))).
Finite Holder precedes integration and maximum selection. The diagonal
case P<q is exact. `exists_typed_difference_bound` identifies the selected
next type (d+1,T'), T'=(h*q)*T, T<=T'<=P*T. Constant-phase removal keeps
every original tail coordinate in the same ambient torus. No boundary
completion or mixed-moment estimate is assumed. The following nonsingular
conditioning stage now supplies an actual count-to-integral bound.
Do not claim a smaller final moment coefficient or new region from this
step. Continue locally without commits, pushes or subagents.

`VinogradovColourProducts`, `VinogradovPolynomialConditioning` and
`VinogradovPolynomialNonsingular` now prove the actual nonsingular count
bound S_ns<=m!*p^((r-d)*(r-d-1)/2)*L for a prime-dilated monomial tail.
Full tuple colours, original endpoints and all d+m tail equations are
retained; every required tail divisibility is proved. This is the last
nonsingular stage after tail dilation, not the full original K count.
`VinogradovNonsingularDescent.exists_nonsingular_descent` composes it with
the quantitative difference bound and identifies the full tail moment
with ordinary J_{s,d+m}(Q). Its next type, fixed displacement and every
numerical cost are explicit. The separate existing
`VinogradovNonsingularConditioning` module must remain intact.
`VinogradovLowDegreeTail.exists_tail_class_bound` also proves the original
nonsingular count is <=d!*p^(2s-d) times one fixed tail residue-class count
at unchanged endpoints. The first d integer equations cancel the original
nonzero dilation before prime reduction, with no p/q coprimality premise.
Newton rigidity includes repeated residues, and finite Holder is applied
before selecting the largest class integral. The possible extra endpoint
is paid by the following continuation.

`VinogradovEndpointDeletion.mixedMoment_succ_le` proves K(N+1)<=2*K(N)
for the literal mixed count when N>=16*s^2 and s>=1, using its actual
diagonal tail reserve and two-term weighted Holder.
`VinogradovResidueEndpoint.exists_floor_tail_bound` applies the original
quotient injection and pays its extra endpoint, reaching floor(Q/p) with
factor 2*d!*p^(2s-d). The usual p<=2*M,32*s^2*M<=Q packet conditions
discharge the floor threshold. `VinogradovBinomialRows.hasType_rowSystem`
proves exact type preservation for the full binomial row operator.
`VinogradovRowTransport.shifted_count_eq` preserves the literal solution
count, including every low-degree and constant equation. For the actual
tail q*(p*x+xi-p), its row shift is q*(p-xi), retaining the original q.

`VinogradovPolynomialConditionedDescent.exists_conditioning` now proves
S_3(p)<=2*d!*m!*p^(2s-d+(r-d)*(r-d-1)/2)*L(P,floor(Q/p);Phi;p,q,r).
Its `exists_descent` takes this original nonsingular count all the way to
an attained next polynomial type, with the same explicit differencing
alternative and T<=T'<=P*T. There is no supplied analytic estimate or
unpaid tail endpoint in this chain. The left side of that theorem still
requires blocks distinct modulo the given eligible prime. The following
continuation now supplies the unrestricted entry point.

`VinogradovTypeMaximum.exists_maximizer` constructs an attained maximum
of the actual natural-number mixed counts over every coefficient system
and binary exponent of the fixed type. Doubling only the polynomial block
stays in this family while retaining the identical original tail.
`VinogradovMixedRepeated.repeated_integral_le` proves the three-factor
Holder bound K(F)^(1-1/m)*K(2F)^(1/(2m))*J^(1/(2m)); no mixed-moment
partial-dilation invariance is assumed. `VinogradovMixedExceptional`
compresses literal repetitions, counts unordered position pairs on both
blocks and proves K<=2*S_1 at the maximizing system for m>=2,P>=4*m^4.
Its exact diagonal reserve also covers zero moments and equality at the
threshold. `VinogradovPolynomialExceptional.exists_count_reduction`
therefore bounds every original type count by twice a distinct-block
count of an attained system of the same type, tail and endpoints.

`VinogradovTwoBlockPacket` retains T times the unordered separation
products of both blocks, with budget P^(d+2*choose(m,2)). The constructed
R-prime Bertrand packet lies in (M,2^R*M], not (M,2M].
`VinogradovPolynomialPrimeTransfer.exists_prime_carrying_count` selects
one fixed prime avoiding T and separating both blocks, and proves
K(F)<=2*R*S_3(p,G). `VinogradovUnrestrictedConditioning.exists_conditioning`
joins all preceding steps into the full unrestricted K-to-L bound with
coefficient 4*R*d!*m!*p^(2s-d+(r-d)*(r-d-1)/2). The explicit hypotheses
include P>=4*m^4,0<T<=P^d,d+m<=M, the strict packet budget
P^(d+2*choose(m,2))<M^R and 16*s^2*(2^R*M)<=Q. The exact fixed tail,
its original q, and floor(Q/p) are retained. No moment estimate is supplied.

The direct diagonal continuation now closes a controlled s->s+k
iteration. `VinogradovDiagonalMoment.exists_diagonal_moment_step` uses
the literal integer k-th root to force P<p^k, so the exact diagonal
L=P^k*J identity removes the maximizing polynomial system. The actual
moment defect contracts by 1-1/k. `VinogradovDiagonalThreshold` pays
every small endpoint with the independent maximum max(H^S,D*C), not a
new factor H^S at every iteration. `VinogradovDiagonalIteration` starts
from the proved diagonal k-th moment and reaches defect <=k^2/256 after
7k steps. `VinogradovDiagonalCost.explicit_relative_moment_bound` proves
J_{(7k+1)k,k}(P)<=2^(18*k^6)*P^(2*(7k+1)*k-k*(k+1)/2+k^2/256)
for every k>=2 and positive integer P, with no moment premise. Keep its
actual tuple order (7k+1)k; the old Gaussian/Dirichlet transport fixes
k(k+1) and cannot silently inherit this coefficient. See
`docs/vinogradov-diagonal-descent.md`.

The fixed-width continuation is now proved. `VinogradovShortPacket`
uses the existing Suzuki bound psi-theta<=18*sqrt and actual Chebyshev
estimates to construct exactly R primes in (M,8M] when M>=4096 and
M>=9*R^2. The generic `exists_conditioning_of_packet` retains actual
cardinality, upper endpoint and the complete two-block prime-product
budget. With R=2*k^3, `VinogradovNarrowThreshold` pays every root-scale
condition polynomially. `VinogradovNarrowCost.explicit_relative_moment_bound`
proves the same actual moment and defect with coefficient
(2^62*k^6)^(k^3), including all positive endpoints. Both moment coefficients
and the whole Gaussian factor fit below 2^(2*r^2) for r=(7k+1)k.
`VinogradovNarrowResonance.polynomial_bound` therefore has coefficient two
and saving 1/(8192*k^2), at that actual tuple order. The original
`VinogradovNarrowDirichlet.block_bound` has coefficient five:
|sum_(n<M^4)(z+n)^(-it)|<=5*M^(4-1/(8192*k^2)), for k>=12,
M>=(7k+1)k, M^(2k-2)<=t<=M^(2k) and M^4<=z<=2*M^4.
Its partial-block bound is 3*ell*M^(-1/(8192*k^2))+2*M^2; the weighted
bound retains actual mass and charges the boundary to the initial weight.
`feature_block_bound` applies to literal damped zeta terms at every
nonnegative real part. No moment premise or unevaluated degree coefficient
remains in those theorems. See `docs/vinogradov-narrow-packet.md`.

The all-scale continuation is now proved. `VinogradovDyadic` bounds the
actual block on [X,2X) by
6*X^(1-sigma-1/(32768*k^2))+2*X^(1/2-sigma), paying integer fourth-root
rounding and the complete damping boundary. `VinogradovScaleSelection`
constructs k and M in every middle block for n>=12 and
t>=T_n=(16*(2*n+1)^2)^(2*n), with 12<=k<=2*n+1 and every original
moment-order, root and time-rectangle condition discharged. The actual
small blocks pay their damped mass; sixth- and fourth-derivative profiles
pay both terms on every remaining scale through 4*t.
`VinogradovNearOneBudget.canonical_block_bound` therefore pays every
block in the literal eta reconstruction. With
Delta_n=1/(65536*(2*n+1)^2) and a_n=2*Delta_n/n,
`ZetaVinogradovBound.bound_abs` proves
|zeta(1-Delta_n+i*t)|<=32768*|t|^a_n*log|t|/Delta_n for |t|>=T_n.
`bound_strip_abs` covers 1-Delta_n<=sigma<1 with denominator 1-sigma.
`bound_band_abs` proves exponent <=12288*(1-sigma)^(3/2) on each
adjacent band 1-Delta_n<=sigma<=1-Delta_(n+1). Both signs of height,
both eta prefixes, the endpoint, the infinite tail and the division
cost are proved. `ZetaVinogradovEulerBound` then uses the existing direct
Euler reconstruction on the same actual prefix to remove that entire
1/(1-sigma) cost. Its coefficient is 8192, and `bound_strip_abs` covers
the closed strip through sigma=1. `bound_band_abs` retains the same
three-halves displacement exponent with no eta denominator. Keep the
explicit band-dependent height threshold. See
`docs/vinogradov-near-one-growth.md`.

The complete VK zero detector and its joint height schedule are now proved.
`ZetaEulerRightStrip` supplies the actual right-of-one bound;
`ZetaVinogradovLocalDisc` covers the whole analytic disc above T_n+1.
`ZetaVinogradovCanonical` retains the full divisor and its controlled
analytic residual. `ZetaVinogradovSignedBudget` pays the three-height
prime inequality with multiplicity and radial correction. The explicit
reserve in `ZetaVinogradovMargin` gives actual nonvanishing at width
Delta_n/(4096*Q_n), without an analytic or arithmetic premise.
`VinogradovHeightSchedule` chooses floor((L/log L)^(1/3)) and pays the
original degree-dependent threshold on that same moving schedule.
`ZetaVinogradovScheduledMargin` gives Q_n<=8*log L eventually and pays
the complete radius cost. `ZetaVinogradovZeroFree` therefore proves
both zero-strip edges and literal closed-edge nonvanishing at width
1/(19327352832*L^(2/3)*(log L)^(1/3)), L=log(abs(t)+2), above a finite
unevaluated height. Its union keeps all existing explicit and eventual
components. Every fixed earlier log-log coefficient is eventually
strictly narrower, with no evaluated crossover. Do not call adaptive
coverage or the classical-power zero detector open. The coefficient is
conservative; benchmark constants and finite threshold evaluation remain
open. See `docs/vinogradov-zero-free.md`. Keep the plotted finite-height
region unchanged until a starting height for the new curve is proved;
never draw an eventual component from an invented finite threshold.
The signed angular improvement is now proved in
`ZetaVinogradovAngularZeroFree`. The full radius Delta_n is available;
`ZetaVinogradovAngularBound` uses the exact signed boundary moment and
costs 2*A/(pi*Delta_n), retaining the full selected multiplicity and radial
correction. `VinogradovScaledSchedule` chooses
floor((L/log L)^(1/3)/64), paying the original threshold. On that same
natural degree, `ZetaVinogradovBalancedBudget.cost_tendsto` proves the
entire contradiction cost tends to 98560*C/(3*pi), including the
leading Euler-center allowance 2/3. Actual zero exclusion and closed-edge
nonvanishing follow for every 0<C<3*pi/98560; C=1/11000 is checked.
`millionfold_improvement` compares that member with the earlier fixed VK
component, not with the full union at every height. The union keeps every
previous component, including the older VK width for arbitrarily small C.
For C>=1/11000, `exists_eventual_union_compact` proves the README formula.
The threshold remains finite and unevaluated. Keep the explicit plot
unchanged. Do not call the degree schedule or signed angular payment open;
the next major quantitative target is the actual moment-to-growth saving,
followed by benchmark constants and finite starting-height evaluation.
No world record, fixed-height arithmetic floor or RH conclusion follows.

The shorter-moment continuation now gives the stronger actual endpoint
`ZetaVinogradovSharperZeroFree`. `VinogradovExponentialDefect` retains the
literal defect and proves its exponential decay. `VinogradovShortMoment`
pays orders (3k+1)k and (4k+1)k with defects k^2/40 and k^2/100,
coefficient (2^41*k^6)^(k^3), and every positive endpoint. Both moment
coefficients and the variable-order Gaussian cost fit the true root with
multiplier two. `VinogradovShortDirichlet.block_bound` has coefficient five
and saving 1/(512*k^2) for k>=48, or 1/(1600*k^2) for 12<=k<48,
with M>=(4k+1)k and the original time rectangle. All dyadic scales,
including the low-degree range, are paid. `ZetaVinogradovSharperBound`
proves coefficient 8192, Delta_n=1/(4096*(2*n+1)^2), a_n=2*Delta_n/n
on the full closed strip for n>=48 above the original explicit T_n.
At a fixed index the strip is sixteen times wider; its growth exponent
also increases. Do not describe the width improvement as preserving that
exponent. Adjacent bands have exponent at most 3072*(1-sigma)^(3/2).
The generic `ZetaAngularDiscBudget` retains its explicit disc hypotheses;
`ZetaVinogradovSharperCost.margin_of_budget` discharges both for actual zeta.
The natural degree floor((L/log L)^(1/3)/32) pays the original height,
gives normalized radius 1/16, profile cost five and Euler-center cost 2/3.
The complete signed cost tends to 38080*C/(3*pi). Actual zero exclusion
and closed-edge nonvanishing hold for 0<C<3*pi/38080, including 1/4500.
`coefficient_gain` proves a ceiling increase of exactly 44/17, and
`previous_limit_lt_rational` places the earlier signed ceiling below 1/4500.
The complete union retains previous coverage; its compact formula holds
for C>=1/4500. Update the README and VK explorer to this endpoint, while
keeping the all-height explicit plot and default endpoint unchanged until
a finite starting height is proved. The threshold is still unevaluated.
The next quantitative target is stronger incomplete-system moment and
block estimates toward published benchmark constants; the fixed-height
Riesz floor, harmonic Type-II estimate, RH and world-record goal remain open.

The retained scale-profile continuation now proves the stronger endpoint
`ZetaVinogradovCubicZeroFree`. `VinogradovCubicSaving.degree_log_bound`
keeps k*log(X)<=9*log(t)/4 at every actual high-degree block.
`power_le_cubic_profile` retains the unmaximized exponent
Delta*v-v^3/10368, v=log(X)/log(t); `cubic_le` bounds its full maximum by
40*Delta*sqrt(Delta). The original lower-degree range, damping boundary,
long-block profiles and expanded small-block range are all paid in
`VinogradovCubicBudget`. `growth_lt_previous` proves the new exponent
is less than 5/32 of its predecessor at a fixed strip displacement.
The actual closed-strip zeta bound has coefficient 8192 and exponent
40*Delta_n^(3/2) for n>=48, but now requires T_(8n), not T_n.
Keep this larger starting threshold with every growth claim. The older
bound remains proved at its earlier height. Adjacent bands have coefficient
320. The natural degree floor((L/log L)^(1/3)/64) pays T_(8n)+1,
with normalized radius 1/4, profile cost six and Euler-center cost 2/3.
`ZetaVinogradovCubicCost.cost_tendsto` proves the complete signed cost
limit 11200*C/(3*pi). Every 0<C<3*pi/11200 gives actual nonvanishing
and both zero-strip edges; 1/1250 is checked. `coefficient_gain` proves
an exact 17/5 ceiling increase over the preceding shorter-moment family.
The compact union holds for C>=1/1250, retains previous coverage, and
keeps its finite unevaluated threshold. This is the predecessor of the
summed endpoint below. See `docs/vinogradov-cubic-profile.md`.

The complete scale summation now proves `ZetaVinogradovSummedZeroFree`.
`VinogradovCubicDecay.block_bound` retains -v^3/2097152 on every actual
dyadic block, including small and lower-degree blocks and both terms of
each long derivative profile. `VinogradovCubicSummation.sum_le` proves
the full cubic tail is at most 1024*L^(2/3), by Gaussian comparison.
Actual zeta is bounded by 1048576*|t|^(40*Delta_n^(3/2))*log(|t|)^(2/3)
on 1-Delta_n<=Re(s)<=3/2 above the unchanged T_(8n), for n>=48.
The larger absolute constant and sharper logarithmic exponent must both
be stated. Both complete analytic profiles have normalized limit 17/3;
the unchanged Euler-center allowance raises this to 19/3. The actual
signed cost tends to 10640*C/(3*pi). The proved family is now
0<C<3*pi/10640, including 1/1150, with an exact 20/19 coefficient-ceiling
gain. The compact union holds for C>=1/1150. Use this endpoint in the
README and VK explorer; retain the explicit all-height plot and default
endpoint because the eventual starting height remains unevaluated.
Stronger incomplete-system moments, asymmetric block estimates, published
leading constants and finite starting heights remain open. This does not
discharge the independent fixed-height Riesz floor or harmonic Type-II
premise. No world-record claim is justified. See
`docs/vinogradov-cubic-summation.md`. Continue locally without commits,
pushes or subagents.

On 2026-09-23 the user reaffirmed the priority: directly formalize the
published zero-free arguments and reproduce their constants and height
domains before optimizing our variant. Follow
`docs/vinogradov-literature-reproduction.md`; a weaker constant or a width
comparison is not reproduction. `VinogradovLiteratureStep` proves the
literal next-type count transport, Ford 3.3'/Bellotti 2.2 for integer
endpoints including the diagonal case, the paper's conditioning coefficient,
and their composition for an explicit prime packet. The `k^3` packet's
discriminant product budget is proved from P<=M^(k+1) for natural and real
M, but existence in the required short interval remains open.
`VinogradovResidueMonotone` proves tail-endpoint monotonicity at cost one
by injecting actual counts. `VinogradovLiteratureIteration` now proves
the finite backward induction from the exact diagonal case all the way
to the literal J_(s+k),k(P), retaining the exact conditioning exponent
2s-d+(r-d)(r-d-1)/2. Its explicit allowance is conditional on actual
packets, size conditions and ordinary source-moment bounds; it assumes
no intermediate mixed estimate. The checked
`published_scale_balance` exposes a positive residual
d(d-1)*phi_(d+1)/(4(k-d)) for d>=2 under the current normalization.
Do not silently cancel it or claim that it disproves the published final
bound. The original Ford 3.4 / Bellotti 2.4 recurrence now gives a verified
continuation: `VinogradovFordScales.scale_balance_nonpos` pays the whole
shrinking-tuple exponent under the published depth restriction.
`VinogradovPowerConditioning` retains p^e*floor(Q/p)^lambda before using
the packet width, reducing its exponent to e-lambda.
`VinogradovFordStep.backward_power_step` applies this to the actual mixed
count, and `VinogradovFordIteration.moment_power_bound` carries the finite
diagonal-based induction through to the literal homogeneous moment. The
updated defect is exactly Ford's original formula; the full explicit
coefficient recursion is independent of P,Q. Actual short packets, source
moment bounds and the explicit minimum-tail conditions remain premises.
`VinogradovFordCoefficient.full_coefficient_bound` now proves the complete
coefficient at most k^(3k)*eta^(4s+k^2). It derives lambda>=s from the
literal diagonal moment count; that reserve is not an extra arithmetic
premise. `VinogradovFordMoment.published_moment_bound` inserts the exact
coefficient into the homogeneous moment. `VinogradovFordTailThreshold`
proves the recursive minimum costs only one factor 16*s^2 times all
packet endpoints. V>=64*k^3 and eta^10<=64 pay this complete product at
the stated P>=V^(k+1), using the original j<=9*r/10 depth restriction.
`published_height_bound` therefore removes the separate tail-size and
repeated-tuple threshold premises. `VinogradovFordSchedule` now constructs
the backward scales and pays both bounds using Ford 3.5's stationary
phi-star criterion. `VinogradovFordParameters.moment_bound_of_packets`
constructs floor cutoffs and proves all remaining degree, product-budget,
root and strict terminal diagonal conditions, retaining exact-root cases.
`VinogradovFordGlobalStep.all_endpoint_bound` also covers small endpoints
with the published maximum coefficient; defect decrease is proved.
`VinogradovFordMomentSequence.iterated_moment_bound` repeats the original
recurrence from the proved diagonal moment at all positive endpoints,
with no source or intermediate moment estimate left as a premise.
`ShortPrimeSupply` is an explicit UNPROVED arithmetic hypothesis: exactly
k^3 primes in every (M,(1+omega)M] for real M>=V. The general sequence
retains scalar restrictions on arbitrary schedules.
`VinogradovFordRank` now constructs Ford's rounded rank
floor(k-Delta/k+1) and maximal depth, proving every scalar restriction
throughout k-1<=Delta<=k(k-1)/2, including the final rank-k boundary
step. `VinogradovFordSelectedIteration` uses
these choices in the actual all-endpoint moment sequence, stopping the
defect update once Delta<=k-1 and then raising the moment trivially without
coefficient loss. Its moment theorem has no schedule-admissibility premise.
`VinogradovFordScaleError` proves (3.12) and the full finite triangular
error sum. `VinogradovFordQuantitativeScale` proves the original
0.071/k^4 terminal error, 0.16/k^3 stationary reserve and
16/(7*k^2*r) first-scale error for every k>=1000.
`VinogradovFordDefectRate.selectedDefect_rate` proves Ford's exact
normalized recurrence (3.14), including 32/21 and 16/7, for the selected
sequence. `VinogradovFordLowerDefect` proves strict positivity and the
geometric lower envelope through the boundary and stopped steps.
`VinogradovFordPotentialIteration.potential_cumulative` now proves
H(d_J)<=H(d_0)-2J/k+67/(50k), with H(d)=d+log(d)+log(2-d), for
k>=1000 whenever every preceding defect exceeds k. The endpoint condition
Delta_J>k-1 implies that active-prefix condition. The signed quadratic
potential gain and full reciprocal-defect sum pay the uniform 1.34/k
allowance. `VinogradovFordClosedDefect.selected_defect_bound` now evaluates
both endpoints and proves Delta_J <= (3/8)*k^2*exp(1/2-2*(J+1)/k+1.69/k)
through the full published upper order range. Its actual moment transport
retains the recursive coefficient and the unproved `ShortPrimeSupply`.
`VinogradovFordCoefficientScale.published_height_le` proves
V^(k+1)<=W=k^(4.11*k) at omega=0.06 and k>=1000.
`VinogradovFordEarlyDefect.early_defect_drop` proves decrease at least
0.01916*k whenever j+1<=1.97*k; `VinogradovFordCoefficientStep.early_step_le`
pays the complete early maximum by W^(Delta_j-Delta_(j+1)). The later
step retains the product of both factors. These scalar bounds do not
assume prime supply. `VinogradovFordCoefficientBudget` now telescopes the
actual early coefficient and multiplies the later packet costs exactly.
`VinogradovFordClosedCoefficient.selected_coefficient_bound` proves the
full original coefficient with constants 2.055, 5.91 and 9.7278 for
k>=1000 and J+1>=2*k. `selected_moment_closed` combines this with the closed
defect across the entire published order interval, retaining only short-prime
supply as an unproved arithmetic input.
`VinogradovMomentInterpolation` proves Holder interpolation for the actual
torus moments, including zero values and both interpolation endpoints.
`VinogradovFordOrderBudget` pays the complete interpolation error with
the original 1.7/k allowance. `VinogradovFordAllOrders.published_moment_bound_real`
now proves the k>=1000 part of Ford Theorem 3 for every integer order in
2*k^2<=s<=(k^2/2)*(1/2+log(3*k/8)) and every real P>=1 via the literal floor cutoff,
conditional on `ShortPrimeSupply k (3/50)`. No source-moment, coefficient,
schedule, divisibility or interpolation hypothesis remains.
Next prove dense short-prime supply and the published lower-degree estimates.
Do not list potential endpoint evaluation, the closed defect bound,
rank/maximal-depth selection, scale/cutoff admissibility,
numerical one-step coefficient, recursive quotient sizes or all-endpoint
moment induction, the closed coefficient product or high-degree order
interpolation as still open. Do not claim unconditional Ford 3.6/Theorem 3
or a zeta region before the explicit arithmetic premise is discharged.
The sharper Bellotti 2.3 recurrence remains under audit. Then finish the
numerical complete/incomplete moments and block bound.
Do not replace these by the diagonal iteration or silently use (M,8M]
with the paper's constants. Retain the wrapped Gaussian estimates as
auxiliary work; defer further optimization and zero-detector transport
until the literature chain is reproduced. No published zeta-region benchmark,
new zero-free endpoint, or RH arithmetic floor follows from this slice.
On 2026-09-24 the user authorized committing and pushing the accumulated
local work. This supersedes the earlier local-only publication hold;
the prohibition on subagents remains in force.

The user's "no shortcuts" instruction applies to this reproduction: keep
the full published omega range, constants and height domains. Do not
substitute omega=1/2, a wider packet, a qualitative PNT threshold, or an
assumed prime-count bound. `RosserSchoenfeldAnchor` checks the complete
230-prime list through 1451, 1360<theta(1451)<1410 and the needed logarithm
anchors. `RosserSchoenfeldBounds` proves the three actual J-comparisons
from section 7, including the negative-0.47 lower comparison from 1451.
`RosserSchoenfeldZeroFree.published_zero_edge` proves the paper's exact
Theorem 26 constant and height from our stronger signed-pole theorem.
This is a discharged dependency, not a new region. `RosserSchoenfeldError`
checks the final numerical epsilon comparison for x>=exp(5000); its
actual theta-error premise is NOT proved. `VinogradovRosserPrimeSupply`
transports the explicit prime-count bounds to the unchanged
`ShortPrimeSupply` throughout 1/(3 log k)<=omega<=1/2 for k>=26.
That theorem is CONDITIONAL on the two actual prime-count estimates.
The detailed analytic and finite-verification dependencies are in
`docs/rosser-schoenfeld-reproduction.md`. The first 25000 low zeros have
not been verified in Lean here; the 67.31% proportion certificate supplies
no such premise. The Chebyshev estimates and finite prime-table ranges
remain open as stated there.

`RosserSchoenfeldSharpConstants` proves the unconditional rational bounds
gamma < 577215666/10^9 and log(pi) > 1144729883/10^9. Its cubic atanh
lower bound proves monotonicity of the twice-corrected harmonic sequence;
exact arithmetic at order 200 bounds the actual Euler constant. These
supporting constants feed the now-proved higher inverse-power zero sums
below; prime-count estimates and a larger zero-free region remain open.

`RosserSchoenfeldZeroMass` now discharges the complete reciprocal-square
zero sum: `ordinate_mass_lt` and `norm_square_mass_lt` are unconditional
strict bounds by 463/10000, including analytic multiplicity and both
ordinate signs. `hasSum_poisson` evaluates the entire reflected mass at
one as 2+gamma-2*log(2)-log(pi). The proved critical-line verification
through height 54 and absence of zeros through 14 pay its discrepancy
from inverse squares. `RosserSchoenfeldEulerConstant` proves the numerical
constant with a corrected harmonic sequence and rational log bounds.
This is the classical Rosser reciprocal-square dependency, not a new
zero-free region or prime-count theorem. The larger finite verification,
smoothed explicit-formula estimates and the unchanged `ShortPrimeSupply`
premise remain open. Keep both public
frontiers and top-ten lists unchanged. Expose this as a separate supporting
endpoint; do not draw a proved implication to dense prime supply.

`RosserSchoenfeldFourthMass.norm_fourth_mass_lt` and
`RosserSchoenfeldCubeMass.norm_cube_mass_lt` now close the remaining classical
Rosser constants: the complete sums are below 744/10^7 and 167/10^5,
respectively, with summability, both signs and every analytic multiplicity.
The fourth-power comparison uses a positive difference of the exact xi
Poisson masses at one and two. `RosserSchoenfeldZetaTwo` proves the actual
logarithmic-derivative bound at two from a kernel-checked finite sample,
its complete Euler--Maclaurin tail and an independent Cauchy derivative
budget. `RosserSchoenfeldZetaTwoSample` checks intermediate dyadic values
and prefix blocks of eight; retain those proof boundaries to bound kernel
memory, and never replace them by a compiler-trusting numerical check.
The inverse-cube proof extracts a strict excess from the verified first
conjugate pair. No additional low-zero verification is assumed. These
statements reproduce classical constants, not a new zero-free region or
prime-count theorem. The analytic and finite-verification gaps in the
Rosser ledger, and the unchanged short-prime supply target, remain open.

`RosserSchoenfeldExplicitFormula.finite_prime_explicitFormula` now proves
the actual smoothed von-Mangoldt formula at every real x>=1, with all
nontrivial-zero multiplicities, both signs and the full trivial-zero
correction. The complex Laplace transforms, absolute integrability,
sum-integral exchanges and Fourier uniqueness are proved, not assumed.
`RosserSchoenfeldZeroTail.value_le` pays the complete inverse-square tail
above T by (8+2*log T)/T for every T>=2, using the actual positive xi
Poisson mass, actual prime-power positivity and the digamma bound.
The existing signed-pole edge and cutoff exp(3*sqrt(t)/8) give
`RosserSchoenfeldLargeSmoothed.abs_prime_sub_main_lt`: the literal smoothed
error is below exp(t)/(64*t^2) for every t>=4900. Exact rational Taylor
anchors and the complete zero tail pay the bound.
`RosserSchoenfeldLargeChebyshev` now proves actual psi error <=0.40*x/log x
and actual theta error <=0.41*x/log x for every x>=exp(5000), by monotone
desmoothing at step 1/(4*log x) and the proved proper-prime-power allowance.
`abs_theta_sub_self_lt_published` discharges the strict 0.47 allowance
throughout the source's final range. This is a proved alternative using
our stronger existing zero-free region; it does NOT claim the paper's
sharper exponential Theorem 11 error, the smaller source ranges or the
full actual prime-count estimates. No larger low-zero table is assumed.
Keep ShortPrimeSupply unchanged and distinguish its full all-degree target
from the now-proved explicit large-degree part below. The public zero-free frontier, top-ten
lists, RH signed-floor status and 67.31% certificate are unchanged.
Expose this as the separate `rosser-prime-error` endpoint in both explorers;
do not draw a proved edge to prime supply or a published VK benchmark.

`RosserSchoenfeldFiniteBounds.bounds_through_sixteen_thousand` now proves
both original strict prime-count inequalities at every real x in [67,16000].
The 136 closed cells and exact count 1862 at 16000 are kernel checked.
`RosserSchoenfeldFiniteBounds.catalog_mem_iff`, in the finite catalog module,
proves the retained prime catalog complete. `catalog_nodup`, `catalog_sorted`
and `smallPrimeCount_eq` provide sorted, exact smaller lookups. Preserve those
lists for larger finite certificates. Every integer
is checked in the eight data modules, not merely the proposed primes.
Use `primeCounting_step_of_block` and `primeBlock_append_of_eq` to assemble
checked data: direct concrete rewriting of the counting definition caused
expensive repeated kernel enumeration. Keep `Elab.async false` confined to
these new data files; do not change global elaboration settings.
The new prime-supply corollary pays the finite count premise and retains
explicit hypotheses above 16000, with the original packet target unchanged.
That finite count theorem alone does NOT pay the small theta range in the
anchored J comparison, the remaining prime estimates, ShortPrimeSupply or
a published VK benchmark; the separate continuation below discharges more.
Expose `rosser-finite-prime-counts` as an optional supporting endpoint in
both explorers. Keep all public zero-free/RH frontiers, the top-ten lists
and the 67.31% certificate unchanged.

`RosserSchoenfeldFiniteTheta.bounds_through_sixteen_thousand` now proves the
original -47/100 and +31/100 theta allowances throughout [1451,16000].
The complete prime catalog, literal primorials, checked exponential enclosure
and 69 closed cells pay every real endpoint. Do not claim the source's
range below 1451. Keep the seven theta data modules sequential and their
`Elab.async false` local; their proof boundaries bound kernel memory.
`RosserSchoenfeldLargePrimeCounting.bounds_above_exp_5100` proves both
original strict count bounds for every x>=exp(5100), using the proved
41/100 theta error, exact Abel summation and a full earlier-prefix allowance.
`VinogradovRosserLargeSupply.shortPrimeSupply_of_intermediate_counts`
confines the conditional all-degree count premise to 16000<x<exp(5100).
That middle interval is still open; no numerical estimate there is assumed
as a theorem.

`shortPrimeSupply_of_log_ge` in the same module independently proves the
unchanged ShortPrimeSupply when log(k)>=1700, for the full original width
range. The original published base lies above exp(5100), so both packet
endpoints have actual proved count estimates. The cardinality k^3, physical
endpoint and all width constants are unchanged. `fixedWidth_shortPrimeSupply`
discharges the exact 3/50 width.
`VinogradovFordLargeDegree.moment_bound_real` then proves the actual complete
Ford moment theorem with no arithmetic supply premise on this explicit
large-degree range, every original allowed order and every real P>=1.
Its coefficient and 1.7/k defect allowance are unchanged. This is NOT the
full published k>=1000 theorem, the lower-degree table, a sharp incomplete
moment, a VK benchmark or a new zero-free region. Continue proving the
remaining degrees and literature estimates; do not substitute this large
cutoff for the full original target. Expose `rosser-proved-prime-ranges`
and `ford-unconditional-large-degree` as optional endpoints in both explorers.
Keep default zero-free/RH frontiers and top-ten lists unchanged.

`ZetaEulerMaclaurin.zeta_eq` now gives the arbitrary-order actual zeta
expansion with the literal signed Bernoulli tail. `norm_error_le` pays
that full tail by an explicit finite coefficient allowance.
`ZetaEulerMaclaurinBudget.uniform_error` proves error <10^(-12) for
the evaluator `approximation 22020 s 18` on 1/2<=Re(s)<=1 and
abs(Im(s))<=22000, with s!=1. `rosser_height_lt` proves exp(9.99)<22000.
All Bernoulli arithmetic is checked in the kernel. The generalized
`uniform_error_of_norm` allows shorter prefixes when norm(s)+20<=N+1,
with N<=22020. `CertifiedComplexInterval` provides checked complex
rectangle arithmetic and phase reduction using proved twenty-decimal pi
bounds. `ZetaEulerMaclaurinEnclosure.mem_evaluate` encloses the complete
finite expression, scaling each rising factor before multiplication.
The exact Bernoulli coefficient cache is proved from the recurrence;
neither floating point nor native evaluation supplies a proof.
`ZetaEulerMaclaurinCertificate.nonzero_of_check` combines the numerical
check with the proved analytic error and checks all geometry and pole
conditions. `ZetaEulerMaclaurinValidation.height_fourteen_rectangle`
actually discharges the computation for
1/2<=Re(s)<=50001/100000 and 14<=Im(s)<=1400001/100000.
This is one small validation rectangle, NOT a complete low-zero
verification or a new published zero-free benchmark.
`ZetaLowZeroIsolation.isolated_critical_zero` now proves an actual unique
simple zero in the closed radius-10^(-5) disc centered at
1/2+(14134725141735/10^12)*I. Its real part is exactly 1/2, by the
proved reflection symmetry and uniqueness. `zero_distance_lt` places
every zero in this disc strictly within 1/50000000 of the center;
`nonzero_on_sphere` excludes zeros on the entire outer circle.
The two literal complex value inequalities in `ZetaLowZeroSamples` are
discharged by kernel computation, not assumed decimal data. They pay the
analytic and rounding errors. The independent Cauchy bounds are |zeta|<=32
and |zeta''|<=4096; the two-value derivative bound and Banach contraction
are proved in `AnalyticNewtonIsolation`. The resulting derivative is nonzero
and the analytic order is one. This disc theorem isolates ONE zero;
`ZetaFirstZeroCompleteness`, described below, now identifies it as the
first positive zero by a complete count through height 15. The complete
list through the published height remains open. Existence of many isolated
zeros alone does not prove completeness. The Rosser--Schoenfeld prime-count estimates remain
open. Do not replace the full height requirement by this local certificate.

`DigammaMidpointApproximation.norm_digamma_sub_log_midpoint_le` now
proves |psi(z)-log(z-1/2)|<=1/(2*(Re(z)-1/2)^2) for Re(z)>=3/2,
uniformly in height, directly from the actual Euler digamma limit.
`GammaPhaseApproximation` integrates this signed midpoint error and
retains every arctangent in the exact finite Gamma shift. With shift 200,
`theta_error_lt_one_seventh` proves a strict 1/7-radian error for the
actual unwrapped theta phase at every abs(T)<=22000. Its finite formula
uses only real logs and arctangents; no Stirling-error premise is assumed.
`GammaContinuousPhase.Gamma_eq_amplitude_mul_phase` proves the exact
positive-amplitude factorization of actual Gamma with this phase.
`ZetaHardyPhase` then proves actual Hardy Z real and continuous. The
finite-phase rotation is exactly Hardy Z times the cosine of the phase
error; `cosine_error_gt` proves that cosine exceeds 97/98 across the
whole required range. Checked opposite signs therefore imply actual
critical-line zeros without a numerical derivative premise. The signs
themselves have NOT been checked for the complete low-zero list.
Do not treat this phase-error bound or the sign-change theorem as a total
zero count. The existing `GaussianXiDivisorContour` already has the exact
complete finite-divisor rectangle formula, including multiplicities.
Use it to establish and certify the total count; do not rebuild the same
contour identity. No full 25000-zero verification, prime-count bounds or
published VK region follows yet. Keep these as supporting completion
and foundational theorems, with the existing proved region as default.

The current fixed-width packet is not a proof of a packet in (M,2M]. The
general mixed-type iteration remains a separate possible refinement;
choose a fresh eligible prime for each new type parameter, as the previous
prime generally divides T'. Keep the exact diagonal branch when P<p^r.
The growing-height rectangle does not discharge the fixed-height harmonic
Type-II premise. The independent signed floor and RH remain open. Continue locally
without commits, pushes or subagents.

`ZetaFiniteZeroCount` and `ZetaZeroCountFormula` now specialize the existing
complete divisor contour, retaining the factor two for both signs of the
ordinate and every analytic multiplicity. The actual pole contribution is
pi, and the Gamma path equals theta exactly. The finite shift-200 count
approximation has error strictly below 1/10 for 0<T<=22000, with the entire
actual zeta phase retained. `ZetaRightPhase.zeta_re_pos` proves positivity
on Re(s)=3/2 at every height from the complete logarithmic Euler series.
`ZetaCountingEndpoint` proves that positive real part on the horizontal
segment gives both complete boundary regularity and the actual endpoint
argument, with no untracked winding. Its general numerical premises are
NOT discharged at every height.

They ARE discharged at T=15. `CertifiedArctan` checks rational brackets by
sine/cosine signs with tangent branch conditions. `GammaThetaFifteen`
proves -3/2<theta(15)<0 after paying the actual Gamma error.
`ZetaHeightFifteen` checks fourteen adjacent closed rectangles covering
1/2<=Re(s)<=3/2 at height 15, plus the endpoint's positive imaginary part.
Every check uses `decide +kernel` and the full Euler--Maclaurin error.
`ZetaFirstZeroCompleteness.count_fifteen` proves the complete symmetric
multiplicity count is 2. `complete_first_pair` identifies the entire
window with the independently isolated simple critical-line zero and its
conjugate. `critical_line_through_fifteen` proves every nontrivial zero
with abs(Im(rho))<=15 has Re(rho)=1/2; `no_zero_through_fourteen` proves
14<abs(Im(rho)) for every nontrivial zero. The general finite-set matching
criterion is in `ZetaZeroCountCompleteness`. This is the first COMPLETE
validation window, not the required full 25000-zero verification or a
world-record region. Preserve the current default region and RH frontier.
Next extend the verified list and complete count to the published height;
address the direct evaluator's kernel cost before launching thousands of
samples. Rosser--Schoenfeld prime-count bounds, Ford's actual prime supply,
optimized schedules and the published VK region remain open. Continue
locally without commits, pushes or subagents.

`ZetaThreeZeroCompleteness` extends the complete finite verification to
height 26: `count_twentySix` proves the full symmetric multiplicity count
is six, and `critical_line_through_twentySix` proves every nontrivial zero
with abs(Im(rho))<=26 has Re(rho)=1/2. `nonzero_through_twentySix` gives
actual off-line zeta nonvanishing for Re(s)>0, with the pole excluded.
`ZetaHardySamples` checks actual signs -, +, -, + at 14,15,22,26 using
`decide +kernel`; `ZetaHardyWindowCompleteness` proves the general ordered
window/conjugate matching theorem. Eight closed horizontal cells, a checked
endpoint sign, and the unwrapped theta bound in `GammaThetaTwentySix`
independently discharge the count. No assumed numerical zero table is used.
`ZetaHardyProduct` replaces the 200 phase angles by one phase and an exact
rational product. Its positive coordinate normalization has norm at most
one and preserves actual Hardy signs for abs(T)<=22000.
`ZetaHardyProductCertificate` checks all analytic and numerical conditions.
Use the product rotation for signs; keep the unwrapped phase for counting.
The native high-height probes in the Rosser ledger are performance tests,
NOT certificates. The direct prefix is still too expensive for a naive
25000-zero run. The next scaling candidate is a fully proved Riemann--Siegel
formula with an explicit remainder, feeding the existing sign/count chain;
Hiary's elementary block accelerator (Theorem 1.1, Lemma 3.3 of
arXiv:1403.0317) is a second candidate that could retain the existing
Euler--Maclaurin correction and budget. Compare cost and conditioning before
choosing. The block accelerator is now formalized as detailed below;
Riemann--Siegel is not. An asymptotic big-O statement
is not an evaluated error bound. Full low-zero
verification, Rosser--Schoenfeld prime estimates, Ford's actual supply and
the published VK region remain open. Preserve the public default region
and RH frontier. Continue locally without commits, pushes or subagents.

`ZetaBlockTaylor` now proves the shared degree-eighteen block polynomial's
actual error at most 1/25000000000000, for Re(s)>=0, norm(s)<=22500 and
normalized x in [0,1]. Its finite differential residual leaves only two
coefficients; their positive rational majorant is kernel-checked. No
unproved Taylor or Cauchy remainder is assumed. `ZetaBlockApproximation`
transfers this to every original Dirichlet term and consecutive valid
partition. Keeping the entire Euler--Maclaurin correction gives
`zeta_error_lt`: total error <1/1000000000 on 1/2<=Re(s)<=3/2,
abs(Im(s))<=22000, s!=1, at the unchanged cutoff 22020.
`ZetaBlockMoments` proves the exact finite geometric-moment recurrence,
including its denominator-free resonant form. `ZetaBlockEnclosure` uses
materialized coefficient/moment arrays, repeated squaring, and a direct
Horner fallback for short or poorly conditioned blocks. Do not replace the
moment array by a function-valued recurrence: compiler eta expansion
recomputes lower moments exponentially. `ZetaBlockCertificate` checks the
actual partition, analytic domain and full error; `nonzero_of_check` gives
actual zeta nonvanishing from a successful kernel check.
`ZetaBlockHardyCertificate.hardy_sign_of_check` feeds the same sound evaluator
into the existing bounded Gamma rotation and complete sign-window chain.
`ZetaBlockValidation` kernel-checks two original high-height finite block
sums, including the polynomial error. These do NOT verify new zeros or
extend the complete height-26 window. The optional
`scripts/ProbeZetaBlocks.lean` took about 23 seconds natively at height 22000
(1167 blocks, degree 18), versus about 87 seconds for direct summation.
Its native output is exploratory data, not a kernel certificate. This
modest speedup alone does not establish feasibility of the complete
25000-zero calculation. Full low-zero verification and all pending
published prime estimates remain open. Keep the public default zero-free
and RH endpoints; continue locally without commits, pushes or subagents.

`ZetaBlockShift` proves a degree-twelve correction for purely imaginary
height shifts of norm at most 64: error <=1/80000000000000000 on the
normalized block. Its finite ODE residual leaves one coefficient, paid
by a checked rational majorant. `ZetaBlockBatch` combines this with the
center polynomial, with error <=801/20000000000000000 per term and
total zeta error <1e-9 after the unchanged analytic correction. Its exact
amplitude formula uses 31 center moments and 13 shift amplitudes.
`ZetaBlockBatchEnclosure`, `ZetaBlockBatchPacket` and
`ZetaBlockBatchPrefix` certify the materialized cache and exact early
terms. `phaseAt` resets each eighth phase using repeated squaring;
naively threading rectangular phase products across hundreds of samples
causes catastrophic interval wrapping. Preserve the proved phase law and
every rounding error. `ZetaBlockBatchCertificate` checks actual sample
geometry and radius, and `ZetaBlockBatchHardy.hardy_sign_of_check`
feeds the sound cache into actual Hardy signs. Preparation soundness must
be discharged and reused, never replaced by unverified cached data.
The optional `scripts/ProbeZetaBatch.lean` is a native timing probe, not
a kernel certificate; do not run the full intended zero list in ordinary
CI. The phase-reset prototype's 257 samples took about 426 seconds
including preparation; the proved pure implementation took about 641
seconds (58 preparation, 584 sample evaluation). The difference includes
recomputing short phase chains instead of threading their state.
These are not measured kernel costs. `ZetaBlockCacheCheck` independently
checks supplied early-term rectangles and proves actual prefix soundness.
Never use unverified numerical data as a replacement for that check.
Its `prefixCheck_cons` assembles independently checked entries into the
unchanged full-length checker. A 40-entry kernel probe took 385 seconds
as one reduction versus 43 seconds with separate entry proofs. Use this
proof-sharing pattern when scaling; executable timings alone do not
predict kernel replay. Changing the recursion to `Nat.rec` alone did not
resolve the measured cost and its probe was interrupted.
`ZetaBlockBatchValidation` now kernel-checks the direct 20-term block at
21836 and compressed 32-term blocks at 21836,21840,21964, with original
finite-sum conclusions and paid polynomial errors. Its full cached sample
proves zeta(1/2+18i)!=0, including the analytic tail and phase reset.
All 40 cache entries are checked independently. Small-height precision
-32/depth 12 and high-block precision -48/depth 24 are distinct settings.
The module build fell from 512 to 84 seconds after splitting entry proofs;
the 85-second direct check used about 7 GiB peak RSS. Asynchronous profiler
spans include waiting behind other kernel checks. The apparent 80-second
final-sample span was not an isolated cost: separate linear and balanced
sample checks both took about 7.8 seconds. The balanced variant was not
adopted. This is not yet a measured scalable complete-list verifier.
Height 18 lies inside the existing complete window. The complete finite
verification now reaches height 54, as described below; actual prime-count
estimates and the published VK region remain open. Further scaling work must measure
certificate costs, retain completeness and pay all analytic errors.
Keep the public default region and RH frontier, and work locally without
commits, pushes or subagents.

`ZetaElevenZeroCompleteness.count_fiftyFour` now proves the complete symmetric
multiplicity count is 22. `critical_line_through_fiftyFour` proves all
nontrivial zeros with abs(Im(rho))<=54 have real part one half;
`nonzero_through_fiftyFour` gives actual off-line nonvanishing on Re(s)>0,
excluding the pole. `ZetaHardyBatchData` independently kernel-checks eighty
cached terms and increments, with center 34 and a unit lattice starting at
14. `ZetaHardySamplesFiftyFour` checks eight further signs; the twelve
heights 14,15,22,26,31,34,38,42,44,49,51,54 alternate negative/positive.
`GammaThetaFiftyFour` proves 30<theta(54)<31. Four complete closed horizontal
cells and the endpoint imaginary sign independently discharge the count.
No numerical zero list or simplicity premise is assumed.
The contour's 400 one-term checkpoints are literal equalities to the
original evaluator, not approximate substitutes or unchecked data. The
first cell took 74 seconds versus 152 with ten-term checkpoints; all five
checks passed in 344 seconds. The combined module used about 17 GiB, so
keep its cells in separate `ZetaHeightFiftyFour.Cell0` through `Cell4`
modules: each checked in 77–79 seconds with peak RSS below 6.7 GiB.
Do not restore a single large
certificate file without a measured memory budget. The optional
`scripts/GenerateZetaHeightFiftyFour.lean` regenerates the candidate numeric
blocks; every emitted equality and final check still requires kernel replay.
This is a complete finite-height result through 54, not the full published
low-zero input near 22000, a published VK reproduction or a world record.
The actual prime estimates, full optimized moments and original published
region constants/heights remain open. Preserve the public default region
and RH frontier; continue locally without commits, pushes or subagents.

Work in one coherent slice at a time. A slice should close a real lemma or
interface needed by the current RH frontier, not merely add parallel
abstractions.

The 2026-09-14 arithmetic handoff is now promoted into the ordinary root;
its provenance and exact open target are recorded in
`docs/zeta-riesz-signed-fourier-tail.md`. `ZetaRieszFourierCarrier`
identifies the original factorial-filtered band with a genuinely integrable
two-frequency response at the unchanged physical cutoff, retaining its
signed first moment and ordinary-prime correction. The hypothetical-zero
source limit is unchanged. `ZetaPrimeCharacterRemainder` separately proves
a cutoff-independent integrated nonlinear local-log bound at every fixed
Re(s)>1/2 for labels at least 16. Small primes remain explicit; no uniform
limit as Re(s) approaches 1/2, bound on the first-order exponential, or
filtered source-scale saving follows. Do not treat generic cofactor marks
as an unweighted prime product without proving that bridge. The exact
cofinal criterion needs only one fixed c<1 with Re(B_N)>=-c at arbitrarily
large N, but that premise remains open. Bare unfiltered unit floors and
the immediate absolute-completion estimate have checked obstructions;
they do not refute the original filtered floor. Keep the Riesz critical
profile as the default explorer endpoint and expose the Fourier identities
as supporting arithmetic results. The handoff's model diagnostics are not
actual-zero estimates. No historical novelty or new zero-free width is
claimed. Continue independent local theorem work during exact-SHA CI.

`ZetaRieszFixedCofactor` now proves source-scale decay of the complete
original prime-insertion band for every fixed squarefree nonunit composite
cofactor. The coefficient vanishes above the common cutoff once it contains
the cofactor. Below its fixed multiple of `(D_N+2)^2`, the complete factorial
filter has an explicit allowance proportional to
`u/(N+1)+2*u^(N+1)`. This is a genuine arithmetic component bound with no
zero assumption. Prime cofactors leave the exact semiprime coefficient
`-log(p*a)*log(a)/L`; do not infer filtered decay just from its `1/L`.
`ZetaRieszPrimeClasses` deletes all-small support at `N>=60` and proves that
one-large-prime labels have nonunit cofactor dividing 30030. The prime
cofactors are exactly among 2,3,5,7,11,13. Each fixed composite-cofactor
insertion band is paid; `ZetaRieszReducedCofactorSource` now assembles the
entire finite deletion with exact restrictions into a reduced source theorem. The signed
semiprime and multiple-large-prime terms remain unpaid jointly.
`ZetaRieszFilteredCompletion` carries the complete original factorial filter
through the completed-minus-boundary response, retaining both frequencies
inside a genuinely integrable quotient. Do not claim its separate channels
are integrable or bounded. `ZetaPrimeNonlinearHalfplane` makes the isolated
nonlinear allowance uniform on every fixed closed half-plane strictly
right of one half; the first-order exponential coupling is still unpaid.
See `docs/zeta-riesz-fixed-cofactor-decay.md` and the supporting RH explorer
endpoint `fixed-cofactor-decay`. The default whole-carrier endpoint remains
`ZetaRieszCriticalProfile.exists_original_band_critical_profile`.

`ZetaRieszPrimeFourier` now proves that each complete squarefree nonunit
composite divisor measure has zero mass and log moment, and identifies
the actual band with its integrable full prime-factor response. Its exact
centered sine factors preserve prime count and phase. This cancellation
does not remove the first moment of the older truncated common-divisor
marks. `ZetaPrimeNonlinearTail` bounds the integrated multiplicative
correction exp(E)-1 by a nonnegative, decreasing square-log allowance
that tends to zero above a growing prime threshold, uniformly in finite
prime selections and imaginary height at each fixed Re(s)>1/2. The exp(A)
coupling, finite small primes, original factorial filter and independent
signed floor still require estimates. `ZetaRieszCompositeProduct` proves
the complete composite symbol is exp(A+E)-1-A under the local small-factor
conditions; never drop the unit or singleton subtraction. Its actual-band
completion also retains an explicit signed boundary, with no claimed
smallness. Keep these component bounds in the supporting prime-factor
explorer view; the default Riesz critical-profile bound is unchanged.

`ZetaRieszGrowingCofactor` now pays the entire original-band class n=p*a
with squarefree nonunit composite cofactor a<=A_N, where A_N is the threefold
natural square root of N+1. Its eighth-power budget gives a vanishing
inverse-square-root plus polynomial-geometric allowance with the full
fixed factorial filter. All terms outside the common compact range are
eventually exactly zero; every cutoff inclusion is proved. Deleting this
unbounded class retains the negative-multiplicity source. The exponent is
a conservative admissible range, not an optimum. The joint signed floor
for surviving semiprimes and larger composite cofactors remains open.
`ZetaRieszReducedCofactorSource.rh_of_reduced_cofinal_floors` audits logical
closure to Mathlib RH with the arithmetic floor explicitly an unproved
premise. Do not report that conditional theorem as proving RH. See
`docs/zeta-riesz-growing-cofactor-decay.md` and the supporting endpoint
`growing-cofactor-decay`; the default whole-carrier endpoint is unchanged.

`ZetaRieszExponentialCofactor` now gives a geometric bound on the entire
composite-cofactor class in an explicit range E_N eventually exceeding
N^k for every fixed k, at 2/3<u<1. Its three-halves tilt retains the full
polynomial factorial filter and all rounding; log E_N<=L_N at every order.
Its adaptive deletion preserves the source for every hypothetical
right-half zero, using this stronger class at Re(rho)<5/6 and the earlier
polynomial class elsewhere. Semiprimes and larger composite cofactors
remain unpaid jointly. `ZetaRieszCofactorTiltRate` proves the unique exact
scalar optimizer and tests every positive tilt analytically. The
exception u=exp(-1/2) is a contact of that scalar envelope, not a zero
exclusion. The downstream general-tilt module now supplies the spatial
estimate and arithmetic component bound; the scalar theorem alone is
not that bound. See
`docs/zeta-riesz-exponential-cofactor-decay.md` and the supporting endpoint
`exponential-cofactor-decay`. The default whole-carrier endpoint is unchanged.

`ZetaRieszGeneralCofactorTilt` now pays the full spatial and coefficient
cost for every q>1/2 with geometric rate r(u,q)<1. Its exact scalar optimizer
provides a geometric bound on the complete original-band composite-cofactor
class at every 1/2<u<1 except u=exp(-1/2). The explicit integer schedule
retains the physical-cutoff minimum and eventually exceeds each fixed N^k.
The earlier polynomial class covers the exceptional contact, so the exact
optimized complementary source applies to every hypothetical right-half
zero. Constants may depend on fixed u and P; the component bound is uniform
in height. Do not assert that the cofactor growth schedule is optimal, that
the contact is zero-free, or that semiprimes and larger composite cofactors
have a joint signed floor. That floor remains open. See
`docs/zeta-riesz-general-tilt-decay.md` and supporting endpoint
`general-tilt-decay`; keep the default whole-carrier endpoint unchanged.

`ZetaRieszEulerQuotient` now factors the full finite character into its
leading Euler quotient and quadratic local corrections. `ZetaRieszEulerCorrectionEnergy`
pays the complete correction product with every interaction order retained:
the even paired quotient has an integrated square-log allowance, and the odd
channel has a separate energy allowance. Both tend uniformly to zero above a
growing prime threshold on each fixed closed half-plane Re(s)>=sigma>1/2.
These are genuine integrability and finite-selection-uniform component bounds.
The exact weighted identity retains both even and odd leading-response
couplings. Do not discard the odd channel or assert that the leading Euler
quotient, finite small primes, physical cutoff phase, original factorial
filter or signed completion boundary is paid. No infinite Euler-product-to-zeta
identification is asserted. The original joint signed floor remains open.
See `docs/zeta-riesz-euler-correction-energy.md` and supporting endpoint
`euler-correction-decay`; keep the default whole-carrier endpoint unchanged.

`ZetaRieszEulerCutoff`, `ZetaRieszEulerMoments` and
`ZetaRieszEulerCorrectionDeletion` now remove the complete standalone Euler
correction from the literal original normalized arithmetic band with error
tending to zero. The physical phase costs linearly in the cutoff length;
the original inverse-length normalization absorbs that cost. Exact Cauchy
radii preserve every factorial moment and the full logarithm-marked fixed
polynomial filter, with genuine frequency integrability. Its bound is
proportional to `(N+1)*(u/R)^(N+1)`, and the original prime universe and actual
growing cutoff are retained for all fixed P,y and 0<u<1. No hypothetical-zero
premise is used for this deletion. The explicit residual keeps the leading
Euler quotient and small-prime head, ordinary-prime compensation, mixed
leading-correction interaction and entire signed completion boundary.
Do not infer control of the mixed term from standalone correction decay.
The joint independent floor remains open. See
`docs/zeta-riesz-euler-correction-deletion.md` and endpoint
`euler-correction-deletion`; keep the default whole-carrier endpoint unchanged.

`ZetaRieszEulerMultiplier`, `ZetaRieszEulerHead`, `ZetaRieszEulerHeadDeletion`,
`ZetaRieszEulerGrowingHead` and `ZetaRieszEulerWindowDeletion` now pay the complete
Euler correction multiplied by a growing head of actual primes. Every finite
head has an exact signed Fourier expansion and explicit Euler-product cost.
At original orders d*n, a positive stride satisfying 3*(u/R)^d<1 pays every
head prime at most n+16 for all fixed P,y and 0<u<1. The literal band deletion
preserves its actual physical cutoff, both phases, every factorial/log mark,
ordinary frequency integrability and the exact negative multiplicity source
on a proved cofinal sequence. The explicit residual keeps compensated leading
quotient SG-1-A, mixed S(G-1)(H-1), and the entire signed boundary B. The growing
leading quotient is not independently bounded, and the joint floor remains
open. Do not infer mixed-term control or a zero-free improvement from the
growing-head correction estimate. The fixed-head RH-floor implication is
conditional; its arithmetic premise is not proved. See
`docs/zeta-riesz-euler-growing-head.md` and supporting endpoint
`euler-growing-head-deletion`; keep the default whole-carrier endpoint unchanged.

`ZetaRieszEulerPrimeHeadDensity` and `ZetaRieszEulerQuadraticHead` strengthen
that correction deletion to all actual head primes through N^2 at every
original factorial order. The existing Chebyshev theorem bounds the complete
head coefficient product by exp(16*sqrt(b)/log(b+2)), uniformly over prime
subsets through b and sigma>=1/2. At b=N^2 this is at most exp(eps*N)
eventually for every eps>0. The full polynomial frequency/factorial cost is
absorbed by the original geometric saving, so no stride is required. The
literal band deletion is independent of a hypothetical zero and retains the
original physical cutoff and all integrability conditions. Its exact
negative multiplicity source is preserved under the original hypothetical
zero. Compensated leading SG-1-A, mixed S(G-1)(H-1), and the entire signed B
still require their joint independent floor. Small primes remain in S in
these terms; this does not delete every smooth integer from the residual.
The displayed RH implication assumes the open floor and supplies no new
zero-free width. See `docs/zeta-riesz-euler-quadratic-head.md` and supporting
endpoint `euler-quadratic-head-deletion`; retain the default whole-carrier
endpoint.

`ZetaRieszSmoothHead`, `ZetaRieszSmoothDeletion` and `ZetaRieszSmoothCofactor`
now pay the actual N^2-smooth squarefree band terms, including their original
signed Riesz coefficient and complete factorial filter. For 0<u<1 the
explicit eventual allowance is 32*log(2)*u*sum(norm(P_k))*N*(sqrt(u))^N.
The threshold is uniform over the selected classes, filters, ordinates and
positive physical lengths; the displayed filter cost remains, and no
numerical starting order is claimed. This deletion combines with the
previous optimized cofactor class: every remaining label has a prime above
N^2 and every eligible composite cofactor exceeds its paid threshold.
Keep the scalar-contact polynomial fallback. Semiprimes and larger
composite cofactors remain coupled. Both deletion errors vanish independently,
the exact negative source survives, and an independent vanishing-error bridge
connects the new actual sum with the signed quadratic Euler-window residual.
Do not infer that the individual Euler factors now have only large-prime
support or that the whole remaining sum is bounded. Its independent joint
floor and RH remain open; the displayed RH closure is conditional. See
`docs/zeta-riesz-smooth-prime-deletion.md` and endpoint `smooth-prime-deletion`;
retain the default whole-carrier endpoint and both ten-entry README lists.

`ZetaRieszPhysicalPrefixDeletion.tendsto_actual_band_sub_prefixResidual`
now removes the actual physical prime prefix inside the earlier joint residual
for 1/2<u<exp(-1/2). The paid class is n=p*a with N^2<p<=(D_N+2)^2
and squarefree a supported on primes through N^2, with no separate size cap
on a. Preserve every order-dependent subband mask and unique prime insertion;
the pair sum must count each actual integer once. The full-filter geometric
allowance retains the complete cofactor Euler mass and physical cutoff.
Every surviving single-large-prime factorization with a smooth cofactor now
has p>(D_N+2)^2. This does not bound that remaining class or terms with
multiple large primes. The adaptive remainder retains the previous residual
for exp(-1/2)<=u<1 and preserves its exact negative source at every scale.
Do not extend the new component estimate outside its proved u interval.
The independent full signed floor and RH remain open; the displayed RH
closure is conditional. No new zero-free width or historical novelty is
claimed. See `docs/zeta-riesz-physical-prime-prefix.md` and endpoint
`physical-prime-prefix-deletion`; retain the default whole-carrier endpoint.

`ZetaRieszCompositeDeletion.tendsto_actual_band_sub_compositeResidual`
now pays the entire one-large-prime composite-smooth class on
1/2<u<exp(-1/2), including every prime beyond the physical cutoff.
The exact product ceiling leaves harmonic cofactor mass 2^omega(a)/a.
Large smooth cofactors a>=(D_N+2)^2 decay independently whenever 0<u and
2*u^2<1; smaller composite cofactors vanish exactly above the prime cutoff.
Combined with the prefix estimate this removes every composite smooth
cofactor size. Preserve all masks and unique actual integer counting.
`surviving_support_dichotomy` leaves only small-prime/large-prime semiprimes
beyond the physical cutoff or integers with at least two distinct primes
above N^2. All earlier cofactor restrictions remain. These two classes still
need their joint independent signed floor; do not report them as bounded.
Keep the all-scale fallback, exact negative source and independent Euler
bridge, and do not extend the complete deletion outside its proved interval.
No numerical starting order, zero-free improvement or historical novelty is
claimed; the displayed RH closure is conditional. See
`docs/zeta-riesz-composite-smooth-deletion.md` and endpoint
`composite-smooth-deletion`; retain the default whole-carrier endpoint.

`ZetaRieszLargeSmoothDeletion.tendsto_actual_band_sub_largeSmoothResidual`
now pays every actual term whose complete N^2-smooth factor reaches the
physical cutoff, on 1/2<u and 2*u^2<1, with any number of rough primes.
The exact divisor hyperbola costs only one extra logarithm; its cubic
order allowance is absorbed by the same geometric rate. Keep all divisor
choices, masks, factorial shifts and disjoint prime supports. Unique counting
and existence of the complete factorization are both proved.
`surviving_support_with_small_smooth_factor` supplies every nonzero survivor's
full factorization with smooth part below the physical cutoff. Every earlier
deletion remains, including the complete one-large-prime composite deletion
on its own smaller interval. Do not conflate those source-scale intervals.
The all-scale fallback, exact negative source and independent signed Euler
bridge remain. The full joint signed floor and RH are still open; the RH
closure is conditional. No numerical starting order, zero-free improvement
or historical novelty is claimed. See
`docs/zeta-riesz-large-smooth-factor-deletion.md` and endpoint
`large-smooth-factor-deletion`; retain the default whole-carrier endpoint.

`ZetaRieszSurvivingPrimeLayers.surviving_layers_with_boundary_witness`
constructs every nonzero survivor's complete smooth, intermediate and extreme
factors. Composite smooth cores contribute only through actual divisors in
the strict physical window X_N/a<d<X_N, including a nonzero shifted-profile
witness. Keep every Moebius sign and both strict boundary edges.
`norm_coefficient_physical_extreme_le_log` bounds a saturated extreme core's
coefficient by log(n), independently of its extreme-prime count. Extreme
primes disappear only from the divisor profile; the original logarithm,
integer, phase and factorial kernel retain them. Coefficient sign or amplitude
is not a signed-floor bound for the filtered sum. These exact identities do
not enlarge the earlier deletion intervals or replace the adaptive fallback.
The full joint signed floor and RH remain open. See
`docs/zeta-riesz-extreme-prime-window.md` and endpoint `extreme-prime-window`;
retain the default whole-carrier endpoint and the existing source/axiom audit.

`ZetaExposedZero.exists_exposed_right_half_zero` now selects an exposed
zero from any hypothetical right-half zero using actual inverse-square
divisor summability; no globally rightmost-zero premise is introduced.
`ZetaRieszSemiprimeBand.tendsto_actual_semiprime_integer_band` pays the
entire actual, uniquely counted semiprime band with a prime factor at most
N^2 at exposed zeros, for every fixed filter and varying selected small
primes. Complete prime moments, factorial convolution, the damped physical
prefix, both original-band tails and integer uniqueness are all proved.
The completed head has an eventual C*N^(-(beta-1/2)) bound; this is not a
numerically evaluated starting order for the actual band. The prefix bound
retains both prime logarithms and 1/L_N and vanishes for every 0<u<1.
Arbitrary prefix masks are allowed, but arbitrary masks on a completed
infinite prime sum do not inherit its cancellation.
`ZetaRieszSemiprimeSupport` independently pays the overlap with every
earlier deletion: above-cutoff semiprimes survive all earlier adaptive cuts.
`ZetaRieszSemiprimeDeletion.tendsto_actual_band_sub_residual` therefore
removes this whole class while retaining the exact negative multiplicity
source, all earlier support restrictions and the signed Euler bridge.
On 1/2<u<exp(-1/2), every nonzero survivor eventually has at least two
distinct primes above N^2. Composite-cofactor fallback classes remain at
other scales, and the complete smooth-factor bound a<X_N still requires
2*u^2<1. The independent whole-residual cofinal floor remains open;
`rh_of_exposed_residual_floors` assumes it explicitly. Do not report a
new zero-free region, numerical certificate or historical novelty.
See `docs/zeta-riesz-semiprime-deletion.md` and supporting endpoint
`semiprime-class-deletion`; retain the default whole-carrier endpoint
and both ten-entry README lists.

The continuation in `docs/zeta-riesz-unfiltered-narrow-carrier.md` proves
independent decay of both actual outer pieces outside
`2*N/5<log(n)<=8*N*log(2)`, for every fixed filter and `0<u<1`, with no zero
premise. The exact allowance retains `u^(N+1)`, convergent divisor masses,
and the rates `(1/2)*exp(5/8)<1` and `5*exp(-(7/3)*log(2))`, whose cube is
`125/128`. `ZetaRieszNarrowCarrier.tendsto_actual_residual_sub_narrow`
intersects every earlier support cut with this window; it does not extend
their parameter ranges. At exposed zeros, the constant filter `P=1`
retains the full negative multiplicity source, and the real carrier is
exactly its signed coefficient times a nonnegative factorial envelope
times `cos(gamma*log(n))`. `tendsto_normalizedResidual` preserves that
source in the narrowed window. The joint interior floor is still open:
multiple-large-prime products and composite-cofactor fallback cases remain
on their previously stated ranges. The conditional
`rh_of_exposed_narrow_floors` keeps this arithmetic floor as a premise.
Do not report an RH proof, new zero-free region or numerical zero bound.
Use supporting endpoint `unfiltered-narrow-carrier` while retaining the
default whole-carrier endpoint and both ten-entry README lists.

`ZetaRieszFourExtremeBound.eventually_norm_four_extreme_sum_le` now bounds
every actual finite selection with at least four distinct prime factors at
or above X_N, for 0<u<exp(-1/2). The source-normalized allowance is
`(4*exp(-23/16))^N*u*A(P,1/4,65/64)`, with its rate strictly below one,
the actual damped floor, all fixed filter shifts and uniformity in the
ordinate and selection. No zero premise is used. For every fixed 0<u<1,
some higher degree also has independent unnormalized geometric decay.
`ZetaRieszFourExtremeDeletion.tendsto_narrow_sub_fourResidual` removes the
entire paid four-prime class and keeps the previous residual unchanged
outside its proved interval. The negative multiplicity source and exact
cosine identity survive. On 1/2<u<exp(-1/2), nonzero survivors eventually
have at least two primes above N^2 but at most three at or above X_N.
Do not conflate these thresholds: intermediate primes and their cofactor
coupling remain. All earlier cuts retain their own scale ranges. The
whole independent cofinal floor remains open; the terminal RH theorem is
conditional. No new zero-free region or numerical zero bound is claimed.
See `docs/zeta-riesz-extreme-degree-deletion.md` and supporting endpoint
`extreme-degree-deletion`; retain the default whole-carrier endpoint and
both ten-entry README lists.

`ZetaRieszLowerDegreeBounds` now pays the actual two-or-more-extreme-prime
class on 0<u<exp(-2/3) and the three-or-more class on 0<u<exp(-9/16).
Their exact rates are `(8/3)*exp(-95/96)<1` and
`(27/8)*exp(-2533/2048)<1`; every fixed filter and physical floor remain.
`ZetaRieszPhysicalProductBounds.tendsto_above_physical_square` pays the
broader entire actual class n>=X_N^2 on the first interval, irrespective
of prime count. Every coefficient with n<=X_N is exactly zero.
`ZetaRieszPhysicalAnnulus.tendsto_degree_sub_annulus` therefore restricts
the actual carrier to X_N<n<X_N^2 with independent vanishing error;
other scales retain their prior residual. The entire negative multiplicity
source and exact signed cosine identity survive. Once N^2<X_N, a nonzero
annular label either has all primes below X_N or is an intermediate/extreme
semiprime n=p*a with N^2<a<X_N<=p. The latter retains exact coefficient
`-log(n)*log(a)/L_N`; composite cofactors vanish by saturation. Do not
replace the uniquely counted integer carrier by an ordered prime-pair sum
without proving diagonal, multiplicity and cutoff corrections. The JOINT
floor for these two classes remains open. At larger u retain all earlier
degree and composite-cofactor fallback regimes, with their original ranges.
The RH closure is conditional; no zero-free enlargement or numerical zero
bound follows. See `docs/zeta-riesz-physical-annulus.md` and supporting
endpoint `physical-annulus`; retain the default whole-carrier endpoint and
both ten-entry README lists.

`ZetaRieszInfinitePhysical.eventually_norm_infinite_upper_le` extends the
physical product bound to every changing infinite mask of the actual
coefficient above X_N squared, with genuine summability proved first.
`ZetaRieszAnnulusCompletion.eventually_norm_annulus_completion_error_le`
now completes the entire actual cross-prime class N^2<a<X_N<=p on
1/2<=u<exp(-2/3). Its geometric error has rate (8/3)*exp(-95/96)<1.
All earlier support cuts, both logarithmic windows and unique actual
integer counting are discharged, retaining every fixed filter and phase.
The completed prime head MUST retain its exact finite physical prefix:
diagonal and repeated incidences inside that prefix are real corrections.
`ZetaRieszAnnulusJoint.eventually_norm_joint_sub_annulus_le` bounds the
error of the whole representation: all-subcutoff response plus completed
prime head minus physical prefix. Its full negative multiplicity source
survives at exposed zeros in the stated interval. The independent JOINT
signed floor remains open. Do not assert that the prefix, the completed
head or the subcutoff class separately decays. Larger source scales keep
their previous fallback regimes. No RH proof, zero-free enlargement,
numerical zero bound or historical novelty follows from this completion.
See `docs/zeta-riesz-annulus-prime-completion.md` and supporting endpoint
`annulus-prime-completion`; preserve the default whole-carrier endpoint
and both ten-entry README lists.

`ZetaRieszPrefixDiagonal.tendsto_diagonalResponse` independently removes
the genuine selected prime-square prefix for every 0<u<1, at rate
2u/(u+1). `ZetaRieszMixedPrefix.tendsto_mixedResponse` pays the entire
small/intermediate-prime prefix on 1/2<u<exp(-1/2), retaining the
INTERMEDIATE-prime logarithmic mark, unique integer labels and every
fixed filter. Its explicit allowance is C(P,u,q)*(N+1)^3*tiltRate(u,q)^N
with the proved mathematical tilt. Exact partitions preserve the entire
negative multiplicity source on the existing annular interval. The wider
component estimate does not extend that interval. The remaining prefix
is exactly the distinct-intermediate-prime product sum with coefficient
-log(n)^2/L_N. All earlier support masks are discharged before combining
it with the actual Riesz coefficient into log(n)*min(1,log(n)/L_N).
`ZetaRieszPairedCorrection.eventually_refinedJoint_eq_clipped_split`
retains the completed head, unpaired subcutoff response and full clipped
pair response together. Positive coefficients do not supply a cosine floor.
`ZetaRieszCentralWindow.norm_sub_centralBand_le` independently pays ALL
divisor-majorized labels outside 3N/2<log(n)<=8N/3 on 0<u<exp(-2/3),
with rates (3/2)*exp(-631/1536)<1 and (8/3)*exp(-95/96)<1. The actual
central annulus retains every older support cut and its whole exposed-zero
source. The central signed floor remains open. Do not silently apply this
central restriction to the completed head or assume any separate surviving
component decays. The completed representation has its own exact transport
in `ZetaRieszCentralPair`, described below.
Other source scales retain all previous fallback regimes. No RH proof,
new zero-free region, numerical zero bound or historical novelty follows.
See `docs/zeta-riesz-prefix-central-window.md` and supporting endpoint
`prefix-central-window`; preserve the default whole-carrier endpoint and
both ten-entry README lists.

`ZetaRieszCentralPair.eventually_norm_refined_sub_centralJoint_le` now
transports the two finite components to the central window with allowance
2E_N on 1/2<=u<exp(-2/3), while retaining the entire completed prime head.
For u>=1/2 and N>=20, the actual floor gives L_N<=3N/2, so the central
pair clip is identically one. Order twenty is ONLY this clip threshold,
not the starting order for all earlier asymptotic transports. Every
nonzero central unpaired coefficient eventually has >=3 distinct primes.
`ZetaRieszTriplePrime.actual_three_prime_coefficient_bounds` proves
0<=C_L(n)<=log(n)/2 for the actual three-prime coefficients when L>0 and
log(n)<=2L. `norm_actual_three_prime_le_midpoint_gap` also bounds their
norm by (log(n)/L)*(2L-log(n)). The exact third-prime insertion is a
difference of two complete tents; keep that signed identity. The actual
annular support discharges log(n)<2L_N without a zero assumption.
`ZetaRieszCentralPrimeLayers.eventually_centralJoint_eq_prime_layers`
retains four terms: whole completed head, central log-weighted prime pairs,
actual three-prime response, and actual >=4-prime response. Known signs
apply only to the pair and three-prime coefficients; cosine phases can
still be negative. `re_normalized_three_ge_negative_phase` pays only
negative observations with the half-logarithm budget. Its unevaluated
phase cost is NOT a subunit source-scale floor. The joint floor, RH and
all remaining global source ranges stay open. No new zero-free region
or historical novelty is claimed. See `docs/zeta-riesz-central-prime-layers.md`
and supporting endpoint `central-prime-layers`; preserve the default
whole-carrier endpoint and both ten-entry README lists.

`ZetaRieszHeadOrders.completedHead_eq_convolution` now retains the finite
complex cofactor moments G_A,k inside the complete head convolution.
For M=N+j+1, it is exactly -sum_j P_j*M/L_N*sum_k G_A,k*B_(M-k),
with genuine prime summability including order zero and every filter shift.
The actual damping denominator gives L_N<=2N*log(2)<=45N/32 for
u>=1/2 and N>=2. `norm_highHead_le` independently bounds ALL orders
16k>=15M by highHeadCost(P,u)*(N+1)^2*exp(-7N/3200), for every fixed P,
uniformly y, on 1/2<=u<exp(-2/3). No zero or cancellation premise is used.
The Euler tilt 127/256 pays every complementary complete prime order;
the finite tilted mass includes the harmless totalized zero index.
`tendsto_highHead` proves that this exact component decays. Order two
is ONLY this estimate's threshold, not an earlier transport threshold.
`completedHead_eq_remaining_add_high` keeps the remaining 16k<15M orders
exactly; it does not truncate either prime variable or complete the
finite cofactor set. `norm_centralJoint_sub_orderReduced_le` gives the
whole-carrier transport allowance, and `tendsto_orderReducedJoint_exposed`
retains the entire negative multiplicity source on the annular interval.
The remaining head orders, central pair correction, three-prime phases,
and >=4-prime response still need a JOINT cofinal real floor above -1.
The independently paid high head is not a bound for those components.
Do not extend this range to all right-half zeros or claim new zero-free
regions, RH, or historical novelty. See `docs/zeta-riesz-head-orders.md`
and supporting endpoint `head-orders`; preserve the default whole-carrier
endpoint and both ten-entry README lists.

`ZetaRieszHeadAdaptiveTransport.norm_adaptiveHead_le` now independently
pays the larger head range 8k>=7M, M=N+j+1, with allowance
adaptiveHeadCost(P,u)*(N+1)^2*exp(-7N/9216), for every fixed P,
uniformly y, 0<u<exp(-2/3), N>=3. Keep the actual correlation
L_N<=-2N*log(u); the damped physical floor is unchanged.
`ZetaRieszPrimePairConvolution.pairLogResponse_eq_convolution_sub_diagonal`
retains the exact unordered pair half and repeated-prime diagonal.
Distinct products have two ordered incidences, not one or an arbitrary
multiplicity. The diagonal independently decays for 0<u<1 at rate
2u/(u+1), including arbitrary moving finite prime masks.
`ZetaRieszPairOrders.norm_outerPairResponse_le` pays BOTH pair ranges
8k<=M and 8k>=7M with outerPairCost(P,u)*(N+1)^2*exp(-7N/9216),
on the same independent component interval and threshold as the head.
Exact complex order reflection cancels the original pair half; do not
replace the product by a Hermitian square or assert positivity.
The whole central transport still uses ONLY 1/2<=u<exp(-2/3), with
every earlier central error and clip correction discharged. Order three
is this estimate's threshold; order twenty remains the clip threshold.
`middleJoint_eq_unpaired_add_form` retains one shared prime quadratic:
the head has 8k<7M and (k+1)*F_(k+1)*B_(M-k)/L_N with its negative
sign, while the pair has M<8k<7M and F_k*F_(M-k)/2. Keep the finite
prime array, adjacent derivative order, complete prime moment and all
fixed filter coefficients together. Neither prime series is silently
completed or truncated. The actual unpaired three-prime and >=4-prime
terms remain with every prior mask. `tendsto_middleJoint_exposed`
preserves the full negative multiplicity source. Its independent JOINT
cofinal real floor above -1 remains open. These controlled order ranges
are not percentages of arithmetic mass. All other global source ranges
retain prior obligations; no RH proof or new zero-free region follows.
See `docs/zeta-riesz-pair-orders.md` and supporting endpoint `pair-orders`;
preserve the default whole-carrier endpoint and both ten-entry README lists.

`ZetaRieszPrimeCompletion.eventually_norm_finite_sub_complete_le` now
independently completes the actual finite prime array on N<=3k and
128k<=65N: norm(u^k*(F_A,k-B_k))<=2Z*exp(-17N/12288), eventually
uniformly in all eligible orders and all heights, on0<u<exp(-2/3).
Both omitted prime ranges and their genuine sums are paid; the actual
floor and both endpoints stay unchanged. `tendsto_weighted_finite`
then transports the complete phase k*u^k*B_k->-m_rho to the actual
moving finite array, retaining its EXPLICIT zero and exposure premises.
`ZetaRieszMatchedMiddle.eventually_matchedBlock_re_bounds` proves an
eventual signed budget for a nonempty actual middle HEAD/PAIR block:
-m_rho^2/8<=Re(u^(N+1)*matchedBlock)<0, on the annular source interval.
This is SOURCE-CONDITIONED, not an unconditional arithmetic floor, a
decay theorem, or a subunit whole-carrier bound. Multiplicity is never
assumed one. Strict negativity alone does not prove a nonzero limit.
Keep the exact atom normalization k*l*u^(k+l)*sharedAtom =
half*weightedF_k*weightedF_l - [k/(uL_N)]*weightedF_(k+1)*weightedB_l.
The actual relative head cost is in[7/12,1]; positive pair phases alone
would omit a larger negative head contribution. The selected k,l,k+1
all meet the proved completion inequalities; l=N+1-k. The actual order
count32card<=N and reciprocal weight sum<=5/32 hold forN>=256, and
floor(N/2) proves nonemptiness there. Order256 is ONLY this structural
threshold; the phase threshold remains eventual and zero-dependent.
`middleJoint_one_eq_unmatched_add_matched` retains every complementary
head and pair order as literal set differences and the whole unpaired
three-prime and higher-prime response. Only unmatchedJoint+matchedBlock
is asserted to retain the complete -m_rho source. The original unfiltered
P=1 source is used, with its product-logarithm prefactor unchanged.
The complementary JOINT floor and all other global source ranges remain
open. See `docs/zeta-riesz-matched-middle.md` and supporting endpoint
`matched-middle`; preserve the default whole-carrier endpoint and both
ten-entry README lists. No RH or zero-free enlargement follows.

`ZetaRieszPrimeCompletionRate` now keeps the full completion exponent
theta*log(u/q)-(3/2-q-sigma)*ell and proves its unique positive-tilt
minimum at q=theta/ell. This is an optimum for this estimate, not all
arithmetic weight families; retain every separate admissibility condition.
Its independent completion range reaches N<=3k and32k<=17N, with error
exp(-11N/30720)*(Z1025+Z8193), uniformly in height on1/2<=u<exp(-2/3).
Derivative-weighted errors also vanish for every eligible moving order.
`ZetaRieszWiderMatched` uses that actual wider range, contains every old
matched order, and proves strict enlargement by an explicit new order.
Under the exposed-zero hypotheses, the larger block has the SAME budget
-m_rho^2/8 and persistent upper bound-m_rho^2/1536. Multiplicity remains
unrestricted; this cost need not be subunit. Nondecay and source-change
guards explicitly prohibit dropping the block from the full-m source.
The actual counts N/32<=card<=N/16 and reciprocal costs in[1/16,5/16]
hold forN>=256. The head-cost interval[5/9,4/5] also uses the proved
eventual physical-length lower bound; never label256 as a phase threshold.
Keep the complete complementary head/pair orders and every T3/T>=4 label.
`ZetaRieszEndpointTaper.reflected_sharedAtom_eq` retains the reflected
pair as B_k*T_l-(k+1)/L*B_(k+1)*B_l plus BOTH low-leg completion errors
with their multiplying factors. The literal T_l has weight1-log(p)/L
and independent envelope q^-l*exp(aL)/(aL)*Zsigma for a=q+sigma-3/2>0,
q>0,sigma>1. This inverse-length gain does not itself pay a positive
exponential rate or either completion-error product. Preserve the
negative complete head, original factorial shifts and complex prime phases.
Only unmatchedJoint+matchedBlock retains the source. The remaining JOINT
floor and other global source ranges remain open; no RH or zero-free
enlargement follows. See `docs/zeta-riesz-wider-matched.md` and endpoint
`wider-matched`; keep the default whole-carrier endpoint and top-ten lists.

`ZetaRieszCompletionProduct` and `ZetaRieszReflectedCompletion` now pay
BOTH reflected completion corrections at their full product scale.
The entire selected wing error, including source prefactor and order
count, is at most8exp(2)Z1025^2(N+1)^4exp(-5N/4096) and tends to zero,
uniformly in every moving height on0<u<exp(-2/3), independently of zeros.
Keep the actual disjoint lower/reflected selections and every derivative
successor. The central complement is a subset of WiderMatched.S; its
source-conditioned budget remains[-m^2/8,0]. Do not double-count overlapping
wider and wing blocks. `ZetaRieszLowHeadPrefix` independently bounds ANY
derivative-weighted selected small-prime order sum by600sqrt(N+1)Z1025.
`ZetaRieszLowHeadCorrection` includes the complete complementary leg and
pays both actual low-head corrections. Its final decay theorem uses the
explicit exposed-zero phase bound; do not describe that whole product
statement as independent of hypothetical zeros.
`ZetaRieszCompletedCarrier` combines the complete low and reflected heads
without overlap. Their exact order set forN>=256 is
range(floor((15N+64)/32)+1), with2k<=N+1. The threshold is structural only.
`HarmonicProductContinuity` imports only Mathlib and proves centered
harmonic-product decay for every convergent complex array and EVERY moving
lower-half order selection. It preserves the reference complex square and
pays both injective marginals by one Cesaro average. This is a theorem for
that harmonic kernel, not a classification of all coefficient families.
`ZetaRieszCompleteHeadHarmonic` then proves
u^(N+1)H_N+m^2h_N->0, where
h_N=(N+1)/(uL_N)*sum_completeHeadOrders(1/(N+1-k)) is explicit and
nonnegative. Its two-sided real estimate retains the negative leading cost
and unrestricted multiplicity; the head itself is NOT asserted to vanish.
The terminal source is exactly
u^(N+1)(T3+T>=4+taperedWing+centralBlock)-m^2h_N -> -m.
Every completion error is paid in this chain. The actual joint signed
bound for T3+T>=4+taperedWing remains open, together with the other global
source ranges. Keep all old masks, the floor-defined length, source and
exposure hypotheses, and the central and harmonic costs. No RH, zero-free
enlargement or historical novelty follows. See
`docs/zeta-riesz-complete-head-harmonic.md` and supporting endpoint
`complete-head-harmonic`; preserve the default whole-carrier endpoint.

`ZetaRieszLengthAsymptotic` and `HarmonicIntervalLimit` now evaluate the
actual floor-defined length and harmonic endpoint ratios. The generic
harmonic and finite-weight continuity modules import only Mathlib.
`ZetaRieszHeadHarmonicAsymptotic` gives the exact complete-head limit
-m^2log(32/17)/(-2u logu), with its source-conditioned component range
u<=3/5. Do not extend the WHOLE source range using that component theorem.
`ZetaRieszCentralProductPhase` pays both actual central prime-product
errors uniformly at arbitrary precision under the exposed-zero premises.
`ZetaRieszCentralHarmonicCost` identifies the exact central interval
[floor((15N+64)/32)+1,N-floor((15N+64)/32)] forN>=256 and preserves reflection.
Its reciprocal mass tends to log(17/15); the actual central block tends to
m^2log(17/15)(1-1/(-2u logu)). The head plus central block therefore tends to
-m^2c(u), where c(u)=log(32/15)/(-2u logu)-log(17/15)<1 on the original
annulus. `RieszHarmonicCostBounds` proves the scalar inequality independently
of hypothetical zeros. The actual real components are eventually greater
than -m^2, but the original source is -m. Never absorb unrestricted
multiplicity into c(u), assume simplicity, or call this a sub-source bound
for every zero. The exact remaining source is
u^(N+1)(T3+T>=4+taperedWing)->-m+m^2c(u). These three actual arithmetic
components still need an independent joint signed bound. All older masks,
complex product phases, floor/damping factors, exposure hypotheses and
other global source-range obligations remain. The threshold256 concerns
only the integer partition; phase thresholds remain unevaluated. A
nonnegative asymptotic floor would suffice in the simple-zero case, but is
not proved. Preserve the default whole-carrier endpoint and both top-ten
lists; see `docs/zeta-riesz-exact-harmonic-costs.md` and the supporting
`exact-harmonic-costs` endpoint. No RH, zero-free enlargement, numerical
zero bound or historical novelty follows from this slice.

The user also prioritizes expanding u-coverage and obtaining an actual
zero-free theorem from this arithmetic path. Distinguish a wider component
range or retained support from a proved zero-free region; the latter must
discharge the independent arithmetic estimate and required source premises.

`LogarithmicDeviation` now classifies every successful positive exponential
cutoff tilt by log(2u)<I(x), I(x)=x/2-1-log(x/2). It imports only Mathlib;
do not describe this as a classification of signed methods. The universal
window9N/20<logn<=11N/2 improves the older global logarithmic window and
preserves every previous mask and X_N<n. The additional deletion has one
common geometric allowance across0<=u<=1, even for moving radii and heights.
`ZetaRieszDeviationCarrier` retains the full source for every exposed
right-half zero without an extra local-u restriction. This does not widen
the separate three-unpaid source decomposition or prove a zero-free region.

`ZetaRieszSignedFrequency` keeps the complete prime product and paired
opposite frequencies. Each prime supplies one vanishing factor, and odd
prime count supplies one extra factor with exact gap L-logn/2. Three-prime
pairing is exactly16sin(xi*(L-logn/2))*prod sin(xi logp/2). Four-or-more
prime counts also give a quadratic quotient bound on abs(xi)*logn<=1.
Both actual nonlinear classes have the cubic low-frequency allowance
u^(N+1)*d^3/(3pi)*(C3+C4), with positive d=3/(8(N+1)) valid at everyN.
C3 retains(logn/L)*normK*abs(L-logn/2)*prod logp; C4 retains
(logn/L)*normK*(logn)^4. All original masks, filter shifts and phases remain;
the complementary Ioi d integral is explicit and genuinely integrable.
The finite costs are NOT proved bounded or vanishing at source scale.
Do not count the cubic frequency factor without its growing prime-log
costs, describe within-divisor cancellation as cancellation between integers,
or discard cross-degree or complementary-frequency interactions. Both the
high-frequency signed response and the tapered wing remain unpaid.
The full signed floor, unrestricted multiplicity/source obligations and
RH remain open. See `docs/zeta-riesz-signed-frequency.md` and
`docs/zeta-riesz-deviation-window.md`; keep the default whole-carrier
endpoint and both top-ten lists. No new zero-free theorem, numerical zero
bound or historical novelty is claimed by this slice.

Per the user's 2026-09-14 instruction, announce genuine arithmetic bounding
milestones in chat as they pass Lean. Name the controlled quantity, state
the bound's range and uniformity, and say what remains outside the bound.
Distinguish identities from estimates, component control from a bound for
the full signed tail, and local Lean success from exact-SHA CI success.
Do not describe an unevaluated tail allowance as a numerical zero bound.

1. Inspect `git status`, the imported theorem chain, the current dashboard
   data, and any newly supplied research dispatch before editing.
2. State the exact mathematical obstruction and the theorem that removes a
   concrete part of it. Check that its assumptions are available upstream.
3. Put new mathematics in a focused module with a module docstring and
   theorem-level documentation. Import it from `RiemannGaussian.lean` so the
   root environment and full build contain it.
4. Compile the changed module directly with warnings treated as errors.
5. Run the whole-package declaration linter, which includes every new public
   declaration. Use its verbose form during an audit when the individual
   results need to be recorded. Fix all findings; do not suppress them merely
   to pass.
6. Run `#print axioms` on the slice's terminal theorems. The result may contain
   only `propext`, `Classical.choice`, and `Quot.sound`.
7. Run the source placeholder scan, whole-project declaration lint, focused
   build, full build, generated-status check, and whitespace check described
   below.
8. Keep one `Current RH Proof Direction` section immediately below the proved
   zero-free and numerical-certificate sections. It replaces the separate
   `Current Direction` and top-level `Latest Update` sections. Its prominent
   explorer link and actual browser screenshot precede one direction paragraph
   of at most 500 characters. Keep `Latest Update` as a nested subsection.
   The stable direction changes only when the active branch or strategy has a
   material update; record why. Latest Update changes with every commit and
   describes that commit, including documentation or maintenance work without
   inventing mathematical progress. Replace entries rather than append history.
   Both are generated from `docs/rh-proof-explorer/metadata.json`; update the
   milestone list in `scripts/GenerateProjectStatus.lean` when and only when a
   new theorem genuinely advances the displayed frontier, then regenerate the
   artifacts.
   The generated panel is a theorem inventory, not a proximity meter: never
   draw a causal edge between milestones unless a checked theorem proves that
   implication, and label RH equivalences as reformulations rather than
   progress on their open direction.
   In the README, display only the latest proved zero-free region in its own
   `Proved Zero-Free Region` section immediately after the introduction. Display the
   bound prominently and link directly to the compiled Lean proof. Include
   a brief linked entry in `Accomplishments` too. State its exact bound and
   height-threshold scope, including whether the threshold is existential or
   numerically evaluated.
   When a stronger region is proved, replace the previous README presentation
   and remove references to superseded smaller regions, including historical
   comparison constants, duplicate table rows, and old accomplishment entries.
   Retain proof history and older bounds in the Lean sources and detailed
   documentation; the README is not a history of zero-free-region improvements.
   Keep `Accomplishments` to exactly ten major accomplishments. Select by
   mathematical significance, breadth and relevance to the project's goals,
   rather than recency or the number of new lemmas. A new entry may replace
   an existing one only if it is materially more significant; otherwise keep
   the result in its detailed documentation and the generated inventory.
   Limit `Notable Formalisations` to exactly ten significant results or
   frameworks as well, consolidating related theorem steps and selecting by
   mathematical significance rather than recency. New entries must displace
   less significant ones; the complete catalogue belongs in the family index.
   Keep `Mathematical Program` out of the README: the active program is already
   described by `Current RH Proof Direction`. The live GitHub renderer check
   must verify the ten-entry Notable table and the absence of that section.
   Consolidate related theorem steps into one result
   rather than spending multiple slots on the same advance. Preserve source
   attribution, scope and any unevaluated thresholds when shortening text.
   Place `Repository Structure` immediately after `Accomplishments`. Keep it
   compact: link the complete generated theorem-family index and give a short
   directory map; do not copy module inventories into the README. Preserve
   existing Lean source paths and imports, as requested by the user.
9. Apply the current theorem-push commit gate. Commit and push the complete
   slice only after its actual mathematical target and all verification
   gates pass. Track GitHub Actions on that exact commit SHA. Per the user's
   2026-09-13 instruction, continue local theorem work while CI runs.

Lake builds independent modules in parallel. Direct elaboration of one Lean
module is normally one process; do not mistake that focused check for the
parallel full-library build.

`ZetaRieszFrequencyDecay` now pays the complete growing low-frequency
allowance of both actual nonlinear prime classes. For every fixed P,
all heights and0<=u<=1, deleting0<=xi<=3(3/4)^N/(8(N+1)) has normalized
error at most C(P)(N+1)^2(27/28)^N->0. More generally every positive U,r
with r<=1 and2Ur^3<1 admits a summable tilt and one common bound for
arbitrary moving radii in[0,U] and moving heights. The window shrinks
exponentially; do not claim decay on the larger natural1/N sector.
The complementary coupled integral plus tapered wing retains exactly
-m+m^2c(u), with unrestricted multiplicity, exposure and the original
source range1/2<=u<exp(-2/3). Their independent joint bound is still open;
the deletion range does not enlarge the source range or prove nonvanishing.
`ZetaRieszPrimeEndpoint` separately bounds the complete actual three-prime
coefficient by log(n) times the minimum of1/2 and the largest-prime endpoint
taper, on the original upper-reflection support. Its finite negative-phase
cost is unpaid. Do not apply a full-coefficient amplitude bound to a
frequency sector. `TripleRieszProfile` retains the exact four margins for
ordered distinct primes; all margins are nonnegative on the actual annulus.
The one-small-pair chamber has the wing's exact endpoint weight, but no
cross-component cancellation has been proved. Replacing the actual largest
prime by its average loses the new improvement. Preserve all integer masks,
the floor-defined length, filter shifts, default whole-carrier endpoint and
both top-ten lists. See `docs/zeta-riesz-frequency-decay.md` and supporting
endpoint `frequency-sector-decay`. A zero-free theorem from this arithmetic
path remains the user's next major milestone; component progress is not it.

`ZetaRieszPrimeCountFrequency` retains the actual prime count through AM-GM.
For squarefree n with k>=4, the paired quotient on |xi| log(n)<=1 is bounded
by 2 |xi|^2 log(n)^4 / k^k. The full selected arithmetic integral on the
natural window d_N=3/(8(N+1)) has bound C(P,U,q)(N+1)^2(U/q)^N/K^K.
For K_j=2^(j+3), N_j=8(j+4)K_j, Lean proves K_j^K_j >= (17/16)^N_j and
N_j tends to infinity. Every fixed 0<U<17/32 admits a summable tilt giving
uniform decay for arbitrary moving heights and radii in [0,U]. This pays
only the k>=K_j low-frequency component, not all counts on that window.
The exact remainder is all frequencies with 3<=k<K_j, k>=K_j frequencies
above d_N, and the tapered wing. Their original exposed-zero source remains
-m+m^2c(u), with unrestricted multiplicity and u<exp(-2/3). The component's
radius ceiling is not a zero-free region or an enlargement of the source
range. Do not add this deletion to the earlier overlapping shrinking-sector
deletion without a new exact partition and error bound. The independent
joint signed bound, a zero-free theorem from this arithmetic path, and RH
remain open. Preserve the exact cutoff, count, filter and frequency data;
see `docs/zeta-riesz-prime-count-frequency.md` and its supporting explorer.

`ZetaRieszPrimeCountMass` now removes the complete k>=K_j integer class,
including all its frequencies, with K_j=2^(j+3), N_j=8(j+4)K_j. The full
squarefree mass with all 2^k divisor choices is at most exp(2rM(sigma))/r^K.
The genuinely summable count mass and factorial tilt give a uniform complete
arithmetic allowance. Its exp(C K_j) cost is subexponential in N_j and can
be absorbed for every fixed 0<U<17/32. Actual central-band support conditions
are discharged; radii, heights and positive lengths may move, and every fixed
polynomial filter is retained. The exact surviving source is now only the
full 3<=k<K_j signed integral plus the tapered wing. Their independent joint
bound remains open; unrestricted multiplicity, exposure and the original
u<exp(-2/3) source range remain. Do not label either component radius ceiling
a zero-free region, infer a percentage paid, or claim any fixed-count class
has vanished. `ZetaRieszPrimeCountWindow` also pays every moving prefix up to
the square root of the count threshold times the natural frequency window,
on its exact cofinal subsequence and below33/64. Its two-cutoff source theorem
combines the earlier overlapping frequency deletions by exact subtraction.
Retain these independent prefix bounds alongside whole-integer decay. See
`docs/zeta-riesz-whole-prime-count-decay.md` and supporting explorer endpoint
`whole-prime-count-decay`. The full signed floor, a new zero-free theorem from
this arithmetic path, and RH are still open. Standard exponential-moment and
AM-GM arguments are used without a historical novelty claim.

`ZetaRieszPrimeCountRightHalf` uses K_j=2^(j+3), M_j=(j+4)K_j to pay the
complete high-count integer class for every fixed 0<U<1, with arbitrary
moving radii in [0,U], heights, lengths and subbands. This trades the size
of the deleted class for a wider radius range; it does not extend the old
larger class unchanged. The exact intersection with the previous optimized
cofactor complement decays, leaving source -m for every right-half zero,
with full multiplicity and no exposure assumption. No wing decay or broader
range for the separate central-plus-wing identity is asserted.
`ZetaRieszSperner` cancels two smallest-prime fibres before bounding the
remaining divisor windows. They are antichains in the actual cofactor's
prime-subset lattice. The full coefficient has allowance
(log n)^2/(kL) times choose(k-2,floor((k-2)/2)), with all support conditions
discharged. The original finite-band theorem retains the complete factorial
filter; it does not prove decay of its full allowance. On the actual central
band this saves at least 2k over the coarse Boolean bound 2^k log n. Retain
the sharper middle-layer estimate and existing three-prime bounds together.
This controls cancellation within each integer, not across different
integers. The lower-count signed sum, a zero-free conclusion from this
arithmetic path, and RH remain open. Standard Sperner and exponential-moment
arguments carry no historical novelty claim. See
`docs/zeta-riesz-prime-count-sperner.md` and supporting explorer endpoint
`prime-count-sperner`; keep the default endpoints and both top-ten lists.

`ZetaRieszWindowGram` and `ZetaRieszWholeWindow` retain every original
prime-pair family in one exact complex interval lift. Its explicit Gram
bound keeps both Mobius factors, all complex filter amplitudes, prime
logarithms and physical window endpoints, with genuine integrability.
`exists_original_band_primeWindowGram` discharges all prime-selection and
support conditions and keeps the complete factorization certificate.
Do not replace its cross-family Gram form by separate family norms without
retaining the original identity and paying the resulting cost. The full
source-normalized signed energy bound remains open; energy positivity is
not smallness and no zero-free result follows from this slice.
`ZetaRieszSpernerRate` gives the actual central coefficient bound
2^k log(n)/(2k sqrt(k-1)), relative to the coarse Boolean allowance. Retain
the sharper binomial and earlier atom-specific bounds. `ZetaRieszWindowUnitDeletion`
proves the unit cofactor-divisor window absent for every actual central
atom with at least four prime factors; this does not remove the separate
Euler prime-head term. The central conclusions keep u<exp(-2/3); the
whole original carrier bound has no exposure or simplicity premise.
No external divisor-moment estimate is imported and no historical novelty
is claimed for the finite-interval or Cauchy--Schwarz identities. See
`docs/zeta-riesz-window-gram.md` and supporting endpoint `signed-window-gram`.
Keep the default endpoints and both top-ten lists unchanged.

`ZetaRieszWindowGcd` keeps the original amplitude at L while its shared
prime factor shifts only the window cutoff. Fixed-prime-pair comparable
divisors have zero overlap; negative Mobius overlap requires at least three
nonshared primes. This is not the sign of the full complex Gram entry.
`ZetaRieszCrossFamilyWindow` restricts comparable interactions with the SAME
first prime; do not generalize it to every changing first-prime scale.
`ZetaRieszPrimeReplacement`, `ZetaRieszReplacementPhase` and
`ZetaRieszReplacementFamily` prove an explicit whole-original-carrier bound
by absolute mass minus nonnegative savings from disjoint prime-to-product
pairs. Preserve the four-integer identity and both smaller terms unless
their actual profiles are proved saturated. Both full complex amplitude
costs are paid; the exact sine phase remains available alongside the
integer-gap bound. Prime support and injectivity prove no double counting.
Keep the exact unmatched remainder and original complex partition upstream.
Do not infer uniform positive saving, sufficient source-scale saving, a new
zero-free region, or RH from the nonnegative budget alone. No coverage
theorem across all prime triples or varying-first-prime correlations is
proved. Exploratory floating-point savings are not numeric certificates and
must not be rerun in ordinary CI. See `docs/zeta-riesz-prime-replacement.md`
and supporting endpoint `prime-replacement`; default endpoints and the two
top-ten lists remain unchanged.

`ZetaRieszCenteredCofactor` centers the complete zero-mass Mobius divisor
measure before estimating cutoff increments and the compact two-prime tent.
`ZetaRieszCenteredPhase` halves the complete opposite-prime allowance for
EVERY eligible nonunit squarefree cofactor, not only prime cofactors.
`ZetaRieszPrimeMatching` constructs all eligible pairs from the original
integer indices and their actual gcd; the fully proved costs feed a maximum
over every disjoint subfamily. Do not call this a proof of coverage or a
positive aggregate saving. `ZetaRieszPairMatching` retains the exact complex
pair/remainder partition before its norm bound. Keep that remainder and
cross-pair phases available. The separately improved prime-to-product
profile cost is not included in this prime-insertion candidate graph.
A fixed fractional gain need not beat the exponential source-scale cost.
No new zero-free theorem follows from this slice. Keep the default endpoint
and both top-ten lists unchanged; supporting endpoint `centered-cancellation`
and `docs/zeta-riesz-centered-cancellation.md` record its precise scope.

`ZetaRieszTentSlope` keeps the full two-prime tent one-Lipschitz and
quarters cutoff and complete phase costs for every composite squarefree
cofactor. `ZetaRieszDescendingAmplitude` retains exact factorial-coefficient
endpoint sums beyond all stationary points, including the derivative's
growth-minus-decay factor. Its eventual moving-cutoff theorem holds for each
fixed P and 0 < u < exp(-1/2), uniformly in height; the order threshold is not
numerically evaluated. `ZetaRieszSharpMatching` uses the smaller proved cost
where eligible and the prior refined cost elsewhere. The whole original
carrier needs no extra stationary hypothesis and retains the unmatched
remainder. Do not extrapolate finite percentage savings or constant-factor
cofactor improvements to a source-scale bound. Aggregate savings, coverage,
cross-pair cancellation and a new zero-free region remain open. Supporting
endpoint `sharp-matching` and `docs/zeta-riesz-sharp-matching.md` record the
scope; default endpoints and both top-ten lists remain unchanged.

`ZetaRieszMassTransport` splits equal mass across successive pairs, keeping
unused amplitudes on their original complex rays and retaining the full
sent vector sum. `ZetaRieszTransportPhase` preserves the full polynomial
directions; P=1 gives cosine chords for equal arithmetic signs and sine
chords for opposite signs. `ZetaRieszTransportCoverage` proves that a
complete pair fallback leaves at most one nonzero amplitude, and pays its
source-normalized unsent mass by diagonal energy for every fixed 0 < u < 1,
fixed full polynomial, and arbitrary height sequences. ALL fallback chord costs remain
in the whole bound: do not call this free coverage or sufficient aggregate
cancellation. `ZetaRieszTransportSource` retains the full actual source in
one signed sent sum, without exposure or simplicity. Its independent bound
and a new zero-free region remain open. Preserve midpoint phases and
cross-pair signs before summing chord norms. Supporting `mass-transport`
and `docs/zeta-riesz-mass-transport.md` record the scope; default endpoints
and both top-ten lists stay unchanged.

`ZetaRieszCycleCore` and `ZetaRieszCycleIteration` remove exact positive
three-direction zero cycles from the full original carrier, keeping every
remainder and preventing reused capacity. `ZetaRieszCycleSaving` proves
at least twice the smallest available amplitude is removed on each
successful branch. `ZetaRieszPairMidpoint` and `ZetaRieszCycleCorrelation`
retain common phases and full polynomial sine/cosine cross-correlations.
`ZetaRieszPhaseBracket` proves quadratic extra partner-mass overhead;
actual shortages remain in its minimum-capacity bound. Do not confuse
nearby-prime availability with sufficient weighted mass or aggregate
source-scale cancellation. `ZetaRieszCycleSource` preserves the full
source without exposure or simplicity; all later transport charges remain.
A sufficient independent whole remainder bound and a new zero-free region
remain open. Supporting `zero-cycles` and `docs/zeta-riesz-zero-cycles.md`
record the scope. Keep default endpoints and both top-ten lists unchanged.

`ZetaRieszTargetProfile` retains the exact signed cofactor profile at the
phase target, charging only small flank gaps. `ZetaRieszFullCycleSupply`
includes every complex polynomial and all nonunit squarefree cofactors,
using the half slope for prime cofactors and quarter slope for composites.
`ZetaRieszRetainedFraction` and `ZetaRieszCycleCapacity` preserve each
original remaining fraction and each oriented capacity. The central atom
is unrestricted, so cross-prime-count cycles are allowed. Earlier P=1
margin and sign identities remain useful but do not restrict the general
full-filter bound. `ZetaRieszArithmeticCycles` discharges every local
budget from literal tests, accumulates the actual arithmetic saving, and
bounds the whole original carrier. Its available-initial-budget filter
prevents uncredited steps from consuming later supply. All failed and
unselected terms stay included. The full source survives without exposure
or simplicity. Sufficient aggregate capacity or a cofinal strictly
sub-source allowance remains open; decay to zero is not required for the
contradiction. No new zero-free region follows yet. Supporting
`arithmetic-cycles` and `docs/zeta-riesz-arithmetic-cycles.md` record scope.
Keep default endpoints and both top-ten lists unchanged. Finite unfiltered
physical-annulus probes are not whole-band or asymptotic certificates.

`ZetaRieszPrimeCells` and `ZetaRieszCellBoundary` retain exact affine
cofactor profiles and signed corrections only at crossed divisor hinges.
`ZetaRieszCellOrders` keeps both adjacent factorial orders on the original
band; `ZetaRieszCellEnergy` retains their signed covariance. Unique
largest-prime ownership in `ZetaRieszOwnedCells` covers the full carrier.
`ZetaRieszRetainedCells` proves the cell norm allowance after actual
arithmetic cycles never exceeds the earlier allowance. Those individual
prime residual weights still need their own analytic control.
`ZetaRieszPrimeIntervals` and `ZetaRieszArithmeticCells` instead expose
fixed complete prime intervals independent of filter and height, including
zero-filter points. `ZetaRieszCellCycles` cancels whole interval responses,
leaving one constant scalar per cell. Ordinary prime interval estimates
may then be applied without an internal phase-selection mask, but such
sufficient estimates have not been proved. All full-pole-jet source
claims cover arbitrary multiplicity, no exposure assumption and the full
right-half source range. Sufficient cofinal aggregate saving, a new
zero-free region from this path and RH remain open. Supporting
`prime-cells` and `docs/zeta-riesz-prime-cells.md` give the exact scope.
Keep both adjacent moments and inter-cell signs available. Do not treat
an arbitrary residual prime mask as an unweighted interval or infer
unbounded-order control from small floating-point physical-annulus tests.
Keep default endpoints and both top-ten lists unchanged.

`ZetaRieszSmallCompositeCells` now independently pays the entire absolute
mass of composite owner cofactors with log a <= N/10. Its geometric bound
holds eventually for 1/2 <= u < exp(-2/3), every fixed full complex filter,
and all heights uniformly, including moving heights. Saturation forces
all surviving products into log m <= 3N/2, where the existing original
majorant gives geometric decay without a growing cofactor-count cost.
The whole corresponding cell norm mass also vanishes. The remaining
cells are semiprimes or composite cofactors larger than exp(N/10); their
joint signed bound is still open. The full pole-jet source remains after
this paid deletion, without exposure or simplicity, in the stated narrower
quantitative u-range. Do not promote this component estimate to a zero-free
region or claim an evaluated starting order. Supporting endpoint
`small-composite-cells` shares `docs/zeta-riesz-prime-cells.md`.

Per the user's 2026-09-16 instruction, pursue independent mathematical
tracks locally without subagents. Run focused Lean validation as changes
are made, and amortize full build, root audits, publication checks and CI
across a coherent batch of compatible slices. Do not omit required gates.

`ZetaRieszOwnerWindow`, `ZetaRieszOwnerMass`, `ZetaRieszOwnerCells` and
`ZetaRieszOwnerBounds` extend the independent composite-owner deletion.
The complete absolute mass up to exp(N/5) now decays geometrically for
0<u<exp(-2/3); the exp(N/10) class decays for 0<u<exp(-16/25).
Every fixed full complex filter and all heights, including moving ones,
are covered. The exact floor-defined length stays coupled to the source
radius; the original divisor majorant pays the whole support without a
separate cofactor-count factor. Across 1/2<u<1 except exp(-1/2), a positive
u-dependent exponential owner range is also proved, but do not claim one
fixed exponent there. The single scalar contact is a limitation of this
estimate, not a zero-location statement or a general impossibility result.
All selected complete cell norms vanish and the full pole-jet source
survives with the stated radius hypotheses, no exposure and no simplicity.
The starting order is unevaluated. Remaining semiprimes and larger
composite owner cofactors still need a joint signed bound. No new zero-free
region follows from these component estimates. Supporting endpoint
`owner-windows` and `docs/zeta-riesz-owner-windows.md` record this scope.
Keep earlier estimates, default endpoints and both top-ten lists.

## Commit and check-in invariant

The introductory research-agent/model statement belongs directly below the
repository summary and before `Proved Zero-Free Region`.

The third README section, `Current RH Proof Direction`, and its dedicated
`/rh-proof/` Pages explorer track the active RH campaign, independently of the
zero-free and numerical-certificate views. Its default endpoint is exactly
`campaign.frontierStatusPath` from `docs/rh-proof-explorer/metadata.json`,
resolved through compiled project status. End at the furthest **checked**
active theorem; show the remaining obstruction in prose, never as a proved
edge to RH. Keep the conditional source limit and all theorem hypotheses
visible. Reuse the shared family taxonomy, viewer, exact Lean source links,
compiled dependency exporter and full transitive axiom checks.

For every commit, increment `campaign.latestUpdate.sequence`, give it a new
`id`, and replace its title/body/next step with this commit's actual work.
Presentation and maintenance updates must be labelled as such and must not
claim new bounds. Change `campaign.direction` only for a branch change or
material strategy update, with a new `changeReason`. The tracked hook checks
the staged update against HEAD; CI checks the commit against its parent.
Keep the README's generated marker block intact and regenerate it with
`scripts/build_rh_proof_explorer.py`; never maintain duplicate status prose.

After ordinary Lean/status validation, export the dedicated graph using
`THEOREM_GRAPH_METADATA=docs/rh-proof-explorer/metadata.json` and
`THEOREM_GRAPH_OUTPUT=.lake/rh-proof-explorer/lean-graph.json` with
`scripts/ExportTheoremGraph.lean`. Run the dedicated builder, then the pinned
browser's `scripts/test_rh_proof_explorer.py --refresh-preview`, then the
builder's `--check`. Commit the real `preview.png` and its `preview.json`
input/capture audit. The screenshot must show the actual current default
explorer, not a hand-drawn graph. CI verifies its input and image hashes and
exercises desktop/mobile interaction, exact terminal/source lines, zoom,
conditional-source selection and the visible open obstruction. Do not demand
byte-identical rasterization across platforms. Run the live GitHub README
renderer check for the section placement, nested Latest Update, loaded linked
preview, mobile fit and introductory model statement. Stage all metadata,
README, viewer, source/audit and screenshot outputs together. After exact-SHA
CI and Pages deployment pass, verify the published third explorer and README.
See `docs/rh-proof-direction.md` for reproduction. These steps use the ordinary
root and must never trigger exhaustive numerical certificate verification.

The zero-free section's interactive theorem explorer is derived from the
compiled Lean dependency graph and the existing proof-status metadata.
Maintain logical families and optional theorem reading labels in
`docs/theorem-explorer/metadata.json`; theorem statements, docstrings, source
locations, dependency edges and transitive axiom audits come from Lean.
The same family metadata drives `docs/theorem-families/` and the Lean source
directory's landing page. Every project source module must have an
unambiguous family and be reachable from the ordinary root or the explicitly
optional `NumericalCertificate` root. Assign new modules
by an appropriate prefix or explicit override, then run
`scripts/build_theorem_explorer.py` to regenerate both indexes and explorer
assets. Its `--check` mode rejects missing, ambiguous or stale assignments and
stale generated pages. Keep one shared family taxonomy; do not hand-edit the
generated indexes or duplicate their full contents in the README.

Per the user's explicit numerical-certificate build instructions, exhaustive
certificate verification is opt-in. Keep generated `CertificateData` and every
module importing it out of `RiemannGaussian.lean` and `defaultTargets`; import
them from `NumericalCertificate.lean` instead. Normal CI and pre-commit builds
must not trigger those computations. The manual
`.github/workflows/numerical_certificate.yml` workflow checks prerequisite
data, eight disjoint cover shards, then the complete assembly and
`scripts/AuditNumericalCertificate.lean`. Caches accelerate unchanged inputs.
Hosted runners compile one prerequisite or two cover modules at a time and
have eight GiB of additional swap. The dedicated `NumericalCertificateData`
library owns only `RiemannGaussian.CertificateData` submodules. Its
performance-only `weakLeanArgs` disables asynchronous elaboration there,
preserving Lake's proof traces and independent module scheduling. Ordinary
proofs keep their established elaboration mode: changing it globally produced
a different generated-helper inventory between cached local and cold CI
builds. Do not weaken dashboard freshness or the complete axiom audit to
accommodate that difference. The hook and both CI workflows run
`test_numerical_certificate_build_config.py` after installing Lean; tiny
compiled probes check actual library ownership, elaboration modes and the
default import boundary without compiling certificate proofs. A strict
cold anchor check passed at about 7.5 GiB peak resident memory with that
setting; the asynchronous check exceeded its 12 GiB limit. Retain this
setting unless a replacement has a measured resource budget.
Progress reports include memory and disk
headroom. SIGTERM must stop the owned compiler process group and leave an
interrupted verdict, with no success marker; the regression includes an
actual spawned descendant. The first hosted run terminated while compiling
four anchor modules concurrently, so do not restore that concurrency without
a measured memory budget.
Artifacts from that same run transport checked prerequisites and all shards,
so cache eviction cannot remove a required inter-job dependency. The cold
option skips restored project certificate caches. Run the applicable
optional target and axiom audit locally when its proofs change; a default
build alone does not validate them. Preserve labels separating checked
components, the full cover, and an unconditional literal-count endpoint.
The final audit must type-check the actual unconditional dyadic and
cumulative statements and inspect their proof axioms before writing its
report. Run `scripts/test_numerical_certificate_audit.py` after the optional
target is built; it requires the genuine audit to pass before rejecting a
conditional replacement without a success report. Normal CI runs only the
fast build-boundary and scheduler regressions. Failed or changed-input runs
must remove stale success markers; partial jobs cannot claim a full result.
The current certificate work stays in this repository; an upstream PR is no
longer requested. See `docs/numerical-certificate.md` and its JSON metadata.

Use `python3 scripts/verify_numerical_certificate.py --jobs 4` for a cold
complete-cover build. It bounds concurrent heavy compiler processes and
retains each finished group's Lake artifacts. Small kernel reductions and
proved child-box equalities keep peak memory bounded; do not replace these
with one giant reduction of the entire tree. The driver records its live
process and progress and rejects an input digest change during the run.
Inspect that process before restarting; preserve completed artifacts. Keep
proof inputs stable while a verification run is active. Documentation outside
the input digest may be updated without interrupting it.

The README's `Proved Numerical Certificate: 67.31%` section belongs directly
after the zero-free section. Keep it compact: a live GitHub status badge for
`numerical_certificate.yml`, the literal eventual bound and unevaluated
height threshold, a comparison chart linked to its dedicated theorem explorer,
and exact-source, full-audit and successful-run links. The badge must link to
the actual optional workflow. Record a successful exhaustive run separately
from ordinary presentation CI; never substitute the latter as evidence of a
complete certificate. Compare with the attributed Anthropic/Zeta23 coefficient,
as well as its two-thirds headline. Distinguish the limiting coefficient
from the smaller closed rational endpoint and preserve epsilon conventions.

The certificate explorer is exported explicitly with
`scripts/build_numerical_certificate_explorer.py --refresh` after the optional
target is verified. It shares the ordinary explorer's family taxonomy and
interaction code. Its compact graph follows authored dependencies and marks
generated data as proof boundaries with full transitive axiom audits; link
the complete optional audit for all underlying data. Freeze the export with
the full optional input fingerprint, source hashes and exporter hash. Ordinary
CI and the hook run only `--check`, never `--refresh`, and reject stale
snapshots. Keep `docs/numerical-certificate/verification.json` attached to the
exact successful exhaustive run and matching input digest. Publish the
dedicated site under `/numerical-certificate/`, with presentation source links
pinned to the current ordinary CI commit.

Run lightweight `scripts/ExportNumericalCertificatePlot.lean` and
`scripts/build_numerical_certificate_plot.py` to regenerate the chart, rational
enclosures and drawing audit together. Display both full-scale context and
a labelled magnification; do not infer new bounds from plotted pixels. The
chart and explorer metadata live in their respective documentation directories.
Ordinary CI checks their freshness without importing `NumericalCertificate`.
The live GitHub README renderer check must verify this section's placement,
badge workflow link, chart load and desktop/mobile fit, and prominent explorer
link. Run the dedicated explorer browser check for metadata, source lines,
family zones, navigation and audit links before publishing, then check the
actual published site after exact-commit CI succeeds.

The README's `Proved Zero-Free Region` is the first section after the introduction.
Keep its mathematics in compact, readable display-math boxes using
`\boxed{\begin{gathered} ... \end{gathered}}` inside GitHub-supported math
blocks. Prefer fenced `math` blocks: they preserve TeX line breaks and
subscripts without Markdown escape processing. Write strict inequalities
with `\lt` instead of a bare `<`: GitHub's math renderer reparses formula
text as HTML, so `<L` or `<A` can swallow part of a formula and produce a
misleading "Missing close brace" error. Include assumptions and
endpoint conventions in the presentation;
do not leave formulas or coefficient ranges scattered in inline code.
Wrap each display box in a single-cell HTML table, with blank lines around
the fenced math block, so the frame remains visible when a browser's native
MathML renderer omits the `\boxed` border.
Show only the current proved union, with a direct Lean proof link. An
eventual component must state that its coefficient-dependent threshold is
unevaluated unless an actual numerical threshold has been proved.

Keep the colour comparison graph prominent at the start of `Proved Zero-Free
Region`. Its source annotations, colours and plotting ranges live in
`docs/zero-free-regions/metadata.json`. `scripts/ExportZeroFreePlot.lean`
checks the numerical expression trees against the actual imported width
definitions, the starting height and exact comparison endpoints. Run it after
the ordinary Lean build, then use the pinned environment in
`scripts/requirements-plots.txt` with `scripts/build_zero_free_plot.py`.
Commit the generated SVG, formula export and audit together. Do not edit
either plot audit before its corresponding theorem explorer is generated:
the zero-free plot hashes the main explorer audit, and the numerical plot
hashes the certificate explorer audit. Generate the explorers first, then
the plot artifacts, to avoid stale audit hashes at the commit gate. Do not edit
generated curves or copy their constants into a second plotting formula.
Update the checked formula interface when the proved region changes; its
endpoint must match the default proof-status theorem. Preserve `log(abs(t)+2)`
in the Gaussian curve, the exact crossover and ceiling, open/closed edges,
and the distinction between inspected and merely reported external results.
Never draw an eventual region from an invented finite starting height. The
overview must show heights where the external benchmark is stronger as well
as the magnified comparison interval; the graph does not establish a world
record or import an external analytic proof. Ordinary CI and pre-commit run
the exporter and `--check` to reject stale artifacts, without invoking the
optional numerical certificate. The GitHub README renderer check must also
verify the section title, graph placement, image load, enlargement link and
desktop/mobile fit. See `docs/zero-free-regions/README.md` for reproduction.

Keep benchmark details in `docs/zero-free-literature-frontier.md`, linked
from the compact zero-free section. Record source version, theorem/equation,
height range, open/closed edge, proof or retrieval status, and the relevant
compiled comparison theorem. Distinguish inequalities between explicit
width functions from importing external zero-free proofs. Preserve the
exact crossover and ceiling, including the enlarged height's `+2`; strict
improvement excludes the crossover where widths tie. No exhaustive record
claim follows from checking only headline constants or from an eventual
bound with an unevaluated threshold.

The interactive explorer belongs inside that same README section as a
linked preview and compact links, with the full interface on GitHub Pages.
Place a prominent, descriptive link immediately above or alongside the
clickable preview so readers know to open the interactive explorer.
It must support zooming, theorem selection and hover metadata, coloured
logical-family zones, and links to the exact Lean file and declaration line.
Expose the evergreen repository metadata and proof audits alongside it.
Do not hand-maintain theorem statements, source lines, dependency edges or
audit verdicts in the README or generated site. For a new comparison or
terminal endpoint, update its status references and reading labels in the
metadata; retain the actual zero-free conclusion as the default endpoint.
After changing an endpoint or its dependencies, run
`scripts/ExportTheoremGraph.lean` and `scripts/build_theorem_explorer.py`, then
check the generated assets and run `scripts/check_theorem_graph.cjs` and the
browser interaction checks. Every compressed edge must have an exported
dependency-path witness. Keep the README presentation to the linked preview
and its compact explorer/metadata/audit links. Publish only a verified source
snapshot, with GitHub links pinned to its commit; respect the user's current
commit and push instructions.
Check the rendered README math and the explorer at desktop and narrow
viewport widths after presentation changes. Confirm navigation, source-line
links and audit links in the published artifact after exact-commit CI passes.
For every README presentation change, run `scripts/test_github_readme.py`
with the pinned Playwright browser before committing. It sends the working
README through GitHub's Markdown API and its live `math-renderer` component;
a standalone MathJax render is not a substitute. Require every math block to
render without an error, retain its box and fit its available width at
desktop and mobile sizes. Wait for a loaded graph and positive visible
layout together before measuring it; GitHub hydration can temporarily
replace an article. Keep all fit, placement and math assertions enforced.
This check is also a mandatory CI step before
Pages publication. After pushing, run it again with `--published` to check
the actual README page at the exact current commit. A network or renderer
failure is a failed check, not a reason to claim rendering success. The
script writes screenshots and a JSON report under `.lake/github-readme/`.

The repository history is the durable record of verified progress. Enforce
this regime yourself; do not rely on the user to request individual commits,
pushes, or CI checks.

- The user authorized parallel theorem development and CI on 2026-09-13,
  and reaffirmed this on 2026-09-14, until further notice. Continue local work while CI checks a committed
  snapshot; keep verification and publication claims attached to that exact
  SHA. This supersedes earlier instructions to wait before starting a slice.
- The user also authorized committing and pushing all accumulated work once
  the complete numerical certificate and its optional cached CI workflow are
  ready. Preserve the running verifier's frozen inputs until it finishes;
  partial cover verification is not readiness of the literal-count endpoint.
- Keep one coherent mathematical slice per commit. Include infrastructure or
  documentation changes needed by that theorem advance. Do not mix unrelated
  cleanup into the slice.
- Before committing, stage the complete intended slice and verify the staged
  content with all applicable local gates, `git diff --cached --check`, and
  the tracked pre-commit hook. Documentation-only and CI-only commits are not
  exempt from the gate.
- Do not bypass the pre-commit hook. If an exceptional environment prevents
  the hook from running, execute every command it enforces manually and record
  that fact in the handoff.
- Push each passing commit promptly, record its full SHA, locate the workflow
  run whose `headSha` is exactly that SHA, and require a `success` conclusion.
- While exact-SHA CI is pending, continue local proof work. If CI fails,
  prioritize its repair, preserve later local work, rerun affected gates and
  verify the repair commit. Do not report a pending or failed SHA as green.
- Progress reports and handoffs must distinguish local success from remote
  verification and should cite both the exact commit SHA and CI run number.

## Mandatory local gates

Use the repository's pinned Lean toolchain. In environments where `lake` is
not already on `PATH`, invoke the pinned binary through the configured
`ELAN_HOME` rather than changing the project version.

Enable the tracked pre-commit gate once in every fresh clone:

```bash
git config core.hooksPath .githooks
```

The hook repeats the staged placeholder scan, warning-as-error build,
whole-project declaration lint, compiled-environment/dashboard audit, and
staged whitespace check. CI remains authoritative because local hooks can be
bypassed and a partially staged commit may differ from the working tree.

For a changed module `RiemannGaussian/NewSlice.lean`, the minimum gate is:

```bash
lake env lean -DwarningAsError=true RiemannGaussian/NewSlice.lean
lake env lean -DwarningAsError=true /tmp/RiemannGaussianAudit.lean
if git grep -nE '\<(sorry|admit|sorryAx)\>' -- '*.lean'; then exit 1; fi
lake env lean -DwarningAsError=true scripts/LintProject.lean
lake build RiemannGaussian.NewSlice --wfail
lake build --wfail
lake env lean -DwarningAsError=true scripts/GenerateProjectStatus.lean
git diff --exit-code -- docs/proof-status.json docs/proof-status.svg
git diff --check
```

The temporary audit file must import the root library. Its verbose lint command
and explicit axiom commands for terminal theorems have this form:

```lean
import RiemannGaussian
import Mathlib.Tactic.Linter
#lint+ in RiemannGaussian
#print axioms RiemannGaussian.newFrontierTheorem
```

The generator is also a soundness gate. It scans every declaration in
compiled project modules for indirect placeholder dependencies, rejects all
project-defined axioms and disallowed transitive axioms, and verifies that
every green dashboard milestone is an actual project theorem using only the
three permitted standard axioms.

Public status language is an additional gate: never describe an abstract or
conditional `13/18` statement as a result. Until a theorem over literal zeta
counts discharges the required eta-arithmetic inequality, README, dashboard,
commit messages, and handoffs must say that no `13/18` certificate exists.

## GitHub gate

Do not infer remote success from a local build or from a workflow attached to
another commit. After pushing:

1. Record `git rev-parse HEAD`.
2. Locate the GitHub Actions run whose `headSha` is exactly that value.
3. Wait for it to finish and require conclusion `success`.
4. Record that the checked snapshot is green. Later local changes still
   require their own gates before being committed.

If CI fails, repair the same slice, rerun every affected local gate, push the
repair, and verify the new exact commit. The user permits continued local
mathematical work during CI; preserve exact-SHA status throughout.

## Research discipline

The user-requested boundary-renewal test is recorded in
`docs/zeta-riesz-boundary-renewal-audit.md`. The exact two-large threshold
is log(p)>=log(n)-L, not p>N^2. `ZetaRieszPairBoundary` derives saturation
from that literal support, proves the positive/negative boundary split,
and evaluates the innermost layer. `ZetaRieszLeastPrimeRenewal` proves
a terminating least-prime tree and its exact application to `pairForm`,
retaining every original mask, allocation weight, incidence denominator,
phase and unsaturated correction. `ZetaRieszRenewalWeightAudit` proves
that prime deletion leaves the original unit log cell and gives no strict
density-kernel contraction below the saddle. These are infrastructure and
specific transfer obstructions, not a quantitative gain for the actual
signed sum or a general impossibility theorem for renewal. The independent
power saving, signed floor and restricted exclusion remain open. Do not
weaken or rename `LocalizedTypeIIBound`, advance the public source frontier,
or report this investigation as a successful arithmetic endgame. Further
work needs a bound for the weighted signed error of a model, not another
completion or unweighted renewal identity.

The harmonic Type-II go/no-go test is recorded in
`docs/zeta-riesz-typeii-go-no-go.md`. Decision: no-go with current inputs;
stop expanding this route without a new independent arithmetic estimate.
`ZetaRieszTypeIILocalization` proves `exists_narrow_window_error` in namespace
`ZetaRieszTypeII`: it pays the tails outside 1.95N<log(n)<=2.05N, uniformly
for 0<=u<=5001/10000. `ZetaRieszTypeIIReduction` defines the literal
`LocalizedTypeIIBound` and proves its implication to the eventual -3/40
floor and the simple-exposed-zero contradiction. The 1/1000 power saving
is an explicit UNPROVED hypothesis, with fixed C,A and original cofinal
orders. The checked normalized rate is 1667/1670. Do not report this
conditional transport as an independent floor or zero-free region.
`ZetaRieszPairDiscrepancy` retains the unsaturated three-cutoff correction
and averages ordered prime pairs by omega(n)(omega(n)-1). The shorter
Lambda-minus-hinge formula requires saturation; its error is not paid
on the entire carrier. `ZetaRieszTypeIIRateAudit` checks the log/power rate
mismatch and eventual failure of the growing-height VMVT rectangle at
fixed height. These are applicability obstructions, not a proof that the
actual cancellation estimate is false or equivalent to full RH.
Keep the existing whole-carrier source as the public frontier. Reopen
this route only with an actual signed estimate or a weaker direct
one-sided floor with independently paid source-scale errors.

The signed symmetric completion audit is in
`docs/zeta-riesz-symmetric-completion-audit.md`. The obstruction's surviving
balanced three-prime boxes fail `LinearClass`: their pair-saturated
coefficient is `t*(t-L)/L`, not `t*(2*L-t)/L`. The complete Newton and D,K
operator identities do not remove this cutoff correction. The explicit
`balancedTripleBand` now has a proved allocation-removal error bounded by
`C*(N+1)*sectorRate^N`, with `sectorRate<1`, using the existing balanced
companion estimate. This pays only that error on the stated subband. The
complete signed generating function specializes to `1/zeta(s)` at `z=1`;
do not apply the unsigned squarefree response's analyticity to it. The
signed floor, complete-series mask transfer and restricted zero exclusion
remain open; do not report these identities as an arithmetic floor.

- Prefer exact identities, coercion lemmas, summable dominators, and explicit
  quantitative estimates that can be reused downstream.
- Distinguish finite-window, infinite-sum, boundary-limit, and large-height
  statements in names and hypotheses.
- Treat division, logarithmic derivatives, contour deformation, exchanged
  limits, derivatives under integrals, and sum-integral swaps as proof
  obligations requiring their own hypotheses and Lean theorems.
- New mathematics is welcome. Grow it from the checked chain, isolate its
  genuinely novel lemma, test finite or numerical shadows when useful, and
  then prove the general statement in Lean.
- Never claim RH is proved until the completion audit reaches an unconditional
  term of `RiemannHypothesis` and all local and exact-commit remote gates pass.
