from pathlib import Path
import hashlib
import json
import re
import subprocess

out = Path('.lake/riesz-balanced-owner-floor')
source = Path('RiemannGaussian/ZetaRieszBalancedOwnerFloor.lean')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '194a361762f404a8f4473298b25d96fbae0bb56e'
previous_path = Path('docs/riesz-all-tag-native-floor-audit.json')
previous = json.loads(previous_path.read_text())
root = Path('.lake/build/lib/lean/RiemannGaussian.olean')
root_sha = hashlib.sha256(root.read_bytes()).hexdigest()
assert any(p['path'] == str(root) and p['sha256'] == root_sha
           for p in previous['compiledArtifacts'])
for p in previous['sources']:
    if p['path'].startswith('RiemannGaussian/'):
        assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest() == p['sha256']

logs = [out/'strict-lean.log', out/'build.log', out/'audit.log']
for path in logs:
    text = path.read_text()
    assert not re.search(r'^(error|warning):|: error:|: warning:', text, re.M), path
assert 'Build completed successfully' in (out/'build.log').read_text()
lint = (out/'audit.log').read_text()
assert lint.count('All linting checks passed') == 1
assert lint.count('Found 0 errors') == 1
assert lint.count('with 14 linters') == 1
axioms = json.loads((out/'axioms.json').read_text())
assert axioms['module'] == 'RiemannGaussian.ZetaRieszBalancedOwnerFloor'
assert axioms['onlyStandardAxioms']
for theorem in axioms['theoremAxioms']:
    assert set(theorem['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}


def saved(path):
    path = Path(path)
    data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    snapshot = out/f'snapshot-{sha}{path.suffix}'
    if snapshot.exists():
        assert snapshot.read_bytes() == data
    else:
        snapshot.write_bytes(data)
    return dict(path=str(path), sha256=sha, snapshot=str(snapshot))


text = source.read_text()
code = re.sub(r'/\-.*?\-/', '', text, flags=re.S)
assert not re.search(r'\b(sorry|admit|sorryAx)\b', code)
assert not any(line.rstrip() != line for line in text.splitlines())

report = dict(
    schemaVersion=1, date='2026-10-03', head=head,
    objective='Close out the floor.', goalRemainsActive=True,
    slice='Independently pay ALL native high-owner labels jointly with the signed prime head; spend the disjoint geometric owner payment and exact zero labels before clipping the remaining balanced/head aggregate.',
    sources=[saved(p) for p in [
        source,
        'RiemannGaussian/ZetaRieszAllTagNativeFloor.lean',
        'RiemannGaussian/ZetaRieszPrimeHeadPeriods.lean',
        'RiemannGaussian/ZetaRieszJointOwnerEnvelope.lean',
        'RiemannGaussian/ZetaRieszSmallTagNativeFloor.lean',
        'RiemannGaussian/ZetaRieszRoughPrimePairCancellation.lean',
        'RiemannGaussian/ZetaRieszJointCountFloor.lean',
        'RiemannGaussian/ZetaRieszJointPrimeEnergy.lean',
        'RiemannGaussian/ZetaRieszMaskSupport.lean',
        'RiemannGaussian/ZetaRieszComplexNullFloor.lean',
        'RiemannGaussian/ZetaRieszCutoffPeriodFloor.lean',
        'RiemannGaussian/ZetaRieszComplexProjection.lean',
        'RiemannGaussian/ZetaRieszEndgameSlack.lean',
        'docs/zeta-riesz-balanced-owner-floor.md', previous_path,
        'AGENTS.md', 'lean-toolchain', 'lake-manifest.json']],
    compiledArtifacts=[saved(p) for p in [
        '.lake/build/lib/lean/RiemannGaussian/ZetaRieszBalancedOwnerFloor.olean', root]],
    validation=dict(
        scope='Focused local only: strict leaf source, targeted leaf build, frozen compiled ordinary root plus explicit leaf. No root-source rebuild or wider gates.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(source), exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszBalancedOwnerFloor --wfail', exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(out/'Audit.lean'), exitCode=0,
            compiledOrdinaryRootImported=True, explicitLeafImported=True,
            frozenCompiledRootMatchesPrevious=True, rootSourceNotRebuilt=True,
            namespaces=1, lintersPerNamespace=14, allNamespaceLintersPass=True),
        publicTheorems=len(re.findall(r'^theorem [A-Za-z_]', text, re.M)),
        publicDefinitions=len(re.findall(r'^def [A-Za-z_]', text, re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheoremsIncludingPrivateAndGenerated=axioms['theoremsIncludingPrivateHelpers'],
        everyCompiledDeclarationAxiomChecked=True, onlyStandardAxioms=True,
        previousFrozenProofSourcesPreserved=True),
    exactResults=dict(
        radiusRange='1/2<u<=10001/20000', fixedHeight='abs(y)>=54',
        unchangedCoreTotalLogRange=['39N/20 strict','203N/100 closed'],
        unchangedOriginalNativeCountCropAndPhysicalMasks=True,
        unchangedFullAllocationFactorialKernelAndPhase=True,
        geometricPaymentOnlyOnLabelsOutsidePreviousFullOwnerPayment=True,
        additionalBudget='6*divisorSquareDirichletMass(1+1/262144)*(N+1)*exp(-N/25000)',
        arbitraryNativeMasksRetainedInLiteralPopulationInput=True,
        anyOtherHighOwnerResidualCoefficientExactlyZero=True,
        everyNativeHighOwnerLabelIncluded='log(largestPrime n)>=51N/50',
        independentSignedJointBound='abs(highPacket_j+nativeHead(N_j))<=previousCombinedBudget_j+literalErrorBudget(N_j) -> 0',
        independentOfZeroExposureAndUnprovedArithmeticHypotheses=True,
        highPopulationAndHeadSeparatelySmallClaimed=False,
        independentJointComplexNormDecayClaimed=False,
        exactRemainingPopulation='native squarefree labels with log(largestPrime n)<51N/50',
        strictRemainingOwnerShare='log(largestPrime n)/log n < 34/65',
        remainingBalancedSumMinusHeadSourceEquivalentToWholeNativeRealCarrier=True,
        noRemainingCountOrLeastPrimeSubclassDeletion=True,
        wholeHighOwnerPaymentActuallySpentBeforePeriodClipping=True,
        zeroResponseLabelsRemovedByExactTotalsNotAbsoluteVariation=True,
        wholeFreeNullAndTangentColumnsRetained=True,
        sameNativeErrorRetained=True,
        signedHeadJoinedWithRemainingMainBeforeClipping=True,
        oldWholePricesPreservedAsAlternativesNotOverlappingCredits=True,
        monotonicityOfClippedCostsUnderDeletionNotAssumed=True,
        noPercentageOfWholeFloorDeficitClaimed=True),
    openPremises=dict(
        remainingSignedTarget='balanced-owner real remainder minus the exact signed prime correction',
        cofinalWholePrice='price<=399/5000 on a cofinal set of dyadic indices',
        wholeFloorProved=False, multiplicityCeilingProved=False,
        restrictedContradictionProved=False, zeroExclusionProved=False, rhProved=False,
        conditionalEndpointNotCountedAsPremiseProof=True),
    publication=dict(localOnly=True, noCommitsOrPushes=True, noSubagents=True,
        noRootRegistration=True, publicEndpointsUnchanged=True,
        noReadmeExplorerChanges=True, concurrentSemiprimeWorkPreserved=True),
    provenance=[saved(p) for p in logs+[out/'Audit.lean', out/'axioms.json', Path(__file__)]])

blob = json.dumps(report, indent=2)+'\n'
(out/'report.json').write_text(blob)
Path('docs/riesz-balanced-owner-floor-audit.json').write_text(blob)
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    compiledTheorems=report['validation']['compiledTheoremsIncludingPrivateAndGenerated'],
    previousProofSourcesAndRootPreserved=True, floorRemainsOpen=True)))
