# Native angular square-cube joint preflight

Read-only audit. No new Lean declaration, assumed bilinear bound, arithmetic
credit, source continuation, zero exclusion or whole-family no-go.

## Exact native interaction retained

The imported principal frequency join cancels odd local J valuations, so
its principal Euler source has J=V^2. This is NOT an identity deleting odd J
from the literal physical inverse row. In the P-unrelated matching branch,
I=P I0 and B=I0 V^6. Every V power, original ideal support, Mobius/eta I0
coefficient, matching prime, Gaussian length, calibration, height phase and
nonunit zero remain.

The full physical inverse summand is

    columnWeight(Psi,I)/sqrt(NI) * cubeWeight(Psi,J)
      * Vstar W(NI*NJ^3/T).

On J=V^2 its exact cube multiplier is

    star angular(V)^6 * Psi(V)^6 / NV^2,

and the moving length is NI*NV^6/T. The square-root normalization changes
the V power to NV/sqrt(T), before the remaining smooth W. The sixth power
of the actual numerator row is the imported coprimality mask(V,m), not a
missing phase. The exterior angular-six/base factor remains; calibration
and eta/base factors must not be silently identified or discarded.

## Existing Poisson: abstract identity available, uniform estimate missing

HeckeFamily.Character and the imported HeckeTheta theta/latticeL use a
finite residue coefficient with radial normForm Gaussian. The checked
AngularPeriodAudit excludes identifying the actual angular-six coefficient
with any such finite ray coefficient. It excludes that direct substitution,
not harmonic theta or analytic continuation.

Crucial scope correction: the imported actual_eisenstein_periodic_poisson
and actual_joint_periodic_poisson ALREADY accept arbitrary Schwartz
functions. A smooth angular-annular profile, supported away from the origin,
can in principle be supplied as the Schwartz factor, with the actual finite
coprimality/calibration table supplied separately. Thus no new ABSTRACT
Poisson formula is needed. A noncompact Gaussian/angular profile needs its
origin regularity justified, rather than being silently declared Schwartz.

What does not follow is a uniform signed bound after the actual growing
m/I0/V mask and its native cutoffs are joined. The period/conductor still
grows. A fixed-conductor Fourier transform or continuation does not pay the
whole native correlated row. Expanding a coprimality mask through ideal
Mobius divisors is exact, but changes the Gaussian lengths and leaves the
same signed large-divisor/boundary budget. No new estimate has been supplied
by that reindexing.

## Source gate precedes any arithmetic credit

The checked principal angular coordinate is

    R_P(s) = angularCharacter_eta(P) * Norm(P)^(-(6s-3)).

The standard absolute-Euler domain is Re(s)>2/3. There the EXACT checked
relation is

    residualCorrection = product_P(1-R_P) * principalCorrection.

Only after a separate angular Euler/continuation bridge may this be written
principalCorrection = residualCorrection * L_ang(6s-3). The direction is
MULTIPLICATION by L_ang, not division. Angular continuation alone can
therefore cancel a reciprocal target-L source.

Conditional on the usual analytic/nonzero remaining factors, the source
at a target zero rho survives precisely when

    ord L_ang(6rho-3) < ord L_eta(rho).

The affine map with derivative 6 preserves local zero order. This is the
missing source condition, not a claim that an angular/eta zero coincidence
actually occurs. Neither generic Schwartz Poisson, finite-ray radial theta,
nor mere entire harmonic continuation proves this inequality. No source
fraction for an isolated growing-V sector is established below 2/3.

## Quantitative target if both gates can be supplied

The native all-row arithmetic bound currently has exponent
3/16+256epsilon. The original marked source scale, with total slot exponent
1/6, is beta-11/16. Therefore a replacement estimate must be

    o(Z^(beta-11/16)),

and must improve the old exponent by more than 7/8-beta (and its epsilon
loss), while preserving the actual residue. Near beta=1/2 this is nearly
3/8 of exponent saving. This is a conditional benchmark; no lower-strip
source/contour extension or arithmetic estimate follows from it.

The genuine radical-period opportunity is narrower: on principal squares,
i+6v=11/16 and the safe short-volume/full-period exponent is

    >= -1/3-d+5v.

At worst d=1/6 it is positive only for v>1/10 using this bound, while the
admitted maximum is 11/96. The range has width 7/480; its best nominal gap
is 7/96. V=1 and smaller V are untouched. Above 2/3 the convergent angular
Euler channel places small source in growing-V tails; below 2/3 no such
conclusion is licensed by absolute Euler counting. Physical odd J are also
still in the literal ledger until separately joined/paid.

## Verdict

The native square-cube identity supplies genuine sector-dependent radical
geometry. The existing generic Schwartz Poisson identity can retain the
angular annulus, but no imported theorem currently converts it to the
required uniform source-preserving signed growing-cofactor estimate.
Independently, the angular-zero-order noncancellation gate is open. Freeze
an angular-continuation-only shortcut; retain large-V joint estimation as
an unproved arithmetic possibility, with small V and the actual source
condition explicit. This does not exhaust the operator interaction.
