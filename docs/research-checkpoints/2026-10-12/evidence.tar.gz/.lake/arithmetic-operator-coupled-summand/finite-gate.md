# Actual Gaussian/completed-coefficient matching gate

Checked leaf: `scripts/QuasiRHCoupledSummandAudit.lean`.

The exact complete inverse summand, for every ideal I,J and every numerator m,
retains its squarefree Gauss column, all J powers, window/Gaussian and height:

    summand(rowTwist(Psi,a,f,m),W,X,I,J)
      = summand(rowTwist(Psi,a,f,1),W,X,I,J)
        * idealRowHom(m,I*J^3).

This includes zero/nonprimary columns. No separate complete-leg limit, free
inverse array, squarefree-only J restriction, or mask replacement is used.

For an actual permitted prime P=span(p), I=P, J=P^(2t), multiply by the
actual sexticGauss(p,-m). The joined product is zero on m in P and otherwise
is exactly the m-independent native summand at m=1 times the actual complex
matching Gauss constant. Every finite exterior complex weight therefore
remains one signed sum over m outside P. Annulus, Mellin, ray and ordinate
weights may all be included; they are not replaced by absolute values.

The matching Gauss constant is proved nonzero with its true phase. If the
native coefficient and punctured signed mass are nonzero, the joined sum
is nonzero. Thus actual squarefree/cube support and the retained Gaussian
window do not supply automatic local orthogonality. This is a scoped
inference obstruction, NOT an independent bound for the punctured mass.

The shared-prime cofactor lift is also exact:

    idealRowHom(m,P^(6t+1)*B) * sexticGauss(p,-m)
      = 1_(m outside P) * actualMatchingConstant * idealRowHom(m,B).

All phases and divisibility of B remain. Their signed correlation with m
and the actual prime index is precisely what this identity does not pay.
No global cutoff/completion error, cofinal zero source or zero exclusion
is inferred. Arbitrary exterior weights are permitted in the identity;
free/smooth/generalized controls are not granted the actual native ideal,
character, Gaussian or inverse compatibility.

Validation: final cached strict compile exit 0; 15 namespace linters;
10 all-local declarations / 7 theorems including generated helpers;
module-provenance axiom audit allows only propext, Classical.choice and
Quot.sound. The unchanged historical dependency is not counted as new.
