# Published cuspidal Type-II estimate: exact input gate

The downloaded primary paper is Alexander Dunn, *Metaplectic cusp forms
and the large sieve*, arXiv:2403.13151. Its initial setup requires a
**cuspidal** cubic metaplectic form `f` on `Γ₂`; in particular it vanishes
at every cusp. Theorem 1.5 uses that setup and bounds the bilinear sum
of `ρ_f(λ⁻³ab)` for squarefree `a`, preserving the congruence and smooth
norm window. Its displayed upper bound is

```
(X K Norm(v))^ε K^8 Norm(v)^4
  ((AB)^(1/2) + A^(3/2) B^(1/4)) ||μ²α||∞ ||β||₂.
```

The formal audit does not import or assert this external estimate. It
checks one NECESSARY input condition before any attempted import.

The actual inverse `I*J³` coefficients are identified by the imported
`normalized_infinityCoefficient_squarefree_cube` with

```
infinityCoefficientScalar⁻¹
  * star(sourceResidualFourierCoefficient(g(I)*g(J)^3)).
```

Every arbitrary nonzero `J` is retained, with only `I` squarefree. The
actual coefficient RHS keeps the angular/ramified-symbol phase and
`gaussTwo(I)`; no arbitrary coefficient family substitutes for it.

The source is the cubic Eisenstein residual. The imported exact theorems
give its nonzero average on the literal cusp strip `5 ≤ height ≤ 6`, both
before and after native source projection. The native coefficient's
nonzero scalar normalization and conjugation also preserve a nonzero
average. The new checked endpoint therefore says this ACTUAL normalized
source fails the zero-average necessary condition for direct substitution
as the cuspidal input.

This is narrowly an applicability obstruction. It does not prove that no
different cusp form could represent some selected coefficient component;
nor does it deny a spectral/cuspidal decomposition. It gives the exact
ledger for such a decomposition: subtracting any zero-average quotient
vector leaves the entire nonzero native strip average in the remainder.
No theorem here identifies which component would retain a hypothetical
zeta-zero source. That separate source bridge must precede any use of the
external bound after projection.

Proof: `scripts/QuasiRHCuspidalInputAudit.lean`.
The final isolated strict command was

```
/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true \
  -o .lake/build/lib/lean/scripts/QuasiRHCuspidalInputAudit.olean \
  scripts/QuasiRHCuspidalInputAudit.lean
```

It exited 0. Actual stdout/stderr is preserved in `strict-build.log`.
All 28 local declarations, including private/generated helpers, use
only `propext`, `Classical.choice`, `Quot.sound`; 22 are theorems.
The namespace passes all 15 linters. `axioms.json` contains the full
module-provenance audit, not merely a public-name prefix scan.
No shared docs, vendor proofs, registrations or broad gates were changed.
