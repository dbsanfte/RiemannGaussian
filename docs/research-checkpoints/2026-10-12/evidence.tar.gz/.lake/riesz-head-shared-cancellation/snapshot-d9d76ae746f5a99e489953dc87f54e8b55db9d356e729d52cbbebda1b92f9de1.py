from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess


folder = Path('.lake/riesz-head-shared-cancellation')
leaf = Path('RiemannGaussian/ZetaRieszHeadSharedCancellation.lean')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot(path):
    path = Path(path)
    sha = digest(path)
    target = folder / f'snapshot-{sha}{path.suffix}'
    if not target.exists():
        shutil.copy2(path, target)
    return dict(path=str(path), sha256=sha, snapshot=str(target))


previous_path = Path('docs/riesz-prime-head-pole-payment-audit.json')
previous = json.loads(previous_path.read_text())
for section in ['sources', 'compiledArtifacts', 'provenance']:
    for source in previous[section]:
        if source['path'] != 'AGENTS.md':
            assert digest(source['path']) == source['sha256'], source['path']
axioms = json.loads((folder / 'axioms.json').read_text())
assert axioms['onlyStandardAxioms']
assert (folder / 'strict-lean.log').read_text() == ''
assert 'Build completed successfully' in (folder / 'build.log').read_text()
assert '-- All linting checks passed!' in (folder / 'audit.log').read_text()
proof = leaf.read_text()
assert not re.search(r'\b(sorry|admit|sorryAx|axiom)\b', proof)
probe_path = Path('.lake/riesz-joint-interference/probe.json')
stress_path = Path('.lake/riesz-joint-interference/high-height-probe.json')
probe, stress = (json.loads(p.read_text()) for p in [probe_path, stress_path])
assert len(probe['cases']) == 180 and probe['frozenComplexRegressions'] == 18
assert len(stress['cases']) == 28 and stress['frozenComplexRegressions'] == 4
for run in [probe, stress]:
    for source in run['sourceHashes']:
        assert digest(source['path']) == source['sha256'], source['path']
    assert all(r['higherCountNonownerOverlapExactZeroByIntegerSignature']
               and r['wholeSharedPrimeProfileIsOwnerPlusTripleNonowner']
               and r['allCountsAndSameFullComplexHeadRetained']
               and r['noArtificialPrimeOrCountPhaseRotation'] for r in run['cases'])
assert all(r['signedSameLeastPrimeCrossEnergy'] < 0 for r in probe['cases'])
stress_reinforcing = [r for r in stress['cases'] if r['signedSameLeastPrimeCrossEnergy'] > 0]
assert len(stress_reinforcing) == 11
assert sum(r['signedCrossCountEnergy'] > 0 for r in probe['cases']) == 13
paths = [leaf, Path('RiemannGaussian/ZetaRieszPrimeHeadPolePayment.lean'),
    Path('RiemannGaussian/ZetaRieszBalancedRadialPayment.lean'),
    Path('RiemannGaussian/ZetaRieszBalancedOwnerFloor.lean'),
    Path('RiemannGaussian/ZetaRieszPairDiscrepancy.lean'),
    Path('RiemannGaussian/ZetaRieszSignedConvolution.lean'),
    Path('RiemannGaussian/ZetaRieszPostHingeEnergy.lean'),
    Path('RiemannGaussian/ZetaRieszSmallTagNativeFloor.lean'),
    Path('scripts/probe_riesz_joint_interference.py'),
    Path('scripts/probe_riesz_balanced_joint.py'),
    Path('scripts/probe_riesz_balanced_signature.py'),
    Path('docs/zeta-riesz-head-shared-cancellation.md'), previous_path,
    Path('AGENTS.md'), Path('lean-toolchain'), Path('lake-manifest.json')]
lines = {match.group(1): proof[:match.start()].count('\n')+1
         for match in re.finditer(r'^theorem ([A-Za-z0-9_]+)', proof, re.M)}
summary = json.loads(Path('.lake/riesz-joint-interference/summary.json').read_text())
report = dict(schemaVersion=1, date='2026-10-03',
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    objective='Close out the floor.', goalRemainsActive=True,
    slice='Exact all-count cancellation of nonowner head-prime incidences on the actual balanced main; surviving shared profile has one owner per nonzero higher-count label. Global signed floor still open.',
    sources=[snapshot(p) for p in paths],
    compiledArtifacts=[snapshot('.lake/build/lib/lean/RiemannGaussian.olean'),
        snapshot('.lake/build/lib/lean/RiemannGaussian/ZetaRieszHeadSharedCancellation.olean')],
    validation=dict(scope='Focused local strict leaf/targeted build, frozen compiled ordinary root plus explicit leaf; no wider gates.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(leaf), exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszHeadSharedCancellation --wfail', exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true .lake/riesz-head-shared-cancellation/Audit.lean',
            exitCode=0, compiledOrdinaryRootImported=True, explicitLeafImported=True,
            rootSourceNotRebuilt=True, frozenCompiledRootMatchesPrevious=True,
            allNamespaceLintersPass=True, lintersPerNamespace=14),
        publicTheorems=len(re.findall(r'^theorem ', proof, re.M)),
        publicDefinitions=len(re.findall(r'^def ', proof, re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheoremsIncludingPrivateAndGenerated=axioms['theoremsIncludingPrivateHelpers'],
        everyCompiledDeclarationAxiomChecked=True, onlyStandardAxioms=True,
        previousFrozenProofProbeDocumentationAndArtifactsPreserved=True),
    theoremLines=lines,
    exactResults=dict(nativeRange='1/2 <= u <= 10001/20000, N >= 65536',
        nativeMovingLengthAndAllMasksRetained=True, noZeroHypothesis=True,
        heightAndMultiplicityIndependent=True,
        headCofactorLogLowerBound='log q > 7N/10',
        lengthBounds=['277N/200 <= L', 'L <= 139N/100'],
        centralLogUpperBound='log n <= 2029N/1000',
        bothDeletionCutoffsSaturated=True, finalPairCutoffNonpositive=True,
        exactResponse='R_L(pqa)=-Lambda(a)',
        compositeCofactorAllCountsAtLeastFourZero=True,
        nonownerSharedHeadPrimeOriginalCoefficientZero=True,
        sharedHigherCountIncidencesReduceToUniqueOwner=True,
        arbitraryCorrelatedComplexWeightsRetained=True,
        noCountMultiplicityOrSeparateCountPrice=True,
        noPrimeOrCofactorCompletion=True, noPhaseTransferAssumption=True,
        independentWholeNonownerSharedSectorFloor='0, exactly',
        centralRestDeletionExact=True, sameFullSignedHeadRetained=True,
        appliesExistingSaturationWithoutSpendingAlreadyZeroLabelsTwice=True),
    optionalProbe=dict(snapshot=snapshot(probe_path), summary=snapshot('.lake/riesz-joint-interference/summary.json'),
        cases=180, orders=[6, 7, 8], frozenComplexTotalRegressions=18,
        exactIntegerCutoffFloatingPhasesAndSums=True,
        wholeCountsAndSameHeadJoinedBeforeCrossTerms=True,
        crossLeastPrimeTermsRetained=True, noIncidenceIndependenceAssumption=True,
        sharedIncidenceEnergyNotWholeEnergy=True,
        observedSignNotTheorem=True, sameLeastPrimeCrossNegativeCases=180,
        globalCrossCountReinforcingCases=13, byOrder=summary['byOrder'],
        stressTest=dict(snapshot=snapshot(stress_path), log=snapshot('.lake/riesz-joint-interference/high-height-probe.log'),
            cases=28, orders=[6, 7], heights=[100, 150, 250, 500, 1000, 5000, 10000],
            frozenRegressions=4, sameLeastPrimeReinforcingCases=11,
            scope='Floating finite counter-indications to a universal local sign, not a native eventual no-go.'),
        toyLength='-2N log(10001/20000)', nativeMovingIntegerLength=False,
        nativeDyadicSchedule=False, fullNativeDeletionMasks=False,
        noPreviousNativeBudgetApplied=True, noCofinalSavingPercentClaim=True,
        optionalOutsideBuildsCI=True, notNumericalCertificate=True),
    openPremises=dict(remainingTarget='independent cofinal Re(centralRest)-Re(filteredHead) >= -399/5000-o(1), retaining all paid errors',
        survivingOwnerProfileIndependentlyBounded=False,
        tripleNonownerExceptionPaidByThisSlice=False,
        nonsharedMainPaidByThisSlice=False,
        globalSignedCrossGroupEstimateProved=False,
        wholeCofinalFloorProved=False, multiplicityCeilingProved=False,
        restrictedContradictionProved=False, zeroExclusionProved=False, rhProved=False),
    publication=dict(localOnly=True, noCommitsOrPushes=True, noRootRegistration=True,
        noSubagents=True, noReadmeExplorerOrPublicEndpointChanges=True,
        concurrentSemiprimeWorkNotEdited=True),
    provenance=[snapshot(folder / name) for name in
        ['strict-lean.log', 'build.log', 'audit.log', 'Audit.lean', 'axioms.json', 'write_report.py']])
Path('docs/riesz-head-shared-cancellation-audit.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    definitions=report['validation']['publicDefinitions'],
    compiledDeclarations=axioms['declarations'],
    compiledTheorems=axioms['theoremsIncludingPrivateHelpers'],
    probeCases=180, stressCases=28, goalStillOpen=True)))
