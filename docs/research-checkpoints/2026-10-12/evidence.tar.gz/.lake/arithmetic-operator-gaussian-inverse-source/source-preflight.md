# Actual low Gaussian/additive × inverse-row source preflight

Scope: read-only audit of the pinned imported proof and existing native audits.
No new proof, source estimate, contour continuation, or zero-free claim is made.
No arbitrary coefficient family `B` is identified with the actual inverse row.

## Exact native joint object before Cauchy

Put `C = calibrationForSet S hS`, `Q = lowPhysicalScale C X Y`, and use
the actual `lowSelectedWeight` and `lowSelectedIdeal` of the selected prime
tuple. For each fixed unselected tuple, the exact object is

```
Q^(-1/2)/(2π) * ∫ v,
  lowSeparatedIntegrand C W0 W1 Ω X Y
    (lowSelectedInverseRow univ selectedWeight η S hS selectedIdeal T t) v.
```

The unselected tuples themselves are still summed with the signed
`lowUnselectedWeight`; taking their norms is also an information loss.
This is `compensation_tuple_low_polynomial`, not a proposed new carrier.

For additive ideal `s`, `a = primaryGenerator s`, and `q = Norm(s)`, the
actual additive coefficient is

```
1_{excluded primes do not divide s}
 * Y^(-1) W1(q/Y) idealRowHom(C.generator)(s)
 / (C.tau * C.residueMonoid(a))
 * (q/Y)^(-1/2 + i*v) * q^(-1/2) * sexticGauss(a,-m).
```

The outer numerator weight remains

```
Ω(Norm(m)/Q) C.residueMonoid(m) (Norm(m)/Q)^(-i*v).
```

Expand the ACTUAL inverse row by `lowSelectedInverseRow_correction`.
For every ray character χ, let

```
Ψ0 = physicalRayPeriodicBase η S hS σ χ
A  = I * J^3
F(A) = sum selected tuples b, selectedWeight(b) * 1_{selectedIdeal(b) | A}.
```

Its completed coefficient is exactly

```
correctionCoeff(χ)
 * squarefreeGaussCoefficient(I) / sqrt(Norm(I))
 * star(angularFactor(primaryGenerator J))^3 / Norm(J)
 * Ψ0(primaryGenerator A)
 * idealRowHom(C.generator^6 * m)(A)
 * Vstar(normTwistedSource gaussianFixedWindow t)
     (Norm(I)*Norm(J)^3/T)
 * F(A).
```

Thus the new interaction, if any, must occur in

```
sexticGauss(primaryGenerator(s),-m)
 * idealRowHom(C.generator^6*m)(I*J^3)
```

inside the SAME signed `m,s,I,J,χ,selected,unselected,v,t` sum. This retains
the genuine squarefree `I`, all cube-side prime powers `J`, the selected
divisibility marks, the Gaussian annulus/density, the head/exclusion masks,
ray reciprocity and both height phases. The calibration sixth-power factor
can be extracted only with its existing exact coprimality-mask theorem.

## Principal Mellin multiplier and source gate

For native finite prime-ideal slot pools `T_j` with coefficients `b_j(P)`,
the exact principal factor is

```
B_b(s,w,z) = product_j sum_{P in T_j} b_j(P) localMultiplier η P s w z.
```

At the actual double principal pole `w=1,z=1/6`,

```
B_b(s,1,1/6)
 = product_j sum_{P in T_j}
     b_j(P) Norm(P)^(-5/6)
     principalSlot(Norm(P), actualAPhase(η,primaryGenerator P),
                   idealCoeff(η,P), s).
```

The equality for real native windows is checked by `window_at_residue`;
the complex-coefficient expression follows by the same finite distributive
algebra and `local_eq_regionSlot` (not a new compiled declaration here).

The complete double-pole integrand is this factor times

```
R_π^2/6
 * X^(1/3) Z^(s-5/6) exp((s-5/6)^2)
 * mellin(W1,1) mellin(paperRadialFourier(W0),1/6)
 * globalClosedCorrection(η,S,s,1,1/6)
 / LFunction(η.excludePrimes(S),s).
```

For a hypothetical target zero ρ, a proposed noncommon slot modification
passes the algebraic source gate only after proving the appropriate
nonvanishing/valuation of `B_b(ρ,1,1/6)`, together with nonvanishing of the
other analytic factors and the actual residue normalization. It is not
enough to have a nonzero finite Gauss correlation. For higher zero
multiplicity, a zero of `B_b` can lower the residue order.

The existing contour transport and principal-slot estimates require
`Re(s) >= 7/8` (strictness on shifted contours). They cannot be silently
used to establish the source gate for the remaining `1/2 < β <= 7/8` gap.
The newer principal-Euler audit is a local correction extraction, not a
completed lower-strip contour/source theorem.

## Smallest noncommon arithmetic slot test: source gate still open

Changing ONE actual prime-ideal slot weight is the smallest insertion that
already has an exact physical and principal-Mellin bridge. A finite linear
combination of two slot families has a genuinely noncommon multiplier

```
α B_b(s,1,1/6) + β B_c(s,1,1/6).
```

Unlike scalar profile centering, this need not vanish identically. It can
retain a target source if the displayed value at ρ is proved nonzero.
Nevertheless it does not create a new local signed arithmetic constraint:
on each actual shared prime, the inverse valuation `v_P(I)+3v_P(J)` matches
the additive character precisely when it is `1 mod 6`. Since `I` is
squarefree, this means `v_P(I)=1` and `v_P(J)` is even. A slot factor
depending only on `P` leaves the matching residue atom constant. All
valuation families `1+6t`, including `t=0`, remain. This uses the existing
actual matching audit; it does not retry a complete-period payment.
This rules out AUTOMATIC local orthogonality, not cancellation between
different prescribed prime-ideal coefficients. The latter is still a
genuine signed arithmetic question, and is not disproved by the local atom.

There is a second source-cost obstruction to centered moving slot pools.
On the CHECKED domain `Re(s)>=7/8`, permitted actual norm-one character
values and `Norm(P)>=Pmin>=480` satisfy

```
||principalSlot(P,s) + 1|| <= 1440 Norm(P)^(-7/8).
```

Hence for one slot, if the signed leading mass
`sum b(P) Norm(P)^(-5/6)` is zero, finite triangle algebra gives

```
||sum b(P) Norm(P)^(-5/6) principalSlot(P,s)||
 <= 1440 Pmin^(-7/8) sum ||b(P)|| Norm(P)^(-5/6).
```

Centering removes the leading source along with the leading matching mass
on this checked domain only. The estimate is ENDPOINT-SCOPED at the current
unexcluded boundary: the active domain is `1/2 < β <= 7/8`, and no theorem
here closes the slot class below `7/8`. It is not a no-go for signed
cancellation between prescribed actual P coefficients and is not a theorem
ruling out every prime-incidence-dependent packet. The lower-beta source
gate remains open.

An order/valuation factor that removes `v_P(I)=1,v_P(J)=0` is genuinely
noncommon but changes `principalMarked` and `principalReplacement` rather
than merely `b(P)`. Its source bridge is not currently proved. The leading
`-coordD` term and the resulting normalized `-1` cannot be declared
preserved. That exact local replacement is the mandatory source preflight
before trying such a factor.

## Collapse audit and strongest surviving target

The physical identity is linear in every finite slot coefficient. It
therefore remains valid for arbitrary finite slot weights. The source-side
finite algebra uses no additive constraint on those weights. A prime-only
slot reweighting does not defeat arbitrary-weight or smooth source models
by itself. A Kummer/binomial code on ordinary rational primes also has no
proved map to the actual Eisenstein primary-generator sextic character.
These are source/collapse failures of the proposed insertion, not a claim
that the native complete Gaussian probe is an arbitrary Λ test.

The strongest still potentially independent estimate is for the joined
ACTUAL signed object above, including the unselected-tuple and compensation
subset sums BEFORE their norms. In the published geometry

```
X=Z^(17/48), Y=Z^(23/48), total slot length=1/6,
proved low exponent=3/16+ε, principal source exponent=β-11/16.
```

A new joint gain δ with unchanged nonvanishing source could reach
`β>7/8-δ` (after the separate lower-strip analytic/source transport is
proved). Reaching every `β>1/2` at this geometry requires gains approaching
`3/8`, not a sixth-frequency deletion alone. The latter could save only
`1/96` after the current Cauchy square root.

No actual joint estimate is provided by the finite slot identities.
The smallest next real test is an incidence-dependent factor involving the
shared additive ideal `s` AND the native inverse `I,J` allocation, with its
local all-power replacement explicitly computed and nonzero at the source.
If that factor is replaced by an arbitrary bounded slot coefficient before
estimating, it returns to the existing Gram allowance with no new gain.
If it merely removes every matching valuation, its source must be audited
again; a blanket assertion of source preservation is invalid.

## A distinct cheap exact native inference, if a leaf is wanted

The existing finite matching theorem can be lifted to a genuine inverse
COFACTOR without taking any period mean. For an allowed actual prime P,
write `A = P^(6j+1) * B`, retaining the literal B (and its phases/masks).
Multiplicativity gives the pointwise identity

```
sexticGauss(primaryGenerator P,-m) * idealRowHom(m)(A)
 = 1_{P does not divide span(m)}
   * actualSextic(P)(-1) * gaussSum(actualSextic(P),quotientTrace(P))
   * idealRowHom(m)(B).
```

The precise Lean statement would keep the prime-generator nonzero/good
hypotheses and the existing native additive trace convention. It follows
from `map_mul`, `actual_matching_valuation`, and `actual_matching_atom`.
Any common arbitrary *literal* weight is preserved on both sides; no
assumption that the rest of the inverse row is constant is needed. For
`I=P*I'`, `J=P^(2j)*J'`, take `B=I'*J'^3`. This exposes the actual shared
prime as a punctured numerator weight times the remaining genuine inverse
row. The calibration sixth-power coprimality mask must also be retained
when lifting to `rowTwist(C.generator,1,m)`.

This is a possible small compiled finite identity, not an independent
bound: the resulting `m,B,P` sum remains signed and correlated. It neither
proves source preservation of a new multiplier nor forbids cross-P
cancellation. It is distinct from common scalar/profile centering.

## Validation/provenance

Read-only source inspection. No Lean compilation performed for this audit,
and no new checked theorem is claimed. `source-pins.json` records the exact
files read, current SHA256 values, and matching pinned-vendor hashes. Prior
p-free unit/upper proof validations remain unchanged.
