# Actual cube twist and mark gate

Strict isolated Lean check: exit 0, warnings as errors, 15 namespace linters, 22 all-local declarations / 16 theorems including generated helpers. Every local declaration is audited by module provenance against only propext, Classical.choice, Quot.sound.

The native squarefree Gauss column is retained (not replaced by Möbius), and J is any ideal, retaining every prime-power cube order and every zero/nonunit case. For actual row `rowTwist Psi a f m`,

```
summand row W X I(P*J)
 = cubeWeight row P * summand row W (X/Norm(P)^3) I J
cubeWeight row P
 = cubeWeight(rowTwist Psi a f 1) P * idealRowHom m P^3.
```

The total ideal label is exactly `P^3*(I*J^3)`. `shifted_completedT_eq` exports the genuinely shifted J-subfamily into existing `markedCompletedT` with the SAME native cutoff/window and actual shifted mark. It does not assert the shifted subfamily equals the full unshifted row.

At the correctly rescaled physical length, the entire joined finite mark commutator is the signed weighted `d(P^3*A)-d(A)`. Coprime divisor marks are invariant. The prime mark d(A)=1_{P|A} leaves exactly `1-1_{P|A}`. With X held fixed, `fixed_scale_atom_split` retains BOTH the Vstar/Gaussian window difference and the signed mark difference. Neither term is paid, estimated by a generic norm, or promoted to a whole-probe estimate.

The actual residue has `sourceArithmeticResidue(h*p^3)=sourceArithmeticResidue h`. A multiplicative numerator-dependent twist supplies precisely the eigenvalue `(rowTwist Psi a f m p)^3`. Subtracting that true eigenvalue leaves only the exact physical mask jump. If the eigenvalue equals one and the mask is invariant, the whole coefficient difference is zero. This is a scoped source-conservation identity, not a claim that arbitrary native masks or the actual prime-mark jump annihilate the hypothetical-zero Mellin source.

Source preflight is separate: a local principal multiplier/continued contour residue must still be attached to the actual mark/window discrepancy. No all-cusp calibration result, zero exclusion, literal-cutoff cancellation, or generic inverse-row source asymptotic is asserted here. Historical raw cube-difference annihilation and all prior no-gos remain intact. Fixed-scale Gaussian cutoff changes are unpaid.
