"""Binary64 actual trivial-phase local source diagnostic, not proof."""
import cmath
import json
from pathlib import Path

def prime(p):
    if p < 2:
        return False
    d = 2
    while d*d <= p:
        if p % d == 0:
            return False
        d += 1
    return True

ps=[101,10007,10000019,100000007]
assert all(prime(p) and p % 3 == 2 for p in ps)
rows=[]
for sigma in [.5001,.55,.6,.61,.7,.875]:
    for p in ps:
        Q=p*p
        s=complex(sigma,54)
        t=1/Q
        R=cmath.exp((3-6*s)*cmath.log(Q))
        D=cmath.exp(-s*cmath.log(Q))
        K=(1-t)*D
        M=((R*(1-t)-K*t)/(1-t)-D+t*R)/(1-R)
        F=1/(1-t)+t/(1-t)+M
        raw=(F-M)/F
        reduced=(1-R)/(1-t*R-(1-t)*D)
        guard=(Q>=4 and abs(R)<=.5 and abs(D)<=.25)
        budget=2*(Q**(3-6*sigma)+Q**(-sigma))
        rows.append(dict(sigma=sigma,y=54,inert_rational_prime=p,Q=Q,
                         raw_reduced_error=abs(raw-reduced),ratio_norm=abs(raw),
                         ratio_minus_one_norm=abs(raw-1),R_norm=abs(R),D_norm=abs(D),
                         theorem_norm_guards_hold=guard,explicit_budget=budget,
                         diagnostic_budget_holds=(abs(raw-1)<=budget+1e-12)))
result=dict(scope="binary64 native local source multiplier only; not a residue, continuation, or arithmetic estimate",
            primes_verified_by_exact_trial_division=True,
            max_raw_reduced_error=max(r["raw_reduced_error"] for r in rows),rows=rows)
Path(__file__).with_name("probe.json").write_text(json.dumps(result,indent=2)+"\n")
