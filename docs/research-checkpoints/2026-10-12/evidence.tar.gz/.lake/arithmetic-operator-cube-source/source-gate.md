# Actual cube/prime-mark source gate

This is an isolated local-source audit. It adds no estimate for the native
Gaussian/additive × inverse row, no global correction below its checked domain,
no contour continuation and no zero-free theorem. The active unexcluded domain
remains `1/2 < beta <= 7/8`.

## Exact native operator and source

The finite physical cube/mask identity is in `scripts/QuasiRHCubeTwistAudit.lean`.
For the prime mark `d(A)=1_{P|A}`, the actual cube insertion changes it to
`d(P^3 A)-d(A)=1-1_{P|A}`. The full row cube factor and the correctly rescaled
Gaussian length remain part of that identity. Keeping the old Gaussian length
instead leaves its explicit cutoff commutator; this source leaf does not pay it.

At native local completed valuation `(e,l)`, that mark difference is exactly
`1_{e=l=0}`. The finite local theorem `actual_source_complement_term` retains
the actual sourcePrincipalTerm and its Gauss, sextic and target character phases,
including every `(k,m)` order. Their full sum is exactly

`1/(1-V)+W/(1-W)`.

The actual squarefree/cube full-minus-marked source agrees with this expression
on its native convergent Euler region. There is no arbitrary row or arbitrary
weight substituted for the actual coefficient. The exact global Euler identity
`actual_single_complement_source_factorization` on `Re(s)>3/2`, `Re(w)>2`,
`Re(z)>1/6` is

`unmarkedHighSeries - primeMarkedHighSeries`

`= [L_principal(6z) L_principal(w)/L_excluded_eta(s) * globalClosedCorrection]`

`  * cubeMaskLocalRatio`.

Thus the operator supplies a finite scalar multiplier of the SAME inverse-L
source, not a new signed arithmetic constraint.

## Actual principal-axis gate

At `w=1,z=1/6`, use actual native coordinates

`t=Q^-1`, `R=actualAPhase * Q^(3-6s)`, `D=idealCoeff * Q^-s`.

The exact closed formula is

`cubeMaskLocalRatio = (1-R)/(1-tR-(1-t)D)`.

If `Q>=4`, `|R|<=1/2`, `|D|<=1/4`, it is nonzero and

`|cubeMaskLocalRatio-1| <= 2[Q^(3-6 Re(s))+Q^(-Re(s))]`.

For every fixed `Re(s)>1/2` and every actual prime-ideal sequence with norms
tending to infinity, this ratio tends to ONE. The checked scoped no-go
`actual_cube_ratio_not_tendsto_zero` excludes norm-paying this native principal
multiplier to zero. It does not prohibit a new joined arithmetic estimate or
cancellation among differently prescribed prime slots.

This ratio has no compensating `Q^s` multiplier. It is distinct from the existing
compensated `principalSlot`, whose sharp minus-one-centering threshold is `3/5`.
No `>1/2` conclusion for this local ratio silently extends the global angular
Euler source. The original angular Euler channel has the separate absolute Euler region
`Re(6s-3)>1`, equivalently `Re(s)>2/3`; no nonvanishing of its continued
L-function below that region is assumed. The imported global source contours
have `>=7/8` restrictions. Local nonzero ratios alone do not establish the hypothetical
off-line zero residue after density separation. That GLOBAL source gate remains
open in the lower strip.

## Numerical and formal evidence

The diagnostic uses the raw native localFactor/markedFactor formulas and compares
their complement ratio with the exact reduced expression on four verified inert
rational primes (`Q=p^2`), actual trivial phases, height 54 and fixed exponents.
Binary64 samples are diagnostic only. They identify no actual nonlinear zero
source. The explicit `|R|,|D|` theorem guards are recorded separately for each row.

The isolated strict compile/cache exited 0. All 43 module-local declarations
(39 theorems, including generated helpers) use only standard axioms; all 15
namespace linters passed with warnings treated as errors. No broad check ran.
