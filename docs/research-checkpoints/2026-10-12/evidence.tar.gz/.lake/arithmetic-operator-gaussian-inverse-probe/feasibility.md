# Actual additive/Gaussian inverse row: quantitative preflight

This checkpoint deliberately does not create a random Gram probe. There is
no faithful small executable model of the joined physical row in the current
Python scripts. The finite-field probe `probe_quasi_rh_coupled_residue.py`
explicitly states that it does NOT model physical masks, Eisenstein angular
phases or the zero signal. Its matching-character identity cannot be promoted
to a numerical estimate of the complete low probe.

## Authoritative coupled row before Cauchy

The pinned vendor revision is adc7f1241b42e322a6451854ab7e4b4c146bf78a.
`Detector/LowSeparated.lean` identifies the actual inverse factor, not a free B:

    B(sigma,m)=correctedCompletedT C.excluded D
      (physicalRayRowMonoid eta C sigma m) gaussianCompletedProfile Z.

The coupled integrand is

    Mellin(W0)(iv) sum_m Omega(norm(m)/Q) C.residueMonoid(m)
      (norm(m)/Q)^(-iv) sum_sigma lowRayAmplitude(C,W1,Y,sigma,m,v) B(sigma,m),

where Q=norm(C.generator)XY. `LowSelectedSum.lean` and
`LowCompensation.lean` give the compensated/selected-slot factor, including
the full finite ray correction family. This is the row that a faithful probe
would have to evaluate; no independent random inverse coefficients are valid.

The exact additive coefficient in `LowRowMellin.lean` retains:

* the entire supported ideal s (not only prime ideals or squarefree ideals);
* the excluded-ideal mask before inverse residue evaluation;
* idealRowHom(C.generator,s)/(C.tau*C.residueMonoid(primaryGenerator(s)));
* the actual sextic Gauss sum at the physical numerator -m;
* the full height factor (norm(s)/Y)^(iv), annulus and normalization.

`Completed.lean` retains the original inverse ideals I,J, with I squarefree
through its column weight while J is unrestricted; they may share primes.
The label is I*J^3. Its zero masks, mark D|I*J^3, primary generators,
gamma2/alpha phases and fixed mod-four correction cannot be replaced by
generic multiplicative characters. `GaussianCompletion.lean` uses the actual
Gaussian exp(-log(y)^2/4)/(2sqrt(pi)y^(1/2)), not a finitely supported surrogate.

## What Propositions15.2–15.3 actually permit

Paper15.2 only allows the fixed ray coefficients

    c_sigma(s)=1_(s in sigma)*chi_s(b*)/(tau*xi(s)),

zero-extended before inverse evaluation. It explicitly does not assert an
estimate for arbitrary row-dependent arithmetic coefficients. Its Gram split
retains the full common-prime correlation, the exact Mobius coprimality
insertion and periodic extension; the two residual variables are not assumed
coprime after insertion.

The additive-only exceptional frequency criterion is that every prime
outside the common/fixed modulus has valuation divisible by six. Zero
frequency is the additive matching diagonal; nonzero exceptional frequencies
are NOT discarded. The criterion is in `GramClassification.lean`, and the
literal exceptional/nonexceptional split is in `GramTruncation.lean`.
These are classifications of the ADDITIVE SQUARE. One cannot assume that
the same split is the source classification after multiplying by actual B:
the earlier finite-field matching test already shows that a matching inverse
phase can restore a nonzero joined residue when separate means vanish.

Paper15.3 retains the completed gamma2(c)*alpha(c*n^3) inverse coefficients
and every selected slot before Cauchy. Its actual compensated source
normalization is s-11/16, while its upper bound is3/16+epsilon; the gap is
beta-7/8. It gives no extra signed correlated credit below that threshold.

## Smallest faithful next probe, and exact missing implementation data

A minimal viable model would fix a legitimate actual Hecke character eta,
excluded prime-ideal set S including the mandated bad primes, deterministic
local calibration choices, one physical ray and a finite actual selected-slot
system. It must then export or implement:

1. Eisenstein ideals, primary generators, multiplicities, common-prime
   factors, unit quotient representatives and every zero extension.
2. The actual localCalibration values and CRT map, tau, quotientTrace,
   idealRowHom, sextic Gauss sums and the fixedGQuotientValue correction.
3. Completed columnWeight/cubeWeight and actual physicalRayRowMonoid values
   on the SAME inverse ideal labels I*J^3 and physical m rows.
4. Native W0,W1, compensated slot weights and Gaussian profile. For the
   noncompact Gaussian, a tail error certificate must accompany any finite
   ideal/annulus truncation; deleting all larger powers is not legitimate.
5. The exact hypothetical-zero source attachment for this chosen whole
   compensated packet, rather than the source of one raw prime column.

The repository currently provides mathematical definitions and qualitative
finite/support/summability theorems, but no executable table/export covering
items1–5 together. Calibration uses Classical.choose; a numerical gauge
choice needs an exact equality/invariance bridge. The source attachment is
not supplied by choosing a convenient finite-field character independently.
These are missing IMPLEMENTATION/IDENTIFICATION data, not a theorem that no
faithful model can ever be constructed.

Until that bridge exists, even a toy model using norm7/13 fields and standard
additive characters would test only a local matching identity. It would omit
the actual angular/CRT correction and inverse ideal-power tails. No floating
size comparison from that toy can decide whether the full native coupled
row improves the7/8 exponent.

## Next action changed by the preflight

Do not run a generic random-B or squarefree-only Gaussian detector. First
derive/export the exact joined actual inverse-row kernel and its matching
source term, including correction, nonunit zeros and all allowed powers.
Only then run a finite probe with explicit tails and separate matching,
exceptional and nonexceptional contributions. Existing additive-only Gram
classification cannot be used as source cancellation of the joined row.

No numerical arithmetic bound, source response or RH exclusion is asserted
here; no vendor source or shared research note was edited.
