# Joined sextic-additive / cubic-inverse literature preflight

This is a primary-source hypothesis audit, not a new arithmetic estimate or Lean theorem. It is restricted to the actual row before Cauchy. No random coefficient array substitutes for the inverse row. Vendor revision: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. File/PDF hashes are in `literature-preflight.json`.

## Exact object retained

The current inverse row is a finite compensated combination of
`correctedCompletedT S D Ψ gaussianCompletedProfile Z`.
Its arithmetic labels are `I * J^3`, with squarefree `I`, unrestricted `J`, and no imposed coprimality between them. Keep the complete ray correction, every marked/excluded-prime mask, the Gaussian profile, and both height phases. The additive factor is `lowRayAmplitude`, whose underlying coefficient contains the actual sextic Gauss sum at `-m`. The quantity to improve is their joined sum over the same `m` and ray, not either energy separately.

## Closest genuinely distinct estimate

[Dunn, *Metaplectic cusp forms and the large sieve*, Theorem 1.5](https://arxiv.org/pdf/2403.13151) estimates a bilinear sum of fixed cubic-metaplectic **cuspidal** Fourier coefficients `rho_f(lambda^-3 * a*b)`. The `a` variable is squarefree; `b` may be nonsquarefree. For smooth annular weights the bound is

`(X K N(v))^epsilon K^8 N(v)^4 * ((AB)^(1/2) + A^(3/2) B^(1/4)) * ||mu^2 alpha||_infinity * ||beta||_2`,

where `X ~ AB`, `v` is a fixed congruence modulus, and the form vanishes at every cusp. This is a coupled coefficient estimate, so it differs from paying additive and inverse energies independently. Its useful unbalanced range includes `B > X^(2/3+epsilon)`.

**Applicability inference:** Gaussian annular decomposition and smooth height separation could fit its weight format. They do not identify the actual joined sextic/cube kernel with a coefficient of one fixed cuspidal form. A changing form or congruence modulus would also require uniform constants; the published fixed-form estimate is not such a theorem. Thus no immediate import follows.

## Existing cube completion and stronger dispersion hypothesis

[Dunn–Radziwill, *Bias in cubic Gauss sums*, Proposition 5.3](https://arxiv.org/pdf/2109.07463) already treats the `c*d^3` completion, allowing unrestricted `d` and shared primes; it gives an explicit noncuspidal main term and dual sum. This is already used by the pinned OpenAI proof. Proposition 10.1 preserves a main term in a sharper bilinear asymptotic, but requires `beta in C_eta(B,w)`. Definition 3.1 requires bounded squarefree rough support plus square-root-size cancellation for nontrivial cubic/angular twists with divisibility restrictions. Lemmas 6.1–6.2 verify examples using GRH. The theorem may be conditional on its coefficient axiom without assuming GRH globally, but that axiom is not proved for the current inverse row.

**Applicability inference:** the unrestricted cube variable does not satisfy the squarefree coefficient hypothesis as written. Splitting it into squarefree/cube pieces still leaves a new twisted cancellation premise. Neither that premise nor GRH can be inserted as an assumption in the RH campaign. The imported `Re s > 7/8` theorem supplies no automatic `1/2+eta` cancellation with `eta <= 1/4`.

[Blomer–Goldmakher–Louvel, Theorem 1.3](https://arxiv.org/pdf/1112.1650) and [Gao–Zhao, Lemma 2.9](https://arxiv.org/pdf/2201.01885) supply squarefree higher-order/sextic character norm bounds of the familiar `M+N+(MN)^(2/3)` shape. These already underlie the current sieve. They do not give a signed actual additive-row/inverse-row correlation estimate.

## Source preflight for a cusp/main-term projection

The repository gives an exact coefficient identification, not just an analogy:

- `Eisenstein/SquarefreeCoefficients.lean:134`, `infinityCoefficient_squarefree_cube`, expresses the genuine residual Fourier coefficient at `primaryGenerator I * primaryGenerator J ^ 3` using `gaussTwo I` and the unrestricted cube factor.
- `GaussSum/DualKernelSummability.lean:548` proves its normalization scalar is nonzero; line 561 gives `normalized_infinityCoefficient_squarefree_cube`.
- `GaussSum/FiniteTranslations.lean:520`, `fixedThetaTwist_infinity_coefficient`, retains the actual multiplicative twist and reconnects this residual Fourier coefficient to the arithmetic completed summand.
- `Eisenstein/CuspAverage.lean:370`, `cubicSourceResidualFunction_cusp_average`, gives a nonzero cusp average. This actual residual function is therefore not Dunn's cuspidal `f`.
- `Detector/Completed.lean:107`, `correctedSummand_ray_expansion`, and `Detector/LowSelectedSum.lean:54`, `lowSelectedInverseRow_correction`, retain the exact finite ray correction/marked combination.
- `Detector/SpectralCoefficient.lean:47`, `spectralSummand_source_coefficient`, preserves the target character, calibration character, reciprocity sign, and shared-prime label.
- `PrincipalMellinResidues.lean:383`, `source_double_residue`, keeps the explicit `1 / LFunction eta s` source with the multiplier evaluated at `(w,z)=(1,1/6)`.
- `PrincipalSignalComparison.lean:361`, `actual_principal_slot`, identifies the actual compensation with the principal slot; line 421 preserves the normalized source residue.

These facts identify the current inverse coefficients with a noncuspidal Eisenstein-residue function. They do **not** identify a hypothetical cuspidal projection's target-zero residue, nor prove that every possible coupled cuspidal component would annihilate that residue. No theorem supplying that projection was found in this audit.

The exact missing identity, before any Dunn import, is a decomposition of the **actual coupled row** into a fixed-form cuspidal term and an explicitly evaluated noncuspidal term, retaining all shared-prime powers, ray/nonunit masks, marks, Gaussian/height weights, and compensation. It must compute which term carries the same principal slot multiplier. A new estimate of the cuspidal term is useful only if the remaining noncuspidal term is independently controlled without deleting or counting the target source twice.

## Decision

Do not build a cusp projection or add `C_eta` hypotheses now. The audited literature does not supply a verified direct improvement of this actual joined row. The smallest next mathematical gate is the exact source-preserving cusp/main-term identity above, or a genuinely new signed estimate for the noncuspidal joined kernel itself. This conclusion is scoped to the checked theorems; it is not a literature-wide impossibility assertion.
