from pathlib import Path
import hashlib,json,re,subprocess
out=Path('.lake/riesz-complex-zero')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='194a361762f404a8f4473298b25d96fbae0bb56e'

def saved(path):
    p=Path(path); data=p.read_bytes(); h=hashlib.sha256(data).hexdigest()
    snap=out/f'snapshot-{h}{p.suffix}'
    if snap.exists():
        assert snap.read_bytes()==data
    else:
        snap.write_bytes(data)
    return dict(path=str(p),sha256=h,snapshot=str(snap))

weighted=json.loads((out/'probe.json').read_text())
tail=json.loads((out/'tail-probe.json').read_text())
a=[c for b in weighted['cases'] for c in b['cases']]
b=[c for batch in tail['cases'] for c in batch['cases']]
axioms=json.loads((out/'axioms.json').read_text())
assert len(axioms)==2 and all(m['onlyStandardAxioms'] for m in axioms)
modules=['RiemannGaussian/ZetaRieszWeightedZeroFloor.lean','RiemannGaussian/ZetaRieszClosedTailFloor.lean']
sources=modules+[
 'RiemannGaussian/ZetaRieszZeroResponseFloor.lean',
 'RiemannGaussian/ZetaRieszPaidIncidenceFloor.lean',
 'RiemannGaussian/ZetaRieszSmallCofactorCancellation.lean',
 'RiemannGaussian/ZetaRieszShortDivisorCancellation.lean',
 'RiemannGaussian/ZetaRieszTangentCubicCredit.lean',
 'RiemannGaussian/ZetaRieszComplexProjection.lean',
 'RiemannGaussian/ZetaRieszCutoffPeriodFloor.lean',
 'RiemannGaussian/ZetaRieszCenteredPrimeEnergy.lean',
 'RiemannGaussian/ZetaRieszSignedCutoffEnergy.lean',
 'RiemannGaussian/ZetaRieszEndgameSlack.lean',
 'RiemannGaussian/ZetaSquarefreeVaughanLogSource.lean',
 'scripts/probe_riesz_weighted_zero_floor.py',
 'scripts/probe_riesz_zero_response_floor.py',
 'scripts/probe_riesz_factored_population.py',
 'scripts/probe_riesz_complex_null_profiles.py',
 'docs/zeta-riesz-weighted-zero-floor.md','lean-toolchain','lake-manifest.json']
report=dict(schemaVersion=1,date='2026-10-03',head=head,objective='Close out the floor.',goalRemainsActive=True,
 slice='Join label-dependent complex zero responses and complete affine-tail cancellations inside nonzero labels before current native whole-period floor pricing.',
 sources=[saved(p) for p in sources],
 validation=dict(
  scope='Focused local only; compiled ordinary root plus explicit new modules. No full-root source rebuild, wider CI or publication.',
  strictLean=[dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+p,exitCode=0) for p in modules],
  build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszClosedTailFloor --wfail',exitCode=0,dependencyModuleBuilt=True),
  audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true .lake/riesz-complex-zero/Audit.lean',exitCode=0,ordinaryCompiledRootImported=True,newModulesExplicitlyImported=True,rootSourceNotRebuilt=True,lintersPerNamespace=14),
  compiledRootSha256=hashlib.sha256(Path('.lake/build/lib/lean/RiemannGaussian.olean').read_bytes()).hexdigest(),
  publicTheorems={p:len(re.findall(r'^theorem ',Path(p).read_text(),re.M)) for p in modules},
  theoremsIncludingPrivateAndGenerated={m['module']:m['theoremsIncludingPrivateHelpers'] for m in axioms},
  onlyStandardAxioms=True,
  optionalProbes=[dict(command='../.venv/bin/python scripts/probe_riesz_weighted_zero_floor.py',exitCode=0),dict(command='../.venv/bin/python scripts/probe_riesz_weighted_zero_floor.py --closed-tail --output .lake/riesz-complex-zero/tail-probe.json',exitCode=0)],
  probesInOrdinaryBuildOrCI=False),
 exactResults=dict(
  radiusCeiling='10001/20000',heightCondition='54 <= abs(y)',
  weightedZeroDirection='Arbitrary moving label-dependent complex observation of an original exact zero response',
  coefficientBoundOrGrowthCondition=None,
  oldRealTiltedDirectionRecoveredExactly=True,
  constantAndFirstLogMoebiusMomentsRetained=True,
  underlyingAffineIdentityAlreadyInRepo=True,
  tailIndexCondition='d divides B=n/R; e divides R; physicalCutoff <= d',
  canonicalBlock='R is the two least primes of the WHOLE label',
  originalIncidenceInjection='RiemannGaussian.ZetaRieszClosedTailFloor.tailIndices_injective',
  literalDivisorSupport='RiemannGaussian.ZetaRieszClosedTailFloor.tailDivisors_subset',
  complexBlockPairing='RiemannGaussian.ZetaRieszClosedTailFloor.tailDivisors_complex_pairing_zero',
  nullTotal='RiemannGaussian.ZetaRieszClosedTailFloor.sum_tailIncrement_zero',
  completeLabelResponseNeedNotBeZero=True,
  polynomialPrimeSizeCap=None,countRestrictionBeyondOriginalNativeCrop=None,
  originalBasePhaseMaskFactorialAndAllocationRetained=True,
  coefficientPhaseAlignmentAllowedOnlyInExactZeroCorrection=True,
  originalNonzeroCarrierPhaseRemoved=False,
  additionalFundingCost=0,newEarlyCutoffDebit=False,
  distinctAllPrimeAndPaidOwnerAllocationsRetained=True,
  oldCorrectionsPaidBudgetAndNativeErrorRetainedOnce=True,
  wholeCarrierFloor='RiemannGaussian.ZetaRieszClosedTailFloor.eventually_joined_floor_with_closed_tail_credit',
  price='min(weightedPrice, blockCost(nativeStep-nativePaidIncrement-weightedIncrement-tailIncrement)+nativePaidBudget)',
  correctionZeroRecoversPreviousPrice=True,
  arithmeticComparisonUsesZeroHypothesis=False,
  nativeErrorDecayUsesExistingExposedZeroHypotheses=True,
  conditionalSimpleContradiction='RiemannGaussian.ZetaRieszClosedTailFloor.false_of_cofinal_tail_price',
  cofinalNumericalPremise='tailPrice <= 399/5000',cofinalNumericalPremiseProved=False),
 numericalRegression=dict(
  orders=[32,64],seeds=[317,919],heights=[54,65,100],
  frozenInputs=[saved(x['cache']['path']) for x in weighted['cases']],
  fullZeroCorrectionLabelCounts=[len(x['correctionLabels']) for x in weighted['cases']],
  closedTailCorrectionLabelCounts=[len(x['correctionLabels']) for x in tail['cases']],
  closedTailIncludesNonzeroWholeResponseLabels=all(x['correctionIncludesNonzeroWholeResponse'] for x in tail['cases']),
  complexCoefficientGainPositive=sum(c['complexZeroGain']>0 for c in a),
  labelCoefficientGainPositive=sum(c['labelDependentGain']>0 for c in a),
  closedTailGainPositive=sum(c['extraClosedTailGain']>0 for c in b),
  totalComparisons=len(a),tailCostsNearFloatingZero=sum(c['labelDependentZeroPrice']<1e-12 for c in b),
  oldTiltAndNullBoundsUnchanged=True,
  earlierFullLabelFitRepricedAsFeasibleCandidate=True,
  maximumPreviousCandidateResidual=max(c['previousWeightedCandidateRepricingResidual'] for c in b),
  maximumTailNullResidual=max(c['floatingLabelZeroResidual'] for c in b),
  exactIntegerSelectionNotFloatingResponseSelection=True,
  originalImportanceWeightsRetained=True,
  probablePrimalityFloatingLogsPhasesEdgesAndLP=True,
  nativeCofinalPoints=False,nativeCountCropApplied=False,nativePaidOwnerPacketOrBudgetApplied=False,
  nativePopulationPriceRateOrDeficitFractionCertified=False),
 remaining=dict(
  wholeFloor='OPEN: prove an independent cofinal bound on the ACTUAL native joined tailPrice by 399/5000.',
  activeHingeCrossings='Their remaining combined real contribution has no cofinal numerical bound yet.',
  balancedTriplesAndHigherCounts='Retained in the joint carrier; no countwise positive allowance is reused.',
  wholeCeiling='OPEN',positiveNativeAsymptoticSavingMagnitudeProved=False,
  zeroExclusion=False,rhContradiction=False,allPreviousNoGosPreserved=True),
 commitsOrPushesPerformed=False,readmeOrPublicEndpointsChanged=False)
(out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
report['artifacts']=[saved(out/p) for p in ['lean.log','build.log','closed-lean.log','closed-build.log','audit.log','Audit.lean','axioms.json','probe.log','probe.json','tail-probe.log','tail-probe.json','report.json','write_report.py']]
Path('docs/riesz-weighted-zero-floor-audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
for item in report['sources']+report['artifacts']+report['numericalRegression']['frozenInputs']:
    for key in ('path','snapshot'):
        assert hashlib.sha256(Path(item[key]).read_bytes()).hexdigest()==item['sha256'],item[key]
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],compiledTheorems=report['validation']['theoremsIncludingPrivateAndGenerated'],allHashesMatch=True,wholeFloorOpen=True),indent=2))
