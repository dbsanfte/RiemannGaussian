# Fixed cofactor two with explicit valuation marks: source gate remains open

This is one finite integer preflight, not a source or arithmetic estimate.
The full base-prime phase q^(-iy) is retained as a multiplicative factor on
every row. Whole-label phase Q^(-iy) is a different optional convention;
the finite identities hold with either external factor, without equating them.
For an odd ordinary prime q, s>=1 and Q=q^s, use the literal row

    a_k=chi_q(unit_q choose(2Q-1,k)),  0<=k<2Q,
    v_k=v_2 choose(2Q-1,k).

The p=2 unit character is trivial; the q unit character is exactly
chi_q(-1)^(k modQ). The valuation reduces to the genuine smaller row:

    v_k=v_2 choose(Q-1,floor(k/2)).

Both endpoints, every valuation and the midpoint pair are retained.

## Linear mark

If q=1 mod4, the marked sum is

    sum_k a_k v_k
      =2 sum_{i<Q} v_2 choose(Q-1,i)
      =2[Q v_2((Q-1)!)-2 sum_{i<Q}v_2(i!)]
      =4 sum_{i<Q} s_2(i)-2Q s_2(Q-1).

Its normalized scalar weight is

    L(Q)=2/Q sum_{i<Q}s_2(i)-s_2(Q-1).

It also equals Q^(-1) times the exact dyadic suffix sum
sum_{j>=1,2^j<=Q} floor(Q/2^j)(2^j-Q mod2^j).
This is the LINEAR factorial-valuation/Gamma-ledger class. At fixed prime
base2 it is a digital scalar, not the Archimedean Gamma logarithm: the
ordinary log-factorial/Gamma identity requires summing all prime bases.
No actual-prime residue may be inferred by silently making that replacement.

If q=3 mod4, all paired entries cancel except the midpoint, so

    sum_k a_k v_k=2 s_2((Q-1)/2).

The normalized weight is O(logQ/Q), hence not a new source channel.

## Nonlinear valuation-parity mark

If q=1 mod4,

    sum_k a_k (-1)^v_k
      =2 (-1)^s_2(Q-1) c(Q-1),

where c(n)=sum_{i=0}^n t_i t_{n-i}, t_i=(-1)^s_2(i). Its exact recurrences
are c(-1)=0,c(0)=1,c(2m)=c(m)+c(m-1),c(2m+1)=-2c(m). The normalized
weight P(Q)=(-1)^s_2(Q-1)c(Q-1)/Q is nonlinear digital data, not the
unmarked residue-class selector or a linear Gamma coefficient.

If q=3 mod4, only the midpoint remains:

    sum_k a_k (-1)^v_k=2 (-1)^s_2((Q-1)/2),

whose normalized weight is O(1/Q).

Finite Fermat-prime examples q=5,17,257,65537 have P(q)=3/5,7/17,87/257,
21847/65537. For these four actual primes the identities are exact; no
infinite Fermat-prime sequence or source-scale limit is inferred.

## Precise missing source theorem

The surviving ordinary-prime series are, on Re z>1,

    sum_{q prime, q=1 mod4} logq * L(q) q^(-z),
    sum_{q prime, q=1 mod4} logq * P(q) q^(-z).

Before arithmetic-size research, either would need an EXACT continuation
and actual matched-zero response theorem at z=rho, retaining the complete
height twist and growing binary depth. Neither is presently supplied by an
Euler logarithmic derivative, a toy density mode, the unmarked fixed-two
selector theorem, or fixed-p automatic equidistribution. Finite periodic
approximations also do not justify passage through the growing depth at
source scale.

The q=3 mod4 midpoint series are in a safer absolute half-plane. The proper
power counterparts q^s,s>=2 are also safer for Re rho>1/2, with the linear
mark costing at most O(log(q^s)) and the parity mark bounded by1. These facts
do not identify the ordinary-prime q=1 mod4 digital residue. No density
separation preserving an as-yet-unproved source is asserted.

Thus neither proposed marked packet passes the actual-zero source gate at
this checkpoint. Do not start a large automaton/detector or prime estimate
development based solely on these identities. This is NOT a proof that no
digital source mechanism exists; it isolates exactly what is missing.

Validation:209 native rows,41 proper-power rows,727410 depth checks,5260
direct literal binomial unit checks,209 each of linear/parity/midpoint,
factorial/dyadic and Thue–Morse convolution identities. Probe exited0.
All checks are exact integer diagnostics, not Lean proof input.
