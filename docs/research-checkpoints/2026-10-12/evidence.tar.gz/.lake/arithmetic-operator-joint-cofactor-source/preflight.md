# Actual calibrated matched-cofactor preflight

The literal numerator after matching-prime removal is not the arbitrary exterior weight in the older local nonzero-period audit. It is the calibration character times the entire cofactor sextic row, with the prime nonunit puncture retained.

The new strict leaf `scripts/QuasiRHCalibratedMatchingAudit.lean` proves the exact native identity

`R_B,P(Q) = U_B(Q) - chi_C,B(p) U_B(Q/Norm(P))`,

where `U_B(Q)` sums `C.residueMonoid(m) * idealRowHom(m)(B)` against the actual compact complex annular/height test. Both terms are signed; no norms, source replacement or completion are introduced. Cofactor one is retained. The reduced period is genuinely `(C.generator*b)*p` when `B=span(b)`.

With a nonempty actual calibration and the literal excluded-prime coprimality, the complete-period mean is zero, also for `B=1`. This uses the imported exact calibration zero-frequency theorem. The earlier arbitrary-weight nonzero period does not apply to this calibrated mean.

## Native conductor obstruction and fixed-cofactor exception

The paper's Eq.12.4 fixes `lx=17/48`, `ly=23/48`, `ell=1/6`, `M=5/6`. At rescaled slot depth `d`, `0<=d<=1/6`, the literal low numerator has `Q=Nc*Xprime*Yprime`, with `Xprime~Z^(17/48-d)` and `Yprime~Z^(23/48-d)`.

At the nominal inverse Gaussian center, `A=I*J^3` is near `Z^(1+ell-d)`. The allowed squarefree `J=1` matching sector `A=P*B`, `Norm(P)~Yprime`, therefore has cofactor norm near `Z^(11/16)`. The exact nominal ratio is

`Q/[Nc*Norm(P)*Norm(B)] = Z^(-1/3-d) -> 0`.

The leaf proves the rational exponent identity and limit using the actual vendor `lowPhysicalScale`. It also proves the different unit-cofactor ratio tends to infinity:

`Q/[Nc*Norm(P)] = Z^(17/48-d) -> infinity`.

Thus fixed cofactors are candidates for ordinary smooth Poisson payment, but that mechanism is not uniform over native growing squarefree cofactors. This is a scale audit, not a signed character-sum lower bound, not proof of cofinal abundance, and not a no-go for all collective cancellation. The displayed period is an honest period; an arbitrary character's minimal conductor may be smaller. The native squarefree `J=1` sector does not undergo a sixth-power phase reduction.

## Exact joint and source bridges already present

`PhysicalReopen.physical_spectral_reopen` and `SpectralPoisson.physical_spectral_poisson` already reopen the actual inverse `I*J^3` series and Poisson the full calibrated physical numerator before Cauchy. `actualCongruenceCoefficient` retains the additive congruence `s | H-(C.generator*A)d` and the full calibrated finite Fourier coefficient.

Consequently no new generic Gram or physical-row representation is needed. The minimal unpaid object is the signed native cofactor aggregate of the two `U_B` scales, with actual squarefree Gauss coefficients, every cube order, outer inverse marks, fixed rays, inverse Gaussian weight, height integral and prime-slot compensation retained.

The nonzero source must still be tracked through the imported source coefficient bridge. Calibration removes frequency `H=0`; it does not remove nonzero sixth-power frequencies. `CoefficientDirect.calibratedHighCoefficient_eq_bare` preserves them up to the calibration character, and `SourceCoefficient.sourceHighCoefficient_eq_bare` gives the exact source specialization at `H=u*a^6`. The existing continued principal-source estimates have the `Re(s)>7/8` domain. They do not supply the source gate below that threshold.

## Verdict

There is no arbitrary-scalar collapse established for this actual joint row: genuine calibration, cofactor phases and the multiplicative/Gaussian norm relation remain. But existing mean-zero Poisson alone does not save the growing-cofactor sector. The next independent arithmetic theorem must bound the signed aggregate of these actual cofactor terms collectively, while preserving the nonzero principal source. Separate additive/inverse norms, random cofactor surrogates and an unproved cusp projection do not provide that theorem.
