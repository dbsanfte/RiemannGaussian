from pathlib import Path
import hashlib
import json
import re
import subprocess

out = Path('.lake/riesz-balanced-allocation-payment')
source = Path('RiemannGaussian/ZetaRieszBalancedAllocationPayment.lean')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '194a361762f404a8f4473298b25d96fbae0bb56e'
previous_path = Path('docs/riesz-balanced-owner-floor-audit.json')
previous = json.loads(previous_path.read_text())
root = Path('.lake/build/lib/lean/RiemannGaussian.olean')
root_sha = hashlib.sha256(root.read_bytes()).hexdigest()
assert any(p['path'] == str(root) and p['sha256'] == root_sha
           for p in previous['compiledArtifacts'])
for p in previous['sources']:
    if p['path'] == 'AGENTS.md':
        continue
    assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest() == p['sha256']

logs = [out/'strict-lean.log', out/'build.log', out/'audit.log']
for path in logs:
    text = path.read_text()
    assert not re.search(r'^(error|warning):|: error:|: warning:', text, re.M), path
assert 'Build completed successfully' in (out/'build.log').read_text()
lint = (out/'audit.log').read_text()
assert lint.count('All linting checks passed') == 1
assert lint.count('Found 0 errors') == 1
assert lint.count('with 14 linters') == 1
axioms = json.loads((out/'axioms.json').read_text())
assert axioms['module'] == 'RiemannGaussian.ZetaRieszBalancedAllocationPayment'
assert axioms['onlyStandardAxioms']
for theorem in axioms['theoremAxioms']:
    assert set(theorem['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}


def saved(path):
    path = Path(path)
    data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    snapshot = out/f'snapshot-{sha}{path.suffix}'
    if snapshot.exists():
        assert snapshot.read_bytes() == data
    else:
        snapshot.write_bytes(data)
    return dict(path=str(path), sha256=sha, snapshot=str(snapshot))


text = source.read_text()
code = re.sub(r'/\-.*?\-/', '', text, flags=re.S)
assert not re.search(r'\b(sorry|admit|sorryAx)\b', code)
assert not any(line.rstrip() != line for line in text.splitlines())

report = dict(
    schemaVersion=1, date='2026-10-03', head=head,
    objective='Close out the floor.', goalRemainsActive=True,
    slice='Apply the existing independent allocation-tail bound to EVERY label of the remaining balanced population and spend it in the actual joint floor; the signed main minus the same prime head has no allocation mask.',
    sources=[saved(p) for p in [
        source,
        'RiemannGaussian/ZetaRieszBalancedOwnerFloor.lean',
        'RiemannGaussian/ZetaRieszJointAllocationFloor.lean',
        'RiemannGaussian/ZetaRieszParityShareTail.lean',
        'RiemannGaussian/ZetaRieszParityShareError.lean',
        'RiemannGaussian/ZetaRieszPrimeHeadPeriods.lean',
        'RiemannGaussian/ZetaRieszSmallTagNativeFloor.lean',
        'RiemannGaussian/ZetaRieszRoughPrimePairCancellation.lean',
        'RiemannGaussian/ZetaRieszAssignedCompanion.lean',
        'RiemannGaussian/ZetaSquarefreeVaughanLogSource.lean',
        'RiemannGaussian/ZetaRieszComplexNullFloor.lean',
        'RiemannGaussian/ZetaRieszCutoffPeriodFloor.lean',
        'RiemannGaussian/ZetaRieszComplexProjection.lean',
        'RiemannGaussian/ZetaRieszEndgameSlack.lean',
        'docs/zeta-riesz-balanced-allocation-payment.md', previous_path,
        'AGENTS.md', 'lean-toolchain', 'lake-manifest.json']],
    compiledArtifacts=[saved(p) for p in [
        '.lake/build/lib/lean/RiemannGaussian/ZetaRieszBalancedAllocationPayment.olean', root]],
    validation=dict(
        scope='Focused local only: strict leaf source, targeted leaf build, frozen compiled ordinary root plus explicit leaf. No root-source rebuild or wider gates.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(source), exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszBalancedAllocationPayment --wfail', exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(out/'Audit.lean'), exitCode=0,
            compiledOrdinaryRootImported=True, explicitLeafImported=True,
            frozenCompiledRootMatchesPrevious=True, rootSourceNotRebuilt=True,
            namespaces=1, lintersPerNamespace=14, allNamespaceLintersPass=True),
        publicTheorems=len(re.findall(r'^theorem [A-Za-z_]', text, re.M)),
        publicDefinitions=len(re.findall(r'^def [A-Za-z_]', text, re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheoremsIncludingPrivateAndGenerated=axioms['theoremsIncludingPrivateHelpers'],
        everyCompiledDeclarationAxiomChecked=True, onlyStandardAxioms=True,
        previousFrozenProofAndDocumentationSourcesPreserved=True),
    exactResults=dict(
        radiusRangeForAllocation='0<=u<=10001/20000',
        phaseHeightForAllocation='every real y; no zero/exposure hypothesis',
        fixedHeightForPreviousHighOwnerJointPayment='abs(y)>=54',
        unchangedCoreTotalLogRange=['39N/20 strict','203N/100 closed'],
        unchangedNativeCountCropPhysicalSupportPhaseFactorialKernelAndRieszLength=True,
        exactRemainingPopulation='native squarefree labels with log(largestPrime n)<51N/50',
        allPrimeLegsInsideAllocationTail='largest share<34/65<9/16',
        genericAllocationTailTheoremReusedNotClaimedNew=True,
        actualNativeCountCropRetainedNoFixedCount39OrLeastShareRestriction=True,
        independentComplexNormBoundForEntireAllocationCorrection=True,
        normEstimateAppliesToAnySubsetOfEntireRemainder=True,
        allocationBudget='4*radiusCeiling*(N+1)*allocationBoxRate^N*zetaMoebiusLogMajorantMass(1+1/262144)',
        rationalRateUpperBound='allocationBoxRate<9991081/10000000<1',
        allocationBudgetTendsToZero=True,
        noSmallFiniteOrderValueOfDirichletMassAsserted=True,
        exactDifference='unallocatedRest-residualRest=source-scaled assigned sum on SAME labels',
        signedMain='Re(unallocatedRest)-SAME nativeHead',
        originalSignedMainMinusHeadSourceEquivalentToWholeNativeRealCarrier=True,
        noAllocationMaskInNewMainWeight=True,
        oldWholeNativeTangentCorrectionRetained=True,
        allCountsAndCutoffCrossingsJoinedBeforePeriodClipping=True,
        allocationBudgetActuallySpentInWholeJoinedPhysicalFloor=True,
        sameHighOwnerBudgetAndNativeErrorRetained=True,
        oldWholePricesPreservedAsAlternativesNotStackedCredits=True,
        clippingMonotonicityUnderAllocationRemovalNotAssumed=True,
        noNormPaymentForMainOrHeadSeparately=True,
        noCofactorCompletionOrPhaseApproximation=True,
        noPercentageOfGlobalFloorDeficitClaimed=True),
    openPremises=dict(
        remainingSignedTarget='original balanced Riesz coefficient sum minus the exact signed prime head, all counts/radial periods joined',
        cofinalWholePrice='price<=399/5000 on a cofinal set of native dyadic indices',
        wholeFloorProved=False, multiplicityCeilingProved=False,
        restrictedContradictionProved=False, zeroExclusionProved=False, rhProved=False,
        conditionalEndpointNotCountedAsPremiseProof=True),
    publication=dict(localOnly=True, noCommitsOrPushes=True, noSubagents=True,
        noRootRegistration=True, publicEndpointsUnchanged=True,
        noReadmeExplorerChanges=True, concurrentSemiprimeWorkPreserved=True),
    provenance=[saved(p) for p in logs+[out/'Audit.lean', out/'axioms.json', Path(__file__)]])

blob = json.dumps(report, indent=2)+'\n'
(out/'report.json').write_text(blob)
Path('docs/riesz-balanced-allocation-payment-audit.json').write_text(blob)
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    publicDefinitions=report['validation']['publicDefinitions'],
    compiledDeclarations=axioms['declarations'],
    compiledTheorems=axioms['theoremsIncludingPrivateHelpers'],
    allChecksPass=True, wholeFloorStillOpen=True)))
