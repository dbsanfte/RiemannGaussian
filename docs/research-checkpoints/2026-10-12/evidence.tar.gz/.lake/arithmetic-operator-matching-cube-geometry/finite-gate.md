# Native positive shared-prime cube support

The new strict leaf is `scripts/QuasiRHMatchingCubeGeometryAudit.lean`.
It keeps the actual `summand`, height twist, both ideal slots and every
complex total-index mark. It does not substitute a squarefree Moebius
weight for the genuine Gauss column.

For nonzero native ideals, `P|I` and `P|J` imply

```
Norm(P)^4 <= Norm(I) Norm(J)^3.
```

Consequently every such atom is exactly zero in the compact annulus
whenever `2X <= Norm(P)^4`. This is support vanishing before any norm or
real-part estimate. It applies to arbitrary retained phases and marks.
The exact finite matching column therefore retains only `P` not dividing
`J`. It does NOT imply that every retained `J` equals one; unrelated cube
prime factors remain.

The native slot exponents give

```
4(23/48-d)-(7/6-d)=3/4-3d >= 1/4  (d<=1/6).
```

The terminal theorem retains positive fixed annular constants in the lower
prime bound and any fixed upper length constant. It proves the exact
finite-column deletion eventually at those scales, uniformly in its
finite set, all phases, and the literal marks. No population count,
signed estimate of the unshared column, Gaussian infinite-tail sum or
hypothetical-zero source limit is inferred.

This turns the previous nominal component probe into a checked support
statement for that precise native class. The previously surviving `J=1`
matching cofactor is explicitly outside the deleted class; it is not
claimed paid. This is an arithmetic support audit, not a new RH endpoint
or an exhaustion of any operator family.

Validation: warnings-as-errors strict cached leaf; all 15 linters;
all module-local declarations, including generated helpers, have only
`propext`, `Classical.choice`, `Quot.sound` axioms. See `strict-build.log`
and `axioms.json` for the final counts.
