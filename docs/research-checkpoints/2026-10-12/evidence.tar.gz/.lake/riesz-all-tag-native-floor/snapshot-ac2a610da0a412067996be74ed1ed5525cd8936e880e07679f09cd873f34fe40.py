from pathlib import Path
import hashlib
import json
import re
import subprocess

out = Path('.lake/riesz-all-tag-native-floor')
modules = ['ZetaRieszPrimeHeadPeriods', 'ZetaRieszAllTagNativeFloor']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '194a361762f404a8f4473298b25d96fbae0bb56e'
previous = json.loads(Path('docs/riesz-rough-prime-pair-cancellation-audit.json').read_text())
root = Path('.lake/build/lib/lean/RiemannGaussian.olean')
root_sha = hashlib.sha256(root.read_bytes()).hexdigest()
assert any(p['path'] == str(root) and p['sha256'] == root_sha
           for p in previous['compiledArtifacts'])
for p in previous['sources']:
    if p['path'].startswith('RiemannGaussian/'):
        assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest() == p['sha256']

logs = ['.lake/riesz-prime-head-periods/strict-lean.log',
        str(out/'strict-lean.log'), str(out/'build.log'), str(out/'audit.log')]
for path in logs:
    s = Path(path).read_text()
    assert not re.search(r'^(error|warning):|: error:|: warning:', s, re.M), path
assert 'Build completed successfully' in (out/'build.log').read_text()
lint = (out/'audit.log').read_text()
assert lint.count('All linting checks passed') == 2
assert lint.count('Found 0 errors') == 2
assert lint.count('with 14 linters') == 2
axioms = json.loads((out/'axioms.json').read_text())['modules']
assert {m['module'] for m in axioms} == {'RiemannGaussian.'+m for m in modules}
for m in axioms:
    assert m['onlyStandardAxioms']
    for theorem in m['theoremAxioms']:
        assert set(theorem['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}


def saved(path):
    path = Path(path)
    data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    snapshot = out/f'snapshot-{sha}{path.suffix}'
    if snapshot.exists():
        assert snapshot.read_bytes() == data
    else:
        snapshot.write_bytes(data)
    return dict(path=str(path), sha256=sha, snapshot=str(snapshot))


sources = [Path(f'RiemannGaussian/{m}.lean') for m in modules]
for path in sources:
    text = path.read_text()
    code = re.sub(r'/\-.*?\-/', '', text, flags=re.S)
    assert not re.search(r'\b(sorry|admit|sorryAx)\b', code)
    assert not any(line.rstrip() != line for line in text.splitlines())

probe_path = Path('.lake/riesz-prime-head-periods/probe.json')
probe = json.loads(probe_path.read_text())
probe_source = Path('scripts/probe_riesz_prime_head_periods.py')
assert hashlib.sha256(probe_source.read_bytes()).hexdigest() == probe['source']['sha256']
assert len(probe['cases']) == 6
assert not probe['scope']['floorOrZeroExclusionProved']
assert not probe['scope']['nativeCoreOrCofinalPoint']
for c in probe['cases']:
    assert c['earlyHeadFraction'] == 1

report = dict(
    schemaVersion=1, date='2026-10-03', head=head,
    objective='Close out the floor.', goalRemainsActive=True,
    slice='Independently pay ALL small-prime cofactors in the native owner range; join this complete owner population and its exact prime head before whole-floor period clipping.',
    sources=[saved(p) for p in sources+[
        'RiemannGaussian/ZetaRieszSmallTagNativeFloor.lean',
        'RiemannGaussian/ZetaRieszRoughPrimePairCancellation.lean',
        'RiemannGaussian/ZetaRieszTaggedCoreWindow.lean',
        'RiemannGaussian/ZetaRieszMaskSupport.lean',
        'RiemannGaussian/ZetaRieszComplexNullFloor.lean',
        'RiemannGaussian/ZetaRieszCutoffPeriodFloor.lean',
        'RiemannGaussian/ZetaRieszComplexProjection.lean',
        'RiemannGaussian/ZetaRieszEndgameSlack.lean',
        'docs/zeta-riesz-prime-head-periods.md',
        'docs/zeta-riesz-all-tag-native-floor.md',
        'docs/riesz-rough-prime-pair-cancellation-audit.json',
        'scripts/probe_riesz_prime_head_periods.py',
        'AGENTS.md', 'lean-toolchain', 'lake-manifest.json']],
    compiledArtifacts=[saved(p) for p in
        [f'.lake/build/lib/lean/RiemannGaussian/{m}.olean' for m in modules]+[root]],
    validation=dict(
        scope='Focused local only: strict leaf source, targeted two-leaf build, frozen compiled ordinary root plus explicit leaf. No root-source rebuild or wider gates.',
        strictLean=[dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(p), exitCode=0) for p in sources],
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszPrimeHeadPeriods RiemannGaussian.ZetaRieszAllTagNativeFloor --wfail', exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(out/'Audit.lean'), exitCode=0,
            compiledOrdinaryRootImported=True, explicitLeavesImported=True,
            frozenCompiledRootMatchesPrevious=True, rootSourceNotRebuilt=True,
            namespaces=2, lintersPerNamespace=14, allNamespaceLintersPass=True),
        modules=[dict(module='RiemannGaussian.'+m,
            publicTheorems=len(re.findall(r'^theorem [A-Za-z_]', p.read_text(), re.M)),
            publicDefinitions=len(re.findall(r'^def [A-Za-z_]', p.read_text(), re.M)),
            compiledDeclarations=next(a['declarations'] for a in axioms if a['module']=='RiemannGaussian.'+m),
            compiledTheoremsIncludingPrivateAndGenerated=next(a['theoremsIncludingPrivateHelpers'] for a in axioms if a['module']=='RiemannGaussian.'+m))
            for m,p in zip(modules,sources)],
        everyCompiledDeclarationAxiomChecked=True, onlyStandardAxioms=True,
        previousFrozenNativeAndRoughProofSourcesPreserved=True),
    exactResults=dict(
        radiusRange='1/2<u<=10001/20000', fixedHeight='abs(y)>=54',
        ownerLogRange=['51N/50','5N/4'], coreTotalLogRange=['39N/20 strict','203N/100 closed'],
        originalNativeCountCutoffAndAllPhysicalDeletionMasksProved=True,
        originalFullAllocationProductPhaseAndFactorialWeightsRetained=True,
        allSmallPrimeTagsThroughNCubedRetainedIncludingBelowNSquared=True,
        allTagBudgetEqualsPreviousRestrictedTagBudget=True,
        newlyPaidLabelsExcludeAllPreviouslyPaidSmallTagLabels=True,
        newlyPaidSignedRealContribution='abs(addedPacket_j)<=2*previousSmallTagBudget_j -> 0',
        independentOfZeroExposureAndUnprovedArithmeticHypotheses=True,
        exactSmallRoughPartitionCoversEverySquarefreeCompositeCofactorInOwnerCore=True,
        partitionIsDisjointAndHasNoAdditionalLeastOrSmallPrimeRestriction=True,
        completeOwnerPopulationJointBound='abs(fullPacket_j+nativeHead(N_j))<=combinedBudget_j -> 0',
        combinedBudgetUnchangedFromPreviousRoughPlusRestrictedTagSlice=True,
        independentComplexOrSeparatePacketHeadDecayClaimed=False,
        primeHeadCompleteCutoffTotalExactlyIdentified=True,
        primeHeadSieveSmoothAllocationAndPhaseRetained=True,
        oldMarkedTwoPrimeZeroTheoremNotMisapplied=True,
        physicalEndpointAddedOnlyByZeroNativeExtension=True,
        entireOwnerPaymentSpentOnceInActualNativeFloor=True,
        signedHeadJoinedWithWholeUnpaidMainBeforePeriodClipping=True,
        exactPeriodCostSaving='same-sign whole-period overlap - negative head period mass',
        negativeHeadCrossingsFullyRetained=True,
        wholeNullAndTangentDirectionsRetained=True,
        sameNativeErrorRetained=True,
        oldFloorsRetainedAsAlternativesNotStackedCredits=True,
        remainingOwnerExteriorAndHeadNumericalPriceOpen=True),
    optionalProbe=dict(source=saved(probe_source), result=saved(probe_path),
        outsideBuildsAndCI=True, toyIntegerCofactorIntervalExhausted=True,
        actualFiniteJointErrorPaidWithoutEventualRate=True, allCountsAndPeriodsJoined=True,
        floatingCases=6, casesWithPositiveFiniteImprovement=sum(c['verifiedFiniteSaving']>0 for c in probe['cases']),
        finiteSavingFractions=[c['verifiedFiniteSaving']/c['separatePrice'] for c in probe['cases']],
        nativeCoreOrPopulationSample=False, finiteOrCofinalCertificate=False),
    openPremises=dict(
        cofinalWholePrice='price<=399/5000 on a cofinal set of dyadic indices',
        noUniformNativeCreditOrCostBoundProved=True,
        wholeFloorProved=False, multiplicityCeilingProved=False,
        restrictedContradictionProved=False, zeroExclusionProved=False, rhProved=False,
        percentageOfGlobalFloorDeficitClaimed=False),
    localOnly=dict(noCommitsPushesSubagentsRootRegistrationPublicEndpointsOrWiderGates=True,
        concurrentSemiprimeWorkPreserved=True),
    frozenArtifacts=[saved(p) for p in logs+[str(out/'Audit.lean'),str(out/'axioms.json'),str(out/'write_report.py')]])
Path('docs/riesz-all-tag-native-floor-audit.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(modules=report['validation']['modules'],
    allCompiledDeclarationsAxiomChecked=True, onlyStandardAxioms=True,
    allTagBudgetUnchanged=True, completeOwnerPopulationJointlyPaid=True,
    wholeFloorProved=False), indent=2))
