"""Binary64 native-slot diagnostic; not a proof or source residue."""
import cmath
import json
from pathlib import Path

def prime(p):
    if p < 2:
        return False
    d = 2
    while d*d <= p:
        if p % d == 0:
            return False
        d += 1
    return True

ps = [101, 10007, 10000019, 100000007]
assert all(prime(p) and p % 3 == 2 for p in ps)
rows = []
for sigma in [0.5001, 0.55, 0.59, 0.6, 0.61, 0.7, 0.875]:
    for p in ps:
        Q = p*p
        s = complex(sigma, 54)
        t = 1/Q
        R = cmath.exp((3-6*s)*cmath.log(Q))
        D = cmath.exp(-s*cmath.log(Q))
        B = cmath.exp(s*cmath.log(Q))
        K = (1-t)*D
        J = -D+t*R
        marked = ((R*(1-t)-K*t)/(1-t)+J)/(1-R)
        correction = (1-t*t+(1-t)*(1-t)*marked)/(1-D)
        replacement = ((B-t)*(1-t)*(1-t)*marked-t*(1-t*t))/(1-D)
        raw = replacement/correction+1
        reduced = (1-t)*(R*(B-t)-(1-t)*D)/(1-t*R-(1-t)*D)
        lead = Q**(3-5*sigma)
        rows.append(dict(sigma=sigma, y=54, inert_rational_prime=p, Q=Q,
                         slot_plus_one_norm=abs(raw), leading_BR_norm=lead,
                         norm_ratio=abs(raw)/lead, raw_reduced_error=abs(raw-reduced)))
result = dict(scope="binary64 diagnostic of exact principal signs/powers at actual inert Eisenstein-prime trivial-character phase values; not proof/source residue",
              primes_verified_by_exact_trial_division=True,
              max_raw_reduced_error=max(r["raw_reduced_error"] for r in rows),
              leading_exponent="3-5*sigma", rows=rows)
Path(__file__).with_name("probe.json").write_text(json.dumps(result, indent=2)+"\n")
