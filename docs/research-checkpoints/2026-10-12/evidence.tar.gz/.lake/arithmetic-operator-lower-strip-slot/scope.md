# Actual principal slot below the published threshold

This leaf audits only the native all-prime-power local slot and its finite
positive supported-window multiplier. It does not extend a contour, global
Euler correction, source residue, inverse-row estimate, or zero-free theorem.
The active unexcluded zero domain remains `1/2 < beta <= 7/8`.

At the actual source coordinates `w=1`, `z=1/6`, set

- `t=Q^{-1}`;
- `D=eta Q^{-s}`;
- `R=A Q^{3-6s}`;
- `B=conj(eta) Q^s`, with `B D=1` for unit target phase.

The exact native formulas proved in the leaf are

`principalMarked = (1+t)(R-D)/(1-R)`;

`den = 1-tR-(1-t)D`;

`principalSlot+1 = (1-t)[R(B-t)-(1-t)D]/den`;

`principalSlot+1-RB = [t RB(R-1)+(1-t)^2(R-D)]/den`.

For sufficiently large Q at any fixed `Re(s)>1/2`, the last error has the
explicit bound

`3 Q^(2-5 Re(s)) + 2 Q^(3-6 Re(s)) + 2 Q^(-Re(s)) -> 0`.

The actual unramified sixth-angular/character phases have modulus one. Thus
`|RB| = Q^(3-5 Re(s))`. Compensation is the important exponent change: the
uncompensated marked term has exponent `3-6 Re(s)`, but the actual replacement
multiplies it by `Q^s`. The sharp local outcomes are:

- `Re(s)>3/5`: `principalSlot -> -1`;
- `Re(s)=3/5`: `|principalSlot+1| -> 1`;
- `1/2<Re(s)<3/5`: `|principalSlot+1| -> infinity`.

All three statements allow moving norm-one phases and retain all local powers.
Above `3/5`, the leaf also proves the actual native finite window multiplier at
`(w,z)=(1,1/6)` is nonzero when every norm exceeds a displayed sufficiently large
cutoff, every slot's target phase is unramified/norm-one, windows are nonnegative,
and each weighted window mass is positive. The cutoff conditions are eventually
available at every fixed exponent strictly above `3/5`. This is the finite source
multiplier gate only; global correction/source/contour continuation below `7/8`
remains separate. Below `3/5`, individual growth does not rule out cancellation
among specially prescribed prime-window coefficients; that source gate is open.

## Diagnostic and validation

`probe.py` compares the raw native definitions with the reduced formula using
binary64 complex arithmetic. It uses four verified inert rational primes, their
actual Eisenstein norms `Q=p^2`, the trivial target/positive angular phase `A=eta=1`,
height 54, and exponents on both sides of `3/5`. `probe.json` records the results.
It is diagnostic only, with no actual-zero residue or floating proof claim.

The isolated strict compile produces `QuasiRHLowerStripSlotAudit.olean` and the
actual `strict-build.log`. All 58 declarations defined by this leaf (57 theorems,
including generated helpers) were audited by module provenance: no project axiom,
and only `propext`, `Classical.choice`, and `Quot.sound`. All 15 namespace linters
passed with warnings treated as errors. No broad/migration check was run.
