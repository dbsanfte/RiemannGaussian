# Simultaneous-prime Kummer source gate: already audited, actual correlation open

This is a read-only source preflight. No new Lean leaf is proposed: the exact
source-inference question is already covered by
`scripts/ArithmeticOperatorKummerAffineSourceAudit.lean`.

## Native finite identity

`twoLarge_iff` (line 45) proves the full iff for the SAME binomial row:

`n even, n>=4, p>q>2 prime, n<p^2, n<q^2, p|evenGcd(n), q|evenGcd(n)`

is exactly

`n=2q, p=2q-1, q>2, q and p both prime`.

`twoLarge_valuations` gives both exact valuations one. `nativePacket_eq`
(line 132) joins every original label, owner, prime and phase mask into

`sum_q log(q) log(2q-1) W(2q,2q-1,q)`

with both primality tests and all three finite supports retained.
`affine_prime_mod_three` keeps the actual exceptional pair `(p,q)=(5,3)`:
apart from it, `q mod 3=1`. It is only a necessary local condition, not a
character selector for the prime-pair population.

The selected above-square-root sector has valuation one. The whole nonprefix
row, including every proper power and the raw empty `n=2` endpoint, is
separately preserved in `ArithmeticOperatorKummerParityAudit`. Its complement
has not been paid by the selected-sector theorem.

## Existing exact source non-implication

`actual_residue_does_not_force_affine` (line 346) is already the strongest
requested scoped array theorem. At the exact actual zero and its analytic
multiplicity, a density-free complex Dirichlet residue alone does not force
ANY nonzero affine packet among the permitted arrays.

The explicit control is

`g(0)=0; g(n)=2v*n^(beta-1+iy)` on positive even `n`, and zero on odd `n`.

Its response converges genuinely for `Re(s)>beta`, continues analytically at
the density point 1, and has exact residue `v` at `beta+iy`. Nevertheless
`g(q)g(2q-1)=0` for every natural q, including q=0. Every correlated mask,
complex weight, and zero-preserving leg operation remains joined. Möbius
inversion gives exact divisor realization of the same array.

**Scope is essential:** this is NOT the actual prime/von-Mangoldt array, a
generalized-prime Euler control, or an array granted the actual complete
binomial/Gamma identities. In particular it is NOT granted the unchanged
actual `mu * log` Selberg coefficient equality. It disproves only linear
residue/divisor-incidence source inference. It does not prove that the actual
restricted prime source vanishes, that no prime-specific theorem can attach
it, or that the entire Tier-1 family is exhausted.

## Why the imported finite convolutions do not already close it

`SuzukiLogarithmicConvolution.vonMangoldt_logWeight_add_self_convolution`
is the exact actual identity

`Lambda(n) log n + sum_(ab=n) Lambda(a)Lambda(b) = sum_(d|n) mu(d)log(n/d)^2`.

It includes ALL multiplicative pairs `ab=n`. It neither selects nor assigns
a zero residue to the affine curve `2q-p=1`. Inserting that constraint adds an
unestimated correlation/mask term; it does not preserve the complete pair
log-derivative Euler source automatically.

Full prime-power completion must be honest. At the coefficient level, let
`P(n)=Lambda(n)-Q(n)`, where Q is the existing proper-prime-power coefficient.
Then the ordinary selected pair is exactly

`P(q)P(2q-1) = Lambda(q)Lambda(2q-1)
 - Lambda(q)Q(2q-1) - Q(q)Lambda(2q-1) + Q(q)Q(2q-1)`.

This elementary ring identity could be formalized, but by itself is another
equivalent coefficient ledger. It does not prove a pole, continuation,
nonzero zero response, or a signed estimate. All mixed proper-power terms,
the `q=2` excluded head, and the retained `(5,3)` pair must stay explicit
before any analytic completion is claimed.

`PFreeTwoSourceAudit` is a DIFFERENT gate: its unmarked cofactor-two row is
exactly `(principal_8 + chi_4)/2` on ordinary odd primes. The complete Euler
response has the actual nonzero mass `m_zeta/2+order(L_chi4)/2`, with proper
powers analytic for `Re(s)>1/2`. Adding `2q-1 prime` is not part of that fixed
selector. Its source proof cannot be silently transferred through this
nonlinear mask.

## Precise remaining input and decision

The missing theorem must attach a nonzero hypothetical-zero response to the
ACTUAL restricted affine correlation with its canonical weights, masks,
heads and proper-power corrections; after that, an independent signed
estimate is still required. Diagnostic power responses, arbitrary arrays,
fixed-character Euler products, and complete multiplicative Selberg pairs
do not supply that attachment.

The existing exact no-go is sufficient to freeze the same source-inference
shortcut. Do not duplicate it or expand a detector around the population
without a genuinely new prime-specific correlation identity. No new RH
estimate, population asymptotic, family-exhaustion claim, or zero exclusion
is produced by this preflight.

Historical evidence for the unchanged affine source leaf records strict
warning-as-error exit 0, all 15 linters, 41 all-local declarations / 34 theorem
declarations and standard axioms only. This preflight does not count that
old build as a new proof or rerun broader migration checks.

## Short primary-literature check (8 October 2026)

[Green and Tao, *Linear equations in primes*, Lemma 1.6, page 8](https://arxiv.org/pdf/math/0606088)
requires the absence of affinely dependent forms for finite complexity.
Here the forms are `q` and `2q-1`; their linear parts are proportional, so
this theorem does not supply the restricted correlation. The paper itself
separates binary systems from its finite-complexity result. This is an
applicability check, not a claim that its methods cannot be enhanced.

[Ford and Maynard, *On the theory of prime-producing sieves*, introduction](https://arxiv.org/html/2407.14368v1)
starts from separately established Type I distribution and Type II bilinear
information. It does not produce those hypotheses from a zeta-zero residue.
Its discussed comparison weights are nonnegative; using it on this complex
phase-preserving packet would additionally require an exact reduction and
the corresponding proved estimates. Neither paper attaches the desired
actual masked nonlinear source in the presently checked chain. No full
Hardy–Littlewood asymptotic is asserted necessary for the weaker endpoint.
