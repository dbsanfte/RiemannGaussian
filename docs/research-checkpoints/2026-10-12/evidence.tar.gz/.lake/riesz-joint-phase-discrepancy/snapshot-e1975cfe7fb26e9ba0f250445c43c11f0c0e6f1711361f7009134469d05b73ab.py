from pathlib import Path
import hashlib
import importlib.util
import json
import math
import shutil
import subprocess
import sys

import numpy as np

sys.dont_write_bytecode = True
folder = Path('.lake/riesz-joint-phase-discrepancy')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot(path):
    path = Path(path)
    sha = digest(path)
    target = folder / f'snapshot-{sha}{path.suffix}'
    if not target.exists():
        shutil.copy2(path, target)
    return dict(path=str(path), sha256=sha, snapshot=str(target))


previous_path = Path('docs/riesz-owner-completion-audit.json')
previous = json.loads(previous_path.read_text())
for section in ['sources', 'compiledArtifacts', 'provenance']:
    for source in previous[section]:
        if source['path'] != 'AGENTS.md':
            assert digest(source['path']) == source['sha256'], source['path']
for source in json.loads((folder / 'unrelated-working-tree-before.json').read_text()):
    assert digest(source['path']) == source['sha256'], source['path']

# Independent small closed-form checks of the energy algorithm. These are
# floating regressions, not a Lean proof or an interval certificate.
sys.path.insert(0, str(Path('scripts').resolve()))
spec = importlib.util.spec_from_file_location('joint_discrepancy',
    'scripts/probe_riesz_joint_phase_discrepancy.py')
probe_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe_module)
checks = []
period = 2*math.pi
for phase in [0., 0.123, math.pi, period-1e-8]:
    a = 0.75
    row = probe_module.discrepancy(np.array([phase]), np.array([a]))
    assert abs(row['centeredPrimitiveEnergy']-a*a*period/12) < 2e-14
    assert abs(row['signedTotal']['re']-a*math.cos(phase)) < 2e-14
    assert abs(row['signedTotal']['im']+a*math.sin(phase)) < 2e-14
    checks.append(dict(kind='single atom exact sawtooth energy', phase=phase))
row = probe_module.discrepancy(np.array([0.5, 0.5]), np.array([0.75, -0.75]))
assert row['centeredPrimitiveEnergy'] == 0
assert row['signedTotal'] == dict(re=0., im=0.)
checks.append(dict(kind='identical phases opposite amplitudes cancel exactly'))
row = probe_module.discrepancy(np.array([0., math.pi]), np.array([0.5, -0.5]))
assert abs(row['centeredPrimitiveEnergy']-period/16) < 2e-14
assert abs(row['signedTotal']['re']-1) < 2e-14
checks.append(dict(kind='opposite signed phases reinforce first harmonic'))

rows, regressions = [], 0
for name in ['probe.json', 'order8.json']:
    data = json.loads((folder / name).read_text())
    for source in data['sources']:
        assert digest(source['path']) == source['sha256'], source['path']
    rows += data['cases']
    regressions += data['frozenComplexTotalRegressions']
assert len(rows) == 18 and regressions == 18
assert sum(r.get('improvesPreviousFundedPrice', False) for r in rows) == 0
assert sum(r.get('improvesPreviousCubicSignedPrice', False) for r in rows) == 0
for row in rows:
    assert row['fullComplexPhaseRetained'] and row['noSourceHarmonicDeleted']
    assert row['noCofinalFloorProved']
    assert abs(row['signedIntegralOfPrimitive']-row['signedTotal']['re']) < 3e-12
    assert 0 <= row['firstHarmonicEnergyFraction'] <= 1

report = dict(schemaVersion=1, date='2026-10-03',
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    objective='Close out the floor.', goalRemainsActive=True,
    verdict='Finite no-go for the tested whole circular CDF Cauchy price; no new arithmetic floor saving. This does not refute every native/cofinal phase-energy method.',
    sources=[snapshot(p) for p in [
        'scripts/probe_riesz_joint_phase_discrepancy.py',
        'scripts/probe_riesz_balanced_joint.py',
        'scripts/probe_riesz_balanced_signature.py',
        'scripts/probe_riesz_joint_phase_transport.py',
        'RiemannGaussian/ZetaRieszJointPhaseTransport.lean',
        'RiemannGaussian/ZetaRieszBalancedRadialPayment.lean',
        'RiemannGaussian/ZetaRieszSignedConvolution.lean', previous_path, 'AGENTS.md']],
    validation=dict(noNewLeanDeclarations=True, noLeanBuildOrRootRebuildRun=True,
        previousFocusedProofValidationNotRerun=True,
        frozenPreviousProofProbeDocumentationAndCompiledArtifactsHashChecked=True,
        unrelatedWorkingFilesHashChecked=231,
        closedFormFloatingAlgorithmChecks=checks,
        intervalCertified=False),
    algorithm=dict(
        atoms='Every original balanced toy main label and SAME full correction joined before energy',
        signedMeasure='nu = sum a_label delta_(y log(label) mod 2pi)',
        primitive='F(theta) = nu([0,theta]) - nu(circle)*theta/(2pi)',
        centeredPrimitive='F0 = F - mean(F)',
        energy='E = integral_0^(2pi) F0(theta)^2 dtheta',
        signedIdentity='Re(joint) = integral_0^(2pi) F0(theta) sin(theta) dtheta',
        wholeCauchyPrice='sqrt(pi*E)',
        firstHarmonicEnergy='abs(joint)^2/pi',
        allArithmeticSignsAndOriginalComplexPhasesRetained=True,
        sameFullHeadWindowAfterMainRadialPruning=True,
        noCountPrimeOrthogonalityOrDensityAssumed=True,
        noSourceHarmonicDeleted=True),
    optionalProbe=dict(cases=18, frozenComplexTotalRegressions=18,
        orders=[6, 7, 8], heights=[54, 65, 100],
        mainWindows=[[1.95, 2.03], [1.971, 2.029]], fullHeadWindow=[1.95, 2.03],
        previousFundedPriceComparisons=12, previousFundedPriceImprovements=0,
        previousCubicSignedPriceComparisons=18, previousCubicSignedPriceImprovements=0,
        firstHarmonicEnergyFractionRange=[min(r['firstHarmonicEnergyFraction'] for r in rows),
                                         max(r['firstHarmonicEnergyFraction'] for r in rows)],
        byOrder=[dict(N=N,
            wholeCauchyPriceRange=[min(r['wholeSignedCauchyPrice'] for r in rows if r['N']==N),
                                  max(r['wholeSignedCauchyPrice'] for r in rows if r['N']==N)])
            for N in [6, 7, 8]],
        toyLength='-2N log(10001/20000)', nativeMovingIntegerLength=False,
        nativeDyadicSchedule=False, fullNativeDeletionMasks=False,
        previousEventualBudgetsApplied=False,
        optionalOutsideBuildsCI=True, numericalCertificate=False,
        evidence=[snapshot(folder / p) for p in ['probe.json', 'probe.log', 'order8.json', 'order8.log']]),
    literatureCheck=dict(
        applicabilityConclusionIsAnInference=True,
        sources=[dict(title='Tao and Teravainen: The structure of logarithmically averaged correlations of multiplicative functions',
            url='https://arxiv.org/pdf/1708.02610', location='Corollaries 1.6 and 1.8',
            result='Logarithmically averaged cancellation under fixed multiplicative-function hypotheses.',
            gap='Does not state the required fixed power saving for this moving masked factorial sum.'),
            dict(title='Matomaki and Radziwill: Multiplicative functions in short intervals',
            url='https://annals.math.princeton.edu/2016/183-3/p06', location='Abstract and published paper',
            result='Relates short and long averages, including Mobius cancellation in almost all growing short intervals.',
            gap='No uniform signed source-scale estimate for the present masked packet has been derived from it.')],
        existingRateAudits=['RiemannGaussian/ZetaRieszTypeIIRateAudit.lean',
                            'RiemannGaussian/ZetaRieszManyBinRateAudit.lean'],
        noUniversalLiteratureImpossibilityClaim=True),
    nextObligation=dict(
        exactSignedBias='Re(centralRest)-nativeHead, retaining all counts and original correlated phase weights',
        sufficientCofinalFloor='-399/5000-o(1)',
        firstHarmonicArithmeticallyBounded=False,
        genericCircularL2InfrastructureNotAdded=True,
        higherHarmonicSmallnessDoesNotPayFirstHarmonic=True,
        newGlobalSavingProved=False, cofinalFloorProved=False,
        multiplicityCeilingProved=False, contradictionProved=False,
        zeroExclusionProved=False, rhProved=False),
    publication=dict(localOnly=True, noCommitsOrPushes=True,
        noRootRegistration=True, noPublicEndpointUpdates=True,
        noSubagents=True, concurrentSemiprimeWorkNotEdited=True),
    provenance=[snapshot(folder / 'unrelated-working-tree-before.json'),
                snapshot(folder / 'write_report.py')])
Path('docs/riesz-joint-phase-discrepancy-audit.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(cases=18, regressions=18, closedFormChecks=len(checks),
    wholePriceImprovements=0, newFloorSaving=False, goalStillOpen=True)))
