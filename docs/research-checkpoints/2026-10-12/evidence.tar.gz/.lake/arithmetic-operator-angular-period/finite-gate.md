# Actual angular-six coefficient versus finite ray characters

Strict local leaf: `scripts/QuasiRHAngularPeriodAudit.lean`, warning-as-error
exit 0, all 15 namespace linters, all 27 local declarations / 22 theorems
including generated helpers audited by module provenance. Only the
standard `propext`, `Classical.choice`, `Quot.sound` axioms occur.

For any actual finite ray characters eta and psi, let

    b = 3 * period_eta * period_psi,
    z = 1 + b*omega.

The element is nonzero and primary; its values under both finite
characters are exactly one. Its embedded sixth power has imaginary part

    3*b*(1-b)*(1+b)*(2-b)*(1-2*b)*Im(omega3),

which is nonzero for b>=3. Consequently the actual angular-six coefficient
of z is not one. Passing through `primaryGenerator_span` yields a genuine
ideal coefficient mismatch, not a synthetic complex phase.

The witness can also be chosen congruent to one modulo any prescribed
nonzero ideal M: enlarge the proxy's recorded period by Norm(M), without
changing its values. Its principal ideal is then coprime to M. Thus a
fixed collection of bad-prime exclusions does not repair the direct
coefficient substitution. The final theorem is
`actual_angular_channel_not_finite_ray_outside_modulus`.

This blocks applying a finite-ray theorem by asserting coefficient
equality. It does NOT rule out an independent infinity-type Hecke
continuation/nonvanishing theorem, accidental norm-fiber Dirichlet-series
identities, or a new source-preserving coupled arithmetic estimate.
There is no new RH inequality or zero exclusion.
