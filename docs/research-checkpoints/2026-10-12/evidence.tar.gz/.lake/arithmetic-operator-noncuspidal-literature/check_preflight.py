"""Read-only source pins and exact rational strength calibration.

The hypothetical volume-Burgess formula is a diagnostic, not an imported
theorem for Eisenstein composite moduli and not a whole-probe estimate.
"""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
pin = json.loads((ROOT / "vendor/openai-quasi-rh/upstream-pin.json").read_text())

def objects(obj):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            yield from objects(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from objects(value)

upstream = {o["path"]: o["sha256"] for o in objects(pin)
            if "path" in o and "sha256" in o}
paths = [
    "vendor/openai-quasi-rh/OAI/NumberTheory/DirichletL/Detector/GramBound.lean",
    "vendor/openai-quasi-rh/OAI/NumberTheory/DirichletL/Detector/LowSelectedSum.lean",
    "vendor/openai-quasi-rh/OAI/NumberTheory/DirichletL/Detector/LowNominalEnergy.lean",
    "vendor/openai-quasi-rh/OAI/NumberTheory/DirichletL/Detector/LowCauchy.lean",
    "vendor/openai-quasi-rh/OAI/NumberTheory/DirichletL/Eisenstein/CompactEnergyFamilies.lean",
    "vendor/openai-quasi-rh/OAI/NumberTheory/DirichletL/GaussSum/DualKernelSummability.lean",
    "RiemannGaussian/ZetaQuasiRHProbeCalibration.lean",
    "scripts/QuasiRHCuspidalInputAudit.lean",
    "scripts/QuasiRHCalibratedMatchingAudit.lean",
    ".lake/arithmetic-operator-openai-next/budget-audit.md",
    ".lake/arithmetic-operator-gaussian-inverse-source/source-preflight.md",
]
rows = []
for name in paths:
    digest = sha256((ROOT / name).read_bytes()).hexdigest()
    row = {"path": name, "sha256": digest}
    prefix = "vendor/openai-quasi-rh/"
    if name.startswith(prefix):
        row["upstreamPinMatched"] = upstream[name[len(prefix):]] == digest
        assert row["upstreamPinMatched"]
    else:
        row["scope"] = "current local read-only checkpoint"
    rows.append(row)

sources = [
    {"id": "DFDDS-v2", "url": "https://arxiv.org/html/2410.03048v2",
     "versionDate": "2026-03-03", "location": "Lemmas 6.6 and 6.7",
     "classification": "unconditional theta-pole-separated input, native coefficient/joint-budget bridge missing"},
    {"id": "DFDH-v1", "url": "https://arxiv.org/html/2607.07911v1",
     "versionDate": "2026-07-08", "location": "Theorem 1.1, equations (2.4)-(2.10)",
     "classification": "unconditional cubic generic-norm bias lower bound, not prescribed signed-row upper bound"},
    {"id": "Dunn2025", "url": "https://msp.org/ant/2025/19-9/ant-v19-n9-p04-s.pdf",
     "location": "Theorem 1.5", "classification": "cuspidal hypothesis fails for actual native residual"},
    {"id": "Dunn-Radziwill", "url": "https://authors.library.caltech.edu/records/gj1ev-0dk12",
     "location": "primary authors' abstract, dispersion main-term hypothesis",
     "classification": "GRH-conditional dispersion, unavailable as unconditional input"},
    {"id": "DDHL", "url": "https://arxiv.org/abs/2306.11875",
     "classification": "quartic Gaussian-field coefficients, no native cubic/sextic substitution"},
    {"id": "Alsetri-Shao-v1", "url": "https://arxiv.org/html/2509.07765v1",
     "versionDate": "2025-09-09", "location": "Theorem 1.1",
     "classification": "prime-field rank-two GAP, composite Eisenstein applicability open"},
    {"id": "Chattopadhyay-v5", "url": "https://arxiv.org/html/2602.22167v5",
     "versionDate": "2026-06-28", "location": "Theorem 1",
     "classification": "finite-field boxes with subfield conditions, not CRT-composite annuli"},
    {"id": "Wu-v6", "url": "https://arxiv.org/html/1604.08551v6",
     "versionDate": "2019-02-23", "location": "Theorem 1.1",
     "classification": "all-number-field Hecke L subconvexity; actual character/conductor/Mellin bridge needed"},
]
data = {"kind": "read-only primary-source applicability preflight",
        "reviewDate": "2026-10-08", "upstreamCommit": pin["commit"],
        "sourcePins": rows, "primarySources": sources,
        "newLeanTheorem": False, "newArithmeticEstimate": False,
        "newZeroFreeClaim": False, "broadBuildRun": False,
        "sharedFilesChanged": False, "activeUnexcludedDomain": "1/2 < beta <= 7/8"}
(OUT / "source-pins.json").write_text(json.dumps(data, indent=2) + "\n")

b = F(11, 16)
depths = [F(0), F(1, 12), F(1, 6)]
table = []
for d in depths:
    vl, vs = F(5, 6)-2*d, F(17, 48)-d
    def saving(v, r):
        return v/r - b*F(r+1, 4*r*r)
    rl = max(range(1, 10001), key=lambda r: saving(vl, r))
    rs = max(range(1, 10001), key=lambda r: saving(vs, r))
    table.append({"slotDepth": str(d), "longVolumeExponent": str(vl),
                  "shortVolumeExponent": str(vs),
                  "longConductorRatioExponent": str(vl-b),
                  "shortQuarterMargin": str(vs-b/4),
                  "hypotheticalLongBestR": rl,
                  "hypotheticalLongSaving": str(saving(vl, rl)),
                  "hypotheticalShortBestR": rs,
                  "hypotheticalShortSaving": str(saving(vs, rs))})
assert table[-1]["shortQuarterMargin"] == "1/64"
assert table[-1]["hypotheticalShortBestR"] == 22
assert table[-1]["hypotheticalShortSaving"] == "1/2816"
assert table[-1]["hypotheticalLongSaving"] == "5/32"
# The exact square identity proves the short maximum beyond the finite scan.
for r in [F(i) for i in range(1, 10001)]:
    assert F(1, 2816) - (r-11)/(64*r*r) == (r-22)**2/(2816*r*r)
budget = {"kind": "exact rational diagnostic, not a Lean theorem or native estimate",
          "hypotheticalFormula": "V^(1-1/r) * Norm(B)^((r+1)/(4*r^2)+epsilon)",
          "table": table, "globalRequiredCriticalLineGain": ">3/8",
          "shortUniversalSquareIdentity": "1/2816-g_r=(r-22)^2/(2816*r^2)",
          "optimisticLongSavingTransferWouldLeaveBeta": str(F(7, 8)-F(5, 32)),
          "actualWholeProbeTransfer": "unproved; row saving must not be substituted into 3/16 automatically"}
(OUT / "quantitative-preflight.json").write_text(json.dumps(budget, indent=2) + "\n")
print(json.dumps({"vendorPinsMatched": sum("upstreamPinMatched" in r for r in rows),
                  "primarySources": len(sources), "rationalChecks": "passed",
                  "newArithmeticEstimate": False}))
