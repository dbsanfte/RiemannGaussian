# Noncuspidal cubic-theta literature and calibrated puncture preflight

Read-only audit, 2026-10-08. No external theorem was imported, no proof file
was changed, no build was run and no new arithmetic/RH bound is claimed.
The active unexcluded domain remains `1/2 < beta <= 7/8`.

## Native object and quantitative hurdle

The joined matching channel is the actual Eisenstein row, not an arbitrary
coefficient sequence. The checked `calibrated_matching_annulus_eq` gives

```
actual matching constant *
  [U_B(Q) - chi_B(p) * U_B(Q / Norm(p))],

U_B(V) = sum_m C.residueMonoid(m) * idealRowHom(m)(B)
                   * W(Norm(m)/V).
```

The same `B` and calibration `C` occur in BOTH sums. The conductor of the
punctured whole function may include `p`, but neither complete cofactor
sum should be charged conductor `C*B*p`. The actual height twist remains
inside `W`; all powers in `B` and the unit-cofactor endpoint are retained.

In the existing squarefree-cube inverse coefficient, the label is `I*J^3`,
with `I` squarefree and every `J` retained. The imported
`normalized_infinityCoefficient_squarefree_cube` identifies that actual
coefficient with a nonzero scalar times the conjugate of the cubic
Eisenstein residual coefficient. Its nonzero cusp average is already
checked in `QuasiRHCuspidalInputAudit`. Thus cuspidal estimates cannot be
applied directly by renaming this sequence.

The pinned native low cost is `Z^(3/16+epsilon)`; the selected signal is
`Z^(beta-11/16)`. Their margin is `beta-7/8`. A uniform transfer to beta=1/2
requires low-exponent gain strictly greater than `3/8`. Eliminating the
entire exceptional sixth-frequency allowance saves only `1/96` in the
existing Cauchy budget. These are existing checked calibrations, not
exponents supplied by the papers below.

## Recent primary literature: exact scope

### David--de Faveri--Dunn--Stucky, revised March 2026

[Non-vanishing for cubic Hecke L-functions, v2](https://arxiv.org/html/2410.03048v2),
Lemmas 6.6--6.7, is the closest unconditional residual-separated input.
For smooth compact `H`, nonzero `eta,a,b,c` with primary `a,b,c`,
squarefree `abc`, and `eta | 3`, Lemma 6.7 separates the Gauss-character
sum into its explicit theta pole and a contour remainder. The pole is
zero unless `b=1`, and otherwise has scale `M^(4/3-sigma-it)` with the
actual normalized Gauss coefficient and local `Delta` factors. Its
remainder has `M^(1-sigma+epsilon)` times divisor-weighted integrals of
the Kubota series at `1+epsilon+i(t+y)`. Lemma 6.6 bounds its second moment
in a full twist ball by `Norm(h)^(1/2) M^(1+epsilon)(1+|t|)^2` for
`1<sigma<=5/4`.

Classification: genuinely noncuspidal and source-preserving for THAT
polar sum. It is not a signed estimate for the prescribed sextic
calibration/inverse-theta join. An exact coefficient/coprimality/profile
bridge and quantitative summation over the actual `I,J` family are still
missing. No improvement to the native `3/16` is furnished by direct
substitution. Removing its theta pole requires a source ledger; it must
not be declared source-free.

### de Faveri--Dunn--Hoffstein, July 2026

[Non-orthogonality of the cubic and quartic large sieves via Rankin--Selberg](https://arxiv.org/html/2607.07911v1),
Theorem 1.1 and equations (2.4)--(2.10), use the preceding residual
separation to prove unconditionally

```
Xi_3(A,B) >= const_epsilon * (AB)^(-epsilon)
                         * [A+B+(AB)^(2/3)].
```

Here `Xi_3` is the operator norm over arbitrary squarefree primary cubic
character coefficients. The polar mean-square is of size
`A^(2/3-epsilon) B^(5/3)` while the remainder mean-square is
`O((AB)^(1+epsilon))`. This proves the generic cubic large-sieve bias is
unavoidable. It does NOT rule out cancellation for the repository's one
prescribed signed row. The paper explicitly distinguishes its
unconditional norm result from the still conditional prime results in
Dunn--Radziwill.

Classification: unconditional generic norm obstruction and useful
residual bookkeeping; not a new signed upper bound for the native row.

### Dunn, published 2025; Dunn--Radziwill

[Dunn, Metaplectic cusp forms and the large sieve](https://msp.org/ant/2025/19-9/ant-v19-n9-p04-s.pdf),
Theorem 1.5, requires a cusp form. The actual residual fails the necessary
zero-average condition. The local Lean audit already retains its
normalization and every `J` power. Classification: direct application
blocked; a genuine cusp/residual decomposition must preserve the
hypothetical source before estimating either part.

[Dunn--Radziwill, Bias in cubic Gauss sums](https://authors.library.caltech.edu/records/gj1ev-0dk12)
separates a nontrivial asymptotic main term in its dispersion estimate,
but assumes GRH for Hecke L-functions over the Eisenstein field.
Classification: conceptually relevant but unavailable as unconditional
RH input. The July 2026 norm lower bound removes GRH from that norm
conclusion, not from the prime dispersion theorem.

The quartic prime-sum improvement of
[David--Dunn--Hamieh--Lin](https://arxiv.org/abs/2306.11875)
is over the Gaussian field with quartic theta data. Classification:
different native field/coefficients; no direct cubic/sextic transfer.

## Punctured Burgess test: genuinely distinct conductor, still a gate

For the Gaussian-centered `J=1` cofactor at native slot depth
`0 <= d <= 1/6`, the checked geometry is

```
Norm(B) ~ Z^(11/16),
Q       ~ Z^(5/6-2d),
Q/Norm(p) ~ Z^(17/48-d).
```

Ignoring the fixed calibration norm only in exponent arithmetic, the
first ratio `Q/Norm(B)` has exponent `7/48-2d`. The second volume still
exceeds the quarter-conductor scale: at the worst depth `d=1/6`,

```
short volume exponent = 3/16,
quarter conductor    = 11/64,
margin                = 1/64.
```

This is a legitimate small-sum preflight improvement over assigning the
larger conductor `C*B*p`. It is not yet a Burgess theorem for the actual
row. Native nonzero `B` need not itself be squarefree: `I*J^3` is literal,
and a primitive squarefree conductor reduction must retain zeros at
imprimitive primes. Even in the `J=1` sector the effective modulus is
composite and the Eisenstein quotient/lattice is not one prime field.

[Alsetri--Shao, 2025 preprint / 2026 journal publication](https://arxiv.org/html/2509.07765v1),
Theorem 1.1, proves cancellation for proper rank-two GAPs in a prime
field, above volume `p^(1/4+epsilon)`. It does not treat the composite
Eisenstein ring `O/(C*B)`.

[Chattopadhyay, June 2026 v5](https://arxiv.org/html/2602.22167v5),
Theorem 1, treats boxes over a finite field `F_(p^n)`, with side/volume
and subfield-character hypotheses. It does not assert the corresponding
CRT-composite theorem. Annular weights and the growing calibration
conductor require additional exact bridges. Both classify as possible
tools for prime-modulus subfamilies, not direct whole-row input.

For strength calibration ONLY, suppose the classical volume-shaped
bound `V^(1-1/r) Norm(B)^((r+1)/(4r^2)+epsilon)` were valid. At `d=1/6`
the short-sum saving is exactly

```
g_r = (r-11)/(64*r^2),
max_(integer r>=1) g_r = 1/2816, attained at r=22.
```

The long sum has positive raw savings as well; the best value in this
formula at the same depth is `5/32` at `r=1` (the classical
Polya--Vinogradov-shaped case), or `31/256` at `r=2`. Neither is an
asserted Eisenstein estimate. A pointwise row saving is not automatically
a gain in the existing global `3/16` budget: the signed cofactor sum,
slot averaging and inverse coefficients must be joined before a valid
whole-probe comparison. Even optimistically transferring the worst-depth
raw `5/32` as a full low-exponent gain would leave beta threshold
`23/32`, well above the critical line. It could improve a restricted
frontier, but cannot discharge RH through this budget alone.

The broader unconditional number-field theorem
[Wu, Burgess-like subconvexity for GL1](https://arxiv.org/html/1604.08551v6)
bounds the Hecke L-value by analytic conductor to
`1/4-(1-2theta)/16+epsilon`. This covers varying Hecke characters, rather
than arbitrary multiplicative row functions. Applying Mellin inversion
to the actual annulus would first require unit/ideal descent, the actual
primitive conductor, fixed calibration, and height-uniform smooth-weight
control. Its direct smoothed-sum estimate is not the quarter-threshold
short-sum theorem above. No such bridge or full probe gain is claimed.

## Verdict and next finite test

No applicable unconditional source-preserving signed estimate improving
the complete native growing-cofactor join was found in this audited
set. This is not a claim that the literature contains no such theorem.
The 2026 results make a blanket better cubic norm payment less plausible;
they do not settle the prescribed correlated row.

The strongest distinct short test is to prove the actual cofactor
character's unit/ideal descent and primitive conductor after extracting
the matching prime, retaining the fixed calibration and all imprimitive
zeros. Then determine whether a genuine number-field short-sum estimate
can be summed over the prescribed `I,J` row with a useful low-budget gain.
That source-preserving bridge must precede a theorem import. A mere
arbitrary-coefficient large-sieve bound or deleting the polar theta term
is not that bridge.
