# Actual minimum-period obstruction: prime cofactor

The new isolated leaf is `scripts/QuasiRHMinimalPeriodAudit.lean`, namespace
`OpenAIReview.MinimalPeriod`. It imports the unchanged calibrated matching
audit. No vendor proof, public theorem root, shared note, or campaign endpoint
was edited.

## Exact native result

For genuine good prime ideals `(b)` and `(p)`, and the actual calibration
`C`, retain the full row

`f(m) = 1_{m not in (p)} C.residueMonoid(m) idealRowHom(m,(b))`.

The exact zero locus is

`f(m)=0 iff m in (p) or mk_C(m) is not a unit or m in (b)`.

This follows from the actual finite multiplicative characters'
`apply_eq_zero_iff`, not from an assumed primitive conductor or random
phase. If `b` is coprime to `C.generator*p`, CRT gives an exact zero atom
whose translate is nonzero whenever the translation `r` is outside `(b)`.
Consequently every full additive period satisfies `b | r`.

If additionally `p` is coprime to `C.generator*b`, the same **zero-locus**
argument also gives `p | r`. Swapping the prime roles never asserts equality
of their nonzero complex phases. Therefore

`b*p | r`, and for `r != 0`, `Norm(b)*Norm(p) <= Norm(r)`.

`actual_matching_period_dvd_product` transfers this statement directly to
the native calibrated numerator times its genuine sextic additive Gauss row,
for every matching valuation `6t+1`. The Gauss prefactor is the actual
nonzero one, including its complex phase. The cofactor is the genuine single
prime `B=(b)`; the native `J=1` case is included with `t=0`.

## What this closes

The honest period `(C.generator*b)*p` was only an upper period. The new
lower bound shows that a true period cannot omit either growing factor `b`
or `p` on this single-prime cofactor channel. At most the fixed calibration
factor remains unaccounted for in this lower bound. Thus shortening the
true period cannot eliminate the native growing-cofactor scale obstruction
by losing either of these two factors.

## Scope preserved

This is an exact finite integer support/period theorem. It does not establish
the entire minimal conductor, a minimum primitive finite-character modulus,
an actual cofinal prime-cofactor population, incomplete annular cancellation,
a signed lower bound, or a source inequality. Squarefree composite cofactors
and collective cancellation between different cofactors remain separate.
The Gaussian/height window has not been declared periodic or paid. No
smooth-density or generalized-prime model is granted genuine CRT/Gauss
compatibility by this proof.

## Verification

The final warning-as-error isolated build exits 0. All 15 namespace linters
pass. The provenance audit scans every local declaration including generated
helpers: 21 declarations, 17 theorem declarations; only `propext`,
`Classical.choice`, and `Quot.sound`. See `check.log`, `axioms.json`, and
`source-pins.json` in this evidence directory.
