import scripts.QuasiRHCalibratedMatchingAudit
open OAI OAI.CanonicalRowCompletion OAI.CompletedGauss OAI.ConcretePrimeRowBridge
open OAI.ConcreteTraceCRT OAI.CubicEisenstein OAI.GaussianShiftedPartition
open OAI.SevenEighths.ProbePhysical
open OpenAIReview.CalibratedMatching
#check MulChar.apply_eq_zero_iff
#check MulChar.apply_ne_zero_iff
#check Ideal.Quotient.eq
#check Ideal.Quotient.eq_zero_iff_mem
#check Ideal.Quotient.mk_surjective
#check Ideal.quotientMulEquivQuotientProd
#check Ideal.isCoprime_span_singleton_iff
#check Ideal.ne_top_iff_one
#check Ideal.IsMaximal.ne_top
#check IsCoprime.of_mul_right_left
#check IsCoprime.of_mul_right_right
#check ConcreteTraceCRT.principalCRT
#check ConcreteTraceCRT.principalCRT_mk
#check idealRowHom_prime
#check CalibrationData.residueMonoid
#check CalibrationData.residue
#check localRowValue_zero_of_mem
#check idealRowHom_ne_zero_of_coprime
#check isUnit_iff_ne_zero
#check Ideal.Quotient.field
#check Ideal.span_singleton_prime
#check Ideal.Quotient.mk_eq_one
