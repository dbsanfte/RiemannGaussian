# Read-only pinned 7/8 arithmetic-budget audit

This reviews current imported sources at upstream revision
`adc7f1241b42e322a6451854ab7e4b4c146bf78a`, rather than inferring a theorem
from an announcement. Twelve critical vendor file hashes match
`vendor/openai-quasi-rh/upstream-pin.json`; see `source-pins.json`.
No proof file, registration, shared note or public metadata was edited.
No broad build was run, and no new Lean or arithmetic theorem is claimed.

## Actual endpoint and threshold

`RiemannGaussian.ZetaQuasiRHOpenAI.sevenEighthsNonvanishing` applies the
actual imported `OAI.riemannZeta_ne_zero_of_seven_eighths_lt_re`.
The latter calls `ProbeFinalAssemblyUnconditional.zeta_nonzero`, whose
unconditional certificate is supplied by `Energy.CertifiedExistence`.
The strict endpoint is Re(s)>7/8, not its boundary and not RH.

The analytic closure `HeckeCommonProbe.PrimitiveContract` requires one
actual physical probe J and a nonvanishing analytic correction H with:

```
J(Z)             = O(Z^(3/16+omega)),
J(Z)-signal(Z)   = O(Z^(beta_*-11/16-sigma)),
0<omega<beta_*-7/8,  sigma>0.
```

The supremum argument selects a zero near beta_*; it does not assume an
attained rightmost zero. Nothing about the intrinsic type of a zero
changes at 7/8. The available low/source exponent inequality loses its
positive margin there.

## The concrete unconditional low inequality

`ProbeGramCommon.actual_additive_gram_bound` is an estimate of the actual
Eisenstein Gauss energy, with the fixed character, nonunit deletion,
annular profile and height retained. Write P=Y^2/Q. Its cost is

```
K (1+|v|)^J (Q/Y) [1+P^(1/6)+P^2/Y] Y^delta.
```

The three terms are, respectively, the zero/diagonal frequency, the
exceptional sixth-power frequencies, and the nonexceptional periodic
discrepancy. The corresponding paper Proposition 15.2 is not a statement
about arbitrary row-dependent Gauss coefficients. Its complete means
retain collision/nonunit zeros; the nonexceptional means vanish at a
genuine nonprincipal local character, while the sixth-power exceptional
family is counted rather than canceled.

`lowSeparatedIntegrand_actual_gram` and
`LowTupleGram.compensation_tuple_actual_gram` then use Cauchy--Schwarz
against the **actual** inverse row `lowSelectedInverseRow`.
`low_selected_nominal_energy` pays that reflected inverse row. The final
parameters X=Z^(17/48), Y=Z^(23/48), slot length=1/6 give

```
P ~ Z^(1/8),
square-root Gram scale = Z^(3/16+small loss),
normalized principal signal exponent = beta-11/16.
```

Thus 3/16 and beta-11/16 agree exactly at beta=7/8. This is where the
currently proved arithmetic comparison stops. High marked/plain moment
certificates and contour/Euler correction domains are also obligations;
improving this low budget alone would not automatically extend them.

## Quantitative strength audit already checked locally

`ZetaQuasiRHProbeCalibration` proves, at the published geometry:

* Reaching beta=1/2 requires a low-exponent gain **strictly greater than
  3/8**.
* Deleting the entire P^(1/6) allowance would save only **1/96** after
  Cauchy--Schwarz, leaving an exponent boundary **83/96** and critical
  gap **35/96**.
* Rescaling lengths while retaining the same low formula cannot calibrate
  below **5/6**.

These are exact exponent preflights, not new zero-free regions. A
putative row square-root saving across the width-5/6 family is a useful
size benchmark (gain5/12 would leave margin1/24), not an independence or
arithmetic theorem.

## Can native Gamma/Kummer/unit information enter automatically?

No. The separated integrand has the literal form

```
Mellin(W0,iv) * sum_m
  annularMask(m) * calibrationCharacter(m) * radialHeightTwist(m)
  * sum_sigma lowRayAmplitude(sigma,m,v) * B(sigma,m).
```

For the physical probe B is the actual selected inverse-theta row, not a
free function. The current separated estimate accepts arbitrary B but
uses its squared norm. Multiplying B or its allowed slot coefficients
by a bounded native unit/carry code can therefore enter this **norm
class** without improving its power budget. It does not supply the
missing correlation or preserve the principal source automatically.

The ordinary-integer p-free binomial theorem likewise has no existing
exact bridge to the Eisenstein ideal/primary-generator character in B.
It must not be treated as a Gauss character, a reciprocal-L source, or
as a raw Lucas-support mask. That bridge is a real source gate, not a
constant change in an imported theorem.

Existing local audits already rule out the cheap alternatives:

* `QuasiRHCoupledResidueAudit.matching_weighted` shows the genuine
  matching local character survives with its Gauss scalar inside every
  finite complex mask. Separately zero means do not norm-pay that join.
  The actual matching completed indices include all powers
  I=P, J=P^(2t).
* `QuasiRHProfileCenteringAudit.centered_source_zero` shows scalar smooth
  profile centering cancels the entire common principal Mellin channel.
  Its `two_profile_arithmetic_difference` leaves a noncommon arithmetic
  B0-B1 factor; it does not estimate that factor.
* Ordinary Kummer Hessians that collapse to a scalar Lambda test, and
  off-resonant p-free internal Fourier codes already shown source-small,
  do not add the missing source-sensitive input here.

## Strongest next distinct interaction and strict gate

The most concrete remaining Tier-1#8 target is a **prescribed joint
additive/Gaussian row × actual inverse-theta row** estimate, with
arithmetic slot factors retained **before** the Cauchy step. The native
Gaussian/cutoff infrastructure is relevant to its exact smooth lattice
profile. Kummer/p-free data can be proposed only through an exact
arithmetic slot identity whose **actual** principal multiplier remains
nonzero; bounded arbitrary weighting is insufficient.

The smallest useful preflight is to join the actual exceptional local
character component with `lowSelectedInverseRow`, including shared
prime masks and the complete Gaussian profile, and compute its actual
principal Mellin multiplier. A noncommon arithmetic comparison must
retain this multiplier while eliminating a correlated main term.
Blanket sixth-frequency deletion, complete-period matching cancellation,
and common scalar profile centering are already closed classes.

Only a proved quantitative saving for this prescribed join—or an exact
application of it to an existing Suzuki/Gaussian endpoint—would advance
the arithmetic goal. If the proposed slot interaction collapses to an
arbitrary twisted Lambda test, or its source cannot be identified, stop
that class. The reviewed imported proof does not currently provide the
necessary improvement, and this audit does not claim one.

Primary source content was available locally: pinned Lean vendor files,
the pinned manuscript text (Propositions15.2–15.3), and the existing
native proof-review/checked calibration leaves. No web approximation,
announcement, floating estimate or generalized-prime model is used as
proof of the imported endpoint or of a new bound.
