# Finite inverse matching gate

Checked leaf: `scripts/QuasiRHInverseMatchingAudit.lean`.

The squarefree I coefficient in the imported carrier is
`squarefreeGaussCoefficient I * Psi(primaryGenerator I)`. It is not the
ideal Möbius function. The actual Möbius factor is attached to the outer
H variable of cube inversion. No coefficient substitution is made here.

For the actual local completed index P^i * (P^j)^3, with i at most one,
the full residue period retains exactly i=1 and even j. This is proved
on native ideal rows, including the unit index i=j=0 and every nonunit.
At that endpoint the scalar zeroth power and the principal-character
value differ at residue zero, but their joined additive atom is zero;
the proof retains this endpoint rather than excluding it. An arbitrary
finite polynomial over J keeps its literal complex-weighted even
subsequence. This is infrastructure, not an independent saving.

The stronger scoped obstruction joins the actual outer prime Möbius
factor before taking a norm. Put c=cubeWeight(P), and let f_j(m) be the
actual Gauss-coupled native row of I=P,J=P^j. For every complex weight
w_j(m), every native numerator m, and every finite K, the correctly
shifted total-index cutoff satisfies exactly

    sum_{j=0}^K c^j w_j f_j
      - c sum_{j=0}^{K-1} c^j w_{j+1} f_{j+1}
    = w_0 f_0.

The actual coefficient mu(P)=-1 gives the displayed minus sign. It
has the same sign for every residual J power, not an alternating sign
in j. Thus cube inversion cancels every positive J power but leaves
the matching ordinary-prime column I=P,J=1. Literal total-index masks
and full exterior phases may be included in w without changing this
identity. With the same unshifted residual cutoff on both sums, the
exact additional boundary is -c^(K+1) w_(K+1) f_(K+1). This boundary
has no estimate in the leaf.

The pointwise inverse also permits `Psi : O -> (O ->* C)`: the actual
base row and its cube coefficient may depend on the numerator m.
`inverse_row_masked_matching` retains this entire dependence through
the finite identity, so no fixed-base approximation is used. The
native squarefree-column prefactor may remain in w_0(m).

After summing over any finite physical numerator mask B, the surviving
quantity is exactly the actual complex matching Gauss phase times
the one signed sum of w_0(m) over m in B outside P. No absolute values
or incomplete-period payment are used. With w_0=1 on a complete
period, normalization gives mass 1-1/Norm(P), hence at least 1/2 for
every permitted actual nonprincipal character and primitive additive
row. Consequently squarefree I plus cube J plus the actual outer-H
Möbius inverse does not by itself remove the matching channel.

This closes only that finite local cancellation inference. No native
cofinal cutoff, joined global Gaussian source, pole subtraction,
unpaid last boundary, or RH endpoint estimate is claimed. Free,
smooth-density and generalized-prime controls receive no actual ideal,
character, Gaussian or inverse compatibility from the proof.

Validation: final isolated `lean -DwarningAsError=true` exit 0;
15 namespace linters; 38 all-local declarations / 30 theorems,
including generated helpers, audited by module provenance. Only
propext, Classical.choice and Quot.sound occur. Historical dependency
was cache-compiled strictly, unchanged, and is not counted as new work.
