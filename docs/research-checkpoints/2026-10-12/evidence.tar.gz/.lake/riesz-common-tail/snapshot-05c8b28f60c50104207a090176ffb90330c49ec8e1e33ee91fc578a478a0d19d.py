from pathlib import Path
import hashlib,json,re,subprocess

out=Path('.lake/riesz-common-tail')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='194a361762f404a8f4473298b25d96fbae0bb56e'

def saved(path):
    p=Path(path); data=p.read_bytes(); digest=hashlib.sha256(data).hexdigest()
    snap=out/f'snapshot-{digest}{p.suffix}'
    if snap.exists():
        assert snap.read_bytes()==data
    else:
        snap.write_bytes(data)
    return dict(path=str(p),sha256=digest,snapshot=str(snap))

common=json.loads((out/'probe.json').read_text())
feedback=json.loads((out/'feedback.json').read_text())
long=json.loads((out/'feedback128.json').read_text())
projected=json.loads((out/'projected-feedback.json').read_text())
rough_owner=json.loads((out/'rough-owner-feedback.json').read_text())
axioms=json.loads((out/'axioms.json').read_text())
assert len(axioms)==1 and all(m['onlyStandardAxioms'] for m in axioms)
assert len(common['cases'])==len(feedback['cases'])==len(projected['cases'])==12
module='RiemannGaussian/ZetaRieszTailFeedbackFloor.lean'
sources=[module,
    'RiemannGaussian/ZetaRieszClosedTailFloor.lean',
    'RiemannGaussian/ZetaRieszWeightedZeroFloor.lean',
    'RiemannGaussian/ZetaRieszZeroResponseFloor.lean',
    'RiemannGaussian/ZetaRieszPaidIncidenceFloor.lean',
    'RiemannGaussian/ZetaRieszQuantitativeNullStep.lean',
    'RiemannGaussian/ZetaRieszSignedNullGain.lean',
    'RiemannGaussian/ZetaRieszCutoffPeriodFloor.lean',
    'RiemannGaussian/ZetaRieszComplexProjection.lean',
    'RiemannGaussian/ZetaRieszEndgameSlack.lean',
    'scripts/probe_riesz_common_tail_rule.py',
    'scripts/probe_riesz_tail_feedback.py',
    'scripts/probe_riesz_weighted_zero_floor.py',
    'scripts/probe_riesz_zero_response_floor.py',
    'scripts/probe_riesz_factored_population.py',
    'scripts/probe_riesz_complex_null_profiles.py',
    'docs/zeta-riesz-tail-feedback-floor.md','lean-toolchain','lake-manifest.json']

report=dict(schemaVersion=1,date='2026-10-03',head=head,
    objective='Close out the floor.',goalRemainsActive=True,
    slice='Signed whole-period feedback from literal closed affine tails, with successive boundary-paid quantitative credits and canonical coefficients for every native squarefree label.',
    sources=[saved(p) for p in sources],
    validation=dict(
        scope='Focused local only; compiled ordinary root plus explicit new module. No full-root source rebuild, wider gates or publication.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+module,exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszTailFeedbackFloor --wfail',exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true .lake/riesz-common-tail/Audit.lean',exitCode=0,
            ordinaryCompiledRootImported=True,newModuleExplicitlyImported=True,rootSourceNotRebuilt=True,lintersPerNamespace=14),
        compiledRootSha256=hashlib.sha256(Path('.lake/build/lib/lean/RiemannGaussian.olean').read_bytes()).hexdigest(),
        publicTheorems=len(re.findall(r'^theorem ',Path(module).read_text(),re.M)),
        theoremsIncludingPrivateAndGenerated=axioms[0]['theoremsIncludingPrivateHelpers'],
        onlyStandardAxioms=True,
        optionalProbes=[
            dict(command='../.venv/bin/python scripts/probe_riesz_common_tail_rule.py',exitCode=0),
            dict(command='OPENBLAS_NUM_THREADS=1 ../.venv/bin/python scripts/probe_riesz_tail_feedback.py',exitCode=0),
            dict(command='OPENBLAS_NUM_THREADS=1 ../.venv/bin/python scripts/probe_riesz_tail_feedback.py --steps 128 --output .lake/riesz-common-tail/feedback128.json',exitCode=0),
            dict(command='OPENBLAS_NUM_THREADS=1 ../.venv/bin/python scripts/probe_riesz_tail_feedback.py --project-near --steps 12 --output .lake/riesz-common-tail/projected-feedback.json',exitCode=0),
            dict(command='OPENBLAS_NUM_THREADS=1 ../.venv/bin/python scripts/probe_riesz_tail_feedback.py --project-near --unpaid-column-audit --steps 12 --output .lake/riesz-common-tail/rough-owner-feedback.json',exitCode=0)],
        probesInOrdinaryBuildOrCI=False),
    exactResults=dict(
        carrier='joinedPhysical',newCarrierDefined=False,
        radiusCeiling='10001/20000',heightCondition='54 <= abs(y)',
        column='Original complete affine-tail null, with the whole carrier phase retained outside the null correction',
        wholeFeedback='V=sum_i w_i*adverseCorrelation_i*Z_i',
        signedFeedbackIdentity='adverseCorrelation(V)=sum_i w_i*adverseCorrelation_i^2',
        familiarGramIdentityNotClaimedNew=True,
        coefficientBoundOrPrimeCountRestrictionAdded=None,
        canonicalRule='Every original native squarefree label; phase-aligned singleton null; inverse complete-period square norm; zero column gets zero weight',
        canonicalRequiresNewLabelCoefficientFit=False,
        originalNonzeroBasePhaseRemoved=False,
        originalSupportMasksAllocationAndFactorialOrdersRetained=True,
        distinctAllPrimeAndPaidOwnerAllocationsRetained=True,
        previousNullsTangentPaidRowsAndBudgetsRetainedOnce=True,
        nearDebit='Full JOINED actual one-sided crossing debit; zero and near-zero periods retained',
        credit='max(sum_i w_i*g_i^2-nearDebit,0)^2/(4*farPrice)',
        step='max(sum_i w_i*g_i^2-nearDebit,0)/(2*farPrice)',
        safeStepTheorem='cost_adjusted_add_credit_le',
        successiveCreditTheorem='cost_iterate_add_credit_le',
        zeroTotalTheorem='sum_iterate_eq',
        literalMixingTheorem='nativeColumns_mix',
        exactNearCancellation='nearDebit_feedback_zero',
        usefulNativeNearProjectionAssumed=False,
        arithmeticWholeFloor='eventually_joined_floor_with_feedback',
        canonicalArithmeticWholeFloor='eventually_joined_floor_with_canonical_feedback',
        arithmeticComparisonUsesZeroHypothesis=False,
        oldPriceAlternativeRetained=True,
        zeroStepsRecoverPreviousPrice=True,
        newFundingErrorOrBoundaryDeletion=False,
        errorDecayUsesExistingExposedZeroHypotheses=True,
        exactRationalRegressions=['16/41 with the original zero period charged','1/2 after exact joint near-period cancellation'],
        cofinalSimpleContradiction='false_of_cofinal_feedback_price',
        cofinalPricePremise='feedbackPrice <= 399/5000',cofinalPricePremiseProved=False),
    numericalRegression=dict(
        orders=[32,64],seeds=[317,919],heights=[54,65,100],
        frozenInputs=[saved(p) for p in sorted({c['frozenInput']['path'] for c in common['cases']})],
        frozenMatrices=[saved(c['matrixArtifact']['path']) for c in common['cases']],
        commonRuleCrossSeed=dict(
            allEarlierNullDirectionsAndBoundsRetained=True,
            strictReplayImprovements={name:sum(c['rules'][name]['crossSeed']['strictReplayPrice']<c['beforeTailPrice'] for c in common['cases']) for name in common['cases'][0]['rules']},
            afterEarlierOnlyRebalanceImprovements={name:sum(c['rules'][name]['crossSeed']['rebalancedEarlierPrice']<c['beforeTailPrice'] for c in common['cases']) for name in common['cases'][0]['rules']},
            uniformTransferObserved=False),
        explicitFeedback=dict(
            newLPOrPerLabelFit=False,previousNullCoefficientsAndTiltFixed=True,
            twelveStepPositiveCredits=sum(c['accumulatedFormulaCredit']>0 for c in feedback['cases']),
            twelveStepActualCostSavings=sum(c['actualSaving']>0 for c in feedback['cases']),
            twelveStepFormulaCreditFractions=[min(c['formulaCreditFraction'] for c in feedback['cases']),max(c['formulaCreditFraction'] for c in feedback['cases'])],
            projectedTwelveStepPositiveCredits=sum(c['accumulatedFormulaCredit']>0 for c in projected['cases']),
            projectedTwelveStepActualCostSavings=sum(c['actualSaving']>0 for c in projected['cases']),
            projectedFormulaCreditFractions=[min(c['formulaCreditFraction'] for c in projected['cases']),max(c['formulaCreditFraction'] for c in projected['cases'])],
            projectionResidualAlwaysCharged=True,
            hundredTwentyEightStepPositiveCredits=sum(c['accumulatedFormulaCredit']>0 for c in long['cases']),
            noGenericConvergenceToZeroPriceClaim=True),
        previouslyPaidGeometryColumnAudit=dict(
            selector='Only new columns: owner share <60069/100000 and second least prime >N^3',
            sourceBasePopulationDeleted=False,earlierNullCoefficientsAndTiltFixed=True,
            retainedLabels=[c['retainedCorrectionLabels'] for c in rough_owner['cases'] if c['height']==54],
            retainedCounts=[c['auditedCorrectionCounts'] for c in rough_owner['cases'] if c['height']==54],
            positiveFormulaCredits=sum(c['accumulatedFormulaCredit']>0 for c in rough_owner['cases']),
            positiveActualSavings=sum(c['actualSaving']>0 for c in rough_owner['cases']),
            formulaCreditFractions=[min(c['formulaCreditFraction'] for c in rough_owner['cases']),max(c['formulaCreditFraction'] for c in rough_owner['cases'])],
            eventualPaidTheoremsAppliedAtSampleOrders=False,completeUnpaidPopulationInventory=False,
            ownerShareClassifierFloating=True),
        countsAndPeriodsJoinedBeforePricing=True,
        originalImportanceWeightsMasksAndBasePhasesRetained=True,
        probablePrimalityFloatingPhasesEdgesEarlierLPAndSVD=True,
        nativeCofinalPoints=False,nativeCountCropApplied=False,nativePaidOwnerBudgetApplied=False,
        nativePopulationCoverageCostRateOrDeficitFractionCertified=False),
    remaining=dict(
        wholeFloor='OPEN: prove an independent cofinal bound by 399/5000 on the actual native feedbackPrice, or equivalently a sufficient signed aggregate estimate.',
        numericalCreditMagnitude='No cofinal lower bound on the native computed credit / upper bound on the native residual price yet.',
        exactNullCannotChangeWholeSignedTotal=True,
        activeHingeAndPrimePhaseCorrelations='Retained with all counts and radial periods; their remaining source-scale total is not independently bounded.',
        wholeCeiling='OPEN',zeroExclusion=False,rhContradiction=False,allPriorNoGosPreserved=True),
    commitsOrPushesPerformed=False,readmeOrPublicEndpointsChanged=False)

(out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
report['artifacts']=[saved(out/p) for p in ['lean.log','build.log','audit.log','Audit.lean','axioms.json',
    'probe.log','probe.json','feedback.log','feedback.json','feedback128.log','feedback128.json',
    'projected-feedback.log','projected-feedback.json','rough-owner-feedback.log',
    'rough-owner-feedback.json','report.json','write_report.py']]
Path('docs/riesz-tail-feedback-floor-audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
items=report['sources']+report['artifacts']+report['numericalRegression']['frozenInputs']+report['numericalRegression']['frozenMatrices']
for item in items:
    for key in ('path','snapshot'):
        assert hashlib.sha256(Path(item[key]).read_bytes()).hexdigest()==item['sha256'],item[key]
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],compiledTheorems=report['validation']['theoremsIncludingPrivateAndGenerated'],
    allHashesMatch=True,hashCount=len(items),wholeFloorOpen=True),indent=2))
