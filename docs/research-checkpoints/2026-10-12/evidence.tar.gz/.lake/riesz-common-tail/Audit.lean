import RiemannGaussian
import RiemannGaussian.ZetaRieszTailFeedbackFloor
import Mathlib.Tactic.Linter
import Lean.Util.CollectAxioms
#lint+ in RiemannGaussian.ZetaRieszTailFeedbackFloor
open Lean Elab Command
set_option maxHeartbeats 0
run_cmd do
  let selected : Array Name := #[`RiemannGaussian.ZetaRieszTailFeedbackFloor]
  let env ← getEnv
  let mut reports : Array Json := #[]
  let mut seen : Nat := 0
  for _h : i in [0:env.header.moduleNames.size] do
    unless selected.contains env.header.moduleNames[i]! do continue
    seen := seen + 1
    let mut declarations : Nat := 0
    let mut theorems : Nat := 0
    let mut axioms : Array Json := #[]
    for ci in env.header.moduleData[i]!.constants do
      declarations := declarations + 1
      if ci.isAxiom then throwError "Project-defined axiom: {ci.name}"
      let dependencies ← Lean.collectAxioms ci.name
      for ax in dependencies do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "Unexpected axiom in {ci.name}: {ax}"
      if ci.isTheorem then
        theorems := theorems + 1
        axioms := axioms.push (Json.mkObj [("theorem",toJson ci.name.toString),
          ("axioms",toJson (dependencies.map Name.toString))])
    reports := reports.push (Json.mkObj [("module",toJson env.header.moduleNames[i]!.toString),
      ("declarations",toJson declarations),("theoremsIncludingPrivateHelpers",toJson theorems),
      ("onlyStandardAxioms",toJson true),("theoremAxioms",Json.arr axioms)])
    logInfo m!"Checked {theorems} theorems in {env.header.moduleNames[i]!}; only standard axioms."
  unless seen == selected.size do throwError "A target module was not imported"
  IO.FS.writeFile ".lake/riesz-common-tail/axioms.json" (Json.arr reports).pretty
