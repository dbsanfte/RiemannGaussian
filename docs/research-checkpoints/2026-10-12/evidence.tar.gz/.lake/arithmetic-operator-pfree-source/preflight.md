# P-free common-row source preflight

Status: read-only paper-level source/collapse audit, 2026-10-08. No new
Lean theorem, source residue, native asymptotic, arithmetic estimate or
family exhaustion is asserted here. The finite recurrence proof belongs
to `scripts/ArithmeticOperatorPFreeUnitAudit.lean`; exact diagnostics
belong to `scripts/probe_arithmetic_operator_pfree_structure.py`.

## Literal candidate and the lost raw-residue hypothesis

For positive binomial B, write

    v_p(B)=padicValNat p B, U_p(B)=B/p^(v_p(B)).

The candidate is the actual common row B_D(k)=choose(D-1,k), 0<=k<D,
with both units U_p(B_D(k)), U_q(B_D(k)), their complete valuations,
and the internal and exterior phases retained. With characters chi_p,
chi_q, define f_D(k)=chi_p(U_p(B_D(k))) chi_q(U_q(B_D(k))). The raw
residue is zero when p divides B; the p-free unit is never zero modulo
p on this literal positive row. Raw Lucas support counting therefore
does not bound this unit statistic.

Away from p/q crossings, the exact adjacent unit recurrence is
f_D(k+1)=sigma f_D(k), sigma=chi_p(-1)chi_q(-1). The valuations are
stable on those same noncrossing atoms, so a retained valuation mark
must remain part of the jump data rather than be set to zero.

## Resonance: what cancels and what does not

Put F_D(lambda)=sum_(k<D) lambda^k f_D(k), with both unit endpoints 1.
Let delta_k=f_D(k+1)-sigma f_D(k). The exact finite defect identity is

    (1-sigma lambda)F_D(lambda)
      =1-sigma lambda^D+sum_(crossings k) lambda^(k+1)delta_k.

For odd D and lambda=sigma, sigma^2=1. Its right-hand side vanishes.
This is conservation of the zeroth jump moment. It does NOT say that
F_D(sigma) vanishes or is small. Differentiating this finite polynomial
at the resonance instead gives the source-bearing first spatial moment:

    F_D(sigma)/D
      =1-(1/D)sum_(crossings k)(k+1)sigma^(k+1)delta_k.

This formula is a paper-level algebraic deduction here, not a claim that
the unit leaf has already formalized differentiation. It identifies
precisely which weighted jump data need a genuine prime-index theorem.

## Fixed p and growing unaligned q

For P=p^r, Q=q^s and D=PQ, the exact-depth formula under investigation is

    U_p(B_D(k)) = (-1)^(k mod P)
                  U_p(choose(Q-1,floor(k/P)))  (mod p),
    v_p(B_D(k)) = v_p(choose(Q-1,floor(k/P))).

The probe verifies these formulas exactly; the source audit does not
promote them to a checked Lean theorem beyond the leaf's actual results.
At the internal resonance they give a staircase join

    sum_(k<PQ) A_floor(k/P) B_floor(k/Q),

    A_i=chi_p(-1)^i chi_p(U_p(choose(Q-1,i))),
    B_j=chi_q(-1)^j chi_q(U_q(choose(P-1,j))).

The native overlap of the two upper-digit intervals is indispensable.
It is not the product of independent residue means or a complete CRT
period. Fixed P leaves q of the fine intervals and only P of the coarse
intervals; the nonshrinking fixed-p jump density must not inherit the
earlier growing-p saving.

For ordinary Q=q>P, the q valuation of choose(P-1,j) is exactly zero:
q does not divide (P-1)! or any prime factor of that binomial. No stronger
q>2^(P-1) hypothesis is required. With quadratic q characters, each of
the finitely many B_j(q) is a reciprocal quadratic-character value on
the fixed integer (-1)^j choose(P-1,j), hence admits the usual finite
Dirichlet-character interpretation in q. The A_i(q) remain a growing
p-adic unit/carry row, with spatial cuts at rational fractions j/P.
Reducing B does not reduce that upper-row factor.

Exact finite regression, p=3 and q=5,29,53 (all q=5 mod 24): the
unnormalized resonant sums are 7,-17,7. Their affine-in-q determinant
is 1152. Thus these literal normalized traces cannot have the old
level-24 periodic bulk plus periodic endpoint/q form. This rejects only
that precise cheap finite-level ansatz, not every periodic expansion,
every finite character level, or an asymptotic decomposition with an
independently controlled error. At p=3,q=11 the raw resonant sum is 0
and the p-free sum is -9; the omitted carry layers are substantive.
These are diagnostics, never actual-zero residue evidence.

## The exact missing actual-source theorem

Let b_p(q) be the prescribed literal normalized resonant staircase trace
(or its specified valuation-marked version). Its actual ordinary-prime
series is

    P_b(s)=sum_(q prime, q!=p) log(q)b_p(q)q^(-s), Re(s)>1.

The constant exterior fixed-p factor is explicit and nonzero; it does
not identify the residue of P_b at a hypothetical actual zero rho.
Likewise ordinary-prime versus full-Mangoldt completion can keep a
bounded proper-power complement analytic for Re(s)>1/2, but it cannot
manufacture a residue for the still-unestimated prime-index coefficient.

For a useful actual source gate one must prove one of:

1. An exact finite character decomposition of b_p(q), with every moving
   spatial/digit and proper-power correction independently regular at
   rho, yielding a nonzero sum of actual zeta/L-function multiplicities.
2. A Mangoldt-weighted spatial transition theorem decomposing the
   staircase coefficient into explicit spectral components, together
   with its actual continued Laurent coefficient at rho.
3. Another exact generating identity tying the prescribed weighted jump
   moment (k+1)sigma^(k+1)delta_k to an actual zeta-zero residue while
   retaining the native overlaps and valuations.

None follows from the finite recurrence or from a power-mode diagnostic.
The sufficient ansatz b_p=mu_p+g_p, mu_p!=0, with the prime series of g_p
regular at rho, gives only -mu_p*m_rho plus any explicit character
channels. If mu_p is the sole surviving component, this is the old prime
source times a scalar, not genuinely new source-sensitive arithmetic.
Deleting that principal component algebraically deletes its source.
Subtracting the actual analytic density pole is a different operation
and needs its own germ identity; a finite row or transition mean is not
that identity. A useful new statistic must establish nonzero source
after such density removal and also retain additional exact integer data
through the final independent estimate.

## A cheap source-passing escape, and its precise collapse

For P=2, Q=q^s with q odd, the p-free unit modulo 2 is identically 1.
The upper q row is choose(1,j)=1. The unmarked resonant unit trace is
therefore exactly (1+chi_4(q))/2, at every positive exponent s. The
uncoded trace adds (1-chi_4(q))/(2Q). This has a genuine actual-source
route: at ordinary q, the Euler response is

    -(logDeriv zeta(s)+logDeriv L_chi4(s))/2
      + explicit analytic heads and proper-power correction.

The extension using chi_4(q^s) rather than chi_4(q) changes only the
proper powers; the bounded coefficient correction is analytic for
Re(s)>1/2. The uncoded inverse-Q endpoint is analytic for Re(s)>0.
Consequently the actual continued residue at a right-half rho is
-(m_zeta+analyticOrder(L_chi4,rho))/2, nonzero because m_zeta>0 and
the other analytic order is nonnegative. The fixed-p exterior factor
log(2)*2^(-rho) is nonzero. The density pole is a genuine analytic
pole with coefficient 1/2 and can be subtracted without removing rho.

This is a source preflight to formalize by the existing character
machinery, not a new checked theorem in this read-only note. It is
not merely an unknown principal mean: the auxiliary actual L-channel
is explicit. But ALL binomial unit geometry has disappeared into a
fixed level-4 character selector, and no independent arithmetic
estimate follows. It is a scoped unmarked P=2 collapse checkpoint.

A nonconstant mark in the upper v_2(choose(q-1,i)) would retain carry
information and prevent this trivial collapse. That genuinely marked
variant has a new source gate; the unmarked selector theorem must not
be extended to it. The current `unitAtom` contains the true unit but
does not itself multiply an additional valuation/carry mark.

## Collapse controls and their limits

The finite recurrence holds with ANY outer weights on the same native
rows. Thus the identity alone supplies no constraint specific to the
literal Mangoldt-weighted prime-index state measure. If unrestricted
moving internal codes are allowed, the constant code c(q) realizes any
bounded scalar profile, even though the underlying unit data remain
genuine. This refutes an inference from free-code bookkeeping, not an
estimate for the prescribed character/carry code.

Replacing only the outer weights by a smooth density is a diagnostic
control. It does not turn its apparent power response into a genuine
zeta source. Generalized-prime controls are not granted actual integer
binomial, Gamma, valuation or unit compatibility. Conversely, a proof
that discards all such compatibility after the join and uses only a
free bounded coefficient cannot claim to exploit it later.

The primary paper Barat--Grabner, *Spatial equidistribution of binomial
coefficients modulo prime powers*, Theorems 1--2, averages all integer
rows in a triangle, for a fixed p and fixed modulus exponent, including
spatial and valuation data. It does not give the required prime-index
Mangoldt-weighted continuation or residue on q. Its marked automaton
is relevant infrastructure, not a source or growing-prime estimate.
Source: https://www.math.tugraz.at/~grabner/Publications/Binomial-spatial.pdf

Conclusion: resonant p-free unit/carry structure remains a genuinely
distinct open source gate. The exact missing theorem is the weighted
prime-index spatial transition response above. No absence-of-literature
argument, universal family no-go, independent arithmetic bound or RH
payment has been proved by this preflight.
