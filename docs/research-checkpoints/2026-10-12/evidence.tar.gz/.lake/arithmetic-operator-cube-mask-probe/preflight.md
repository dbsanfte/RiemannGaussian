# Native cube-mask collapse preflight

The native squarefree slot is the actual Gauss coefficient `columnWeight Psi I`; the outer inverse, not that slot, carries Moebius. Every cube order `J` and its actual numerator-dependent monoid/phase are retained.

## Aligned operator

The exact operator is `summand Psi W T I(P*J) = cubeWeight Psi P * summand Psi W(T/Norm(P)^3) I J`, together with the full mark `F(P^3*(I*J^3))`. In this reindex only the completed inverse length T is moved. The physical numerator Xprime/Yprime and annular weight remain fixed. The native total-index profile argument and its complete height phase coincide exactly.

This is already the generic total-index cube inverse in pinned `Descent.Completion`: `markedExpandedTerm_scale`, `marked_cube_inner_inverse` and `marked_cube_inverse` include arbitrary marks and complex compact windows. The older local finite telescoping also allows the actual numerator-dependent base row. Correct alignment therefore adds no new independent cancellation.

## Unaligned boundaries

If T is kept fixed, the full Gaussian difference is explicit:

`G(Norm(P)^3*t)/G(t) = exp(-(9/4)(log Norm(P))^2 -(3/2)log Norm(P)log t)`.

Its sign switches at `t=Norm(P)^(-3/2)`; it has no uniform favorable sign. The actual compact window used in low separation is supported on `1/2<t<2`. Its cube-shifted support is disjoint for actual Norm(P)>=4, so this is not a small moving-boundary perturbation.

The divisibility jump is also literal: `1_(D|P^3*A)-1_(D|A)` is the indicator that `D|P^3*A` but `D` does not divide `A`. Only the P valuation changes; its admissible interval is `max(0,vP(D)-3)<=vP(A)<vP(D)`. For the distinct-prime slot marks this is just insertion of a missing marked P. Other primes, ray, excluded-prime mask and full complex coefficient are retained.

Equal native local truncations leave exactly the old last boundary `c^(K+1)*w(K+1,m)*completedAtom(p,1,K+1,m)`. It must not be silently deleted or counted as a new estimate.

## Native matching geometry

Paper Eq.12.4 gives `Norm(P)~Z^(23/48-d)` for the actual additive prime and the inverse Gaussian center `T~Z^(7/6-d)`, with `0<=d<=1/6`. In a shared-prime matching sector, `P|I` and any positive same-P cube order `P|J` force `Norm(I*J^3)>=Norm(P)^4`. The exact exponent gap is

`4*(23/48-d)-(7/6-d)=3/4-3*d>=1/4`.

Thus these positive same-P cube terms already lie beyond the nominal Gaussian center by a fixed power of Z. The imported literal Gaussian profile gives a superpolynomial pointwise tail after retaining explicit fixed annular constants. This does not bound the full signed row; it shows that the dangerous `J=1` matching cofactor channel is the endpoint still left by the operator. The earlier calibrated audit remains essential: its complete-period mean vanishes, but its growing-cofactor conductor is not in the fixed-conductor Poisson regime.

## Verdict and next distinct gate

Aligned shifting is a same-source total-index identity already checked in Lean. Unaligned shifting introduces explicit profile/divisibility boundaries whose algebra holds for arbitrary marks. No new arithmetic estimate or zero-source asymptotic results from this preflight. Native profile ratios in the JSON are floating component diagnostics only: no calibration, Gauss coefficient or prime phase has been replaced by a random numerical model, and no full-row numerical value is claimed.

The next genuinely distinct ranked gate is roadmap Phase B, Tier-1 #3/#6, using simultaneous literal additive-shift prime-power restrictions within cutoff/modular quotient/Ramanujan geometry. A mere FFT of an arbitrary weighted sequence is excluded. Alternatively the nonlinear Kummer valuation marks in Tier-1 #8 remain different from unmarked character codes, but their actual prime-index source gate must be proved before another detector or automaton is built.
