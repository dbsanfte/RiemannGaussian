"""Native divisor-exchange regression; floating diagnostics, never proof input."""
from pathlib import Path
import cmath
import json
import math

X = 4096
out = Path(__file__).parent
spf = list(range(X + 1))
for p in range(2, math.isqrt(X) + 1):
    if spf[p] == p:
        for n in range(p * p, X + 1, p):
            if spf[n] == n:
                spf[n] = p


def factor(n):
    ans = {}
    while n > 1:
        p = spf[n]
        ans[p] = ans.get(p, 0) + 1
        n //= p
    return ans


factors = [factor(n) for n in range(X + 1)]
mu = [0] + [(-1) ** len(f) if all(v == 1 for v in f.values()) else 0
            for f in factors[1:]]
lam = [0.0] + [math.log(next(iter(f))) if len(f) == 1 else 0.0
               for f in factors[1:]]
divisors = [[] for _ in range(X + 1)]
for d in range(1, X + 1):
    for n in range(d, X + 1, d):
        divisors[n].append(d)

results = []
for y in [0.0, 54.0, 127.25]:
    phi = [0j] + [cmath.exp(-1j * y * math.log(n)) for n in range(1, X + 1)]
    row = [0j] + [sum(mu[n // d] * (phi[d] + phi[d].conjugate()) * math.log(d)
                     for d in divisors[n]) for n in range(1, X + 1)]
    energy = [row[n] - 2 * lam[n] for n in range(X + 1)]
    comm = [row[n] - (phi[n] + phi[n].conjugate()) * lam[n]
            for n in range(X + 1)]
    energy_err = comm_err = trace_err = 0.0
    tower_traces = []
    for p in range(2, X + 1):
        if spf[p] != p:
            continue
        theta, logp = y * math.log(p), math.log(p)
        n, nu, trace = p, 1, 0j
        while n <= X:
            e = 2 * logp * (nu * (math.cos(nu * theta) - 1)
                            - (nu - 1) * (math.cos((nu - 1) * theta) - 1))
            c = 2 * (nu - 1) * logp * (math.cos(nu * theta)
                                       - math.cos((nu - 1) * theta))
            energy_err = max(energy_err, abs(energy[n] - e))
            comm_err = max(comm_err, abs(comm[n] - c))
            trace += logp * energy[n]
            n *= p
            nu += 1
        j = nu - 1
        expected = 2 * logp ** 2 * j * (math.cos(j * theta) - 1)
        trace_err = max(trace_err, abs(trace - expected))
        tower_traces.append(trace.real)
    semiprime_rows = [n for n in range(2, X + 1)
                      if len(factors[n]) == 2 and all(v == 1 for v in factors[n].values())]
    f2 = 2 * (math.cos(y * math.log(2)) - 1)
    results.append({
        "height": y,
        "ordinary_prime_commutator_max": max(abs(comm[p]) for p in range(2, X + 1)
                                               if spf[p] == p),
        "energy_tower_identity_error": energy_err,
        "commutator_tower_identity_error": comm_err,
        "complete_tower_telescope_error": trace_err,
        "largest_tower_trace": max(tower_traces),
        "energy_Lambda_trace": sum(lam[n] * energy[n] for n in range(1, X + 1)).real,
        "commutator_Lambda_trace": sum(lam[n] * comm[n] for n in range(1, X + 1)).real,
        "composite_commutator_positive_rows": sum(comm[n].real > 1e-10 for n in semiprime_rows),
        "composite_commutator_negative_rows": sum(comm[n].real < -1e-10 for n in semiprime_rows),
        "energy_prime_fiber_actual_Lambda_sign": f2,
        "energy_prime_fiber_test_minus2_1_sign": -f2,
    })

report = {
    "proofInput": False,
    "kind": "native integer divisor/Mobius/height regression; floating diagnostics only",
    "cutoff": X,
    "operators": {
        "energy": "M*(T_y+T_-y)*Z-2I; diagonal generally nonzero",
        "commutator": "M*(T_y+T_-y)*Z-(T_y+T_-y); diagonal zero",
    },
    "action": "Keep two operators distinct. Signed energy trace is source-compatible; commutator trace on Lambda removes ordinary-prime source. No independent RH estimate.",
    "cases": results,
}
(out / "divisor-exchange-probe.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
