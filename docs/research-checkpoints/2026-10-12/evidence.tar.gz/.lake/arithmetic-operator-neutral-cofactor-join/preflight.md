# Prescribed neutral small-square-cofactor join: scoped closure

Read-only source/PSD preflight on the actual imported Eisenstein carrier.
No new Lean declaration, build, arithmetic inequality, contour continuation,
isolated-sector source theorem or zero-free claim.

## Literal coefficient: do not replace it by Mobius

Arithmetic/IdealMobius.squarefreeGaussCoefficient (line419) is, for supported
squarefree I,

    alpha(I)=star(angularFactor(primaryGenerator I))*gaussTwo(I).

The native column is alpha(I)*Psi(primaryGenerator I), with its sqrt(Norm I)
normalizer; the cube column is star(angular)^3*Psi^3/Norm J. This is NOT mu(I).
The actual mu is on the inverse H in Descent/Completion.marked_cube_inverse,
with length X/Norm(H)^3 AND total-index mark d(H^3*A). These two indices,
shifts and coefficients must not be identified or cancelled independently.

## Exact finite joined matching identity before any norm

Fix the genuine matching prime P=(p), a retained unrelated J=V^2 with P not
 dividing V, and a finite actual squarefree cofactor population F with
I=P*I0 squarefree. Write A(I0)=primaryGenerator(P*I0*V^6) and
B(I0)=I0*V^6. Let

    E_t(I0)=spectralSummand S D
        (baseRowCoefficient eta C.Xi p hp) t (P*I0) (V^2).

This is the literal prescribed native coefficient, INCLUDING completedMask,
completedCorrection, the actual cubic Gauss column, target/calibration/ray
phase, cube coefficient and the two fullIdealWeight factors. It is not a
new freely chosen coefficient. The same native Z^t*exp(t^2) Gaussian and
vertical contour normalization multiply both sides below.

Using calibrated_spectralSummand_separation and calibrated_matching_atom,
finite linearity gives exactly, for every actual numerator m,

  C.residueMonoid(m)*sexticGauss(p,-m)*
    sum_(I0 in F) spectralSummand S D
       (rowCoefficient eta C.Xi p hp m) t (P*I0) (V^2)
  = kappa(p)*C.residueMonoid(m)*1_(m notin P)*
      mask(V,m)*sum_(I0 in F) E_t(I0)*idealRowHom(m,I0),

where kappa(p)=actualSextic_P(-1)*gaussSum(actualSextic_P,quotientTrace_p).
The physical annular W(Norm(m)/Q), height phases and all Gaussian factors
are retained on BOTH sides. The V^6 factor is exactly mask(V,m); overlaps
I0/V merely cause redundant zeros, and are never silently assumed coprime.
The existing finite_support_tsum_comm supplies exact finite sum/annulus
exchange for compact W. If the native window or mask depends on I0, it
STAYS inside the I0 sum. This displayed identity is a paper-level finite
composition of pinned checked APIs, not a newly compiled wrapper.

Unit-neutral selection may be inserted into the literal F/E_t support;
its surviving projector is1. It supplies no new conjugate pairing.

## Reciprocity transposes, but supplies no positivity

Eisenstein/ConjugateLevelAction.idealRowHom_primary_reciprocity proves,
for supported primary a=primaryGenerator I0 and supported primary m,

    idealRowHom(m,I0)
      = sexticReciprocityPhase(a,m)*idealRowHom(a,span(m)).

The ideal version gives the same exact finite interchange. Numerators not
satisfying those hypotheses are NOT discarded: the full original row is
already rowTwist and is retained by LowRow.correctedPhysicalRow_eq_inverse_rows.
Bad-prime/unit/ray decomposition, when needed, stays explicit.

This transposition is linear, not conjugate joining. E_t(I0) remains the
prescribed Gauss/eta/ray coefficient, with complex height and asymmetric
cofactor/numerator scales. It does NOT turn into star(a(I0))*a(m), and no
positive square or PSD arithmetic bound follows from symmetry alone.
At the raw actual character level nonunit prime diagonals are0 while
coprime off-diagonal values have norm1. A Hermitian two-prime block of
this shape has eigenvalues +/-|offdiag|; even Hermitianizing is not a
universal PSD argument. This is a kernel-level diagnostic, not a claim
that the prescribed whole carrier is negative or an isolated row has source.

CubicSieve/DualCoefficients.cubicDualRow_eq_gram is a DIFFERENT quadratic
join with conjugate coefficients, pairwise coprimality masks and a dual
window depending on BOTH norms. It does not make this linear aggregate
positive. Norm/Cauchy conversion would bring back the already-audited
source-sized diagonal payment.

## The exact gamma1/gamma2 join is already imported

PrimeRows/ActiveGaussFactorization.canonicalProductCoefficient_mul_gauss_one
(line724) proves the actual normalized finite prime-product identity

    alpha(I0)*gamma1(I0)=mu(I0)*canonicalProductG(I0).

GaussSum/CubicTrace.canonical_radial_poisson_product (line526) retains its
full dual sum and scale, while moebius_gauss_frequency_conversion (line574)
tracks conjugation and modulus-unit transport. Thus the prime-specific
Gauss cancellation is real but already part of the native inverse closure.
It leaves the fixed ray G, eta, calibration, all original support masks,
all dual frequencies and the dual Gaussian boundary. It does NOT turn
alpha into mu before gamma1 is actually supplied.

For the full calibrated cofactor row, calibration, puncture and V nonunit
masks require their genuine CRT/local factors; plain gamma1(I0) alone is
not a license to omit these. Any I0/V overlap or mask expansion remains in
the actualCongruenceCoefficient. PhysicalReopen.physical_spectral_reopen,
SpectralCoefficient.spectralSummand_source_coefficient and
SourceCoefficient.sourceHighCoefficient_eq_bare already retain and join
these factors in the all-variable transform. The full coefficient then
factorizes by bareSourceCoefficient_product/HighRowsEuler, with precisely
the existing native principal reciprocal-L channel.

## Source/density collapse and the unpaid signed term

SourceExclusions.source_principalHigh_L_factorization states EXACTLY
in its convergent domain (Re x>3/2, Re w>2, Re z>1/6)

  markedIdealHighSeries(S,1,eta,1,x,w,z)
    = L_fixed(6z)*L_fixed(w)/L_(eta excluded S)(x)
         *globalClosedCorrection(eta,S,x,w,z).

The density poles are the L_fixed factors in w and6z. After their native
residues the reciprocal target-L source and principal correction remain.
FiniteProductX.continuedSourceMultiplier additionally retains actual
profile Mellin factors, Gaussian exp((x+z-1)^2), lengths and slot multiplier.
It is the SAME source. These formulas do not grant lower-strip correction
nonvanishing: global7/8, angular2/3 and slot3/5 gates stay distinct.

The complete-period mean of a nonempty calibration vanishes, but that is
NOT an incomplete annular estimate and supplies no new source separation.
Fixing small V/neutral rows first is a truncation of the native variable
join; no theorem here identifies that isolated population with all of the
reciprocal source. In particular V=1 is retained, not asserted equivalent.

After the true dual Gauss join the unresolved finite signed expression is
schematically

   sum_(I0 in F) mu(I0)*eta(I0)*G(I0)*
      sum_H [actual calibration/CRT mask coefficient(I0,V,p,H)]*
        FourierW(Q*Norm(H)/fullConductor(I0,V,p)) * nativeWeight(I0,V).

Every bracket/normalizer is the ACTUAL local coefficient, not a free row.
Its moving dual window depends on I0 and the puncture, so the shortened
annulus gives a longer dual range. A further estimate on this prescribed
signed sum could still be new arithmetic input, but reciprocity/Gauss
normalization alone is an equality and does not bound it. Completing its
Mellin variables returns the already-imported reciprocal-L expression.

## Collapse audit and verdict

The finite row separation/interchange is valid for arbitrary bounded
monoid twists (hence yields no independent signed inequality). Reciprocity
is genuine literal Eisenstein arithmetic, but the only proven additional
Gauss pairing is the existing mu*fixed-ray conversion. Once the actual
all-variable principal source is joined, its Euler factorization is the
same reciprocal-Hecke source; generic multiplicative Euler identities
cannot exclude its pole. Neither smooth-density nor generalized-prime
countermodels are claimed to satisfy the actual Gauss constraints; those
constraints are already consumed by the exact normalization, with no
remaining estimate produced by this shortcut.

Freeze the proposed reciprocity-to-PSD / bare-I0-to-mu shortcut. Do NOT
freeze all prescribed cofactor correlations: the literal dual signed
I0/V/H/Gaussian aggregate remains an open possible independent estimate.
No new source response, saving or zero-free claim has been proved.
