# Native Gaussian/moving-mask profile preflight for cubic-Gauss Type I

Read-only paper-level applicability audit. No Lean leaf, native signed
saving, packet source equivalence or zero-free conclusion is claimed.
The sibling source/conductor record is
`.lake/arithmetic-operator-unconditional-gauss-input/preflight.json`.

## Exact input and what is smooth

The primary paper, *An unconditional first moment for cubic Gauss sums*,
Proposition 3.1 (PDF pp. 10–11; cached text line 549), permits

```
sum_r a_r sum_u [G(ru)-c*mu²(ru)Norm(ru)^(-1/6)] W_r(Norm(u)/U)
  << X_G^(5/6-1/100),
R U ~ X_G,   R <= X_G^(51/100).
```

The outer coefficients are divisor-bounded; the inner variable is
unrestricted. `W_r` may depend on `r`. Its support must lie in one fixed
compact interval of `(0,infinity)`, and every fixed derivative must be
uniformly bounded by a fixed power of `log X_G`. Appendix A.4 permits a
fixed angular index with the same hypotheses; it does not authorize an
arbitrary growing finite sextic-character conductor.

The paper's §2.1 explicitly allows separating smooth products/ratios of
norm variables on fixed dyads by Mellin inversion, tracking logarithmic
derivative costs. Therefore independent product weights are not an extra
obstruction at this Type-I stage if the native scalar norm factors have
the prescribed seminorm bounds.

## Existing exact physical/Gaussian bridges

`PhysicalRows.physicalRowWeight` retains the scalar smooth factors

```
W1(Norm(P)/Y') * W0(Norm(m)/(Norm(C)*Norm(P)*X')),
```

together with genuine additive sextic Gauss, calibration and numerator
coefficients. `LowSeparated.physicalRowWeight_low_separated` separates
that norm ratio exactly, with the cofactor/inverse row left unchanged.
`LowCompensation.compensationRowTest_low_separated` and
`LowSlotPolynomial.compensation_tuple_low_polynomial` retain the selected
divisibility mark, every numerator, and the finite compensation signs.
This is not completion or replacement of their arithmetic coefficients.

`GaussianSlots.gaussian_selected_slot_family` separately handles the
moving Gaussian on the actual product/ratio of selected norm variables.
Its joint Mellin/Fourier density has every polynomial height moment
integrable. The bounds are uniform in the moving positive scale, with
arbitrary fixed power decay away from the central Gaussian scale.

For the scalar logarithmic Gaussian

```
g(y) = constant * exp(-(log y)^2/4),
```

the paper-level derivative check is direct: every `(y d/dy)^j g(y)` is a
fixed polynomial in `log y` times `g(y)`, hence uniformly bounded for
all positive `y`. Multiplying the argument by a growing positive scale
translates `log y`; it does not shrink the smoothness scale. Fixed powers
of the norm variables introduce only fixed derivative factors. On fixed
dyads, ordinary scaled derivatives and logarithmic derivatives are
equivalent. Powers such as `Norm(u)^(-1/2)` are similarly smooth after
their scale is factored out.

Norm-height phases produce polynomial costs in the fixed derivative
order: `d^j/dx^j x^(it)` on a fixed positive interval is bounded by
`C_j(1+|t|)^j`. This is acceptable after integration against the existing
rapidly decreasing Mellin/Gaussian density. It is not a uniform Type-I
estimate at every unbounded `t` without those costs; the paper's
high-height theorem has separate hypotheses.

## Dual profile: no conductor disappears

The exact `PhysicalPoisson.physical_row_poisson` has dual radial argument

```
K*Norm(h) / Norm((C*A)*P),
```

and keeps `actualCongruenceCoefficient C A P h`. Its canonical finite-prime
version `CubicTrace.canonical_radial_poisson_product` likewise retains
the full sextic row and the exact denominator norm. Once all involved
norms are dyadically localized, this scalar argument is a product/ratio
of normalized norm variables. It can be Mellin-separated; choosing its
natural dual length absorbs the varying positive scale.

`LowGramHeight.lowGramProfile_uniform_degree` already bounds every fixed
Schwartz seminorm of the native norm-height profile by a polynomial in
the Mellin height. `LowGramIntegrated.low_mellin_sqrt_weight_bound` pays
these polynomial costs against the Mellin transform of the fixed source
window. These show that the physical/dual scalar profile is manageable.
They do not bound the prescribed arithmetic inverse row, and their old
Gram majorant is not counted as new saving.

The dual Fourier profile is Schwartz rather than compactly supported;
using the Type-I input requires a smooth dual dyadic partition plus
its rapidly decreasing scalar tails. This operation does not delete
the discrete zero-frequency term or the arithmetic dual coefficient.
The exact actual conductor, or a genuinely proved reduced conductor,
must remain in the dual scale. Replacing it by a shorter norm before
proving that row identity is not profile separation.

## Moving marks change the level, not just the smooth weight

For the candidate matching block `I=P*I0`, `J=V²`, the literal total mark
is `D | P*I0*V^6`. Let `D0` denote its part not already absorbed in
`P*V^6`. Factoring the remaining condition `D0 | I0` turns the inner
ideal into `I0=D0*u`. In a candidate native `G(P*I0)` Type-I embedding,
the level is therefore `r=P*D0`, not merely `P`. The nonsquarefree and
shared-prime zero cases must remain; they cannot be replaced by unit
weights. The existing moving-mark finite identities do retain them.

This is a conditional scale calculation, not a checked coefficient
bridge to `G(P*I0)`: the dual Gauss join is actually
`alpha(I0)*gamma1(I0)=mu(I0)*G(I0)`. It does not itself move its Möbius
sign, sextic row or cubic orientation into allowed outer coefficients.
If another exact bridge removes `P` from the Gauss level, `r=D0` has a
different range. No such coefficient/source shortcut is inferred here.

With native compensation depth `d`, cube-inverse ideal `H_c`, and retained
square cube `V`, write

```
Norm(P)  ~ Z^(23/48-d),
Norm(H_c)~ Z^h,  Norm(V)~ Z^v,  Norm(D0)~ Z^w.
```

The completed Gaussian centre is `T~Z^(7/6-d)`. For the above candidate
embedding its Gauss product length and level have exponents

```
x = 7/6-d-3h-6v,
r = 23/48-d+w,
u = x-r = 11/16-3h-6v-w.
```

Hence the paper's precise length gate is

```
w + (153/100)h + (153/50)v <= 139/1200 + (49/100)d.
```

For no unabsorbed mark and `h=v=0` it holds throughout `0<=d<=1/6`;
the endpoint ratios are `23/56` and `5/16`. Small positive cube scales
also fit only within the displayed budget.

At maximal total slot budget `1/6`,
`LowNominalGeometry.lowSelectedLength` gives remaining selected length
`1/6-d`. If those selected marks remain in `D0`, then `w=1/6-d`.
With `h=v=0` the gate reduces exactly to

```
d >= 61/1788.
```

At `d=0` the full unabsorbed mark exceeds the Type-I range by `61/1200`.
The native physical prime exponent `23/48-d` is always larger than
every selected slot exponent `<=1/6`, so its matching incidence does not
automatically absorb those selected marks. Absorption by `V` depends on
its actual prime factors and cannot be assumed. These are exact rational
scale checks, not a new theorem about a source-sized selected population.

## Punctures and source/model distinction

An indicator `P∤m`, a mark `D0|I0`, or the genuine row factor
`idealRowHom m (I0)` is discrete arithmetic data. A Mellin transform of
radial norms does not turn it into a smooth `W_r`. Fixing `m` may place
some puncture into an exterior scalar, but the remaining sextic character
in `I0` still depends on the actual numerator. Expanding coprimality over
divisors of `m` can again enlarge `r`; its divisor costs and Type-I range
must be tracked. A bounded value or smooth norm envelope is not enough
to justify dropping this growing conductor.

The Type-I input compares native cubic Gauss with its squarefree
Patterson model, not with an arbitrary density mode or the repository's
whole reciprocal-Hecke source. Smooth-profile compatibility alone proves
neither that the compared native inverse row has that orientation nor
that subtracting its model preserves a nonzero target-zero residue.
That actual coefficient/model/source gate remains explicitly open in
the sibling audit. No saving is credited from the scalar separation.

Conclusion: fixed-dyad physical and dual radial profiles have acceptable
Mellin costs; moving marks can obstruct the Type-I length range, and the
actual sextic/Möbius coefficient bridge cannot be encoded as a smooth
profile. The next work needs that exact source-preserving arithmetic
bridge and a parameter budget covering its actual marks.
