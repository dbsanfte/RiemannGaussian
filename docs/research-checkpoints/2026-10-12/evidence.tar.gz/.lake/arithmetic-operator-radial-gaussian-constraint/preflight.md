# Unit-neutral actual annulus: Gaussian/Poisson constraint preflight

Read-only scoped closure. No new proof leaf, build, assumptions, carrier,
signed inequality, global source claim or zero-free region.

## Exact unchanged physical target

For the actual CalibrationData C and actual cofactor ideal B, keep

    chi_B(m) = C.residueMonoid(m) * idealRowHom(m,B),
    U_B(Q) = sum_m chi_B(m) W(elementNorm(m)/Q),
    V_B,p(Q) = U_B(Q) - chi_B(p) U_B(Q/elementNorm(p)).

The matching row for span(A)=(span p)^(6*t+1)*B is the SAME V_B,p(Q)
times actualSextic_p(-1)*gaussSum(actualSextic_p,quotientTrace_p).
All t>=0, nonunit/puncture zeros, proper powers, calibration and full
complex radial/height W remain. The exact six-unit projection is only
an identity on this original row. UnitNeutral(C,B) leaves it unchanged.
No off-line-source residue is attached to an isolated B row.

## Already imported exact action

PhysicalPoisson.physical_row_poisson (line39) states, for compact smooth W,
Q>0, A!=0, p!=0:

    sum_m calibratedNumerator(C,A,m)*sexticGauss(p,-m)*W(Nm/Q)
    = [Q/N(C.generator*A)]
      * sum_H actualCongruenceCoefficient(C,A,p,H)
          * paperRadialFourier(W)(Q*NH/N((C.generator*A)*p)).

It is not a prime-only or squarefree-cofactor approximation.
The exact Fourier coefficient includes every physical residue, nonunit
zero and native correction. SpectralPoisson.physical_spectral_poisson
(line23) reopens the complete inverse I*J^3 sum BEFORE this transform.
Transformed.markedPhysicalProbe_eq_poisson (line25) includes the native
outer supported ideal and Gaussian contour exp(t^2), target eta, marks,
all J powers, C.tau and calibration generator norms.
These exact actions already join the required row; applying them again
is not a new cancellation estimate.

## General-residue collapse audit

SexticRadialPoisson.actual_radial_paper_poisson_trace (line499) is valid
for EVERY residue table P on O/(c), not specifically actual prime rows:

    sum_m P(m mod c)*W(Nm/Q)
    = [Q/Nc] * sum_h [sum_r P(r)*trace(h*r)]
          * paperRadialFourier(W)(Q*Nh/Nc).

Thus radial Poisson alone supplies no additional relation special to the
prescribed mu/eta/Gauss join. It exchanges an actual complex coefficient
for its finite additive transform. In particular it does not preserve
coefficientwise positivity for the unit-neutral character row.
For primitive characters a finite Gauss/conjugate-character formula may
simplify that transform; imprimitive/shared conductor primes instead
retain additional explicit support. No primitive conductor, coprime B/p
or missing head deletion is silently assumed here.

Hecke.Theta.finitePair, theta_hasSum, pair_hasMellin and pair_g0 build the
theta functional equation for ARBITRARY periodic coefficients, including
the residue zero and mean terms. Joint GramPeriodicPoisson also handles
arbitrary residue tables on the two-coordinate lattice. Those generic
functional equations are not a new signed bound on the prescribed row.
The framework already retains these Gaussian/integer actions.

## Conductor and scale

The TWO complete U_B sums have a genuine period C.generator*generator(B),
not automatically the punctured full period with another p factor.
The puncture itself has the latter honest period. Neither is claimed to
be minimal for arbitrary composite B.
With native nominal scales

    Norm(B) ~ Z^(11/16), Norm(p) ~ Z^(23/48-d),
    Q ~ Z^(5/6-2*d), Q/Norm(p) ~ Z^(17/48-d),

and fixed calibration, the complete annulus volume/conductor exponents are

    long: 7/48 - 2*d,
    short: -1/3 - d.

For d in [0,1/6], the short annulus is ALWAYS below its period scale.
At d=1/6 the exponents are -3/16 and -1/2 respectively. At d=7/96 the long
annulus crosses its own period; so a long-window mean-zero Poisson regime
cannot cover the whole native band, and the short term remains unpaid even
at shallow depth. This is only a scale audit, not a signed lower bound or
proof of no collective prescribed cancellation.
In a Gaussian model the dual first-frequency argument is Q/Nc; when this
ratio shrinks, Gaussian decay does not supply a uniform dual-frequency gap.
The imported Fourier/Gaussian transport keeps the resulting frequencies.

## Differential and two-scale source gate

At fixed B, differentiating radial scale changes W to its Euler derivative;
it does not change the actual prime/divisibility coefficient. Heat evolution
and Gaussian reciprocity give the imported Mellin/Fourier transport.
For a SAME profile operation across all rows, the checked
QuasiRHProfileCentering.source_eq_mass / actual_pool_centered_source_zero
states that the native double-principal source depends on profiles only via

    M(W0,W1)=mellin(W1,1)*mellin(paperRadialFourier(W0),1/6).

Centering this scalar annihilates the ENTIRE reciprocal target L source,
not just a density/pole term. A nonzero common scalar preserves the same
source and leaves the joined arithmetic estimate open. This no-go is only
for the common-profile class in the exact theorem.

A B-dependent profile, arithmetic-dependent heat action, or reciprocal
cross-B comparison is NOT covered by common-profile centering. Its exact
native source multiplier and density separation must be computed before
estimating. The current inspection found no new theorem of this kind that
changes the actual arithmetic action while preserving a proved nonzero
source. Two-scale puncture reciprocity alone retains noncommon finite
Gauss/CRT coefficients and the existing signed difference V_B,p(Q).
No source estimate follows from an isolated annulus functional equation.

## Scope and next genuinely new input

Closed scoped class: repeat radial heat/Poisson transport, common-profile
centering, or generic theta reciprocity on the same unit-neutral row.
These either preserve the same unresolved signed arithmetic or kill the
same target source. They do not improve the native 3/16 low bound.
NOT exhausted: actual cross-B prescribed mu/eta/Gauss correlations, a new
noncommon arithmetic-dependent profile with a proved source gate, or a
source-preserving cuspidal/residual separation of the joint native kernel.
Any next estimate must act on that joined prescription, not norm-pay
individual transformed annuli. The surviving domain remains
1/2<beta<=7/8, with no changed contour claim.
