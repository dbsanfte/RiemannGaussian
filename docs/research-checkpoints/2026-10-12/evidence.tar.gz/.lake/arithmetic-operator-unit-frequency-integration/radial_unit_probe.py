"""Diagnostic actual F7 sextic row; no certificate or RH/source assertion."""
import cmath,json,math
from pathlib import Path
OUT=Path(__file__).parent
# O=Z[omega], omega maps to2 in F7; generator2-omega has norm7.
EPS=cmath.exp(1j*math.pi/3)
LIFT={pow(3,j,7):EPS**j for j in range(6)}
def norm(a,b):return a*a-a*b+b*b
def chi(a,b,e):
 v=(a+2*b)%7
 return 0j if v==0 else LIFT[v]**e
def row(V,y,e,puncture):
 bnd=math.ceil(3*math.sqrt(V))+3
 vals=[];pairs=0
 for a in range(-bnd,bnd+1):
  for b in range(-bnd,bnd+1):
   n=norm(a,b)
   if not 0<n<2*V:continue
   # independent actual norm13 prime4+omega, omega maps to9 in F13.
   if puncture and (a+9*b)%13==0:continue
   W=max(0.,1-abs(n/V-1))*cmath.exp(1j*y*math.log(n/V))
   vals.append(chi(a,b,e)*W);pairs+=1
 return sum(vals),pairs
results=[]
for V in [2.3,7.1,21.5,64.3,193.1]:
 for y in [0,54,127.25]:
  for puncture in [False,True]:
   d={'V':V,'height':y,'punctureNorm13':puncture,'orders':[]}
   for e in [1,2,3,4,5,6]:
    z,n=row(V,y,e,puncture)
    d['orders'].append({'primeIdealPower':e,'value':[z.real,z.imag],'absolute':abs(z),'terms':n,'unitNeutral':e==6})
   results.append(d)
max_bad=max(o['absolute'] for d in results for o in d['orders'] if not o['unitNeutral'])
r={'scope':'finite actual F7 sextic characters on Z[omega], unit-trivial calibration factor only; diagnostic, not native full-carrier/source estimate',
'primeIdeal':'(2-omega), Norm7','punctureIdeal':'(4+omega), Norm13','radialWindow':'max(0,1-|Norm(m)/V-1|)*exp(i*y*log(Norm(m)/V))','maxNonneutralFloatingResidual':max_bad,'cases':results,'noFormalCertificate':True,'noSourceOrExponentClaim':True}
assert max_bad<1e-8
(OUT/'radial-unit-probe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'cases':len(results),'maxNonneutralResidual':max_bad,'neutralHeight0Norm193': [d['orders'][-1]['absolute'] for d in results if d['V']==193.1 and d['height']==0]}))
