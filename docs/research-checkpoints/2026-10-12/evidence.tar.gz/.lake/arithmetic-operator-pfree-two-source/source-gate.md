# Unmarked cofactor-two source gate

Strict local compilation passed with exit 0: 64 local declarations,
54 theorems including generated helpers, 15 namespace linters, and only
`propext`, `Classical.choice`, `Quot.sound` on every local declaration by
module provenance. The source and evidence hashes are in `summary.json`.

For every ordinary odd prime q, the actual p-free binomial unit trace at
the quadratic parity resonance equals

    (principal_8(q) + character_{-1}(q))/2.

This follows from the complete native row, not a spatial average or an
incomplete cutoff. The ordinary q=2 head is explicitly excluded and zero
in this coefficient; this does not identify a q=2 binomial trace.

The exact all-prime-power Euler response is

    - (logDeriv L(principal_8) + logDeriv L(character_{-1}))/2.

The ordinary-prime coefficient is exactly the completed coefficient minus
the same character selector times the repository's proper-prime-power
coefficient. That correction is analytic throughout Re(s)>1/2. All original
height phases are retained in the Euler identities.

For every actual right-half zeta zero rho, without exposure or simplicity,
the continued ordinary-prime response has residue

    -m_zeta(rho)/2 - order L(character_{-1})(rho)/2.

Its magnitude is at least m_zeta(rho)/2>0. A simultaneous character L-zero
adds the same sign and cannot cancel it. The density residue is exactly 1/2;
subtracting 1/[2(s-1)] gives an analytic density germ and preserves the whole
zero residue. The centered ordinary response is therefore not analytic at
any actual right-half zeta zero.

The row has collapsed to a fixed character selector. Joining arbitrary
outer weights preserves exactly that selector, so this finite identity
supplies no further signed estimate on the weighted prime sum. No smooth
or generalized-prime control has been granted binomial/Gamma compatibility.
No native cofinal source, finite-count-mask payment, independent RH bound,
or exclusion follows from the continued Euler residue. Nonconstant
valuation marks, other fixed cofactors, growing cofactors, incomplete native
rows and prescribed coupled codes remain separate open mechanisms.
