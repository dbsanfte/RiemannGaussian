# Actual Kummer/Gamma × Möbius/log Selberg source gate

Status: read-only source audit; no new Lean leaf, estimate, source claim,
zero exclusion, public registration, or family-exhaustion claim.
The source pins record current files and exact existing declarations.
Existing Lean results were read, not rebuilt in this pass.

## What the full actual constraints do establish

Complete integer factorial/Gamma observations are not free-weight data.
`ArithmeticOperatorFactorialUniqueness.mangoldt_unique_on_prefix` and
`mangoldt_unique` force every positive-index coefficient to be the actual
von Mangoldt sequence. Complete literal coprimality observations similarly
force actual Möbius (`ArithmeticOperatorMoebiusCoprimeAudit.coprime_observations_force_mu`).
Consequently the prior parity, smooth-density and selected-prime controls
cannot be asserted to satisfy these exact observations.

The stronger comparison is already explicit:
`ArithmeticOperatorSelbergControlAudit.control_fails_actual_moebius_constraint`
and `ArithmeticOperatorSelbergHierarchyAudit.control_fails_actual_Gamma`
show that the coherent unit-prime control fails the unchanged actual data,
at every positive hierarchy order. Positivity and Gamma *upper* bounds
are a different, audited weaker class.

## Complete joining: exact identities and actual source laws

1. Actual finite Kummer prefix joining already gives
   `sum_d Lambda(d) sum_{n<=X, d|n, H(n)<d} w(n)`
   (`ArithmeticOperatorKummerPrefixAudit.actual_packet_eq_scalar`).
   The Fubini identity is valid for arbitrary arrays; that statement does
   not grant actual binomial or Gamma compatibility to those arrays.

2. Cofactor-compatible twisting completes to
   `sum_{d|n} Lambda(d) phase(d) phase(n/d) = phase(n) log(n)`.
   Its complete Euler response is `-zeta'(s+i*y)`, whose matched-zero
   logarithmic residue is zero. Fixed finite complete Gamma words remain
   analytic at strip zeros. These are source failures for those complete
   words, not source failures for all incomplete integer correlations.

3. Applying actual Möbius inversion to the complete phased Gamma row
   restores exactly `Lambda(n) phase(n)`
   (`ArithmeticOperatorGammaInverseAudit.actual_decoded`). Its coded cutoff
   is exactly the already-audited scalar packet. Source and density
   cancellation survive, but no independent inequality is added by the
   round trip. The norm debit of its literal inverse fibers diverges at
   source scale; that is a no-go for that norm payment only.

4. The actual Selberg identity is
   `mu * log^2 = Lambda log + Lambda * Lambda`, with every proper prime
   power, ordered incidence, diagonal and endpoint retained.
   At an actual zero of multiplicity m, the complete plus word has
   quadratic source `m(m-1)`; it misses a simple zero at that scale.
   Subtracting the full pair recovers source `-m`. The actual complete
   minus word `Lambda log - Lambda * Lambda` has source `-m-m^2`.
   Its whole density germ can be removed by multiplication by `s-1`
   without cancelling the target-zero source.

5. Genuine complete distinct-prime Kummer/CRT joining already equals
   the actual distinct-prime pair coefficient, and its continued response
   is `(logDeriv zeta)^2 - diagonal`. The actual source is `m^2` for
   Re(rho)>1/2; the diagonal is independently analytic there. The pole
   germ can be removed without removing this source. This is not a
   signed estimate on native incomplete masks.

Thus exact actual arithmetic compatibility is real additional input,
but complete re-expression of it supplies no new signed bound in the
classes above. There is no claim that every use of those constraints is
impossible, or that actual primes are interchangeable with free arrays.

## What a native mask leaves

For `P2(n)=sum_{de=n} Lambda(d)Lambda(e)`, any literal incidence mask M
and any full-label reference c satisfy the elementary finite identity

```
sum_{de=n} M(n,d,e) Lambda(d)Lambda(e)
 = c(n) [sum_{ab=n} mu(a) log(b)^2 - Lambda(n)log(n)]
   + sum_{de=n} [M(n,d,e)-c(n)] Lambda(d)Lambda(e).
```

This displayed residual is a direct algebraic consequence of the checked
Selberg coefficient identity, not a new compiled theorem or estimate.
It vanishes for complete same-height phases
`M(n,d,e)=phase(d)phase(e)=phase(n)=c(n)`.
Native Kummer cutoffs, partial prime-only phases or nonprefix correlations
need not have that property. Calling their residual a boundary does not
pay it. No native mask has been replaced here.

The source-sensitive linear instance is ALREADY Lean-checked:

```
twistCommutator(phase,n)
 = sum_{d|n} Lambda(d) phase(d) [1-phase(n/d)].
```

For the actual height phase its complete response, in the original zeta
coordinate z, is
`zeta(z-i*y)*(-logDeriv zeta(z)) + zeta'(z)`.
At every actual nontrivial zero rho it has residue
`-m_rho*zeta(Re(rho)) != 0`. The nonzero real-strip factor is proved from
the existing eta theorem, without RH. The finite cutoff still joins
exactly to a single scalar kernel against Lambda. Its four-scale density
code preserves the actual matched residue, but the code theorem explicitly
does NOT give a native cutoff asymptotic or bound.

Expanding this residual once more by `Lambda=mu*log` merely reindexes it
as a complete signed triple divisor sum. It does not create another
independent arithmetic constraint or pay its source. Nonlinear successor
commutators and different-prime constrained masks remain outside this
linear collapse theorem.

## Action-changing conclusion

Do not duplicate a Selberg/Gamma reconstruction or cite a parity control
as compatible with the unchanged actual data. The checked classes above
are either source-blind complete Gamma words, an exact same-source
inverse round trip, or already-known source-retaining Selberg/CRT tests.

To reopen this interaction, supply a new *native masked* constraint and
an actual-zero source attachment for its surviving commutator, followed
by an independent signed estimate. The unaltered actual mu/log/Gamma
constraints are still legitimate input for such a theorem. None of the
read identities proves it; absence of it here is not a universal no-go.
Move to the next distinct ranked gate rather than adding another carrier.
