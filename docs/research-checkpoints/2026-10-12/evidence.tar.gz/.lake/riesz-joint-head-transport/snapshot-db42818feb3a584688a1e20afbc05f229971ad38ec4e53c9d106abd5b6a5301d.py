from pathlib import Path
import hashlib
import json
import re
import subprocess

out = Path('.lake/riesz-joint-head-transport')
source = Path('RiemannGaussian/ZetaRieszPrimeHeadTransport.lean')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '194a361762f404a8f4473298b25d96fbae0bb56e'
previous_path = Path('docs/riesz-balanced-radial-payment-audit.json')
previous = json.loads(previous_path.read_text())
root = Path('.lake/build/lib/lean/RiemannGaussian.olean')
root_sha = hashlib.sha256(root.read_bytes()).hexdigest()
assert any(p['path'] == str(root) and p['sha256'] == root_sha
           for p in previous['compiledArtifacts'])
for p in previous['sources']:
    if p['path'] != 'AGENTS.md':
        assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest() == p['sha256'], p['path']

logs = [out/'strict-lean.log', out/'build.log', out/'audit.log']
for path in logs:
    assert not re.search(r'^(error|warning):|: error:|: warning:', path.read_text(), re.M), path
assert 'Build completed successfully' in (out/'build.log').read_text()
lint = (out/'audit.log').read_text()
assert lint.count('All linting checks passed') == 1
assert lint.count('Found 0 errors') == 1
assert lint.count('with 14 linters') == 1
axioms = json.loads((out/'axioms.json').read_text())
assert axioms['module'] == 'RiemannGaussian.ZetaRieszPrimeHeadTransport'
assert axioms['onlyStandardAxioms']
for theorem in axioms['theoremAxioms']:
    assert set(theorem['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}


def saved(path):
    path = Path(path)
    data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    snapshot = out/f'snapshot-{sha}{path.suffix}'
    if snapshot.exists():
        assert snapshot.read_bytes() == data
    else:
        snapshot.write_bytes(data)
    return dict(path=str(path), sha256=sha, snapshot=str(snapshot))


text = source.read_text()
code = re.sub(r'/\-.*?\-/', '', text, flags=re.S)
assert not re.search(r'\b(sorry|admit|sorryAx)\b', code)
assert not any(line.rstrip() != line for line in text.splitlines())
probe_path = out/'probe.json'
probe = json.loads(probe_path.read_text())
assert len(probe['cases']) == 12
assert probe['source']['sha256'] == hashlib.sha256(Path(probe['source']['path']).read_bytes()).hexdigest()
assert probe['scope']['optionalOutsideBuildsCI']
assert probe['scope']['fullSignedHeadUnchanged']
assert probe['scope']['allCountsJoinedBeforeClipping']
assert probe['scope']['exactlyOneGlobalCoefficientPerDirection']
assert not probe['scope']['movingIntegerLength']
assert not probe['scope']['nativeDyadicSchedule']
assert not probe['scope']['previousEventualBudgetsApplied']
significant = []
for case in probe['cases']:
    assert case['allFiniteSignedTotalsAndZeroColumnsVerifiedInFloatingArithmetic']
    assert not case['sourceScaleOrCofinalFloorProved']
    quad = next(c for c in case['candidates'] if c['direction'] == 'divisor-quadratic')
    signed = quad['exactSignedCrossing']
    assert abs(signed['signedCredit']-quad['saving']) < 1e-12
    assert signed['originalZeroFacesAndEveryAdverseCrossingRetained']
    assert signed['nullProfilesAndHeadDirectionJoinedBeforeCrossing']
    if case['oldPrice'] > 1e-16:
        assert quad['saving'] > 0
        significant.append(quad)
    else:
        assert quad['relativeSavingSuppressedAsFloatingZero']
        assert quad['relativeSaving'] == 0
assert len(significant) == 11

report = dict(
    schemaVersion=1, date='2026-10-03', head=head,
    objective='Close out the floor.', goalRemainsActive=True,
    slice='Exact native prime-head transport into its quadratic divisor orbit, followed by signed finite-step cancellation with the old free main profiles. The resulting whole credit is spent in the current floor, with its cofinal arithmetic size still open.',
    sources=[saved(p) for p in [
        source, 'RiemannGaussian/ZetaRieszBalancedRadialPayment.lean',
        'RiemannGaussian/ZetaRieszBalancedAllocationPayment.lean',
        'RiemannGaussian/ZetaRieszBalancedOwnerFloor.lean',
        'RiemannGaussian/ZetaRieszPrimeHeadPeriods.lean',
        'RiemannGaussian/ZetaRieszRoughPrimePairCancellation.lean',
        'RiemannGaussian/ZetaRieszQuantitativeNullStep.lean',
        'RiemannGaussian/ZetaRieszSignedNullGain.lean',
        'RiemannGaussian/ZetaRieszTaggedCoreWindow.lean',
        'RiemannGaussian/ZetaRieszSmallTagNativeFloor.lean',
        'RiemannGaussian/ZetaMoebiusDivisorBoundary.lean',
        'RiemannGaussian/ZetaRieszCutoffPeriodFloor.lean',
        'RiemannGaussian/ZetaRieszComplexProjection.lean',
        'scripts/probe_riesz_joint_head_transport.py',
        'scripts/probe_riesz_balanced_joint.py',
        'docs/zeta-riesz-prime-head-transport.md', previous_path,
        'AGENTS.md', 'lean-toolchain', 'lake-manifest.json']],
    compiledArtifacts=[saved(p) for p in [
        '.lake/build/lib/lean/RiemannGaussian/ZetaRieszPrimeHeadTransport.olean', root]],
    validation=dict(
        scope='Focused local: strict leaf, targeted build, frozen compiled ordinary root plus explicit new leaf. No root-source rebuild or wider gates.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(source),exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszPrimeHeadTransport --wfail',exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(out/'Audit.lean'),exitCode=0,
            compiledOrdinaryRootImported=True, explicitLeafImported=True,
            frozenCompiledRootMatchesPrevious=True, rootSourceNotRebuilt=True,
            namespaces=1, lintersPerNamespace=14, allNamespaceLintersPass=True),
        publicTheorems=len(re.findall(r'^theorem [A-Za-z_]',text,re.M)),
        publicDefinitions=len(re.findall(r'^def [A-Za-z_]',text,re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheoremsIncludingPrivateAndGenerated=axioms['theoremsIncludingPrivateHelpers'],
        everyCompiledDeclarationAxiomChecked=True, onlyStandardAxioms=True,
        previousFrozenProofAndDocumentationSourcesPreserved=True),
    exactResults=dict(
        originalSignedHeadTotalPreservedNotClaimedZero=True,
        originalPrimePairPhaseOwnerAllocationSieveAndFullRadialSupportRetained=True,
        noPrimePairIncidenceAverage=True,
        actualPairDivisorPrefix='1_{1<=k}-1_{p<=k}-1_{q<=k}+1_{pq<=k}',
        exactQuadraticOrbitTotal='2 log(p) log(q)/(N+1)',
        terminalBoundaryCancelledExactlyNotDiscarded=True,
        nativePairOrder='q<p for N>=64 on original pair support',
        transportedHeadTotalEqualsSameNativeHead=True,
        oldMinusTransportedHeadHasExactZeroTotal=True,
        enlargedEndpointContainsAllHeadPairLabels=True,
        addedOldIncrementsExactlyZeroAndOldCostUnchanged=True,
        mathematicallyDefinedTwoOrientationCrossingSquareCreditSpent=True,
        oldFreeProfileAndHeadUpdatesJoinedBeforeCrossings=True,
        exactCoupledCredit='max(signed adverse correlation - exact crossing cost,0)',
        coupledCreditEqualsActualWholeCostSaving=True,
        originalZeroPeriodsAndEveryAdverseCrossingRetained=True,
        noInverseMarginEstimateInExactCoupledCredit=True,
        directIndependentCentralMinusHeadLowerInequality=True,
        allCountsWholePeriodsPhaseAndOriginalMainMasksRetained=True,
        oldWholeNativeTangentColumnsRetained=True,
        creditActuallySpentInJoinedPhysicalFloor=True,
        sameHighOwnerAllocationRadialAndNativeErrorsRetainedOnce=True,
        noSeparateNormPaymentOfMainOrHead=True,
        olderFundedPricesKeptAsAlternativesNotStacked=True,
        positiveNativeCorrelationOrCofinalSmallCostNotAssumed=True),
    optionalProbe=dict(
        snapshot=saved(probe_path),
        command='../.venv/bin/python scripts/probe_riesz_joint_head_transport.py',
        exhaustiveToyCases=12, orders=[6,7], heights=[54,65,100],
        radialWindows=[[1.95,2.03],[1.971,2.029]],
        toyLength='-2N log u; not the native moving integer length',
        nativeDyadicSchedule=False, fullNativeDeletionMasks=False,
        previousNativeBudgetsApplied=False, optionalOutsideBuildsAndCI=True,
        fullSignedHeadUnchangedAcrossRadialWindows=True,
        allCountsJoinedBeforeClippingAndOnlyGlobalCoefficients=True,
        allFiniteLedgersAndExactCrossingIdentitiesCheckedInFloatingArithmetic=True,
        analyticallyZeroLogMinusHingeStepComputedWithoutSubtractiveRoundoff=True,
        nearZeroOptimizedGroupsNotRoundedAway=True,
        oldOptimizedChoiceRetainedAsFallback=True,
        significantBaselines=11, significantQuadraticSavingsPositive=11,
        quadraticRelativeSavingsRange=[min(p['relativeSaving'] for p in significant),
                                       max(p['relativeSaving'] for p in significant)],
        alreadyZeroBaselineNotReportedAsRelativeSaving=True,
        onlyQuadraticHeadDirectionFormalized=True,
        totalLabelAndBothDirectionsExploratoryOnly=True,
        fractionsOfNativeFloorDeficitClaimed=False,
        sourceScaleCofinalOrIntervalCertificates=False),
    openPremises=dict(
        remainingSignedTarget='whole central original Riesz sum minus SAME full signed prime head',
        exactRemainingNumericalTarget='cofinal centralCost - coupledCredit + highOwnerBudget + allocationBudget + radialBudget <= 399/5000',
        requiredNativeCreditSizeProved=False,
        wholeFloorProved=False, multiplicityCeilingProved=False,
        restrictedContradictionProved=False, zeroExclusionProved=False, rhProved=False),
    publication=dict(localOnly=True, noCommitsOrPushes=True, noSubagents=True,
        noRootRegistration=True, publicEndpointsUnchangedByThisSlice=True,
        noReadmeExplorerChanges=True, concurrentSemiprimeWorkPreserved=True),
    provenance=[saved(p) for p in logs+[out/'Audit.lean',out/'axioms.json',out/'probe.log',Path(__file__)]])
blob=json.dumps(report,indent=2)+'\n'
(out/'report.json').write_text(blob)
Path('docs/riesz-prime-head-transport-audit.json').write_text(blob)
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    publicDefinitions=report['validation']['publicDefinitions'],
    compiledDeclarations=axioms['declarations'],
    compiledTheorems=axioms['theoremsIncludingPrivateHelpers'],
    significantToySavings=11, allChecksPass=True, wholeFloorStillOpen=True)))
