from pathlib import Path
import hashlib
import json

root=Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
path=root/'docs/arithmetic-operator-audit.json'
audit=json.loads(path.read_text())
report_path=root/'.lake/arithmetic-operator-roadmap/axioms.json'
report=json.loads(report_path.read_text())
modules=report['modules']
assert len(modules)==60
assert modules[-1]['module'].endswith('ArithmeticOperatorRamanujanInverseAudit')
assert all(m['onlyStandardAxioms'] for m in modules)
log_path=root/'.lake/arithmetic-operator-roadmap/validation.log'
log=log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters')==60
assert 'Checked RiemannGaussian.ArithmeticOperatorRamanujanInverseAudit:' in log
expected_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source,pin in audit['sources'].items():
    assert digest(source)==pin or source in expected_changes,source
for source in ('RiemannGaussian/ArithmeticOperatorRamanujanInverseAudit.lean',
    'RiemannGaussian/ZetaCoprimeEulerPhase.lean',
    'RiemannGaussian/ZetaMoebiusFactorResponse.lean'):
    audit['sources'][source]=digest(source)
for source in audit['sources']:
    audit['sources'][source]=digest(source)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
audit['date']='2026-10-07'
v=audit['validation']
v.update({
    'modules':len(modules),
    'theoremsIncludingPrivateHelpers':sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations':sum(m['declarations'] for m in modules),
    'namespaceLinterRuns':sum(m['namespaceLinters'] for m in modules),
    'reportSha256':digest(report_path),'logSha256':digest(log_path),
    'moduleReports':modules,
})
audit['scope'].update({
    'structuredDivisorCodeGammaInverseExactAllFinitePositiveMasks':True,
    'structuredDivisorCodeGammaInverseKeepsActualGammaAndActualMobius':True,
    'structuredDivisorCodeGammaInverseRetainsProperPowersFullPhaseAndNativeMasks':True,
    'structuredDivisorCodeGammaInverseClassification':'original Mangoldt finite dilations plus explicit single-label logarithmic heads',
    'structuredDivisorCodeGammaInverseNativeHeadsOrBoundariesDiscarded':False,
    'structuredDivisorCodeGammaInverseHeadsClaimedPaid':False,
    'structuredNonconstantCrtLagCodeGammaBridgeExact':True,
    'ramanujanGammaInverseCoefficients':'P*mu(q/P) for every P|q',
    'ramanujanGammaInverseGenuineEulerResponse':'multiplier_q*(-logDeriv zeta)+head_q; Re(s)>1 with absolute convergence',
    'ramanujanGammaInverseFullPhaseEulerIdentity':True,
    'ramanujanGammaInverseExactMultiplier':'q*q^(-s)*coprimeEulerFactor(q,1-s)',
    'ramanujanGammaInverseEverySquarefreeModulusSourceNonzeroOnReLessOne':True,
    'ramanujanGammaInverseActualZeroResidue':'-m_rho*multiplier_q(rho), all actual multiplicities without exposure',
    'ramanujanGammaInverseNonunitPoleClearedAsAnalyticGerm':True,
    'ramanujanGammaInverseAnalyticOnStripIffZetaNonvanishing':True,
    'ramanujanGammaInverseOneFixedPrimeCodeSurjectiveOnFreeInputRows':True,
    'ramanujanGammaInverseFreeControlsClaimedActualGammaEqualities':False,
    'ramanujanGammaInverseControlsClaimedGeneralizedPrimeEulerSystem':False,
    'ramanujanGammaInverseCompositeAuxiliaryModulusClaimedMangoldtColumn':False,
    'ramanujanGammaInverseOriginalSignedDilationPrimeEstimateDischarged':False,
    'ramanujanGammaInverseNoGoScope':'fixed finite divisor-code/dilation-only Gamma-Mobius word; actual input exactly old signed Mangoldt dilations and explicit heads, fixed prime code remains free-input surjective, squarefree coded holomorphy iff original nonvanishing; non-divisor codes, uniform growing rates and genuine constrained nonlinear/native boundary estimates remain unpaid',
})
old='constrained periodic code or correlated-mask estimate after actual Gamma/Mobius inversion; direct fixed-periodic complete rows lose the source, while unrestricted zero-mean codes prescribe arbitrary finite outputs'
new='non-divisor constrained periodic code or genuinely correlated-mask estimate after actual Gamma/Mobius inversion; fixed divisor/Ramanujan words reduce exactly to original signed Mangoldt dilations plus explicit heads and coded holomorphy is original nonvanishing; direct complete periodic rows lose the source and unrestricted codes prescribe arbitrary outputs; an independent estimate of the retained dilations is still new input'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid']=[new if x==old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit,indent=2)+'\n')
carry_path=root/'docs/suzuki-carry-exceptional-audit.json'
carry=json.loads(carry_path.read_text())
for source,pin in carry['sources'].items():
    assert digest(source)==pin or source=='AGENTS.md',source
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; scoped structured Ramanujan Gamma-inverse audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print(json.dumps({
    'modules':v['modules'],'theoremsIncludingPrivateHelpers':v['theoremsIncludingPrivateHelpers'],
    'declarations':v['declarations'],'namespaceLinterRuns':v['namespaceLinterRuns'],
    'sourcePins':len(audit['sources']),'reportSha256':v['reportSha256'],
    'logSha256':v['logSha256'],'rhEndpointDischarged':audit['rhEndpointDischarged'],
},indent=2))
