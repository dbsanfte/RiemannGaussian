from pathlib import Path
import hashlib
import json

root=Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
path=root/'docs/arithmetic-operator-audit.json'
audit=json.loads(path.read_text())
report_path=root/'.lake/arithmetic-operator-roadmap/axioms.json'
report=json.loads(report_path.read_text())
modules=report['modules']
assert len(modules)==59
assert modules[-1]['module'].endswith('ArithmeticOperatorCrtLagAudit')
assert all(m['onlyStandardAxioms'] for m in modules)
log_path=root/'.lake/arithmetic-operator-roadmap/validation.log'
log=log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters')==59
assert 'Checked RiemannGaussian.ArithmeticOperatorCrtLagAudit:' in log
expected_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source,pin in audit['sources'].items():
    assert digest(source)==pin or source in expected_changes,source
for source in ('RiemannGaussian/ArithmeticOperatorCrtLagAudit.lean',):
    audit['sources'][source]=digest(source)
for source in audit['sources']:
    audit['sources'][source]=digest(source)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
audit['date']='2026-10-07'
v=audit['validation']
v.update({
    'modules':len(modules),
    'theoremsIncludingPrivateHelpers':sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations':sum(m['declarations'] for m in modules),
    'namespaceLinterRuns':sum(m['namespaceLinters'] for m in modules),
    'reportSha256':digest(report_path),'logSha256':digest(log_path),
    'moduleReports':modules,
})
audit['scope'].update({
    'completeFlatLagPeriodNativeIntegerRowsKept':True,
    'completeFlatLagPeriodIncludesZeroAndLastLag':True,
    'completeFlatLagPeriodAllPrimePowersDiagonalAndSharedBasePairsKept':True,
    'completeFlatLagIncidenceJoin':'sum_(h mod e) incidenceCount(X,h,d,e)=floor(X/d)',
    'completeFlatLagCompatibleMean':'X/lcm(d,e) if gcd(d,e)|h; zero otherwise',
    'completeFlatLagCompatibleMeanSum':'X/d',
    'completeFlatLagSignedCrtBoundary':'floor(X/d)-X/d; no termwise norm',
    'completeFlatLagAverageOriginalRowPeriodCompleted':False,
    'completeFlatLagArbitraryNonseparableCodeScalarCollapse':True,
    'completeFlatLagFreeWeightAllowanceIffJoinedKernelZero':True,
    'completeFlatLagLiteralFirstColumnCenteringKillsEverySource':True,
    'completeFlatLagPrimeOnlySecondLegPhaseKept':True,
    'completeFlatLagActualLinearCommutatorResidueConserved':'partner(e,y)*(-m_rho*zeta(Re rho)), nonzero for prime e at every actual multiplicity; old first packet unpaid',
    'completeFlatLagDensityCodeIsDiagnosticNotNativeAsymptotic':True,
    'completeFlatLagNativeNonlinearSourceInferredFromLinearMode':False,
    'completeFlatLagActualSecondCofactorPhaseRemovedOrPaid':False,
    'completeNonconstantLagCodeExactSelectedValue':'code(n,-(n mod e)); not its period mean',
    'completeFlatLagControlsClaimedToObeyActualGammaConstraints':False,
    'completeFlatLagActualSignedPrimeEstimateDischarged':False,
    'completeFlatLagNoGoScope':'complete flat additive-lag period with native first cutoff; conserves the unpaid first packet or kills every source after literal centering; nonconstant codes, actual second cofactor phase, incomplete lag periods and constrained signed Gamma/Mobius information remain open',
})
old='source-sensitive signed distinct-prime-column estimate using complete unaltered actual Gamma/Mobius data and literal incomplete-period CRT/order boundaries; complete common-period Kummer/CRT bookkeeping is free even for nonseparable residue codes; the unit-prime Euler control has all proper powers, full PNT and bounded correlated matrix agreement at bulk density scales, yet a coherent full source and still fails actual complete Gamma data'
new='source-sensitive signed distinct-prime-column estimate using complete unaltered actual Gamma/Mobius data, nonconstant correlated lag codes, actual second-row cofactor phase and literal incomplete-period CRT/order boundaries; complete common-period Kummer/CRT bookkeeping is free, and complete flat-lag averaging conserves the first packet or annihilates every source after literal centering; the unit-prime Euler control retains a coherent source while still failing actual complete Gamma data'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid']=[new if x==old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit,indent=2)+'\n')
carry_path=root/'docs/suzuki-carry-exceptional-audit.json'
carry=json.loads(carry_path.read_text())
for source,pin in carry['sources'].items():
    assert digest(source)==pin or source=='AGENTS.md',source
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; scoped complete flat additive-lag audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print(json.dumps({
    'modules':v['modules'],'theoremsIncludingPrivateHelpers':v['theoremsIncludingPrivateHelpers'],
    'declarations':v['declarations'],'namespaceLinterRuns':v['namespaceLinterRuns'],
    'sourcePins':len(audit['sources']),'reportSha256':v['reportSha256'],
    'logSha256':v['logSha256'],'rhEndpointDischarged':audit['rhEndpointDischarged'],
},indent=2))
