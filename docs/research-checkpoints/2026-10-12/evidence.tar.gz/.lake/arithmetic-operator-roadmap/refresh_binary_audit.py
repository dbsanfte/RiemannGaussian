import hashlib,json
from pathlib import Path
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=Path("docs/arithmetic-operator-audit.json")
a=json.loads(audit.read_text())
report=json.loads(Path(a["validation"]["reportPath"]).read_text())
modules=report["modules"]
assert len(modules)==38
assert modules[-1]["module"]=="RiemannGaussian.ArithmeticOperatorBinaryEulerControl"
assert all(m["onlyStandardAxioms"] for m in modules)
for p in ["RiemannGaussian/ArithmeticOperatorBinaryPrimeControl.lean",
          "RiemannGaussian/ArithmeticOperatorBinaryEulerControl.lean",
          "RiemannGaussian/FiniteAbelVariation.lean",
          "RiemannGaussian/ZetaMoebiusResonanceDecay.lean"]:
    a["sources"][p]=sha(p)
for p in a["sources"]:
    a["sources"][p]=sha(p)
v=a["validation"]
v.update(modules=len(modules),
    theoremsIncludingPrivateHelpers=sum(m["theoremsIncludingPrivateHelpers"] for m in modules),
    declarations=sum(m["declarations"] for m in modules),
    namespaceLinterRuns=sum(m["namespaceLinters"] for m in modules),
    moduleReports=modules,
    reportSha256=sha(v["reportPath"]),logSha256=sha(v["logPath"]))
s=a["scope"]
s.update(binaryPrimeRoundingInfiniteMomentTransferProved=True,
    binaryPrimeControlHasLiteralUnitOrdinaryPrimeWeights=True,
    binaryPrimeControlIncludesEveryProperPower=True,
    binaryPrimeControlCompleteSourceIsMinusTwo=True,
    binaryPrimeControlHasAllFreeFeatureGrams=True,
    binaryPrimeControlHasGammaUpperInequality=True,
    binaryPrimeControlFailsCompleteExactGammaEquality=True,
    binaryPrimeControlIsActualMangoldt=False,
    generalizedPrimeEulerProductControlProved=True,
    binaryEulerProductDomain="Re(s)>1",
    binaryEulerControlMeromorphicContinuationProved=False,
    binaryEulerSourceRequiresOffLineZetaZero=False)
s["unpaid"]=[x for x in s["unpaid"] if x!="a generalized-prime Euler-product control is not claimed for the new periodic or fractionally weighted tower models"]
s["unpaid"]=[x.replace("genuine prime-power support, bounded positivity and same-base consistency alone admit coherent controls","even unit ordinary-prime Euler products with all proper powers, free Grams and Gamma upper bounds admit coherent controls") for x in s["unpaid"]]
s["unpaid"].append("periodic and fractional controls retain their original scope; only the separately proved binary subset has a genuine unit-prime Euler product")
a["diagnostics"]["newCountermodelIsGeneralizedPrimeEulerProduct"]=True
a["diagnostics"]["generalizedPrimeClaimAppliesOnlyToBinarySubset"]=True
audit.write_text(json.dumps(a,indent=2)+"\n")
cpath=Path("docs/suzuki-carry-exceptional-audit.json")
c=json.loads(cpath.read_text())
c["sources"]["AGENTS.md"]=sha("AGENTS.md")
c["policyPinUpdated"]="Binary unit-prime Euler-product scoped no-go policy added; historical carry validation unchanged."
cpath.write_text(json.dumps(c,indent=2)+"\n")
print({k:v[k] for k in ["modules","theoremsIncludingPrivateHelpers","declarations","namespaceLinterRuns"]})
