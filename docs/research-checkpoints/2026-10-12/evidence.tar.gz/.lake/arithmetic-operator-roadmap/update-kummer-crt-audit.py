from pathlib import Path
import hashlib
import json

root=Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
path=root/'docs/arithmetic-operator-audit.json'
audit=json.loads(path.read_text())
report_path=root/'.lake/arithmetic-operator-roadmap/axioms.json'
report=json.loads(report_path.read_text())
modules=report['modules']
assert len(modules)==58
assert modules[-1]['module'].endswith('ArithmeticOperatorKummerCrtAudit')
assert all(m['onlyStandardAxioms'] for m in modules)
log_path=root/'.lake/arithmetic-operator-roadmap/validation.log'
log=log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters')==58
assert 'Checked RiemannGaussian.ArithmeticOperatorKummerCrtAudit:' in log
expected_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source,pin in audit['sources'].items():
    assert digest(source)==pin or source in expected_changes,source
for source in ('RiemannGaussian/ArithmeticOperatorKummerCrtAudit.lean',
    'RiemannGaussian/ZetaPrimePairDiagonal.lean'):
    audit['sources'][source]=digest(source)
for source in audit['sources']:
    audit['sources'][source]=digest(source)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
audit['date']='2026-10-07'
v=audit['validation']
v.update({
    'modules':len(modules),
    'theoremsIncludingPrivateHelpers':sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations':sum(m['declarations'] for m in modules),
    'namespaceLinterRuns':sum(m['namespaceLinters'] for m in modules),
    'reportSha256':digest(report_path),'logSha256':digest(log_path),
    'moduleReports':modules,
})
audit['scope'].update({
    'distinctPrimePowerKummerCompleteCrtPeriodExactNativeIntegerSum':True,
    'kummerCrtCompletePeriodRetainsEveryPositivePrimePowerOrder':True,
    'kummerCrtRawMeanExactlyProductOfLiteralSingleCarryMeans':True,
    'kummerCrtArbitraryNonseparableResidueCodeExactlyCartesianMean':True,
    'kummerCrtBoundedConstantCodePrescribesSameBoundedScalarEntry':True,
    'kummerCrtSingleCarryMeansPositiveAtEveryNonunit':True,
    'kummerCrtMeanNormalizedCoefficientExactlyDistinctPrimePair':True,
    'kummerCrtGenuineEulerResponse': '(logDeriv zeta)^2-zetaPrimeDiagonalResponse',
    'kummerCrtActualZeroDoubleSource': 'm_rho^2 at every actual zero with Re>1/2',
    'kummerCrtPoleCenteringAnalyticGerm':True,
    'kummerCrtCenteredActualZeroSource': '(rho-1)^2*m_rho^2, nonzero at every multiplicity',
    'kummerCrtWholeCompletePeriodJoinSurvivesArbitraryWeightControls':True,
    'kummerCrtFreeUnrestrictedWeightsHaveNoUniformAllowance':True,
    'kummerCrtActualSignedPrimeEstimateDischarged':False,
    'kummerCrtLiteralIncompletePeriodBoundaryCompletedOrPaid':False,
    'kummerCrtControlArraysClaimedToObeyActualGammaConstraints':False,
    'kummerCrtNoGoScope': 'complete common-period/free-code bookkeeping; source and density pass but no additional collective signed constraint survives CRT joining; literal incomplete-period/order boundaries and actual Gamma/Mobius matrix information remain unpaid',
})
old='source-sensitive signed distinct-prime-column estimate using complete unaltered actual Gamma data; the unit-prime Euler control has all proper powers, full PNT at every integer endpoint and bounded correlated matrix agreement at bulk density scales, yet a coherent full source; it still fails actual complete Gamma data'
new='source-sensitive signed distinct-prime-column estimate using complete unaltered actual Gamma/Mobius data and literal incomplete-period CRT/order boundaries; complete common-period Kummer/CRT bookkeeping is free even for nonseparable residue codes; the unit-prime Euler control has all proper powers, full PNT and bounded correlated matrix agreement at bulk density scales, yet a coherent full source and still fails actual complete Gamma data'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid']=[new if x==old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit,indent=2)+'\n')
carry_path=root/'docs/suzuki-carry-exceptional-audit.json'
carry=json.loads(carry_path.read_text())
for source,pin in carry['sources'].items():
    assert digest(source)==pin or source=='AGENTS.md',source
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; scoped distinct-prime Kummer/CRT complete-period audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print(json.dumps({
    'modules':v['modules'],'theoremsIncludingPrivateHelpers':v['theoremsIncludingPrivateHelpers'],
    'declarations':v['declarations'],'namespaceLinterRuns':v['namespaceLinterRuns'],
    'sourcePins':len(audit['sources']),'reportSha256':v['reportSha256'],
    'logSha256':v['logSha256'],'rhEndpointDischarged':audit['rhEndpointDischarged'],
},indent=2))
