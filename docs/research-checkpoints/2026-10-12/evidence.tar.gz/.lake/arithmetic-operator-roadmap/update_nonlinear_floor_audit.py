from pathlib import Path
import json, hashlib, re
root=Path('.')
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
audit_path=Path('docs/arithmetic-operator-audit.json')
audit=json.loads(audit_path.read_text())
report_path=Path('.lake/arithmetic-operator-roadmap/axioms.json')
log_path=Path('.lake/arithmetic-operator-roadmap/validation.log')
report=json.loads(report_path.read_text())
log=log_path.read_text()
assert len(report['modules'])==84
assert log.count('-- All linting checks passed!')==84
assert not re.search(r'error:|warning:|Found [1-9][0-9]* errors',log)
assert all(m['onlyStandardAxioms'] and m['namespaceLinters']==14 for m in report['modules'])
new=['RiemannGaussian/ArithmeticOperatorNonlinearFloorAudit.lean',
     'RiemannGaussian/ArithmeticOperatorPolynomialFloorInverseAudit.lean']
assert [m['module'] for m in report['modules'][-2:]]==[
    'RiemannGaussian.ArithmeticOperatorNonlinearFloorAudit',
    'RiemannGaussian.ArithmeticOperatorPolynomialFloorInverseAudit']
allowed_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
                 'scripts/CheckArithmeticOperatorRoadmap.lean'}
for f,h in audit['sources'].items():
    assert f in allowed_changes or digest(f)==h, ('Unexpected prior source change',f)
for f in list(audit['sources'])+new:
    audit['sources'][f]=digest(f)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
v=audit['validation']
v.update(modules=len(report['modules']),
         theoremsIncludingPrivateHelpers=sum(m['theoremsIncludingPrivateHelpers'] for m in report['modules']),
         declarations=sum(m['declarations'] for m in report['modules']),
         namespaceLinterRuns=sum(m['namespaceLinters'] for m in report['modules']),
         reportSha256=digest(report_path),logSha256=digest(log_path),moduleReports=report['modules'])
v['latestLeafBuilds'] = [
    {'module':'RiemannGaussian.ArithmeticOperatorNonlinearFloorAudit',
     'command':'lake --wfail build RiemannGaussian.ArithmeticOperatorNonlinearFloorAudit RiemannGaussian.ArithmeticOperatorPolynomialFloorInverseAudit',
     'exitCode':0,'log':'.lake/arithmetic-operator-roadmap/nonlinear-floor-final-build.log',
     'logSha256':digest('.lake/arithmetic-operator-roadmap/nonlinear-floor-final-build.log')},
    {'module':'RiemannGaussian.ArithmeticOperatorPolynomialFloorInverseAudit',
     'command':'lake --wfail build RiemannGaussian.ArithmeticOperatorNonlinearFloorAudit RiemannGaussian.ArithmeticOperatorPolynomialFloorInverseAudit',
     'exitCode':0,'log':'.lake/arithmetic-operator-roadmap/nonlinear-floor-final-build.log',
     'logSha256':digest('.lake/arithmetic-operator-roadmap/nonlinear-floor-final-build.log')}
]
for leaf in v['latestLeafBuilds']:
    buildlog=Path(leaf['log']).read_text()
    assert 'Build completed successfully' in buildlog
    assert not re.search(r'error:|warning:',buildlog)
audit['scope'].update({
    'nonlinearFloorNativeRowIsExactNegativeRemainderAtEveryIntegerEndpoint':True,
    'nonlinearFloorPhysicalLogRowBridgeRetainsEveryRealCutoff':True,
    'nonlinearFloorEveryFixedCommonPeriodShiftedRowFunctionalIsOnePeriodicCode':True,
    'nonlinearFloorEveryFinitePositiveIntegerScaleFamilyHasCommonPeriod':True,
    'nonlinearFloorEveryPeriodicCodeIsOneRowPolynomialOfDegreeLessThanPeriod':True,
    'nonlinearFloorDirectCompleteActualGammaEvaluationKillsEveryActualZeroResidue':True,
    'nonlinearFloorDensityMeanCenteringRestoresLostSource':False,
    'polynomialFloorInverseActualGammaAndMobiusFibersAndFullPhaseRetained':True,
    'polynomialFloorInverseEveryNonunitDecodedPrefixRealizable':True,
    'polynomialFloorInverseArbitraryCoefficientOrDegreeBudgetClaimed':False,
    'polynomialFloorInverseAllCodeJoinedNormBoundIffWholeKernelZero':True,
    'polynomialFloorInverseAllCodePsdIffOrdinaryFreeVectorPsd':True,
    'polynomialFloorInverseUniformPaymentFailsBeyondEveryHead':True,
    'polynomialFloorInverseDegreeOneParityRetainsEveryActualMultiplicityAndCancelsPole':True,
    'polynomialFloorInverseParityIsOldActualMangoldtDyadicSumWithExactHead':True,
    'polynomialFloorInverseConvergentEulerIdentityOutsideReGtOneClaimed':False,
    'polynomialFloorInverseNativeCutoffSourceAsymptoticClaimed':False,
    'polynomialFloorInverseArbitraryDecodedProfilesAssertedActualMangoldtOrGammaCompatible':False,
    'nonlinearFloorFreeSmoothGeneralizedControlsGrantedActualGammaData':False,
    'nonlinearFloorMovingPeriodsWithBudgetsOrNoncommensurateRealScaleProductsExhausted':False,
    'nonlinearFloorIndependentSignedEstimateOrRhEndpointDischarged':False,
    'nonlinearFloorNoGoScope':'Every FIXED common-period nonlinear functional of native shifted integer quotient rows is exactly one periodic code, and direct complete actual Gamma evaluation annihilates every zero residue. Coding before actual Mobius inversion can preserve source and cancel density but unrestricted one-row polynomials realize ALL nonunit decoded prefixes; all-code bound/PSD reduces to the whole-zero kernel/free-vector criterion. Prescribed quantitative budgets, moving periods with actual estimates, noncommensurate real-scale products, ordered multipoint geometry and genuinely coupled prime columns remain open.'
})
assert audit['scope']['tier1FamiliesExhaustivelyClosed']==0
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
audit_path.write_text(json.dumps(audit,indent=2)+'\n')
carry_path=Path('docs/suzuki-carry-exceptional-audit.json')
carry=json.loads(carry_path.read_text())
for f,h in carry['sources'].items():
    if f!='AGENTS.md': assert digest(f)==h, ('Changed historical carry pin',f)
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; policy additionally records the exact fixed nonlinear integer-quotient/periodic-code alphabet and all-prefix polynomial Gamma/Mobius inverse collapse, with source/pole gates and beyond-every-head scope. Historical carry proof validation and all other source pins unchanged.'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print('Pinned',len(audit['sources']),'operator sources;',v['modules'],'modules;',v['theoremsIncludingPrivateHelpers'],'theorems;',v['declarations'],'declarations;',v['namespaceLinterRuns'],'linter runs.')
print('Historical carry pins preserved:',len(carry['sources'])-1)
print('Report SHA:',v['reportSha256'])
print('Log SHA:',v['logSha256'])
