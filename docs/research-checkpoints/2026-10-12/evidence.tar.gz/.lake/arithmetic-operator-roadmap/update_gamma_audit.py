from pathlib import Path
import json, hashlib, re
root=Path('.')
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
audit_path=Path('docs/arithmetic-operator-audit.json')
audit=json.loads(audit_path.read_text())
report_path=Path('.lake/arithmetic-operator-roadmap/axioms.json')
log_path=Path('.lake/arithmetic-operator-roadmap/validation.log')
report=json.loads(report_path.read_text())
log=log_path.read_text()
assert len(report['modules'])==82
assert log.count('-- All linting checks passed!')==82
assert not re.search(r'error:|warning:|Found [1-9][0-9]* errors',log)
assert all(m['onlyStandardAxioms'] and m['namespaceLinters']==14 for m in report['modules'])
new=['RiemannGaussian/ArithmeticOperatorFiniteGammaControl.lean',
     'RiemannGaussian/ArithmeticOperatorGammaToleranceAudit.lean']
assert [m['module'] for m in report['modules'][-2:]]==[
    'RiemannGaussian.ArithmeticOperatorFiniteGammaControl',
    'RiemannGaussian.ArithmeticOperatorGammaToleranceAudit']
allowed_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
                 'scripts/CheckArithmeticOperatorRoadmap.lean'}
for f,h in audit['sources'].items():
    assert f in allowed_changes or digest(f)==h, ('Unexpected prior source change',f)
for f in list(audit['sources'])+new:
    audit['sources'][f]=digest(f)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
v=audit['validation']
v.update(modules=len(report['modules']),
         theoremsIncludingPrivateHelpers=sum(m['theoremsIncludingPrivateHelpers'] for m in report['modules']),
         declarations=sum(m['declarations'] for m in report['modules']),
         namespaceLinterRuns=sum(m['namespaceLinters'] for m in report['modules']),
         reportSha256=digest(report_path),logSha256=digest(log_path),moduleReports=report['modules'])
audit['scope'].update({
    'finiteGammaRestoresAllPrimeTowersOfEveryChosenHead':True,
    'finiteGammaActualMangoldtAndAllGammaPrefixesThroughHeadMatchedExactly':True,
    'finiteGammaArbitraryNonlinearOrPhasedPrefixObservationsMatched':True,
    'finiteGammaRepairOrdinaryCorrectionIsExactFiniteHead':True,
    'finiteGammaRepairProperPowerCorrectionIndependentlyPaid':True,
    'finiteGammaGenuineUnitOrdinaryPrimeEulerProductRetainedOnReGtOne':True,
    'finiteGammaPntDensityOneAtAllIntegerCutoffsAndFullSourceMinusTwoRetained':True,
    'finiteGammaEveryFixedRepairStillDeletesPrimesBeyondEveryHead':True,
    'gammaToleranceCompleteInverseWeightedDeletionSummable':True,
    'gammaToleranceEveryActualProperPowerAndDyadicEndpointRetained':True,
    'gammaToleranceExactAllCutoffDeficitUpper':'X*tailMass(B), tailMass(B)->0',
    'gammaToleranceForEveryFiniteHeadAndEveryPositiveEpsilon':'exists one fixed repaired unit-prime control with exact head matching, deficit in [0,epsilon*X] at ALL integer cutoffs X, full campaign factorial source -2 and PNT density one',
    'gammaToleranceEveryFixedRepairHasPositiveLinearDeficitOnAnyCofinalScales':True,
    'gammaToleranceOneControlMatchesAllHeadsOrAllEpsilons':False,
    'gammaToleranceCofinalSublinearPositiveConeRigidityRefuted':False,
    'gammaToleranceActualAllScaleExactGammaOrSignedConstraintsRefuted':False,
    'gammaToleranceHypotheticalZeroOrFloatingProofInputRequired':False,
    'gammaToleranceSelectedEulerContinuationBeyondReGtOneClaimed':False,
    'gammaToleranceIndependentActualPrimeSignedEstimateOrRhEndpointDischarged':False,
    'gammaToleranceNoGoScope':'finite exact prime/Gamma calibration plus arbitrarily small FIXED relative Gamma tolerance, even uniformly at ALL cutoffs, retains a coherent unit-prime countermodel. Exact complete/all-scale signed Gamma or genuinely source-sensitive distinct-prime constraints remain separate; each fixed repair has positive linear deficit and is NOT actual Mangoldt or a cofinal o(X) counterexample.'
})
assert audit['scope']['tier1FamiliesExhaustivelyClosed']==0
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
audit_path.write_text(json.dumps(audit,indent=2)+'\n')
carry_path=Path('docs/suzuki-carry-exceptional-audit.json')
carry=json.loads(carry_path.read_text())
for f,h in carry['sources'].items():
    if f!='AGENTS.md': assert digest(f)==h, ('Changed historical carry pin',f)
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; policy additionally records exact finite prime/Gamma head repair and the arbitrarily small uniform fixed-relative-Gamma-tolerance countermodel. Historical carry proof validation and all other source pins unchanged.'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print('Pinned',len(audit['sources']),'operator sources;',v['modules'],'modules;',v['theoremsIncludingPrivateHelpers'],'theorems;',v['declarations'],'declarations;',v['namespaceLinterRuns'],'linter runs.')
print('Historical carry pins preserved:',len(carry['sources'])-1)
print('Report SHA:',v['reportSha256'])
print('Log SHA:',v['logSha256'])
