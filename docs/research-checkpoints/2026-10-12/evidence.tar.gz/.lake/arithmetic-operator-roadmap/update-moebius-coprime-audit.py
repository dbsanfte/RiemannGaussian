from pathlib import Path
import hashlib
import json

root = Path.cwd()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

path = root / 'docs/arithmetic-operator-audit.json'
audit = json.loads(path.read_text())
report_path = root / '.lake/arithmetic-operator-roadmap/axioms.json'
report = json.loads(report_path.read_text())
modules = report['modules']
assert len(modules) == 63
assert modules[-1]['module'].endswith('ArithmeticOperatorMoebiusCoprimeAudit')
assert all(m['onlyStandardAxioms'] for m in modules)
log_path = root / '.lake/arithmetic-operator-roadmap/validation.log'
log = log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters') == 63
assert 'Checked RiemannGaussian.ArithmeticOperatorMoebiusCoprimeAudit:' in log
expected_changes = {'AGENTS.md', 'docs/arithmetic-operator-research.md',
                    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source, pin in audit['sources'].items():
    assert digest(source) == pin or source in expected_changes, source
audit['sources']['RiemannGaussian/ArithmeticOperatorMoebiusCoprimeAudit.lean'] = digest(
    'RiemannGaussian/ArithmeticOperatorMoebiusCoprimeAudit.lean')
for source in audit['sources']:
    audit['sources'][source] = digest(source)
assert digest(audit['externalRoadmap']['path']) == audit['externalRoadmap']['sha256']
audit['date'] = '2026-10-07'
v = audit['validation']
v.update({
    'focusedCommand': 'lake env lean --error=warning scripts/CheckArithmeticOperatorRoadmap.lean',
    'modules': len(modules),
    'theoremsIncludingPrivateHelpers': sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations': sum(m['declarations'] for m in modules),
    'namespaceLinterRuns': sum(m['namespaceLinters'] for m in modules),
    'reportSha256': digest(report_path), 'logSha256': digest(log_path),
    'moduleReports': modules,
})
audit['scope'].update({
    'actualMoebiusCoprimeNativeFloorSquarePlusFloorExact': True,
    'actualMoebiusCoprimeNativeShellConvolutionExact': True,
    'actualMoebiusCoprimeEveryIntegerRowEndpointAndFullPhaseRetained': True,
    'actualMoebiusCoprimeGenuineEulerResponse': '2*zeta(z-iy-1)/zeta(z)',
    'actualMoebiusCoprimeMatchedNumeratorNonzeroProved': True,
    'actualMoebiusCoprimeAllActualAnalyticMultiplicitiesPreserved': True,
    'actualMoebiusCoprimeDensityPoleRemovableAfterExactTransformCentering': True,
    'actualMoebiusCoprimeCompleteObservationsUniquelyForceActualMu': True,
    'actualMoebiusCoprimeFreeColumnsClaimedActualSmoothOrGeneralizedPrimeData': False,
    'actualMoebiusCoprimeFreeColumnScalarCollapseAndZeroKernelCriterion': True,
    'actualMoebiusCoprimeAugmentedMatrixExactlyMatchesNativeDiagonalCredit': True,
    'actualMoebiusCoprimeNegativeLiteralPrimeQuadraticAtEveryFixedNonzeroHeightBeyondEveryHead': True,
    'actualMoebiusCoprimeNegativeQuadraticMargin': '-3/2',
    'actualMoebiusCoprimePrimeWindowUsedOnlyToLocateCounterexampleRows': True,
    'actualMoebiusCoprimeGaussianOrRestrictedSignedEstimateRefuted': False,
    'actualMoebiusCoprimeNativeCutoffAsymptoticProved': False,
    'actualMoebiusCoprimeIndependentSignedArithmeticBoundProved': False,
    'actualMoebiusCoprimeNoGoScope': 'unrestricted phased actual-Moebius coprimality PSD including the native added diagonal credit; no finite head deletion cures it at any fixed nonzero height; restricted signed packets, different Gaussian couplings and unaltered actual Gamma/Mobius source-sensitive estimates remain open',
})
old = 'exact same-label prime-power GCD diagonal and coprime distinct-prime CRT/order kernels; bounded nonseparable coprime contrasts add only source-small same-base cross terms'
new = old + '; actual Moebius coprimality uniquely constrains the weights and retains every zero source, but its unrestricted phased PSD including exact diagonal credit fails beyond every head; a specially constrained signed estimate is still new arithmetic input'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid'] = [new if x == old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit, indent=2) + '\n')
carry_path = root / 'docs/suzuki-carry-exceptional-audit.json'
carry = json.loads(carry_path.read_text())
for source, pin in carry['sources'].items():
    assert digest(source) == pin or source == 'AGENTS.md', source
carry['sources']['AGENTS.md'] = digest('AGENTS.md')
carry['policyPinUpdated'] = '2026-10-07; scoped actual-Moebius coprimality PSD audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry, indent=2) + '\n')
print(json.dumps({
    'modules': v['modules'], 'theoremsIncludingPrivateHelpers': v['theoremsIncludingPrivateHelpers'],
    'declarations': v['declarations'], 'namespaceLinterRuns': v['namespaceLinterRuns'],
    'sourcePins': len(audit['sources']), 'reportSha256': v['reportSha256'],
    'logSha256': v['logSha256'], 'rhEndpointDischarged': audit['rhEndpointDischarged'],
}, indent=2))
