from pathlib import Path
import hashlib
import json

root=Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

path=root/'docs/arithmetic-operator-audit.json'
audit=json.loads(path.read_text())
report_path=root/'.lake/arithmetic-operator-roadmap/axioms.json'
report=json.loads(report_path.read_text())
modules=report['modules']
assert len(modules)==56
assert all(m['onlyStandardAxioms'] for m in modules)
assert modules[-2]['module'].endswith('ArithmeticOperatorPeriodicGammaAudit')
assert modules[-1]['module'].endswith('ArithmeticOperatorPeriodicInverseAudit')
log_path=root/'.lake/arithmetic-operator-roadmap/validation.log'
log=log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters')==56
assert 'Checked RiemannGaussian.ArithmeticOperatorPeriodicInverseAudit:' in log

expected_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source,pin in audit['sources'].items():
    assert digest(source)==pin or source in expected_changes, source
for source in ['RiemannGaussian/ArithmeticOperatorPeriodicGammaAudit.lean',
    'RiemannGaussian/ArithmeticOperatorPeriodicInverseAudit.lean',
    'RiemannGaussian/ZetaFiniteDirichlet.lean']:
    audit['sources'][source]=digest(source)
for source in audit['sources']:
    audit['sources'][source]=digest(source)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
audit['date']='2026-10-07'
validation=audit['validation']
validation.update({
    'modules':len(modules),
    'theoremsIncludingPrivateHelpers':sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations':sum(m['declarations'] for m in modules),
    'namespaceLinterRuns':sum(m['namespaceLinters'] for m in modules),
    'reportSha256':digest(report_path),'logSha256':digest(log_path),
    'moduleReports':modules,
})
audit['scope'].update({
    'arbitraryFixedPeriodicWholeLabelGammaCodeExactJoin':True,
    'periodicWholeLabelGammaCodesNeedNotBeMultiplicative':True,
    'periodicWholeLabelGammaEulerResponse':"-L_Phi'(s+i*y), genuine Euler domain",
    'periodicWholeLabelGammaActualZeroResidue': 'zero at every actual nontrivial zero and every multiplicity',
    'periodicWholeLabelGammaFiniteAnalyticCodeFamiliesSourceBlind':True,
    'periodicWholeLabelGammaZeroMeanDensityResidueZero':True,
    'periodicPrimePhaseOnlyCommutatorEstimated':False,
    'periodicCodingBeforeActualMobiusInverseRetainsAllPhasesAndProperPowers':True,
    'periodTwoGammaInverseExactCoefficient': '2*1[2|n]*Lambda(n/2)-Lambda(n)+2*log(2)*1[n=2]',
    'periodTwoGammaInverseActualZeroResidue': '-m_rho*(2*2^(-rho)-1), nonzero at every multiplicity',
    'periodTwoGammaInverseDensityResidueZero':True,
    'zeroMeanPeriodXPlusTwoCodesRealizeEveryFiniteDecodedProfileWithZeroUnit':True,
    'periodicInverseFreeCodeQuadraticExactlyOrdinaryMatrixPSD':True,
    'periodicInverseUnrestrictedCodesHaveNoUniformAllowanceAtFirstNonunit':True,
    'periodicInverseAuditUsesUnalteredActualGammaRowsAndMobiusCoefficients':True,
    'periodicDecodedOutputsClaimedToSatisfyActualGammaEqualities':False,
    'periodicInverseArithmeticEstimateDischarged':False,
    'periodicInverseNoGoScope': 'unrestricted growing-modulus/amplitude code bookkeeping only; constrained fixed codes, controlled amplitudes, correlated literal masks and actual signed prime estimates remain unpaid',
})
audit['scope']['unpaid'].insert(0,
    'constrained periodic code or correlated-mask estimate after actual Gamma/Mobius inversion; direct fixed-periodic complete rows lose the source, while unrestricted zero-mean codes prescribe arbitrary finite outputs')
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
path.write_text(json.dumps(audit,indent=2)+'\n')

carry_path=root/'docs/suzuki-carry-exceptional-audit.json'
carry=json.loads(carry_path.read_text())
for source,pin in carry['sources'].items():
    assert digest(source)==pin or source=='AGENTS.md', source
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; scoped periodic Gamma/inverse audits appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print(json.dumps({
    'modules':validation['modules'],
    'theoremsIncludingPrivateHelpers':validation['theoremsIncludingPrivateHelpers'],
    'declarations':validation['declarations'],
    'namespaceLinterRuns':validation['namespaceLinterRuns'],
    'sourcePins':len(audit['sources']),
    'reportSha256':validation['reportSha256'],
    'logSha256':validation['logSha256'],
    'rhEndpointDischarged':audit['rhEndpointDischarged'],
},indent=2))
