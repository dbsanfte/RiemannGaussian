import RiemannGaussian.ArithmeticOperatorFloorSourceAudit
open MeasureTheory Set
#check integral_sub_left_eq_self
#check integral_neg_eq_self
#check integral_add_right_eq_self
#check integral_sub_right_eq_self
#check MeasureTheory.Integrable.comp_sub_left
#check MeasureTheory.Integrable.comp_neg
#check RCLike.re_to_complex
#check MeasureTheory.Integrable.ofReal
#check integral_complex_ofReal
#check measurable_exp
#check Real.measurable_exp
#check Real.volume_Ioo
