from pathlib import Path
import hashlib
import json

root=Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
path=root/'docs/arithmetic-operator-audit.json'
audit=json.loads(path.read_text())
report_path=root/'.lake/arithmetic-operator-roadmap/axioms.json'
report=json.loads(report_path.read_text())
modules=report['modules']
assert len(modules)==61
assert modules[-1]['module'].endswith('ArithmeticOperatorCofactorLagAudit')
assert all(m['onlyStandardAxioms'] for m in modules)
log_path=root/'.lake/arithmetic-operator-roadmap/validation.log'
log=log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters')==61
assert 'Checked RiemannGaussian.ArithmeticOperatorCofactorLagAudit:' in log
expected_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source,pin in audit['sources'].items():
    assert digest(source)==pin or source in expected_changes,source
for source in ('RiemannGaussian/ArithmeticOperatorCofactorLagAudit.lean',):
    audit['sources'][source]=digest(source)
for source in audit['sources']:
    audit['sources'][source]=digest(source)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
audit['date']='2026-10-07'
v=audit['validation']
v.update({
    'modules':len(modules),
    'theoremsIncludingPrivateHelpers':sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations':sum(m['declarations'] for m in modules),
    'namespaceLinterRuns':sum(m['namespaceLinters'] for m in modules),
    'reportSha256':digest(report_path),'logSha256':digest(log_path),
    'moduleReports':modules,
})
audit['scope'].update({
    'actualSecondCofactorLagPhaseExactNextMultiple':True,
    'actualSecondCofactorLagOriginalCutoffsQuotientsAndZeroLagRetained':True,
    'actualSecondCofactorLagEveryChosenProperPrimePowerRetained':True,
    'actualSecondCofactorLagSecondSupportFixedFinite':True,
    'actualSecondCofactorLagErrorPointwiseBound':'2*abs(b)*sum_(e in E)(e*Lambda(e))*log(n)/n',
    'actualSecondCofactorLagErrorNativeCutoffBound':'2*abs(b)*sum_(e in E)(e*Lambda(e))*log(X)*(1+log(X))',
    'actualSecondCofactorLagErrorSourceSmallAtEveryPositiveDyadicExponent':True,
    'actualSecondCofactorLagErrorGenuineSeriesAnalyticOnPositiveHalfPlane':True,
    'actualSecondCofactorLagGenuineEulerResponseProved':True,
    'actualSecondCofactorLagActualZeroResidue':'-mass(E)*m_rho*zeta(Re rho), any second height, no exposure or simplicity',
    'actualSecondCofactorLagSourceNonzeroWhenSecondMassNonzero':True,
    'actualSecondCofactorLagDensityCodeExactButDiagnostic':True,
    'actualSecondCofactorLagNativeCutoffAsymptoticClaimedFromDensityCode':False,
    'actualSecondCofactorLagFirstCommutatorIndependentlyBounded':False,
    'actualSecondCofactorLagFreeFirstColumnScalarCollapse':True,
    'actualSecondCofactorLagFreeControlsClaimedActualGammaOrGeneralizedEuler':False,
    'actualSecondCofactorLagOldCrtBoundaryCompletedOrNormPaid':False,
    'actualSecondCofactorLagNoGoScope':'fixed finite second Mangoldt columns, complete lag periods and cofactor-phase-only coupling; exact native old signed commutator plus analytic/source-small correction; growing supports, incomplete lags and genuinely nonseparable actual Gamma/Mobius constraints remain open',
})
old='source-sensitive signed distinct-prime-column estimate using complete unaltered actual Gamma/Mobius data, nonconstant correlated lag codes, actual second-row cofactor phase and literal incomplete-period CRT/order boundaries; complete common-period Kummer/CRT bookkeeping is free, and complete flat-lag averaging conserves the first packet or annihilates every source after literal centering; the unit-prime Euler control retains a coherent source while still failing actual complete Gamma data'
new='source-sensitive signed distinct-prime-column estimate using unaltered actual Gamma/Mobius data, nonconstant/nonseparable correlated lag codes, growing second supports or incomplete-period CRT/order boundaries; complete CRT bookkeeping is free, flat lags conserve or annihilate the first source, and fixed finite actual second-cofactor phase adds only a source-small analytic correction to the old unpaid commutator; unit-prime controls still fail actual Gamma data'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid']=[new if x==old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit,indent=2)+'\n')
carry_path=root/'docs/suzuki-carry-exceptional-audit.json'
carry=json.loads(carry_path.read_text())
for source,pin in carry['sources'].items():
    assert digest(source)==pin or source=='AGENTS.md',source
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; scoped fixed second-cofactor lag-phase audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print(json.dumps({
    'modules':v['modules'],'theoremsIncludingPrivateHelpers':v['theoremsIncludingPrivateHelpers'],
    'declarations':v['declarations'],'namespaceLinterRuns':v['namespaceLinterRuns'],
    'sourcePins':len(audit['sources']),'reportSha256':v['reportSha256'],
    'logSha256':v['logSha256'],'rhEndpointDischarged':audit['rhEndpointDischarged'],
},indent=2))
