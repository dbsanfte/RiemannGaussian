from pathlib import Path
import hashlib
import json

root = Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

audit_path = root / 'docs/arithmetic-operator-audit.json'
audit = json.loads(audit_path.read_text())
report_path = root / '.lake/arithmetic-operator-roadmap/axioms.json'
report = json.loads(report_path.read_text())
modules = report['modules']
assert len(modules) == 54
assert all(m['onlyStandardAxioms'] for m in modules)
assert modules[-2]['module'].endswith('ArithmeticOperatorSelbergControlAudit')
assert modules[-1]['module'].endswith('ArithmeticOperatorSelbergSourceAudit')
log_path = root / '.lake/arithmetic-operator-roadmap/validation.log'
log = log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters') == 54
assert 'Checked RiemannGaussian.ArithmeticOperatorSelbergSourceAudit:' in log

for path in [
    'RiemannGaussian/ArithmeticOperatorSelbergControlAudit.lean',
    'RiemannGaussian/ArithmeticOperatorSelbergSourceAudit.lean',
    'RiemannGaussian/SuzukiLogarithmicConvolution.lean',
    'RiemannGaussian/SuzukiConvolutionSource.lean',
    'RiemannGaussian/ZetaPrimeQuadraticArithmetic.lean',
    'RiemannGaussian/ZetaExposedPrimeFilter.lean',
    'RiemannGaussian/ZetaSignedPoleControl.lean',
    'RiemannGaussian/HarmonicProductContinuity.lean',
]:
    audit['sources'][path] = digest(path)
for path in audit['sources']:
    audit['sources'][path] = digest(path)

validation = audit['validation']
validation.update({
    'modules': len(modules),
    'theoremsIncludingPrivateHelpers': sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations': sum(m['declarations'] for m in modules),
    'namespaceLinterRuns': sum(m['namespaceLinters'] for m in modules),
    'reportSha256': digest(report_path),
    'logSha256': digest(log_path),
    'moduleReports': modules,
})
audit['scope'].update({
    'completeSelbergConvolutionCommutesWithMultiplicativeSelection': True,
    'selbergControlIdentityRetainsArbitraryCorrelatedIncidenceMasks': True,
    'selbergControlIdentityRetainsActualProperPowersAndDiagonal': True,
    'actualSignedSelbergMinusWordEulerResponse': "(logDeriv zeta)' - (logDeriv zeta)^2, Re(s)>1",
    'actualSignedSelbergMinusWordZeroSource': '-m-m^2, every actual analytic multiplicity; no exposure needed for local limit',
    'signedSelbergPoleClearingAnalyticAtOne': True,
    'signedSelbergPoleClearingRetainsActualZeroSource': '(rho-1)*(-m-m^2), nonzero',
    'completeSelbergMomentIdentityIsGenuinelyConvergentOnEulerDomain': True,
    'completeSelbergFactorialConvolutionRetainsAllEndpointOrders': True,
    'completeSignedSelbergTraceSourceLawForAnyConvergentArray': 'ell-ell^2',
    'signedSelbergPureGeometricDensityCancelsExactly': True,
    'binaryUnitControlSignedSelbergTraceSource': '-6 at u=10001/20000, y=54',
    'binaryUnitControlPoleCenteredSelbergTraceNondecaying': True,
    'binaryUnitControlPositiveSelbergCoefficientCompatible': True,
    'binaryUnitControlUnalteredActualMobiusConstraintFailsAtDeletedPrime': True,
    'signedSelbergAuditProvidesIndependentActualPrimeBound': False,
    'completeSelbergWordHasBeenTransferredThroughNativePhysicalMasks': False,
    'completeSelbergNoGoScope': 'support/positivity/complete-convolution-only constraints; actual unaltered Mobius/Gamma data, constrained masked nonlinear source and signed CRT boundaries are not estimated',
})
audit['scope']['unpaid'].insert(0,
    'independent signed estimate using the UNALTERED actual Mobius log-square/Gamma constraint together with separate-prime convolution/cutoff geometry; coherent unit-prime control passes free Selberg positivity and incidence identities but explicitly fails that actual constraint')
audit_path.write_text(json.dumps(audit, indent=2) + '\n')

carry_path = root / 'docs/suzuki-carry-exceptional-audit.json'
carry = json.loads(carry_path.read_text())
carry['sources']['AGENTS.md'] = digest('AGENTS.md')
carry['policyPinUpdated'] = '2026-10-06; Selberg control/source scope appended; historical carry validation unchanged'
carry_path.write_text(json.dumps(carry, indent=2) + '\n')

print(json.dumps({
    'modules': validation['modules'],
    'theoremsIncludingPrivateHelpers': validation['theoremsIncludingPrivateHelpers'],
    'declarations': validation['declarations'],
    'namespaceLinterRuns': validation['namespaceLinterRuns'],
    'sourcePins': len(audit['sources']),
    'reportSha256': validation['reportSha256'],
    'logSha256': validation['logSha256'],
    'rhEndpointDischarged': audit['rhEndpointDischarged'],
}, indent=2))
