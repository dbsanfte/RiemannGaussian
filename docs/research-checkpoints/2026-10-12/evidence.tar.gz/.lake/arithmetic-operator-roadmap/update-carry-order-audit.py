from pathlib import Path
import hashlib
import json

root=Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

path=root/'docs/arithmetic-operator-audit.json'
audit=json.loads(path.read_text())
report_path=root/'.lake/arithmetic-operator-roadmap/axioms.json'
report=json.loads(report_path.read_text())
modules=report['modules']
assert len(modules)==57
assert all(m['onlyStandardAxioms'] for m in modules)
assert modules[-1]['module'].endswith('ArithmeticOperatorCarryOrderAudit')
log_path=root/'.lake/arithmetic-operator-roadmap/validation.log'
log=log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters')==57
assert 'Checked RiemannGaussian.ArithmeticOperatorCarryOrderAudit:' in log

expected_changes={'AGENTS.md','docs/arithmetic-operator-research.md',
    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source,pin in audit['sources'].items():
    assert digest(source)==pin or source in expected_changes, source
source='RiemannGaussian/ArithmeticOperatorCarryOrderAudit.lean'
audit['sources'][source]=digest(source)
for source in audit['sources']:
    audit['sources'][source]=digest(source)
assert digest(audit['externalRoadmap']['path'])==audit['externalRoadmap']['sha256']
audit['date']='2026-10-07'
validation=audit['validation']
validation.update({
    'modules':len(modules),
    'theoremsIncludingPrivateHelpers':sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations':sum(m['declarations'] for m in modules),
    'namespaceLinterRuns':sum(m['namespaceLinters'] for m in modules),
    'reportSha256':digest(report_path),'logSha256':digest(log_path),
    'moduleReports':modules,
})
audit['scope'].update({
    'correlatedCarryOrderTupleExactFullFirstHigherSplit':True,
    'carryOrderPhaseUsesEverySeparatePrimePower':True,
    'carryOrderCodeNeedNotFactorBetweenRows':True,
    'carryOrderExtraSupportSquareRoot':True,
    'carryOrderUnitBoundedExtraNorm': '2^J*(2J)^(D+1)*log(2)',
    'carryOrderFixedRowsFullSourceIffFirstSource':True,
    'carryOrderGrowingRowsBudget': '(2J)^D<=exp(J/4), eventually for convergence',
    'carryOrderGrowingRowsCampaignNormalizedBound': '2*log(2)*J*(3/4)^J',
    'carryOrderCenteredFirstTupleKillsNonzeroCampaignSource':True,
    'carryOrderFirstPacketIndependentlyEstimated':False,
    'carryOrderAllGrowingComplexityOrAmplitudePaid':False,
    'carryOrderDistinctPrimeColumnsPaid':False,
    'carryOrderNoGoScope': 'additional bounded same-prime order-tuple channel; fixed rows or explicit growing complexity budget only; signed first-carry packet and constrained actual Gamma/common-GCD/distinct-prime input remain unpaid',
})
old='signed Kummer/common-GCD and consecutive-balanced threshold prime sums using unaltered actual Gamma constraints; distinct-prime products, growing row complexity or phases inside separate carry orders beyond the fixed same-prime scalar-collapse/source audit'
new='signed Kummer/first-carry/common-GCD and consecutive-balanced threshold prime sums using unaltered actual Gamma constraints; distinct-prime products, larger growing row complexity or unbounded order-code amplitudes beyond the bounded same-prime tuple audit with complexity at most exp(J/4)'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid']=[new if x==old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit,indent=2)+'\n')

carry_path=root/'docs/suzuki-carry-exceptional-audit.json'
carry=json.loads(carry_path.read_text())
for source,pin in carry['sources'].items():
    assert digest(source)==pin or source=='AGENTS.md', source
carry['sources']['AGENTS.md']=digest('AGENTS.md')
carry['policyPinUpdated']='2026-10-07; scoped correlated carry-order audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print(json.dumps({
    'modules':validation['modules'],
    'theoremsIncludingPrivateHelpers':validation['theoremsIncludingPrivateHelpers'],
    'declarations':validation['declarations'],
    'namespaceLinterRuns':validation['namespaceLinterRuns'],
    'sourcePins':len(audit['sources']),
    'reportSha256':validation['reportSha256'],
    'logSha256':validation['logSha256'],
    'rhEndpointDischarged':audit['rhEndpointDischarged'],
},indent=2))
