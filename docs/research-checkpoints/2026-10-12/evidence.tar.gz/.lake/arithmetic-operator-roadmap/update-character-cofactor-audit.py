from pathlib import Path
import hashlib
import json

root = Path.cwd()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


path = root / 'docs/arithmetic-operator-audit.json'
audit = json.loads(path.read_text())
report_path = root / '.lake/arithmetic-operator-roadmap/axioms.json'
report = json.loads(report_path.read_text())
modules = report['modules']
assert len(modules) == 62
assert modules[-1]['module'].endswith('ArithmeticOperatorCharacterCofactorAudit')
assert all(m['onlyStandardAxioms'] for m in modules)
log_path = root / '.lake/arithmetic-operator-roadmap/validation.log'
log = log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters') == 62
assert 'Checked RiemannGaussian.ArithmeticOperatorCharacterCofactorAudit:' in log
expected_changes = {'AGENTS.md', 'docs/arithmetic-operator-research.md',
                    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source, pin in audit['sources'].items():
    assert digest(source) == pin or source in expected_changes, source
audit['sources']['RiemannGaussian/ArithmeticOperatorCharacterCofactorAudit.lean'] = digest(
    'RiemannGaussian/ArithmeticOperatorCharacterCofactorAudit.lean')
for source in audit['sources']:
    audit['sources'][source] = digest(source)
assert digest(audit['externalRoadmap']['path']) == audit['externalRoadmap']['sha256']
audit['date'] = '2026-10-07'
v = audit['validation']
v.update({
    'modules': len(modules),
    'theoremsIncludingPrivateHelpers': sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations': sum(m['declarations'] for m in modules),
    'namespaceLinterRuns': sum(m['namespaceLinters'] for m in modules),
    'reportSha256': digest(report_path), 'logSha256': digest(log_path),
    'moduleReports': modules,
})
audit['scope'].update({
    'fixedCoprimeCrtCofactorExactNativeCharacterProjection': True,
    'fixedCoprimeCrtCofactorBothDivisorAndCofactorCharactersRetained': True,
    'fixedCoprimeCrtCofactorAllowedProperPowersQuotientsAndFullPhaseRetained': True,
    'fixedCoprimeCrtCofactorGenuineEulerResponse': 'L_chi(z-iy)*(-logDeriv L_chi(z))+L_chi_prime(z)',
    'fixedCoprimeCrtCofactorNonprincipalAnalyticOrderFiniteProved': True,
    'fixedCoprimeCrtCofactorExactNonprincipalResidue': '-analyticOrderNatAt(L_chi,z)*L_chi(z-iy)',
    'fixedCoprimeCrtCofactorBothDensityCoordinatesRegularAfterPrincipalDeletion': True,
    'fixedCoprimeCrtCofactorNonzeroCodeSourceForcesCommonLZeroAndNonzeroCofactor': True,
    'fixedCoprimeCrtCofactorCommonLZeroAbsentOrExistsUnconditionallyProved': False,
    'fixedCoprimeCrtCofactorPrincipalActualZetaMultiplicityPreserved': True,
    'fixedCoprimeCrtCofactorPrincipalMatchedRealCofactorNonzero': True,
    'fixedCoprimeCrtCofactorNativeProgressionResidueNoCommonLZeroPremiseExplicit': True,
    'fixedCoprimeCrtCofactorFreeColumnCollapseAndZeroKernelCriterion': True,
    'fixedCoprimeCrtCofactorFreeControlsClaimedActualGammaOrGeneralizedEuler': False,
    'fixedCoprimeCrtCofactorNativeCutoffAsymptoticClaimedFromResidue': False,
    'fixedCoprimeCrtCofactorIndependentSignedPrimeEstimateProved': False,
    'fixedCoprimeCrtCofactorNativePeriodOrOldAbsoluteBoundaryCompletedOrNormPaid': False,
    'fixedCoprimeCrtCofactorNoGoScope': 'fixed coprime arithmetic-progression character bookkeeping of the actual prime-only Gamma commutator; principal source is conserved, while principal-deleted code needs additional common nonprincipal L-zero and nonzero cofactor; nonunit/growing moduli, nonlinear/nonseparable two-column masks and signed constrained CRT/Gamma/Mobius estimates remain open',
})
old = 'source-sensitive signed distinct-prime-column estimate using unaltered actual Gamma/Mobius data, nonconstant/nonseparable correlated lag codes, growing second supports or incomplete-period CRT/order boundaries; complete CRT bookkeeping is free, flat lags conserve or annihilate the first source, and fixed finite actual second-cofactor phase adds only a source-small analytic correction to the old unpaid commutator; unit-prime controls still fail actual Gamma data'
new = 'source-sensitive signed distinct-prime-column estimate using unaltered actual Gamma/Mobius data, nonconstant/nonseparable correlated lag codes, growing second supports, nonunit/growing CRT moduli or literal incomplete-period CRT/order boundaries; complete CRT bookkeeping is free, flat lags conserve or annihilate the first source, fixed finite actual second-cofactor phase adds only a source-small analytic correction, and fixed coprime character masks conserve principal source or require extra common nonprincipal L-zero/cofactor input; unit-prime controls still fail actual Gamma data'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid'] = [new if x == old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit, indent=2) + '\n')
carry_path = root / 'docs/suzuki-carry-exceptional-audit.json'
carry = json.loads(carry_path.read_text())
for source, pin in carry['sources'].items():
    assert digest(source) == pin or source == 'AGENTS.md', source
carry['sources']['AGENTS.md'] = digest('AGENTS.md')
carry['policyPinUpdated'] = '2026-10-07; scoped fixed coprime CRT divisor/cofactor character audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry, indent=2) + '\n')
print(json.dumps({
    'modules': v['modules'], 'theoremsIncludingPrivateHelpers': v['theoremsIncludingPrivateHelpers'],
    'declarations': v['declarations'], 'namespaceLinterRuns': v['namespaceLinterRuns'],
    'sourcePins': len(audit['sources']), 'reportSha256': v['reportSha256'],
    'logSha256': v['logSha256'], 'rhEndpointDischarged': audit['rhEndpointDischarged'],
}, indent=2))
