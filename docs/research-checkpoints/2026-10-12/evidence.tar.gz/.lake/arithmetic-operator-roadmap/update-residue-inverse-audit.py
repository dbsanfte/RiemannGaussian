from pathlib import Path
import hashlib
import json

root = Path.cwd()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


path = root / 'docs/arithmetic-operator-audit.json'
audit = json.loads(path.read_text())
report_path = root / '.lake/arithmetic-operator-roadmap/axioms.json'
report = json.loads(report_path.read_text())
modules = report['modules']
assert len(modules) == 64
assert modules[-1]['module'].endswith('ArithmeticOperatorResidueInverseAudit')
assert all(m['onlyStandardAxioms'] for m in modules)
log_path = root / '.lake/arithmetic-operator-roadmap/validation.log'
log = log_path.read_text()
assert 'error:' not in log and 'warning:' not in log
assert log.count('with 14 linters') == 64
assert 'Checked RiemannGaussian.ArithmeticOperatorResidueInverseAudit:' in log
expected_changes = {'AGENTS.md', 'docs/arithmetic-operator-research.md',
                    'scripts/CheckArithmeticOperatorRoadmap.lean'}
for source, pin in audit['sources'].items():
    assert digest(source) == pin or source in expected_changes, source
new_source = 'RiemannGaussian/ArithmeticOperatorResidueInverseAudit.lean'
audit['sources'][new_source] = digest(new_source)
for source in audit['sources']:
    audit['sources'][source] = digest(source)
assert digest(audit['externalRoadmap']['path']) == audit['externalRoadmap']['sha256']
audit['date'] = '2026-10-07'
v = audit['validation']
v.update({
    'focusedCommand': 'lake env lean --error=warning scripts/CheckArithmeticOperatorRoadmap.lean',
    'modules': len(modules),
    'theoremsIncludingPrivateHelpers': sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations': sum(m['declarations'] for m in modules),
    'namespaceLinterRuns': sum(m['namespaceLinters'] for m in modules),
    'reportSha256': digest(report_path), 'logSha256': digest(log_path),
    'moduleReports': modules,
})
audit['scope'].update({
    'fixedPeriodicActualGammaMoebiusInverseGenuineEulerResponse': '-L_Phi_prime(s)/zeta(s)',
    'fixedPeriodicInverseEveryActualRowProperPowerQuotientMaskAndFullPhaseRetained': True,
    'fixedPeriodicInverseFiniteNumeratorOrderEllGivesExactResponseOrder': 'ell-m_rho',
    'fixedPeriodicInverseRemovabilityIffNumeratorCancelsFullMultiplicity': True,
    'fixedPeriodicInverseSurvivingPoleHasProvedNonzeroComplexLeadingCoefficient': True,
    'fixedPeriodicInverseZeroMeanRemovesDensityAsAnalyticGerm': True,
    'fixedPeriodicInverseTwoBoundedNonDivisorCodes': [[2, 0, -2], [2, -2, 0]],
    'fixedPeriodicInverseCodeNormBound': 2,
    'fixedPeriodicInverseCodesNotFunctionsOfGcdThreeN': True,
    'fixedPeriodicInverseAtLeastOneOfTwoCodesDetectsEveryActualZero': True,
    'fixedPeriodicInverseExposureSimplicityOrCommonLZeroAssumed': False,
    'fixedPeriodicInversePairRemovableExtensionsIffStripNonvanishing': True,
    'fixedPeriodicInverseActualNativeSignedMuKernelJoinedBeforeNorms': True,
    'fixedPeriodicInverseAllFreeRowsBoundIffZeroKernel': True,
    'fixedPeriodicInverseFreeRowsClaimedActualGammaOrGeneralizedPrimeData': False,
    'fixedPeriodicInverseActualAbsoluteFiberDebitLowerBound': '2*H*log(3) at cutoff 3*H',
    'fixedPeriodicInverseActualDyadicAbsoluteDebitDivergesForEveryBetaBelowOne': True,
    'fixedPeriodicInverseNativeCutoffAsymptoticProved': False,
    'fixedPeriodicInverseIndependentSignedEstimateProved': False,
    'fixedPeriodicInverseNoGoScope': 'fixed-periodic complete actual-Gamma/Mobius inverse bookkeeping and absolute fiber payment, including bounded non-divisor codes; genuine constrained signed estimates, growing codes, nonlinear masks and literal incomplete cross-column boundaries remain open',
})
old = 'non-divisor constrained periodic code or genuinely correlated-mask estimate after actual Gamma/Mobius inversion; fixed divisor/Ramanujan words reduce exactly to original signed Mangoldt dilations plus explicit heads and coded holomorphy is original nonvanishing; direct complete periodic rows lose the source and unrestricted codes prescribe arbitrary outputs; an independent estimate of the retained dilations is still new input'
new = 'independent signed estimate for a specifically constrained fixed-periodic actual-Gamma/Mobius inverse kernel, genuinely nonlinear inverse masks or growing-period correlated codes; divisor/Ramanujan words are old Mangoldt dilations plus heads, while non-divisor fixed codes have reciprocal-zeta numerator-order sources and a bounded two-code holomorphy criterion exactly equivalent to original nonvanishing; all actual inverse absolute-fiber costs audited here remain source-divergent'
assert old in audit['scope']['unpaid']
audit['scope']['unpaid'] = [new if x == old else x for x in audit['scope']['unpaid']]
assert audit['goalActive'] and audit['localOnly']
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
assert not audit['scope']['completeRoadmapExhausted']
path.write_text(json.dumps(audit, indent=2) + '\n')
carry_path = root / 'docs/suzuki-carry-exceptional-audit.json'
carry = json.loads(carry_path.read_text())
for source, pin in carry['sources'].items():
    assert digest(source) == pin or source == 'AGENTS.md', source
carry['sources']['AGENTS.md'] = digest('AGENTS.md')
carry['policyPinUpdated'] = '2026-10-07; scoped fixed non-divisor residue-code actual inverse audit appended; historical carry proof validation unchanged'
carry_path.write_text(json.dumps(carry, indent=2) + '\n')
print(json.dumps({
    'modules': v['modules'], 'theoremsIncludingPrivateHelpers': v['theoremsIncludingPrivateHelpers'],
    'declarations': v['declarations'], 'namespaceLinterRuns': v['namespaceLinterRuns'],
    'sourcePins': len(audit['sources']), 'reportSha256': v['reportSha256'],
    'logSha256': v['logSha256'], 'rhEndpointDischarged': audit['rhEndpointDischarged'],
}, indent=2))
