import RiemannGaussian.ArithmeticOperatorKummerCutoff
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Fintype.BigOperators
open scoped BigOperators Classical
open RiemannGaussian
example (N d : ℕ) (hd : 0<d) :
    SuzukiIntegerCarry.carry N d=SuzukiIntegerCarry.carry (N%d) d := by
  have he : 2*N=2*(N%d)+(2*(N/d))*d := by nlinarith [Nat.mod_add_div N d]
  unfold SuzukiIntegerCarry.carry
  rw [he,Nat.add_mul_div_right _ _ hd,Nat.div_eq_of_lt (Nat.mod_lt N hd)]
  omega
example {d e : ℕ} [NeZero d] [NeZero e] (hc : d.Coprime e) (N : ℕ) :
    (ZMod.chineseRemainder hc (N : ZMod (d*e))).1=(N : ZMod d) := by
  simp [ZMod.chineseRemainder]
example {d e : ℕ} [NeZero d] [NeZero e] (hc : d.Coprime e) (N : ℕ) :
    (ZMod.chineseRemainder hc (N : ZMod (d*e))).2=(N : ZMod e) := by
  simp [ZMod.chineseRemainder]
example {d : ℕ} [NeZero d] (N : Fin d) :
    ZMod.finEquiv d N=(N.val : ZMod d) := by
  apply (ZMod.val_injective d)
  rw [ZMod.val_natCast,Nat.mod_eq_of_lt N.is_lt]
  cases d
  · exact (NeZero.ne 0 rfl).elim
  · rfl
