import hashlib
import json
from pathlib import Path

root=Path.cwd()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

audit_path=root/'docs/arithmetic-operator-audit.json'
audit=json.loads(audit_path.read_text())
report_path=root/'.lake/arithmetic-operator-roadmap/axioms.json'
log_path=root/'.lake/arithmetic-operator-roadmap/validation.log'
modules=json.loads(report_path.read_text())['modules']
assert len(modules)==52
assert not any('error:' in line for line in log_path.read_text().splitlines())
assert all(m['onlyStandardAxioms'] for m in modules)
for source in [
    'RiemannGaussian/ArithmeticOperatorKummerThresholdAudit.lean',
    'RiemannGaussian/ArithmeticOperatorKummerThresholdSource.lean',
]:
    audit['sources'][source]=digest(root/source)
for source in audit['sources']:
    audit['sources'][source]=digest(root/source)
validation=audit['validation']
validation.update({
    'modules':len(modules),
    'theoremsIncludingPrivateHelpers':sum(m['theoremsIncludingPrivateHelpers'] for m in modules),
    'declarations':sum(m['declarations'] for m in modules),
    'namespaceLinterRuns':sum(m['namespaceLinters'] for m in modules),
    'reportSha256':digest(report_path),
    'logSha256':digest(log_path),
    'moduleReports':modules,
})
scope=audit['scope']
scope.update({
    'consecutiveBalancedRowFirstCarryIntersectionExact':True,
    'consecutiveBalancedRowThreshold':'indicator(r*d <= (r+1)*(N mod d)), d>0',
    'consecutiveBalancedRowFullLargePrimeValuationsExact':True,
    'consecutiveBalancedRowCommonThresholdHeadBound':'2^J*(2J)*log(2), (r+1)*N <= 2^(2J)',
    'consecutiveBalancedRowFullValuationsSourceEquivalentThreshold':True,
    'consecutiveBalancedRowAllPositiveKummerOrdersRetained':True,
    'consecutiveBalancedRowSourceThreshold':'beta > 1/2; fixed row count; moving unit-bounded base-prime phase',
    'consecutiveBalancedRowPrimeOnlyTwistMatchesRealBeta':True,
    'consecutiveBalancedRowMatchedMellinCoefficientStrictlyPositive':True,
    'consecutiveBalancedRowCompleteDiagnosticDensityCancels':True,
    'consecutiveBalancedRowNormalizedSourceIsFixedNonzeroCoefficient':True,
    'consecutiveBalancedRowLowerPhysicalBoundaryExplicitlyBounded':True,
    'consecutiveBalancedRowActualPrimeSourceAsymptoticProved':False,
    'consecutiveBalancedRowCenteredNativeKernelScalarCollapse':True,
    'consecutiveBalancedRowCountermodelsSatisfyActualGammaData':False,
    'consecutiveBalancedRowIndependentSignedThresholdEstimateProved':False,
    'consecutiveBalancedRowNoGoScope':'bookkeeping/free-PSD-only consecutive balanced-row prototype; unaltered actual Gamma constraints, distinct primes, growing complexity and phases inside separate carry orders remain open',
})
scope['unpaid'][6]='signed Kummer/common-GCD and consecutive-balanced threshold prime sums using unaltered actual Gamma constraints; distinct-prime products, growing row complexity or phases inside separate carry orders beyond the fixed same-prime scalar-collapse/source audit'
audit_path.write_text(json.dumps(audit,indent=2)+'\n')

carry_path=root/'docs/suzuki-carry-exceptional-audit.json'
carry=json.loads(carry_path.read_text())
carry['sources']['AGENTS.md']=digest(root/'AGENTS.md')
carry['policyPinUpdated']='2026-10-06: consecutive balanced Kummer-row threshold source/density/collapse audit; actual signed prime/Gamma/distinct-column estimates remain open; historical carry validation unchanged'
carry_path.write_text(json.dumps(carry,indent=2)+'\n')
print(json.dumps({k:validation[k] for k in [
    'modules','theoremsIncludingPrivateHelpers','declarations','namespaceLinterRuns',
    'reportSha256','logSha256'
]},indent=2))
