from pathlib import Path
import hashlib
import json
import re


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


audit_path = Path('docs/arithmetic-operator-audit.json')
audit = json.loads(audit_path.read_text())
report_path = Path('.lake/arithmetic-operator-roadmap/axioms.json')
log_path = Path('.lake/arithmetic-operator-roadmap/validation.log')
report = json.loads(report_path.read_text())
log = log_path.read_text()
assert len(report['modules']) == 86
assert log.count('-- All linting checks passed!') == 86
assert not re.search(r'error:|warning:|Found [1-9][0-9]* errors', log)
assert all(m['onlyStandardAxioms'] and m['namespaceLinters'] == 14
           for m in report['modules'])
new = ['RiemannGaussian/ArithmeticOperatorOrderedGapGeometry.lean',
       'RiemannGaussian/ArithmeticOperatorOrderedGapAudit.lean']
assert [m['module'] for m in report['modules'][-2:]] == [
    'RiemannGaussian.ArithmeticOperatorOrderedGapGeometry',
    'RiemannGaussian.ArithmeticOperatorOrderedGapAudit']
allowed_changes = {'AGENTS.md', 'docs/arithmetic-operator-research.md',
                   'scripts/CheckArithmeticOperatorRoadmap.lean'}
for f, h in audit['sources'].items():
    assert f in allowed_changes or digest(f) == h, ('Prior source changed', f)
assert digest(audit['externalRoadmap']['path']) == audit['externalRoadmap']['sha256']

leaf_log = Path('.lake/arithmetic-operator-roadmap/ordered-gap-final-build.log')
build_log = leaf_log.read_text()
assert 'Build completed successfully' in build_log
assert not re.search(r'error:|warning:', build_log)
for f in list(audit['sources']) + new:
    audit['sources'][f] = digest(f)
v = audit['validation']
v.update(modules=len(report['modules']),
         theoremsIncludingPrivateHelpers=sum(
             m['theoremsIncludingPrivateHelpers'] for m in report['modules']),
         declarations=sum(m['declarations'] for m in report['modules']),
         namespaceLinterRuns=sum(m['namespaceLinters'] for m in report['modules']),
         reportSha256=digest(report_path), logSha256=digest(log_path),
         moduleReports=report['modules'])
v['latestLeafBuilds'] = [
    {'module': name, 'command':
     'lake --wfail build RiemannGaussian.ArithmeticOperatorOrderedGapGeometry '
     'RiemannGaussian.ArithmeticOperatorOrderedGapAudit',
     'exitCode': 0, 'log': str(leaf_log), 'logSha256': digest(leaf_log)}
    for name in [m['module'] for m in report['modules'][-2:]]]
audit['scope'].update({
    'orderedGapActualNoIntermediateFractionConditionProvedBothDirections': True,
    'orderedGapUniqueNativeNumeratorsIncludingUnitEndpoints': True,
    'orderedGapExactDeterminantAndArchimedeanGap': True,
    'orderedGapStrictSlopingDenominatorBoundaryRetained': True,
    'orderedGapCompleteCountIsExactlyOldTotientPrefix': True,
    'orderedGapMatchedPhaseStaysOnLiteralCutoffIncrements': True,
    'orderedGapGenuineEulerSeriesOnlyOnReGtTwo': True,
    'orderedGapEveryActualZeroMultiplicityHasNonzeroAnalyticSource': True,
    'orderedGapDensityPoleRemovedWithoutCancellingSource': True,
    'orderedGapCenteredStripRemovabilityIffOriginalNonvanishing': True,
    'orderedGapAllOriginalPairMasksJoinedBeforeAnyNorm': True,
    'orderedGapFreeArrayBoundIffEntireJoinedKernelZero': True,
    'orderedGapFreeSmoothGeneralizedControlsGrantedActualAdjacencyOrGammaData': False,
    'orderedGapActualUnsmoothedCountCostAtLeastNOverEightBeyondEveryHead': True,
    'orderedGapGlobalSublinearNormPaymentFalseAtEveryFixedHeight': True,
    'orderedGapNativeCutoffSourceAsymptoticClaimed': False,
    'orderedGapIndependentSignedArithmeticEstimateProved': False,
    'orderedGapSignedSmoothingOrHigherNativeConstraintsExhausted': False,
    'orderedGapNoGoScope':
        'Actual adjacent reduced fractions have a unique primitive strict '
        'denominator-triangle chart. COMPLETE one-step count is the old totient '
        'prefix; its true Euler response keeps every actual zero multiplicity '
        'after density centering, and removability is precisely original '
        'nonvanishing. Every original two-denominator mask joins to a scalar '
        'inverse-weight kernel before any norm; free-array uniform payment '
        'requires the whole kernel zero. Actual unsmoothed count discrepancy '
        'has norm at least N/8 beyond every head, refuting global sublinear '
        'norm payments. Independently constrained SIGNED gap kernels, native '
        'multipoint order and boundary-aware smoothing remain open.'
})
assert audit['scope']['tier1FamiliesExhaustivelyClosed'] == 0
assert not audit['rhEndpointDischarged'] and not audit['zeroExclusionProved']
audit_path.write_text(json.dumps(audit, indent=2) + '\n')

carry_path = Path('docs/suzuki-carry-exceptional-audit.json')
carry = json.loads(carry_path.read_text())
historical = {f: h for f, h in carry['sources'].items() if f != 'AGENTS.md'}
for f, h in historical.items():
    assert digest(f) == h, ('Historical carry source changed', f)
carry['sources']['AGENTS.md'] = digest('AGENTS.md')
carry['policyPinUpdated'] = (
    '2026-10-07; policy additionally records the actual unique native ordered '
    'gap dictionary, complete totient-count/source conservation, whole-mask '
    'inverse collapse and beyond-every-head false global norm payment. '
    'Historical carry proof validation and every other source pin unchanged.')
assert {f: h for f, h in carry['sources'].items() if f != 'AGENTS.md'} == historical
carry_path.write_text(json.dumps(carry, indent=2) + '\n')
print('Pinned', len(audit['sources']), 'operator sources;', v['modules'], 'modules;',
      v['theoremsIncludingPrivateHelpers'], 'theorems;', v['declarations'],
      'declarations;', v['namespaceLinterRuns'], 'linter runs.')
print('Unchanged historical carry pins:', len(historical))
print('Report SHA:', v['reportSha256'])
print('Log SHA:', v['logSha256'])
