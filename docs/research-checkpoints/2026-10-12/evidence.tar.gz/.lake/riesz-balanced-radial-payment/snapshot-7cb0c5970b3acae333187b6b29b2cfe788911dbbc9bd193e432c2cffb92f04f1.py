from pathlib import Path
import hashlib
import json
import re
import subprocess

out = Path('.lake/riesz-balanced-radial-payment')
source = Path('RiemannGaussian/ZetaRieszBalancedRadialPayment.lean')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '194a361762f404a8f4473298b25d96fbae0bb56e'
previous_path = Path('docs/riesz-balanced-allocation-payment-audit.json')
previous = json.loads(previous_path.read_text())
root = Path('.lake/build/lib/lean/RiemannGaussian.olean')
root_sha = hashlib.sha256(root.read_bytes()).hexdigest()
assert any(p['path'] == str(root) and p['sha256'] == root_sha
           for p in previous['compiledArtifacts'])
for p in previous['sources']:
    if p['path'] == 'AGENTS.md':
        continue
    assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest() == p['sha256']

logs = [out/'strict-lean.log', out/'build.log', out/'audit.log']
for path in logs:
    text = path.read_text()
    assert not re.search(r'^(error|warning):|: error:|: warning:', text, re.M), path
assert 'Build completed successfully' in (out/'build.log').read_text()
lint = (out/'audit.log').read_text()
assert lint.count('All linting checks passed') == 1
assert lint.count('Found 0 errors') == 1
assert lint.count('with 14 linters') == 1
axioms = json.loads((out/'axioms.json').read_text())
assert axioms['module'] == 'RiemannGaussian.ZetaRieszBalancedRadialPayment'
assert axioms['onlyStandardAxioms']
for theorem in axioms['theoremAxioms']:
    assert set(theorem['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}


def saved(path):
    path = Path(path)
    data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    snapshot = out/f'snapshot-{sha}{path.suffix}'
    if snapshot.exists():
        assert snapshot.read_bytes() == data
    else:
        snapshot.write_bytes(data)
    return dict(path=str(path), sha256=sha, snapshot=str(snapshot))


text = source.read_text()
code = re.sub(r'/\-.*?\-/', '', text, flags=re.S)
assert not re.search(r'\b(sorry|admit|sorryAx)\b', code)
assert not any(line.rstrip() != line for line in text.splitlines())

probe_path = out/'probe.json'
probe = json.loads(probe_path.read_text())
baseline_path = Path('.lake/riesz-balanced-joint/probe.json')
baseline = json.loads(baseline_path.read_text())
assert len(probe['cases']) == len(baseline['cases']) == 6
assert probe['scope']['radialComparisonUsesActualFiniteSignedErrorNotEventualBudget']
assert not probe['scope']['movingIntegerLength']
assert not probe['scope']['nativeDyadicSchedule']
for a,b in zip(baseline['cases'],probe['cases']):
    assert a['N']==b['N'] and a['height']==b['height']
    for k in ['jointSignedTotal','signedHead','completeJoinedCostWithNulls']:
        assert abs(a[k]-b[k]) < 1e-13
    c=b['radialComparison']
    assert c['fullSignedHeadUnchangedAfterRadialPruning']
    assert abs(c['signedHead']-b['signedHead']) < 1e-13
    assert c['finiteNetRadialSaving'] == 0
    assert not c['floorSourceScaleOrCofinalProved']
assert probe['source']['sha256'] == hashlib.sha256(Path(probe['source']['path']).read_bytes()).hexdigest()

report = dict(
    schemaVersion=1, date='2026-10-03', head=head,
    objective='Close out the floor.', goalRemainsActive=True,
    slice='Spend the existing all-mask geometric radial bound on the entire allocation-free balanced remainder before whole signed period pricing. The same full head stays signed; the central floor remains open.',
    sources=[saved(p) for p in [
        source, 'RiemannGaussian/ZetaRieszBalancedAllocationPayment.lean',
        'RiemannGaussian/ZetaRieszBalancedOwnerFloor.lean',
        'RiemannGaussian/ZetaRieszLargeOrderCore.lean',
        'RiemannGaussian/ZetaRieszPrimeHeadPeriods.lean',
        'RiemannGaussian/ZetaRieszRoughPrimePairCancellation.lean',
        'RiemannGaussian/ZetaRieszComplexNullFloor.lean',
        'RiemannGaussian/ZetaRieszTangentCubicCredit.lean',
        'RiemannGaussian/ZetaRieszCutoffPeriodFloor.lean',
        'RiemannGaussian/ZetaRieszComplexProjection.lean',
        'RiemannGaussian/ZetaSquarefreeVaughanLogSource.lean',
        'RiemannGaussian/LogarithmicDeviation.lean',
        'scripts/probe_riesz_balanced_joint.py',
        'docs/zeta-riesz-balanced-radial-payment.md', previous_path,
        'AGENTS.md', 'lean-toolchain', 'lake-manifest.json']],
    compiledArtifacts=[saved(p) for p in [
        '.lake/build/lib/lean/RiemannGaussian/ZetaRieszBalancedRadialPayment.olean',root]],
    validation=dict(
        scope='Focused local: strict leaf, targeted leaf build, frozen compiled ordinary root plus explicit leaf. No root-source rebuild or wider gates.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(source),exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszBalancedRadialPayment --wfail',exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(out/'Audit.lean'),exitCode=0,
            compiledOrdinaryRootImported=True,explicitLeafImported=True,
            frozenCompiledRootMatchesPrevious=True,rootSourceNotRebuilt=True,
            namespaces=1,lintersPerNamespace=14,allNamespaceLintersPass=True),
        publicTheorems=len(re.findall(r'^theorem [A-Za-z_]',text,re.M)),
        publicDefinitions=len(re.findall(r'^def [A-Za-z_]',text,re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheoremsIncludingPrivateAndGenerated=axioms['theoremsIncludingPrivateHelpers'],
        everyCompiledDeclarationAxiomChecked=True,onlyStandardAxioms=True,
        previousFrozenProofAndDocumentationSourcesPreserved=True),
    exactResults=dict(
        existingGenericRadialBoundReusedNotClaimedNew=True,
        radiusRange='0<=u<=10001/20000',phaseHeightForRadialPayment='arbitrary real y; no zero/exposure hypothesis',
        fixedHeightForPreviousHighOwnerPayment='abs(y)>=54',
        exactRemainingPopulation='original balanced native labels intersect 1971N/1000<log n<=2029N/1000',
        sourceScaleDifferenceNorm='norm(centralRest-unallocatedRest)<=C*exp(-N/1000000)',
        finiteOriginalRadialConstantRetained=True,
        noSmallFiniteOrderConstantClaimed=True,
        radialBudgetTendsToZero=True,
        ownerAndEveryPrimeShare='strictly below 340/657',
        originalCoefficientPhasePhysicalSquarefreeNondominantCountCropAndLengthRetained=True,
        noNewCountOrLeastPrimeRestriction=True,
        allocationAlreadyPaidNotReintroduced=True,
        fullSignedNativeHeadUnchangedIncludingItsRadialSupport=True,
        centralMinusSameHeadSourceEquivalentToNativeRealCarrier=True,
        noNormPaymentOfCentralMainOrHead=True,
        exactCentralIncrementTotal=True,
        wholeNativeFreeNullTangentColumnsRetained=True,
        allCountsCrossingsAndPeriodsJoinedBeforeClipping=True,
        radialPaymentActuallySpentOnceInWholeFloor=True,
        sameHighOwnerAllocationBudgetsAndNativeErrorRetained=True,
        olderPricesAlternativesNotStackedCredits=True,
        clippingMonotonicityUnderRadialDeletionNotAssumed=True,
        noPercentageOfGlobalFloorDeficitClaimed=True,
        squareRootOwnerExtensionThroughSaddleEndpointNotAssumedPaid=True),
    optionalProbe=dict(
        snapshot=saved(probe_path),baselineSnapshot=saved(baseline_path),
        command='../.venv/bin/python scripts/probe_riesz_balanced_joint.py --compare-radial --output .lake/riesz-balanced-radial-payment/probe.json',
        exhaustiveToyCases=6,orders=[6,7],heights=[54,65,100],
        toyLength='-2N log u, NOT actual moving integer length',
        nativeDyadicSchedule=False,nativeDeletionMasks=False,
        previousNativeBudgetsApplied=False,optionalOutsideBuildsAndCI=True,
        wholePhaseFactorialKernelDivisorSignsAndSignedHeadRetained=True,
        allFiniteNullTotalsAndLedgersVerifiedInFloatingArithmetic=True,
        baselineTotalsPreserved=True,
        priorSourceAndOutputSnapshotsPreserved=True,
        radialComparisonChargesActualFiniteSignedRemovedTotal=True,
        finiteRadialComparisonsImproved=0,
        finitePricesCoFinalOrSourceScaleCertificates=False),
    openPremises=dict(
        remainingSignedTarget='contracted balanced original Riesz sum minus SAME full signed prime head',
        cofinalWholePrice='funded price<=399/5000 on a cofinal set of native dyadic indices',
        wholeFloorProved=False,multiplicityCeilingProved=False,restrictedContradictionProved=False,
        zeroExclusionProved=False,rhProved=False),
    publication=dict(localOnly=True,noCommitsOrPushes=True,noSubagents=True,noRootRegistration=True,
        publicEndpointsUnchanged=True,noReadmeExplorerChanges=True,concurrentSemiprimeWorkPreserved=True),
    provenance=[saved(p) for p in logs+[out/'Audit.lean',out/'axioms.json',out/'probe.log',Path(__file__)]])
blob=json.dumps(report,indent=2)+'\n'
(out/'report.json').write_text(blob)
Path('docs/riesz-balanced-radial-payment-audit.json').write_text(blob)
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    publicDefinitions=report['validation']['publicDefinitions'],compiledDeclarations=axioms['declarations'],
    compiledTheorems=axioms['theoremsIncludingPrivateHelpers'],allChecksPass=True,wholeFloorStillOpen=True)))
