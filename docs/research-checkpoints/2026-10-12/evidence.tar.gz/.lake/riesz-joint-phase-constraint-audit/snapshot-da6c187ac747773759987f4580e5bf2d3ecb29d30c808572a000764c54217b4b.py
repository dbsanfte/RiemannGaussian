from pathlib import Path
import hashlib
import json
import math
import re
import shutil
import subprocess

folder = Path('.lake/riesz-joint-phase-constraint-audit')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot(path):
    path = Path(path)
    sha = digest(path)
    target = folder / f'snapshot-{sha}{path.suffix}'
    if not target.exists():
        shutil.copy2(path, target)
    return dict(path=str(path), sha256=sha, snapshot=str(target))


previous_paths = ['docs/riesz-owner-completion-audit.json',
                  'docs/riesz-joint-phase-discrepancy-audit.json']
for p in previous_paths:
    previous = json.loads(Path(p).read_text())
    for section in ('sources', 'compiledArtifacts', 'provenance'):
        for source in previous.get(section, []):
            if source['path'] != 'AGENTS.md':
                assert digest(source['path']) == source['sha256'], source['path']

prior_manifest = json.loads(Path(
    '.lake/riesz-joint-phase-discrepancy/unrelated-working-tree-before.json').read_text())
differences = json.loads((folder / 'previous-manifest-differences.json').read_text())
other_paths = {r['path'] for r in differences}
assert other_paths == {'RiemannGaussian.lean',
                       'docs/semiprime-factorisation-investigation.md',
                       'docs/theorem-explorer/metadata.json'}
# These three unrelated working files differ from the OLDER audit's
# baseline. This slice never edited them; retain their CURRENT bytes.
for source in differences:
    assert digest(source['path']) == source['current'], source['path']
for source in prior_manifest:
    if source['path'] not in other_paths:
        assert digest(source['path']) == source['sha256'], source['path']

assert digest('.lake/build/lib/lean/RiemannGaussian.olean') == (
    'e5e08ad8f2916f96d3fb6753f82ee7b3cabc6e427e69eef3f4b093a59157802f')
assert (folder / 'strict-lean.log').read_text() == ''
assert 'Build completed successfully' in (folder / 'build.log').read_text()
assert '-- All linting checks passed!' in (folder / 'audit.log').read_text()
axioms = json.loads((folder / 'axioms.json').read_text())
assert axioms['onlyStandardAxioms']
leaf = Path('RiemannGaussian/ZetaRieszJointPhaseConstraint.lean')
proof = leaf.read_text()
assert not re.search(r'\b(sorry|admit|sorryAx|axiom)\b', proof)
probe_path = Path('.lake/riesz-joint-phase-constraint/probe.json')
probe = json.loads(probe_path.read_text())
for source in probe['sources']:
    assert digest(source['path']) == source['sha256'], source['path']
assert len(probe['cases']) == 6 and probe['frozenComplexTotalRegressions'] == 18
assert len(probe['actualHeightRegressions']) == 18
for case in probe['cases']:
    assert case['everySelectedLabelHasAFreePrime'] and case['sameFullHeadAlwaysRetained']
    assert case['fixedSupportIncludesZeroSievePrimePairs']
    assert case['completeMainSignCubeAverage'] == 0
    assert case['completeJointSignCubeAverage'] == -case['heightZeroHead']
    assert case['conditionalExpectationJoint'] <= -case['heightZeroHead']+5e-13
    assert not case['actualFixedHeightCharacterUsedForThisSignChoice']
    assert not case['actualFixedHeightCarrierBoundProved']

# Tiny independent exhaustive checks of the conditional-expectation walk.
# These are algorithm regressions, not arithmetic numerical certificates.
checks = []
for groups in [{1: .25}, {1: .25, 2: -.4, 3: .17},
               {1: .2, 2: .3, 4: -.5, 3: .1, 6: .4, 7: -.25}]:
    width = max(groups).bit_length()
    H = .7
    values = [math.fsum(a*(-1 if (mask & v).bit_count() % 2 else 1)
                        for mask, a in groups.items())-H for v in range(1 << width)]
    assert abs(math.fsum(values)/len(values)+H) < 1e-14
    v, expectation = 0, -H
    for i in range(width):
        a = math.fsum(a*(-1 if (mask & v).bit_count() % 2 else 1)
                      for mask, a in groups.items() if mask.bit_length()-1 == i)
        if a > 0:
            v |= 1 << i
        expectation -= abs(a)
    direct = math.fsum(a*(-1 if (mask & v).bit_count() % 2 else 1)
                       for mask, a in groups.items())-H
    assert abs(direct-expectation) < 1e-14 and direct <= -H
    checks.append(dict(variables=width, subsets=len(values), mean=-H, chosenValue=direct))

report = dict(schemaVersion=1, date='2026-10-03',
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    objective='Close out the floor.', goalStillActive=True,
    verdict='Exact all-count native prime-sign audit: arbitrary-prime-sign floor bounds must charge the fixed height-zero head. Actual fixed-height logarithmic correlation remains unbounded; no new arithmetic floor saving.',
    sources=[snapshot(p) for p in [leaf, 'scripts/probe_riesz_joint_phase_constraint.py',
        'scripts/probe_riesz_balanced_joint.py', 'RiemannGaussian/ZetaRieszBalancedRadialPayment.lean',
        'RiemannGaussian/ZetaRieszOwnerCompletionAudit.lean',
        'RiemannGaussian/ZetaRieszHeadSharedCancellation.lean',
        'RiemannGaussian/ZetaRieszPrimeHeadPolePayment.lean',
        'docs/zeta-riesz-joint-phase-constraint.md', 'AGENTS.md', 'lean-toolchain',
        'lake-manifest.json', *previous_paths]],
    compiledArtifacts=[snapshot('.lake/build/lib/lean/RiemannGaussian.olean'),
        snapshot('.lake/build/lib/lean/RiemannGaussian/ZetaRieszJointPhaseConstraint.olean')],
    theoremLines={m.group(1): proof[:m.start()].count('\n')+1
                  for m in re.finditer(r'^theorem (\w+)', proof, re.M)},
    validation=dict(scope='Strict leaf/targeted build; frozen compiled ordinary root with explicit leaf lint and standard-axiom check. No wider gates.',
        strictLeanExitCode=0, targetedBuildExitCode=0, auditExitCode=0,
        publicTheorems=len(re.findall(r'^theorem ', proof, re.M)),
        publicDefinitions=len(re.findall(r'^def ', proof, re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheorems=axioms['theoremsIncludingPrivateHelpers'],
        lintersPerNamespace=14, everyCompiledDeclarationAxiomChecked=True,
        onlyStandardAxioms=True, previousFocusedProofProbeDocsArtifactsPreserved=True,
        unchangedPriorManifestFiles=len(prior_manifest)-len(differences),
        unrelatedOlderBaselineDifferences=differences,
        unrelatedOlderBaselineDifferencesCurrentBytesPreserved=True,
        rootSourceNotRebuilt=True, frozenCompiledOrdinaryRootPreserved=True),
    exactResults=dict(nativeDyadicLabelsRetained=True, originalFullHeadSupportRetained=True,
        headCandidateSupportIncludesZeroSievePrimePairs=True, allCountsJoinedBeforeAveraging=True,
        centralLargestLogStrictlyBelow51Nover50=True, headOwnerLogAtLeast51Nover50=True,
        headCofactorLogStrictlyAbove7Nover10=True, threeSuchCofactorsMiss2029Nover1000Core=True,
        everyCentralLabelHasPrimeOutsideEntireHeadSupport=True,
        sharedPrimeSignsMultiplicativeNotIndependentLabelPhases=True,
        entireCentralSignCubeAverageExactlyZero=True, bothHeadLegSignsRemainOne=True,
        someRelaxedJointValueAtMostNegativeHeightZeroHead=True,
        arbitrarySignFloorAllowanceMustCoverHeightZeroHead=True,
        noNormCompletionDensityPrimeEstimateOrNewFloorEndpoint=True,
        signChoicesNotClaimedToBeOneFixedHeightLogCharacter=True,
        noHeadGrowthOrActualHeightNoGoClaim=True),
    optionalProbe=dict(snapshot=snapshot(probe_path),
        log=snapshot('.lake/riesz-joint-phase-constraint/probe.log'),
        cases=6, orders=[6, 7, 8], heightsForActualComplexRegressions=[54, 65, 100],
        actualComplexTotalRegressions=18, chosenSignsKeepEntireCandidateHeadFixed=True,
        conditionalExpectationUsesWholeSharedPrimeAssignments=True,
        exactIntegerDivisorCutoffFloatingKernelsAndPhases=True,
        syntheticExhaustiveChecks=checks, optionalOutsideBuildsCI=True, numericCertificate=False,
        nativeMovingLengthDyadicScheduleAndAllDeletionMasksNotApplied=True,
        noNativeBudgetAppliedToToyOrders=True, noCofinalOrMarginPercentClaim=True,
        earlierWeightedSupportExperimentPreserved=snapshot(
            '.lake/riesz-joint-phase-constraint/weighted-support-probe.json')),
    openPremises=dict(independentActualLogarithmicPrimeCorrelationBoundProved=False,
        newArithmeticFloorSavingProved=False, wholeCofinalFloorProved=False,
        multiplicityCeilingProved=False, restrictedContradictionProved=False,
        zeroExclusionProved=False, rhProved=False),
    publication=dict(localOnly=True, noCommitsOrPushes=True, noSubagents=True,
        noRootRegistration=True, noReadmeExplorerOrPublicEndpointChangesByThisSlice=True,
        concurrentSemiprimeWorkNotEdited=True),
    provenance=[snapshot(folder / name) for name in
        ['strict-lean.log', 'build.log', 'audit.log', 'Audit.lean', 'axioms.json',
         'previous-manifest-differences.json', 'write_report.py']])
Path('docs/riesz-joint-phase-constraint-audit.json').write_text(json.dumps(report, indent=2)+'\n')
(folder / 'closed-form-checks.json').write_text(json.dumps(checks, indent=2)+'\n')
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    compiledDeclarations=axioms['declarations'], compiledTheorems=axioms['theoremsIncludingPrivateHelpers'],
    regressions=18, unchangedPriorManifestFiles=len(prior_manifest)-len(differences),
    unrelatedOlderBaselineDifferencesRetained=len(differences), newFloorSaving=False, goalStillOpen=True)))
