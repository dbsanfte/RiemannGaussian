from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

root=Path.cwd()
folder=root/'.lake/riesz-joint-phase-transport'
leaf=Path('RiemannGaussian/ZetaRieszJointPhaseTransport.lean')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def snapshot(path):
    path=Path(path)
    sha=digest(path)
    target=folder/f'snapshot-{sha}{path.suffix}'
    if not target.exists():
        shutil.copy2(path,target)
    return dict(path=str(path),sha256=sha,snapshot=str(target.relative_to(root)))

previous=json.loads(Path('docs/riesz-critical-prime-floor-audit.json').read_text())
for source in previous['sources']:
    if source['path']=='AGENTS.md':
        continue
    assert digest(source['path'])==source['sha256'], source['path']
for artifact in previous['compiledArtifacts']:
    assert digest(artifact['path'])==artifact['sha256'], artifact['path']
compiled_root=Path('.lake/build/lib/lean/RiemannGaussian.olean')
axioms=json.loads((folder/'axioms.json').read_text())
assert axioms['onlyStandardAxioms']
chord=json.loads((folder/'probe.json').read_text())
assert chord['frozenComplexTotalRegressions']==12
assert not any(r['newPriceImprovesPrevious'] for r in chord['cases'])
for source in chord['sources']:
    if digest(source['path'])!=source['sha256']:
        assert (folder/f"snapshot-{source['sha256']}{Path(source['path']).suffix}").exists()
probes=[json.loads((folder/name).read_text()) for name in ['cubic-probe.json','cubic-order8.json']]
assert sum(p['frozenComplexTotalRegressions'] for p in probes)==18
for probe in probes:
    for source in probe['sources']:
        assert digest(source['path'])==source['sha256'],source['path']
first=probes[0]
adverse=[r for r in first['cases'] if r['cubicBest']['exactSignedTotal']['re']<0]
favorable=[r for r in first['cases'] if r['cubicBest']['exactSignedTotal']['re']>0]
assert len(adverse)==8 and len(favorable)==4
assert all(r['cubicPriceImprovesPrevious'] for r in adverse)
assert all(r['cubicBest']['cubicFloor']>0 for r in favorable)
for name in ['strict-lean.log','build.log','audit.log']:
    assert (folder/name).exists()
assert 'Build completed successfully' in (folder/'build.log').read_text()
assert '-- All linting checks passed!' in (folder/'audit.log').read_text()
proof=leaf.read_text()
assert not re.search(r'\b(sorry|admit|sorryAx|axiom)\b',proof)
paths=[leaf,Path('RiemannGaussian/ZetaRieszPrimeHeadTransport.lean'),
    Path('RiemannGaussian/ZetaRieszBalancedRadialPayment.lean'),
    Path('RiemannGaussian/ZetaRieszBalancedAllocationPayment.lean'),
    Path('RiemannGaussian/ZetaRieszBalancedOwnerFloor.lean'),
    Path('RiemannGaussian/ZetaRieszCriticalPrimeFloor.lean'),
    Path('RiemannGaussian/ZetaRieszCosineCarrier.lean'),
    Path('scripts/probe_riesz_joint_phase_transport.py'),
    Path('scripts/probe_riesz_balanced_joint.py'),
    Path('scripts/probe_riesz_balanced_signature.py'),
    Path('docs/zeta-riesz-joint-phase-transport.md'),
    Path('AGENTS.md'),Path('lean-toolchain'),Path('lake-manifest.json')]
report=dict(
    schemaVersion=1,date='2026-10-03',
    head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    objective='Close out the floor.',goalRemainsActive=True,
    slice='Independent all-count signed cubic transport inequality for the actual balanced-minus-head sum; the cofinal signed allowance is still open.',
    sources=[snapshot(p) for p in paths],
    compiledArtifacts=[snapshot(compiled_root),snapshot(
        '.lake/build/lib/lean/RiemannGaussian/ZetaRieszJointPhaseTransport.olean')],
    validation=dict(scope='Focused local strict leaf/targeted build, frozen compiled ordinary root plus explicit leaf; no wider gates.',
        strictLean=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true '+str(leaf),exitCode=0),
        build=dict(command='/home/dbsanfte/.elan/bin/lake build RiemannGaussian.ZetaRieszJointPhaseTransport --wfail',exitCode=0),
        audit=dict(command='/home/dbsanfte/.elan/bin/lake env lean -DwarningAsError=true .lake/riesz-joint-phase-transport/Audit.lean',exitCode=0,
            compiledOrdinaryRootImported=True,explicitLeafImported=True,
            frozenCompiledRootMatchesPrevious=True,rootSourceNotRebuilt=True,
            allNamespaceLintersPass=True,lintersPerNamespace=14),
        publicTheorems=len(re.findall(r'^theorem ',proof,re.M)),
        publicDefinitions=len(re.findall(r'^def ',proof,re.M)),
        compiledDeclarations=axioms['declarations'],
        compiledTheoremsIncludingPrivateAndGenerated=axioms['theoremsIncludingPrivateHelpers'],
        everyCompiledDeclarationAxiomChecked=True,onlyStandardAxioms=True,
        previousFrozenProofProbeDocumentationAndCompiledArtifactsPreserved=True),
    exactResults=dict(
        wholeCentralAndSameFullSignedHeadDisjointUnion=True,
        everyOriginalCountOwnerPhysicalRadialAllocationRoughMaskRetained=True,
        originalProductPhaseRetained=True,
        fullSignedArithmeticAmplitudesRetained=True,
        pairwiseCircularLiftCosineExactlyPreserved=True,
        exactUnmatchedRowColumnResidualRetained=True,
        firstCenteredPhaseMomentStaysSigned=True,
        wholeErrorBound='abs(Re(centralRest)-nativeHead-(unmatched-signedMoment)) <= cubicCost',
        cubicCost='sum_{a,b} w(a,b)*abs(delta(a,b))^3/24',
        smallGapCost='cubicCost <= epsilon^2/24 * sum_{a,b} w(a,b)*abs(delta(a,b))',
        floorAndCeilingBeforeAnyCountOrUnmatchedNorm=True,
        explicitNativeCumulativeMassCouplingDefined=True,
        nativeCouplingNonnegativityProved=True,
        nativeCouplingCompleteMarginalIdentityClaimed=False,
        noFullCoverageOrNegligibleUnmatchedAssumption=True,
        noZeroExposureCompletionPrimeDensityOrArithmeticFloorPremise=True,
        nativeWholeFloorTransferRetainsAllPriorPaidErrors=True,
        priceMinWithPreviousFundedAlternative=True,
        stackedCredits=False),
    optionalProbe=dict(
        chordSnapshot=snapshot(folder/'probe.json'),
        cubicSnapshots=[snapshot(folder/name) for name in ['cubic-probe.json','cubic-order8.json']],
        cases=18,orders=[6,7,8],heights=[54,65,100],cuts='0,pi/2,pi,3pi/2',
        frozenComplexTotalRegressions=18,
        allCountsOriginalComplexPhaseAndSameFullHeadRetained=True,
        absoluteChordPriceComparisons=12,absoluteChordImprovesPrevious=0,
        adverseSignedPriceComparisons=8,adverseSignedPricesImproved=8,
        favorableSignedFloorsPositive=4,
        solverRoundoffAtAlreadyZeroPriceNotCountedAsSaving=True,
        cubicDefectMeasuredSmallButNoCofinalRateInferred=True,
        adverseUnmatchedAndSignedMomentContributionsRemain=True,
        toyLength='-2N log(10001/20000)',
        nativeMovingIntegerLength=False,nativeDyadicSchedule=False,
        fullNativeDeletionMasks=False,previousEventualBudgetsApplied=False,
        floatingNotIntervalCertificate=True,
        greedyExecutionEqualityToEvaluatedLeanCDFNotIntervalCertified=True,
        optionalOutsideBuildsCI=True,noNativeSavingsPercentOrZeroExclusionClaim=True),
    openPremises=dict(
        remainingTarget='cofinal Re(centralRest)-SAME full signed nativeHead >= -399/5000-o(1)',
        jointSignedUnmatchedMinusMomentCofinalBoundProved=False,
        nativeCofinalCubicErrorSmallnessProved=False,
        newWholeTransportPriceCofinalCapProved=False,
        wholeCofinalFloorProved=False,multiplicityCeilingProved=False,
        restrictedContradictionProved=False,zeroExclusionProved=False,rhProved=False),
    publication=dict(localOnly=True,noCommitsOrPushes=True,noSubagents=True,
        noRootRegistration=True,noReadmeExplorerOrPublicEndpointUpdates=True,
        concurrentSemiprimeWorkPreserved=True),
    provenance=[snapshot(folder/name) for name in
        ['strict-lean.log','build.log','audit.log','Audit.lean','axioms.json',
         'cubic-probe.log','cubic-order8.log','write_report.py']])
Path('docs/riesz-joint-phase-transport-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(publicTheorems=report['validation']['publicTheorems'],
    definitions=report['validation']['publicDefinitions'],
    compiledDeclarations=axioms['declarations'],
    compiledTheorems=axioms['theoremsIncludingPrivateHelpers'],
    probes=18,goalStillOpen=True)))

