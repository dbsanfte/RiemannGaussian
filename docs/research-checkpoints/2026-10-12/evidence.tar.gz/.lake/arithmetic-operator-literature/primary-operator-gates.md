# Primary literature preflight for the surviving operator interactions

Research checkpoint: 2026-10-08. Read-only literature work; no new Lean assertion or arithmetic endpoint is claimed. The active all-height gap is 1/2 < beta <= 7/8. All Mellin identities below retain prime powers. The finite nonlinear/correlated native source is not inferred from separate complete-prime moments.

## 1. Shifted divisor estimates: exact applicability obstruction

Primary source: Alex Cowan, *A twisted additive divisor problem*, J. Number Theory 266 (2025), 1–32; Theorem 1.1 of the author preprint:
https://arxiv.org/pdf/2304.12572

The theorem treats sigma_{2u}(n,chi) sigma_{2v}(n-k,psi) / n^(u+v), where k is a fixed positive integer, the level is a fixed rational prime, chi and psi are nontrivial even characters whose product is nontrivial, u,v are nonzero complex parameters with |Re u|+|Re v|<1/2, and 0<epsilon<1/2-|Re u|-|Re v|. All variables except X are fixed. Its error exponent is

    1 + |Re u| + |Re v|
      - (1 + 2|Re u| + 2|Re v|)
          / (3 + |Re(u+v)| + |Re(u-v)|) + epsilon.

Pure imaginary u,v yield 2/3+epsilon. This is genuine fixed power-saving in the stated additive-divisor class. The paper uses Eisenstein-series regularization; it does not state an estimate for Mangoldt-only divisor legs.

The repo row is instead

    f_y(n) = sum_(d|n) Lambda(d) d^(-iy),
    sum_n f_y(n)n^(-s) = zeta(s) Z(s+iy),
    Z(s) = -zeta'(s)/zeta(s).

In contrast,

    sigma_alpha(n) = sum_(d|n) d^alpha,
    sum_n sigma_alpha(n)n^(-s) = zeta(s) zeta(s-alpha).

Differentiating alpha any finite number of times inserts log(d)^r against ALL divisors. It creates positive-order derivatives of zeta; it cannot create the reciprocal zeta needed for Z. The character version changes a zeta factor to an L-factor, not to an inverse. Cowan also excludes the principal-character configurations needed for the direct row, so even the class of all-divisor proxies requires its own theorem before an application.

An exact coefficient-level deconvolution pinpoints the source loss. Let

    mu_y(n) = mu(n)n^(-iy),
    ell_y(n) = log(n)n^(-iy),
    g_y = 1 * ell_y.

Then

    f_y = mu_y * g_y,
    Dirichlet(g_y)(s) = -zeta(s) zeta'(s+iy),
    Dirichlet(mu_y)(s) = 1/zeta(s+iy).

The identity follows from Lambda = mu * log with all proper powers included. At rho=beta+iy, beta real in (1/2,1), the row f_y has the local residue -m_rho zeta(beta), which is nonzero because real zeta(beta) does not vanish there. The proxy g_y is regular at s=beta. Thus the Mobius inverse is precisely what restores the missing source. A convolution estimate for the proxy does not pay this inverse. In shifted sums the inverse also changes dilations and congruence cutoffs, so no norm-free transfer is automatic.

A complex ORDER parameter would be a different theorem. The coefficients of zeta(s)zeta(s+alpha)^z can formally generate f_y by -partial_alpha partial_z at z=0, alpha=iy. This is not differentiation in Cowan's shift parameter at fixed order one. A locally uniform source-radius estimate for noninteger z would have to control the branch at the actual zero; such a premise cannot be imported as ordinary additive-divisor input. Root is formalizing the finite-log-jet source blindness; no duplicate Lean module is written here.

Verdict: freeze the naive finite-parameter-derivative import. Actual fixed-shift Mangoldt correlation, inverse stability with literal masks, and nonlinear source response remain open. This does not rule out every spectral estimate or demand the full Hardy–Littlewood conjecture.

## 2. Binomial UNIT parts plus Kummer carries: a genuinely additional finite gate

Primary source: Guy Barat and Peter J. Grabner, *Spatial equidistribution of binomial coefficients modulo prime powers*, Uniform Distribution Theory 11 (2016), 151–161. Author manuscript:
https://www.math.tugraz.at/~grabner/Publications/Binomial-spatial.pdf
Published DOI: https://doi.org/10.1515/udt-2016-0017

Theorems 1–2 keep the prime p and modulus exponent s fixed, and let digit length m tend to infinity. The first is joint spatial equidistribution of the p-free binomial part modulo p^s over 0<=k<=n<p^m. The second conditions on a FIXED valuation j and uses the p-adic Sierpinski measure for the spatial limit. Theorem 3 retains unit parts through Granville's higher-power Lucas formula. The proof joins borrow/carry states, finite p-free factorial ratios and additive spatial phases in a marked finite transition matrix. The stated theorems are limits; they do not supply a uniform p-to-infinity error or a growing-valuation estimate. No such extension is justified by the fixed matrix contraction.

A practical finite identity to investigate is therefore

    unit_p(choose(n,k)) = choose(n,k) / p^(v_p(choose(n,k))),
    code(n,k,p) = chi_p(unit_p(choose(n,k)))
                 * exp(2*pi*i*(xi*k+eta*n)/X),

with the Kummer carry count retained, rather than valuations or GCD alone. The p-free unit contains information discarded by the existing valuation-only corridor. That information is genuinely about ordinary integer addition/product, not a free denominator weight.

However the literature does NOT yet pass the campaign source gate. Its spatial triangle sums contain no Lambda(n) weight and no actual-height prime-index Mellin response. Inserting Lambda into the label row destroys the digit-product calculation unless the literal weighted transfer is independently proved. Summing over a growing family of primes requires uniformity absent from the theorem. Coupling unit parts at two distinct primes on the SAME binomial label also requires a new compatibility theorem; a tensor product at one fixed digit base is not that theorem.

A single fixed-p observation joined against arbitrary outer prime weights remains a one-variable code test. This is a scope statement, not a proof that the resulting nonlinear coded prime sequence is source-blind. Its actual source must be computed before a norm or PSD estimate. Multiple-prime unit compatibility is the potentially new retained information; no nonzero zero response or signed saving is presently supplied.

Verdict: source/compatibility gate worth a finite prototype. Do not formalize the full automaton or claim a new arithmetic saving before a nonzero actual-zero response is proved. The old GCD/carry and Gaussian Schur audits do not automatically exhaust this UNIT-part interaction.

## 3. Digital carry + Fourier prime estimates: genuine arithmetic, but a source-blind channel

Primary source: Christian Mauduit and Joel Rivat, *Prime numbers along Rudin–Shapiro sequences*, JEMS 17 (2015), 2595–2642; Definitions 1–2 and Theorem 1:
https://ems.press/content/serial-article-files/32075?nt=1

For a fixed integer base q>=2 and unit-valued f satisfying their carry property and uniform Fourier property with c>=10, Theorem 1 bounds

    sum_(n<=x) Lambda(n) f(n)e(theta*n)
      << c1(q) (log x)^c2(q) x
          * q^(-gamma(2 floor(log x/(80 log q)))/20).

If gamma(lambda) is bounded below by a positive linear function, this is a fixed power saving. The paper verifies hypotheses for Rudin–Shapiro-type examples. These are special literal-prime estimates, not generic PNT envelopes; a new binomial unit code is NOT granted the carry/Fourier hypotheses. The fixed-height n^(-iy) twist can be retained by ordinary partial summation, at fixed-y constant cost.

The paper-level source audit is especially important here. Its Fourier condition includes kappa=0 and t=0. In a linear-gap case this makes the unweighted partial sums C(X)=sum_(n<=X)f(n) power-small. If |C(X)|<=C X^(1-epsilon), exact Abel summation gives

    sum_(n<=X) f(n)n^(beta-1)
      = C(X)X^(beta-1)
        - (beta-1) integral_1^X C(t)t^(beta-2)dt.

This is O(X^(beta-epsilon)), O(log X) or O(1), according to the exponent, and in every case is o(X^beta) for beta>0. The matched smooth component x^(beta+iy), after the same height twist, therefore has ZERO source-scale response in that centered/nonprincipal channel. The prime bound is real but cannot exclude a zero it does not see. A nonzero-mean component leaves the uncoded prime moment as the surviving source; transferring the centered estimate to that component is exactly the missing input.

Verdict: do not spend a large formalization budget merely importing digital prime orthogonality. First find a unit/carry code that both satisfies the arithmetic theorem's hypotheses AND has a proved nonzero actual-zero response. The model calculation above is a scoped obstruction, not a general assertion about all growing, nonseparable or source-sensitive digital architectures.

## Recommended next action and scope

1. Prove the finite shifted-divisor/log-jet applicability obstruction and retain it as a reusable no-go; root owns this formalization.
2. Preserve binomial p-free UNIT parts as the one genuinely additional finite datum identified by this search. Start with an exact same-label two-prime/unit constraint, then do its actual source test. Do not infer that source from a scalar log-derivative residue.
3. Use Mauduit–Rivat only after proving the needed literal carry/Fourier hypotheses and checking that their very Fourier cancellation does not remove the desired zero mode.

No source-sensitive independent inequality, RH endpoint transfer, exhaustive Tier-1-family closure or new zero-free claim follows from this note. The row-series distinctions and exact inverse-source location are the concrete result of this literature pass.
