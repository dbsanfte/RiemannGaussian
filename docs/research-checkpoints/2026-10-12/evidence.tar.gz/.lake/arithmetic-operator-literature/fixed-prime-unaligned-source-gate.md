# Fixed actual prime / growing unaligned cofactor: source preflight

2026-10-08. Read-only paper-level note, not a new Lean proof. Exact native definitions inspected: `ArithmeticOperatorCrossUnitCancellation.atom`, `pairTrace`, and `ArithmeticOperatorJointConstraintAudit.codedTrace`.

## The actual normalization matters

For fixed actual prime p and growing distinct actual prime q, the existing row is

    D=p*q, n=D-1, 0<=k<D,
    codedTrace = (1/D) sum_k lambda^k
       chi_p(C(n,k) mod p) eta_q(C(n,k) mod q), |lambda|<=1.

These are RAW residue characters. They are NOT characters of the p-free binomial unit part: raw characters vanish at p-divisible coefficients. `LucasUnitAudit.unitRow` is entirely unit-valued only on its special aligned rows p^m-1. The new common unaligned row has higher carries and many zero residues.

Define U_p(n)=#{0<=k<=n : p does not divide C(n,k)}. Iterated Lucas gives

    U_p(n)=product_(base-p digits n_i) (n_i+1).

Since n=p(q-1)+(p-1), the EXACT native shift gives

    U_p(p*q-1)=p*U_p(q-1),
    |codedTrace| <= U_p(q-1)/q.

For D=p^r*q with fixed positive r, the r low digits are all p-1, so the same normalized bound holds. It is independent of eta_q, lambda, exterior phase and any character cancellation.

Full blocks satisfy

    sum_(0<=n<p^m) U_p(n) = [p(p+1)/2]^m.

Writing alpha_p=log_p((p+1)/2), grouping q-1 in p-adic size blocks therefore gives

    sum_(q<=X, q actual prime) log(q) |codedTrace|
      <<_p X^alpha_p log X.

This uses the elementary log(q) upper bound and exact digit count, not PNT or a prime-correlation conjecture. For p=3, alpha_p=log_3(2)~0.63093, and the rational beta>2/3 source-small corollary follows from 2^3<3^2. For any fixed p, alpha_p<1; alpha_p tends to 1 as p grows. Thus there is no uniform all-p saving furnished by this argument.

Conditional on formalizing this counting estimate, the actual prime-index Dirichlet series of the normalized RAW trace converges absolutely on Re(s)>alpha_p. It consequently has no pole at an actual beta in that region. This is a source-gate rejection of this normalization, not a zero-free theorem about zeta. It does not close beta<=alpha_p, growing p, amplitude renormalization, incomplete row masks or p-free unit extraction.

## What the growing q quadratic leg contributes

For q>p and k=q*h+b with 0<=h<p, 0<=b<q, the q-Lucas factor is

    eta_q(C(p*q-1,k)) = eta_q(-1)^b eta_q(C(p-1,h)).

The finite list B_h=C(p-1,h) is independent of q. For the literal quadratic character, the values (B_h/q) reduce by quadratic reciprocity to a fixed finite-modulus profile in q, outside the explicit prime heads dividing B_h. This q-column part is therefore not a new growing arithmetic source by itself.

The remaining exact expression is

    (1/(p*q)) sum_(0<=h<p) eta_q(B_h) eta_q(-1)^(-h)
       sum_(q*h<=k<q*(h+1))
          (lambda*eta_q(-1))^k chi_p(C(p*q-1,k)).

The p-column upper digits of q-1, and the moving interval endpoints q*h, remain. They cannot be replaced by a fixed residue period. This distinguishes the surviving datum from the already-audited fixed-cofactor mod-eight code. The fixed-character L-series argument applies only to the finite q-coefficient profiles; it supplies no actual residue theorem for these correlated moving p-digit traces.

## P-free units are a different candidate

Define genuinely

    unit_p(B)=B/p^(v_p(B)),
    chi_p(unit_p(C(n,k)) mod p^s),

and retain v_p(C(n,k)) separately. Then there are no raw-residue zeros, and the preceding support estimate does not apply. Granville's higher-power Lucas identity and Barat–Grabner's marked finite automaton compute the unit/carry code exactly at each fixed p,s. The state set can be fixed while digit depth grows; this does NOT make the code fixed-periodic in q. Retaining the unbounded carry count requires a marked counter/register or generating variable as well.

Primary source: Barat–Grabner, Theorems 1–3 and finite marked transition matrices:
https://www.math.tugraz.at/~grabner/Publications/Binomial-spatial.pdf
The fixed-p,s spatial limits over 0<=k<=n<p^m are NOT Lambda-weighted prime-index continuations. No theorem in the inspected source supplies the residue of

    sum_(q actual prime) log(q) q^(-s) c_p(q)

for the growing, unaligned, complete-row p-free-unit/carry trace c_p(q), nor a uniform p-to-cutoff rate. A scalar primitive p-character mean would retain only that mean times the old prime series; a nonprincipal fixed residue profile additionally needs common L-zero information. A genuinely growing code needs its own source theorem, not that fixed-periodic character argument.

Mauduit–Rivat's Theorem 1 is a possible estimate framework ONLY after its precise carry/Fourier hypotheses are proved for the literal code:
https://ems.press/content/serial-article-files/32075?nt=1
It gives digital-prime orthogonality, but its nonprincipal Fourier cancellation also annihilates the smooth matched power source. Its theorem does not grant a prime-index actual-zero residue to an arbitrary automatic or p-regular binomial trace. In particular the normalized average of a two-variable automatic array need not itself be a finite-alphabet automatic sequence.

## Exact remaining gate

Choose one literal normalized p-free-unit/carry code c_p(q), specify all prime heads, row endpoints and phase, and prove continuation plus a NONZERO principal part at the actual matched zero after density cancellation. The desired part must not be merely a principal-character mean times the unaltered prime series. If an automaton estimate is then proposed, prove its needed carry/Fourier property and ensure the same cancellation does not erase that principal part. No such actual source theorem was found in the inspected primary material. This leaves the regime open; it does not justify a blanket no-go or a new arithmetic saving.
