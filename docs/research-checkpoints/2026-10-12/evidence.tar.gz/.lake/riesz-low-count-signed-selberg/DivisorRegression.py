import json, math, sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
sys.path.insert(0, str(Path('scripts').resolve()))
import probe_riesz_signed_selberg_coupling as probe

rows=[]
for N in [6,7,8]:
    data=probe.add_selberg(probe.coupling.low_count_data(N),True)
    assert data['originalHeadMass']==0. and data['fullCorrectionMass']==0.
    physical,L,T=data['physical'],data['L'],data['T']
    spf,_=probe.coupling.completion.base.arithmetic(physical)
    mu=np.zeros(physical+1,dtype=np.int64)
    mu[1]=1
    for n in range(2,physical+1):
        p=int(spf[n]); quotient=n//p
        mu[n]=0 if quotient%p==0 else -mu[quotient]
    live=np.flatnonzero((data['prime']+data['pair'])!=0.)
    chosen=live[np.unique(np.linspace(0,len(live)-1,256,dtype=np.int64))]
    scale=np.exp((N+1)*math.log(data['u'])-1.5*T+N*np.log(T)-math.lgamma(N+1))
    worst=0.
    for ix in chosen:
        n=round(math.exp(float(T[ix])))
        response=math.fsum(int(mu[d])*max(0.,L-math.log(d)) for d in range(1,physical+1) if n%d==0)
        direct=-float(T[ix])*response/L
        observed=(data['prime'][ix]+data['pair'][ix])/scale[ix]
        worst=max(worst,abs(direct-observed))
    assert worst<2e-12
    rows.append(dict(N=N,sampledLabels=len(chosen),actualPhysicalCutoff=physical,
        maxCoefficientDifference=worst,definition='full Mobius divisor sum through actual physical cutoff'))
report=dict(cases=rows,labels=sum(r['sampledLabels'] for r in rows),noNativeEstimate=True)
Path('.lake/riesz-low-count-signed-selberg/divisor-regression.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(rows))
