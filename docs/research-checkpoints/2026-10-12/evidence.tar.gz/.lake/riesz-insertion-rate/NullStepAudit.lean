import RiemannGaussian
import RiemannGaussian.ZetaRieszQuantitativeNullStep
import Mathlib.Tactic.Linter
import Lean.Util.CollectAxioms
 #lint+ in RiemannGaussian.ZetaRieszQuantitativeNullStep
open Lean Elab Command
set_option maxHeartbeats 0
run_cmd do
  let selected : Array Name := #[`RiemannGaussian.ZetaRieszQuantitativeNullStep]
  let env ← getEnv
  let mut rows : Array Json := #[]
  let mut total : Nat := 0
  for h : i in [0:env.header.moduleNames.size] do
    let name := env.header.moduleNames[i]
    unless selected.contains name do continue
    let mut declarations : Nat := 0
    let mut theorems : Nat := 0
    for ci in env.header.moduleData[i]!.constants do
      declarations := declarations + 1
      if ci.isAxiom then throwError "Project-defined axiom: {ci.name}"
      if ci.isTheorem then theorems := theorems + 1
      for ax in (← Lean.collectAxioms ci.name) do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "Unexpected axiom in {ci.name}: {ax}"
    unless theorems > 0 do throwError "No theorems in {name}"
    total := total + theorems
    rows := rows.push (Json.mkObj [("module", toJson name.toString), ("declarations", toJson declarations), ("theorems", toJson theorems)])
  unless rows.size == selected.size do throwError "Missing target module in audit environment"
  let report := Json.mkObj [("modules", Json.arr rows), ("theoremCountIncludingGeneratedHelpers", toJson total), ("onlyStandardAxioms", toJson true)]
  IO.FS.writeFile ".lake/riesz-insertion-rate/null-step-axioms.json" report.pretty
  logInfo m!"Checked {rows.size} modules and {total} theorems, including generated helpers; only standard axioms."
