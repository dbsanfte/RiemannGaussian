"""Exact integer regression; no zero-source or asymptotic conclusion."""
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PRIMES = (2, 3, 5, 7, 11)

def valuation(p, n):
    assert n > 0
    v = 0
    while n % p == 0:
        n //= p
        v += 1
    return v

def carry(a, b, d):
    return (a + b) // d - a // d - b // d

checks = {"alignedValuation": 0, "unalignedValuation": 0,
          "unalignedLayer": 0, "deflatedUpperValuation": 0,
          "completeUpperRowMass": 0, "interactionCubeSupport": 0}
witnesses = []
for p in PRIMES:
    for n in range(1, 49):
        a = valuation(p, n)
        power = p ** a
        m = n // power
        upper_mass = 0
        for k in range(n):
            upper = valuation(p, math.comb(n - 1, k))
            upper_mass += upper
            assert valuation(p, math.comb(p*n, p*k)) == valuation(p, math.comb(n, k))
            checks["alignedValuation"] += 1
            assert upper == valuation(p, math.comb(m - 1, k // power))
            checks["deflatedUpperValuation"] += 1
            if a * upper:
                assert p*p <= n and p**3 <= p*n
                checks["interactionCubeSupport"] += 1
                if len(witnesses) < 8:
                    witnesses.append({"p": p, "n": n, "k": k,
                                      "divisibilityOrder": a, "upperValuation": upper,
                                      "m": m, "upperOrder": k // power,
                                      "nativeEndpoint": p*n})
            for c in range(1, p):
                assert valuation(p, math.comb(p*n, p*k+c)) == 1 + a + upper
                checks["unalignedValuation"] += 1
                assert carry(p*(n-k)-c, p*k+c, p) == 1
                for r in range(1, 7):
                    d = p**r
                    assert carry(p*(n-k)-c, p*k+c, p*d) == (
                        carry(n-k-1, k, d) + int(n % d == 0))
                    checks["unalignedLayer"] += 1
        assert upper_mass == power * sum(
            valuation(p, math.comb(m-1, ell)) for ell in range(m))
        checks["completeUpperRowMass"] += 1

report = {"kind": "exact integer diagnostic; not Lean evidence or asymptotic certificate",
          "primes": list(PRIMES), "nRange": [1, 48], "layerRange": [1, 6],
          "checks": checks, "interactionWitnesses": witnesses,
          "sourceClaim": False, "independentArithmeticEstimate": False}
(ROOT / "probe-results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
