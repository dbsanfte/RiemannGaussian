# Unaligned Kummer dilation, divisor inverse and cofactor source gate

Status: a new finite native support leaf is strict-green; the nonlinear
collective actual-zero source gate remains open. This is not an RH estimate
or an exhaustion of Kummer/Gamma/cutoff interactions.

## Exact native recurrence and full phases

Put `κ_d(a,b)=floor((a+b)/d)-floor(a/d)-floor(b/d)`. For a prime `p`,
`0<=k<n` and `0<c<p`, elementary integer division gives

```
κ_p(p(n-k)-c,pk+c) = 1,
κ_(p^(r+1))(p(n-k)-c,pk+c)
  = κ_(p^r)(n-k-1,k) + 1_(p^r|n),      r>=1.
```

Consequently the actual valuations obey

```
v_p binom(pn,pk)   = v_p binom(n,k),
v_p binom(pn,pk+c) = 1 + v_p(n) + v_p binom(n-1,k).
```

These general recurrence displays are paper-level exact identities checked
by the integer regression, not additional endpoints in the new Lean leaf.
The aligned p=2 case is already `choose_double_two_factorization`; the
unaligned recurrence follows from the native choose-order balance and the
complete low digit p-1, retaining every higher level.

For `χ_y(d)=exp(-iy log d)` and the full order-weighted row
`V_(p,y)(N,K)=log p * sum_(r>=1) χ_y(p^r) κ_(p^r)(N-K,K)`, the actual formula is

```
V_(p,y)(pn,pk+c)
 = log p * χ_y(p)
   + χ_y(p) * V_(p,y)(n-1,k)
   + χ_y(p) * log p * sum_(r>=1) χ_y(p^r) 1_(p^r|n).
```

Every sum is finite at its literal endpoint. In particular the final tower
is not silently replaced by `log n` at nonzero height. That replacement
requires the true cofactor phase, exactly as in `GammaTwistAudit`.

## New checked finite restriction

`scripts/ArithmeticOperatorKummerDilationSupport.lean` proves:

* if `p|n`, the upper row `binom(n-1,k)` has no first carry;
* if `n<p^2`, its entire p-adic valuation is zero;
* an active `v_p(n)*v_p binom(n-1,k)` requires `p^2<=n`;
* at the native total cutoff `pn<=X`, it requires `p^3<=X`;
* the same restriction holds separately for every positive divisibility
  order and carry order, with arbitrary correlated complex exterior weights
  retained and without taking norms.

The leaf passed `-DwarningAsError=true`, all 15 namespace linters and an
all-local-provenance standard-axiom audit: 18 declarations / 18 theorems,
including generated helpers. It pays neither the number of cofactor rows
nor any physical cutoff discrepancy. Summing many rows can remain source
sized despite their pointwise cube-root prime support.

## Sharper deflation identifies the surviving correlation

Write `n=p^a*m`, `p∤m`. Its first `a` low digits in `n-1` are all `p-1`.
Keeping the literal quotient and both endpoints gives the exact identity

```
v_p binom(n-1,k) = v_p binom(m-1, floor(k/p^a)),  0<=k<n.
```

The first `a` upper carry layers are zero. Each subsequent layer is the
corresponding layer of the cofactor row. Its full order phase is shifted
by `χ_y(p)^a`; no phase disappears.

For a complete unweighted k-row this repeats each cofactor entry exactly
`p^a` times. For arbitrary literal complex weight `W`, the exact block is

```
B_(p,a)(m,ell) = sum_(u=0..p^a-1) W(p,p^a*m,p^a*ell+u).
```

Thus the nonlinear divisibility/upper-carry aggregate becomes

```
sum_(p,a>=1,m>=1; p∤m; p^(a+1)*m<=X)
  a * sum_(ell=0..m-1) B_(p,a)(m,ell) * v_p binom(m-1,ell),
```

with the actual Möbius sign, cofactor code, physical mask and phase all
inside `W`. The prime-power-order version has the same block with the
explicit order shift. This exact reindexing is a paper-level audit, not a
new compiled source or asymptotic theorem. The 5,880 upper-binomial and 240
complete-row regressions support it; they do not prove its global source.

This is a weighted cofactor-successor carry, not independent two-prime
data. An incomplete k-mask prevents the repetition factor from becoming
a scalar: its exact residue is the nonconstant block weight `B`.

## Source/density and collapse gates

1. **Complete compatible inverse:** the checked `actual_phasedRow`,
   `actual_decoded`, `codedCutoff_eq_packet` and `retained_matched_source`
   already prove that complete actual Gamma data followed by compatible
   Möbius inversion restore the original actual von Mangoldt source. The
   inverse supplies no new signed estimate. The density-balanced cofactor
   code is already checked; its retained source is still the old source.
2. **Complete compatible forward row:** the genuine Euler response is a
   zeta derivative; its simple-pole zero response vanishes. Fixed finite
   products of completed Gamma rows are separately source-blind. These
   endpoints do not apply to a prime-dependent incomplete upper row by
   declaration.
3. **Prime-leg phase only:** the missing cofactor phase is the existing
   exact signed `twistCommutator`. No bound for it is inferred here.
4. **Nonlinear deflated block:** no checked theorem says a hypothetical
   ordinary zeta zero has nonzero response in the selected `B`-weighted
   cofactor-successor carry. It must pass that actual source gate before
   independent estimation. A diagnostic power substitution is insufficient.
5. **Arbitrary weights:** the complete forward/inverse identity applies to
   arbitrary arrays and so cannot itself supply the estimate. The present
   nonlinear native block is not granted that collapse without proof.
6. **Smooth/generalized controls:** previous free, smooth or unit-prime
   countermodels are not asserted to satisfy these complete actual Gamma
   identities or the literal integer binomial recurrence. Their absence of
   compatibility is not an estimate for the actual block either.

The next precise missing input, if this interaction is pursued, is an
actual-zero source theorem and a signed estimate for the above masked
weighted cofactor-successor carry, uniform over its admissible native
`p,a,m,ell` geometry. Cube-root prime support does not furnish that input.
No whole-family impossibility or RH/zero-free claim is made.

## Regression and evidence

`probe.py` uses exact Python integer binomials: 5,880 aligned valuation,
27,048 unaligned valuation, 162,288 unaligned layer, 5,880 deflated upper
valuation and 240 complete-row identities; all assertions passed.
There were 554 genuinely active nonlinear interactions, all inside the
cube support. For example `p=2,n=6,k=2` has both valuation orders 1 and
native endpoint 12. Nonlinear interactions are not identically zero.
`probe-results.json` is diagnostic, not Lean certification. `check.log`,
`axioms.json`, `source-pins.json` and `summary.json` pin the proof and scope.
