# Higher-sixth frequency restriction: native source preflight

This pass tests the literal subset `H=u*a^(6*ell)` with the SAME canonical sixth-power-free row `u`, for an integer `ell>=2`. It does not change the cube Mellin coordinate on the old family. It keeps exactly the frequency valuations `m` divisible by `ell`. The check is anchored to the native principal local rows; general nonunit `u` has additional `j=0..5` row numerators and is not silently identified with the principal row.

`scripts/QuasiRHHigherSixthFrequencyAudit.lean` is strict green: 31 local declarations / 25 theorems, including generated helpers, 15 namespace linters and standard axioms only. It proves the finite native row join, its literal `sourcePrincipalTerm` bridge, the unchanged zero-frequency target channel, finite geometric blocking, and the actual density/angular norm exponents. The restricted infinite rational formula below is a paper-level summation of those native coefficients, with exact rational regression checks; it is not a new Lean-checked Euler continuation or residue theorem.

## Native coefficient convention

Put `Q=Norm(P)`, `D=eta*Q^(-s)`, `W=Q^(-w)`, `V=Q^(-6z)`, `K=eta*(Q-1)*Q^(-s-w)`, and

`T=a^2*Q^(4-6s)`, `R=T*V`.

The native parameter `a` is `actualACube`, NOT `actualAPhase`. The checked identity `actualACube^2=actualAPhase` gives, on actual character rows,

`T=actualAPhase*Q^(4-6s)`.

No Gauss or ideal-character phase is replaced by a freely selected mode. The formulas are algebraic in the native phase parameters, and the explicit norm theorem inserts the actual phase and its proved `norm<=1` bound.

At fixed positive frequency order `m>=1`, the four genuine marked rows give

`(W-D)*T^m + [(1-Q^(-1))*T-K]*sum_{r<m} T^r`.

Adding the native index-zero row yields

`c_m=1+(W-D)*T^m+[(1-Q^(-1))*T-K]*sum_{r<m}T^r`.

At frequency zero, the index-zero outer-order sum contributes `1+W/(1-W)`, and the actual squarefree boundary contributes `-D` exactly. All higher outer orders and odd cube orders are already killed by the native local formulas; the remaining positive cube rows have the explicit finite frequency support used above. Thus

`c_0=1+W/(1-W)-D`.

In particular, the ordinary `-eta*Q^(-s)` target channel is retained. This does NOT prove that the restricted global series still has a nonzero `1/L_eta(s)` pole: local survival alone is insufficient. It only rules out treating this subset as a simple replacement of the entire target by `L_eta(ell*s)`.

## The actual restricted local coefficient series

Write `P_ell(T)=sum_{j<ell}T^j` and `C=(1-Q^(-1))*T-K`. The finite checked blocking identity is

`sum_{r<ell*n}T^r=P_ell(T)*sum_{j<n}(T^ell)^j`,

including `T=1`. Keeping `m=ell*n`, the associated local rational expression is

`F_ell=1/(1-V^ell)+W/(1-W)`

`       +[-D+W*R^ell+C*P_ell(T)*V^ell/(1-V^ell)]/(1-R^ell)`.

This follows by geometric summation wherever the relevant sums genuinely converge. It is not obtained by merely replacing `z` with `ell*z`: the native cube/Gauss rows couple `m` to their half-cube order, and the numerator contains the full finite block `P_ell(T)`. A new globally continued restricted series would need its own normal-convergence, finite-exclusion, nonvanishing and source-residue proofs.

## Density and angular factors move together

The pure index-zero density factor is now `1/(1-Q^(-6*ell*z))`, giving the candidate density axis `z=1/(6*ell)`. Its global pole can still be affected by the other joined factors; no restricted source residue is asserted.

At that SAME axis,

`R^ell=actualAPhase^ell * Q^(4*ell-6*ell*s-1)`.

The new leaf proves the density coordinate norm is exactly `Q^(-1)` and proves the actual angular ratio norm is at most `Q^(4*ell-6*ell*Re(s)-1)`. The corresponding angular Euler argument is

`6*ell*s+1-4*ell`.

Its standard absolute-Euler sufficient condition remains

`Re(6*ell*s+1-4*ell)>1 <=> Re(s)>2/3`.

Thus raising the frequency power does NOT give a safely rightward angular argument at its source-bearing density axis. The local geometric exponent test becomes

`Re(s)>(4*ell-1)/(6*ell)=2/3-1/(6*ell)`.

For `ell=2` this is `7/12`, whereas the old `ell=1` local exponent test was `1/2`. This is an exact exponent obstruction to the proposed uniform standard local/Euler-domain proof. It is NOT an actual divergence theorem from the `norm<=1` upper bound, NOT a claim that the thresholds are optimal, and NOT a claim that analytic continuation is impossible.

## Mask and annular budget impact

The existing calibration cancellation applies at each selected `H` simply by substituting `a^ell` into `sourceHighCoefficient_eq_bare`, provided ALL its original support and coprimality hypotheses hold. This preserves pointwise actual phases; it does not preserve the aggregate source residue or original nonzero source lower bound automatically.

The original squarefree `I`, cube `J`, outer `K`, canonical free row `u`, finite exclusions, calibration/unit mask, primary generator, annular prime masks and Gaussian height weights still remain. The new frequency condition is `L=G^ell`, hence `Norm(H)=Norm(u)*Norm(G)^(6*ell)`. For fixed `u` a frequency annulus therefore sees an ell-th-root scale, but the full native series also sums `u`. Unit-root frequencies remain in every canonical free row. Consequently a fixed-u root count cannot be promoted to a saving for the whole frequency family; a new count/source budget is required. The existing generic Eisenstein element count is NOT a checked higher-power restricted annular count.

The unchanged Mellin weight is

`X^(1/2-z)*Z^(s+z-1)*Y^(w-1)*exp((s+z-1)^2)`.

At `X=Z^(17/48)`, `Y=Z^(23/48)`, `w=1`, its bare exponent at the new candidate axis is

`Re(s)-79/96+31/(288*ell)`.

This is lower than its native value `Re(s)-103/144` by `31*(ell-1)/(288*ell)`. Each marked slot ALSO changes its literal `Q^(z-1)` weight. Including the existing marked-prime annular product whose exponents sum to `1/6`, the checked `source_scale_identity` specializes algebraically to

`Z^(Re(s)-11/16-13*(ell-1)/(96*ell))`.

That is a multiplier-scale calculation on the OLD geometry, not a newly proved restricted residue or signed budget. If the old arithmetic exponent `3/16` were inherited without improvement, the comparison would require

`Re(s)>7/8+13*(ell-1)/(96*ell)`,

which worsens (`181/192` for `ell=2`). No such inheritance or sharp restricted arithmetic size is asserted. Retaining the old normalization while silently moving the density pole is invalid.

## Verdict and exact reopening requirements

Freeze the frequency-thinning proposal at this gate. It does not remove the lower-strip angular-domain obstruction; density and angular factors co-move, and the physical source scale decreases. The actual ordinary target channel remains present locally, but no nonzero global restricted `1/L_eta` source is proved.

A useful reopening needs BOTH a new nonzero source theorem for this precise restricted frequency series (all canonical free rows/masks retained) and an independent arithmetic budget that beats the changed source scale. Merely raising the angular phase, keeping the old density pole, or borrowing the old high-frequency source lower bound does not supply either theorem. No new carrier, generalized-prime model, floating source inference, or RH/zero-free claim is made here.
