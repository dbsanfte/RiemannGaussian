#!/usr/bin/env python3
"""Exact rational bookkeeping only; no arithmetic/source-size experiment."""
from fractions import Fraction as F
from hashlib import sha256
import json
import re
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
VENDOR = ROOT / "vendor/openai-quasi-rh"
PREFIX = "vendor/openai-quasi-rh/OAI/NumberTheory/DirichletL/Detector/"
PINS = {
    "SourceLocal.lean": ["def sourcePrincipalTerm", "lemma sourcePrincipalTerm_pos", "lemma sourcePrincipalTerm_zero"],
    "LocalSeries.lean": ["lemma markedTerm_squarefree_boundary", "lemma markedTerm_even_bulk", "lemma markedTerm_even_kone", "lemma markedTerm_squarefree_bulk"],
    "LocalSummation.lean": ["lemma squarefree_boundary_hasSum", "theorem principalMarkedSeries_eq"],
    "ZeroIndex.lean": ["lemma zeroIndex_inner_pos", "lemma zeroIndexSeries_eq"],
    "EulerCoordinates.lean": ["def coordV", "def coordR", "def actualAPhase", "lemma actualAPhase_norm_le_one"],
    "PrincipalEulerIdentity.lean": ["lemma evenRatio_eq_coordR", "lemma actualACube_sq"],
    "SourceCoefficient.lean": ["def sourceHighCoefficient", "theorem sourceHighCoefficient_eq_bare"],
    "HighSeries.lean": ["def bareIdealHighCoefficient", "def bareIdealHighSummand"],
    "HighValuations.lean": ["def highIdeals", "theorem highValuationTerm_eq_prod"],
    "HighRowsPrime.lean": ["def sourceRowTerm", "theorem bareSourceCoefficient_row_weighted_prime"],
    "HighRowsEuler.lean": ["theorem bareIdealHighSeries_row_hasProd"],
    "SixthMask.lean": ["lemma calibration_sixth_frequency_mask", "lemma sixthFrequencyWeight"],
    "SixthArray.lean": ["lemma bareIdealHighCoefficient_sixth", "lemma rawHighCoefficient_sixth"],
    "SixthSeries.lean": ["theorem rawArithmeticSeries_eq_sixth_high"],
    "MellinScaling.lean": ["def sourceMellinWeight"],
    "FiniteProductBounds.lean": ["def localMultiplier"],
    "PrincipalRemainderBounds.lean": ["def scalePower", "lemma source_scale_identity"],
    "GramFrequencySummation.lean": ["theorem nonzero_frequency_count"],
}

def pin(path, needles):
    data = (ROOT / path).read_bytes()
    lines = data.decode().splitlines()
    declarations = []
    for needle in needles:
        found = [(i + 1, line.strip()) for i, line in enumerate(lines)
            if re.search(re.escape(needle)+r"\b", line)]
        if len(found) != 1:
            raise RuntimeError((path, needle, found))
        declarations.append({"line": found[0][0], "pin": found[0][1]})
    return {"path": path, "sha256": sha256(data).hexdigest(), "declarations": declarations}

pins = [pin(PREFIX + path, needles) for path, needles in PINS.items()]
pins.append(pin("scripts/QuasiRHHigherSixthFrequencyAudit.lean", [
    "theorem positiveMarkedFrequency_eq", "theorem positiveSourceFrequency_eq_native",
    "theorem actual_zero_frequency_target", "theorem geometric_block",
    "theorem native_density_ratio_norm", "theorem actual_angular_ratio_norm_le",
    "theorem restrictedAngular_euler_gate", "theorem restricted_local_ratio_gate"
]))

# These rational parameter values are scalar algebra regressions of the
# proved identity, NOT samples of actual ideal primes or actual Gauss phases.
coefficient_checks = []
for ell in range(1, 7):
    for n in range(1, 9):
        Q, eta, a, X, W = F(7), F(-1), F(1, 3), F(1, 7), F(1, 49)
        T = a*a*Q**4*X**6
        D, K = eta*X, eta*(Q-1)*X*W
        C = (1-1/Q)*T-K
        m = ell*n
        native = (W-D)*T**m + sum(C*T**r for r in range(m))
        P = sum(T**r for r in range(ell))
        section = (W-D)*(T**ell)**n + C*P*sum((T**ell)**r for r in range(n))
        assert native == section
        # This is the positive coefficient of the restricted rational factor.
        rational_coefficient = 1-D*T**m+W*T**m+C*P*sum(T**(ell*r) for r in range(n))
        assert rational_coefficient == 1+native
        coefficient_checks.append({"ell": ell, "selectedFrequency": m, "exactEqual": True})

rate_checks = []
for ell in range(1, 14):
    local_threshold = F(4*ell-1, 6*ell)
    global_euler_threshold = (1+4*ell-1)/F(6*ell)
    assert global_euler_threshold == F(2, 3)
    source_loss = F(13*(ell-1), 96*ell)
    old_geometry_floor = F(7, 8)+source_loss
    bare_exponent_constant = -F(79, 96)+F(31, 288*ell)
    marked_constant = bare_exponent_constant+F(1, 36*ell)
    assert marked_constant == -F(11,16)-source_loss
    rate_checks.append({
        "ell": ell, "localExponentThreshold": str(local_threshold),
        "standardAbsoluteEulerThreshold": str(global_euler_threshold),
        "oldGeometrySourceLoss": str(source_loss),
        "conditionalNoNewBudgetComparisonThreshold": str(old_geometry_floor),
        "bareMellinExponentConstant": str(bare_exponent_constant),
        "nativeMarkedGeometryExponentConstant": str(marked_constant)
    })

axioms = json.loads((OUT/"axioms.json").read_text())
assert axioms["onlyStandardAxioms"] and axioms["declarations"] == 31
strict = (OUT/"strict-build.log").read_text()
assert "error:" not in strict and "All linting checks passed!" in strict
result = {
    "scope": "native principal finite frequency coefficient and higher-sixth subsampling source/domain preflight only",
    "baseCommit": subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip(),
    "openaiRevision": json.loads((VENDOR/"upstream-pin.json").read_text())["commit"],
    "strictLeaf": {"path": "scripts/QuasiRHHigherSixthFrequencyAudit.lean", "declarations": 31,
        "theoremsIncludingHelpers": 25, "namespaceLinters": 15, "onlyStandardAxioms": True,
        "cache": ".lake/arithmetic-operator-higher-sixth-source/QuasiRHHigherSixthFrequencyAudit.olean"},
    "checks": {"coefficientExactRational": coefficient_checks, "exponentExactRational": rate_checks},
    "restrictions": [
        "Rational regressions are scalar algebra, not actual prime samples.",
        "The a parameter is actualACube; a^2 is actualAPhase.",
        "Restricted infinite local rational is paper-level summation, not a new Lean global Euler identity.",
        "m=0 ordinary channel survival does not prove a global reciprocal-L pole.",
        "2/3 is the unchanged standard absolute-Euler sufficient exponent test, not a sharp analytic impossibility.",
        "Fixed-u root thinning is not a full canonical-free-row annular budget.",
        "Native old-geometry scale at new axis is not a new restricted residue or arithmetic estimate."
    ],
    "verdict": "Freeze: actual density/angular co-movement supplies no safely-rightward lower-strip angular channel; a new restricted source residue and stronger arithmetic budget would both be required.",
    "pins": pins,
}
(OUT/"preflight.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({"sourceFilesPinned": len(pins), "exactCoefficientChecks": len(coefficient_checks),
    "exactRateChecks": len(rate_checks), "strictDeclarations": axioms["declarations"]}))
